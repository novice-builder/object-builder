(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();const Ii=[{id:"wood",label:"Wood",icon:"▥",color:12424551,category:"Build"},{id:"brick",label:"Brick",icon:"▦",color:13075044,category:"Build"},{id:"stone",label:"Stone",icon:"▧",color:10267045,category:"Build"},{id:"glass",label:"Glass",icon:"◈",color:10210256,category:"Build"},{id:"flowers",label:"Flowers",icon:"🌷",color:14523267,category:"Garden"},{id:"lantern",label:"Lantern",icon:"🏮",color:15318630,category:"Decorate"},{id:"bench",label:"Bench",icon:"🪑",color:11237968,category:"Decorate"}],bn=[],Tr=[],Ts=[15851437,15185051,12177332,14728124,14268559,11914194],Xa=[4488320,11365457,7042704,7108992];function Nr(n,e,t,i,r){e.forEach((s,a)=>{const o=t+i*16,c=i<0?0:Math.PI;if(r.includes(a))Tr.push({id:`${n}-lot-${a}`,x:s,z:o,w:17,d:16,angle:c,street:n,roadZ:t,subtle:!0});else{const l=n==="north"?[1,5].includes(a)&&i<0:[2,5].includes(a)&&i>0;bn.push({id:`${n}-${i<0?"n":"s"}-${a}`,name:`${n==="north"?"Linden":"Willow"} ${l?"family home":"cottage"} ${a+1}`,x:s,z:o,w:l?12:8+a%3,d:l?12:8+a%2*2,angle:c,wall:Ts[(a+(i+1)*2)%Ts.length],roof:Xa[(a+(i+1))%4],style:l?"gable":["hip","gable","shed"][a%3],storeys:l?2:1,rooms:l||a%3===0,designed:!0,garden:0,garage:a%4===0,street:n})}})}Nr("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,-1,[2,6]);Nr("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,1,[1,5,8]);Nr("south",[-90,-66,-42,-18,6,30,54,78],128,-1,[0,3,6]);Nr("south",[-90,-66,-42,-18,6,30,54,78],128,1,[1,4]);bn.push({id:"linden-library",name:"Linden library",x:60,z:-195,w:12,d:12,angle:Math.PI,route:"trail",wall:15851437,roof:4488320,style:"hip",shop:!0,sign:"LIBRARY",rooms:!0,designed:!0},{id:"willow-workshop",name:"Willow motor workshop",x:-109,z:110,w:12,d:12,angle:0,street:"south",wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,designed:!0},{id:"manor",name:"Magnolia manor",x:103,z:16,w:22,d:18,angle:-Math.PI/2,route:"trail",wall:15851437,roof:7042704,style:"hip",storeys:2,rooms:!0,designed:!0,porch:5},{id:"garden-cafe",name:"Garden cafe",x:112,z:-26,w:10,d:9,angle:Math.PI,wall:14728124,roof:11365457,style:"gable",shop:!0,sign:"GARDEN CAFE",designed:!0});const As=[[[-108,-143],[-64,-143],[-8,-143],[54,-143],[118,-143]],[[-112,128],[-66,128],[-6,128],[60,128],[119,128]],[[72,-28],[81,-16],[83,14],[83,39],[104,42]]];for(const[n,e]of[-28,-52,-76,-100,-122].entries())bn.push({id:`elm-${n}`,name:`Elm lane ${n===2?"family house":"cottage"}`,x:-121,z:e,w:n===2?12:9,d:n===2?12:9,angle:-Math.PI/2,wall:Ts[n%6],roof:Xa[n%4],style:n%2?"hip":"gable",storeys:n===2?2:1,rooms:!0,designed:!0,street:"elm"});Tr.push({id:"elm-lot",x:-150,z:-98,w:12,d:14,angle:Math.PI/2,street:"elm",roadX:-137,subtle:!0});As.push([[-137,-132],[-137,-90],[-137,-45],[-137,-9],[-146,10]]);const qc=[[[73,62],[80,66]],[[80,52],[84,52]],[[53,25],[53,36],[53,56],[65,62],[73,56],[80,52]],[[53,36],[61,34],[76,34],[80,41],[80,52]],[[65,62],[65,45]],[[197,98],[185,96],[181,82],[185,69],[197,65],[208,72],[210,86],[206,96],[197,98]],[[185,96],[197,84],[208,72]]],qa=[{id:"linden",name:"Linden street",icon:"⌂",x:-30,z:-143,color:"#b7a48a",signX:-113,signZ:-150},{id:"willow-street",name:"Willow street",icon:"⌂",x:-18,z:128,color:"#aebf90",signX:-118,signZ:136},{id:"manor",name:"Magnolia manor",icon:"♜",x:103,z:16,color:"#cfbc97",signX:88,signZ:29}],Yc=bn.findIndex(n=>n.id==="north-n-0");bn.splice(Yc,1);for(const n of["north-n-1","north-n-8"])bn.find(e=>e.id===n).z=-154;bn.find(n=>n.id==="south-s-0").x=-86;const nt=(n,e,t,i,r,s,a,o,c,l,d={})=>({id:n,name:e,x:t,z:i,w:r,d:s,angle:a,style:o,wall:c,roof:l,...d}),Xn=0,Rn=Math.PI,ji=Math.PI/2,Cn=-Math.PI/2,Zc=[nt("juniper","Juniper veranda",-160,-45,12,10,Cn,"hip",12177332,11365457,{porch:4.4,carport:!0,garden:2,bay:!0}),nt("birch","Birch twin cottage",-212,-40,8,11,ji,"gable",15851437,7042704,{wing:!0,garden:3,chimney:!0}),nt("copper","Copper longhouse",-161,-80,7,12,Cn,"shed",14268559,4488320,{porch:4,garden:1,bay:!0}),nt("lavender","Lavender bungalow",-215,5,10,8,ji,"hip",14728124,7108992,{garage:!0,garden:2}),nt("acacia","Acacia courtyard",-213,47,14,9,ji,"gable",15185051,4488320,{wing:!0,porch:4.6,garden:3}),nt("riverside","Riverside home",-151,45,9,9,Cn,"hip",11914194,11365457,{carport:!0,garden:1,bay:!0}),nt("north-house","North garden house",-42,-214,12,10,Xn,"hip",14728124,7042704,{wing:!0,garden:3}),nt("north-bakery","Sunbeam bakery",-18,-214,9,8,Xn,"gable",15851437,11365457,{shop:!0,sign:"SUNBEAM",approach:{x:-18,z:-202},chimney:!0}),nt("north-hall","North village hall",7,-214,14,10,Xn,"gable",12177332,4488320,{shop:!0,sign:"VILLAGE HALL",approach:{x:7,z:-202},porch:4.2}),nt("north-clock","Clockmaker house",35,-214,8,8,Xn,"hip",14268559,7108992,{tower:!0,porch:3.2,garden:2}),nt("weavers","Weavers studio",202,-132,9,10,Cn,"shed",14728124,7042704,{shop:!0,sign:"WEAVERS",bay:!0}),nt("clay-yard","Clay courtyard",206,-103,12,8,Cn,"hip",15185051,4488320,{shop:!0,sign:"CLAY YARD",wing:!0}),nt("makers","Makers long workshop",205,-75,8,14,Cn,"gable",14268559,11365457,{shop:!0,sign:"MAKERS",carport:!0,chimney:!0}),nt("greenhouse","Garden potting house",207,-45,7,7,Cn,"gable",12177332,4488320,{porch:3.4,garden:3,bay:!0}),nt("lake-house","Lakeview veranda",213,4,10,9,Xn,"shed",11914194,7108992,{route:"trail",porch:4.6,garden:2,bay:!0}),nt("east-house","Eastern carport house",212,109,14,8,Rn,"hip",15851437,11365457,{route:"trail",carport:!0,garden:1}),nt("beacon-house","Beacon lodge",214,145,8,9,Rn,"gable",14728124,4488320,{route:"trail",tower:!0,garden:2}),nt("farm-home","Farmhouse porch",43,215,12,10,Rn,"gable",15851437,7042704,{route:"trail",porch:5,chimney:!0,garden:1}),nt("farm-shop","Farmyard store",12,216,10,8,Rn,"hip",12177332,11365457,{route:"trail",shop:!0,sign:"FARM STORE",approach:{x:12,z:204},carport:!0}),nt("red-barn","Red barn workshop",-18,214,14,12,Rn,"gambrel",13075044,7108992,{route:"trail",shop:!0,sign:"RED BARN",approach:{x:-18,z:202},chimney:!0}),nt("farm-cottage","Farm garden cottage",-47,213,8,9,Rn,"hip",15185051,4488320,{route:"trail",wing:!0,garden:3}),nt("orchard-barn","Orchard long barn",-96,211,14,12,Rn,"gambrel",14268559,11365457,{route:"trail",carport:!0,garden:1}),nt("pond-cabin","Reed pond cabin",-201,192,7,8,ji,"gable",12177332,7042704,{route:"trail",porch:3.5,garden:2}),nt("trail-hut","North trail cabin",152,-218,6,7,Xn,"shed",14728124,4488320,{route:"trail",porch:3,garden:2})],jc=[[[-124,6],[-146,10],[-169,1],[-186,-22],[-193,-61],[-177,-100],[-147,-127],[-112,-151],[-68,-171],[-15,-183],[40,-182],[89,-166],[133,-136],[160,-100],[175,-55],[174,-12],[176,20],[157,57],[139,92],[122,129],[91,162],[50,184],[3,190],[-47,181],[-91,157],[-124,126],[-156,91],[-181,55],[-196,18],[-174,7],[-146,10]],[[115,-53],[139,-56],[175,-55]]],Kc=[[[-65,-103],[-108,-120],[-123,-150],[-128,-182],[-127,-209],[-99,-225],[-60,-221],[-66,-202],[-42,-202],[-8,-197],[-8,-182]],[[89,-166],[117,-185],[152,-198],[184,-210],[215,-208],[234,-183],[222,-151],[202,-147],[160,-100]],[[108,62],[142,48],[166,45],[184,44],[193,24],[220,20],[239,45],[236,70],[216,95],[185,116],[144,148],[122,129]],[[50,184],[33,202],[-10,198],[-57,193],[-95,193],[-131,174],[-157,173],[-184,174],[-213,181],[-216,205],[-193,222],[-162,224],[-137,212],[-131,192],[-131,174],[-139,147],[-124,126]],[[91,162],[128,181],[151,209],[181,226],[217,212],[232,174],[234,148],[222,127],[185,116]],[[-193,-61],[-218,-88],[-214,-123],[-192,-145],[-157,-151],[-147,-127]],[[-8,-197],[17,-197],[43,-202],[72,-215],[111,-229],[152,-198]],[[-184,174],[-190,183],[-192,194],[-190,206],[-193,222]],[[216,95],[208,99],[197,98],[197,84]]],$c=[{x:-161,z:-218,w:36,d:28,subtle:!0},{x:214,z:-232,w:36,d:20,subtle:!0},{x:-234,z:-111,w:22,d:24,subtle:!0},{x:151,z:234,w:36,d:20,subtle:!0}],Er=[{x:-167,z:197,rx:23,rz:14},{x:215,z:45,rx:18,rz:12}],Ya=[{id:"north-square",name:"Sunbeam village",icon:"☀",x:-8,z:-197,color:"#d7ae71"},{id:"artists",name:"Makers village",icon:"▤",x:190,z:-102,color:"#bd9583"},{id:"east-park",name:"Lake park",icon:"⚑",x:197,z:84,color:"#7aa276"},{id:"farm",name:"Red barn farm",icon:"♧",x:-18,z:197,color:"#bd7967"},{id:"reed-pond",name:"Reed pond",icon:"≈",x:-167,z:197,color:"#72aebc",signX:-141,signZ:216},{id:"beacon",name:"Beacon walk",icon:"♜",x:214,z:145,color:"#8eaaa1",signX:225,signZ:143},{id:"north-meadow",name:"North meadow",icon:"▦",x:-161,z:-218,color:"#a9b774",signX:-182,signZ:-218},{id:"east-meadow",name:"East meadow",icon:"▦",x:151,z:234,color:"#a9b774",signX:173,signZ:234}],et=Object.freeze({id:"little-block-world-06",saveVersion:4,halfSize:250,buildHeight:24,maxBlocks:12e3,maxSaveBytes:4e6,chunkSize:24,fogNear:75,fogFar:155,cameraFar:190,saveKey:"blockworld.neighborhood.06",preferencesKey:"blockworld.neighborhood.controls.v6"}),Yr=Object.freeze({normal:3.4,quick:5.1,fast:6.8}),Za=n=>typeof Yr[n]=="number"?Yr[n]:Yr.normal,Jc=[{id:"home",name:"Home",icon:"⌂",x:-14.4,z:-1.2,color:"#cc9168"},{id:"village",name:"Village square",icon:"▥",x:49,z:-26,color:"#d9ac68"},{id:"park",name:"Play park",icon:"⚑",x:65,z:45,color:"#7aa276"},{id:"pond",name:"Willow pond",icon:"≈",x:18,z:-101,color:"#72aebc"},{id:"woods",name:"Woodland walk",icon:"♠",x:-65,z:-103,color:"#528969"},{id:"meadow",name:"Building meadow",icon:"▦",x:-59,z:61,color:"#a9b774"},{id:"orchard",name:"Orchard picnic",icon:"●",x:81,z:94,color:"#b89c78"},...Ya,...qa];class Oi{constructor(e=12){this.size=e,this.cells=new Map,this.global=new Set,this.entries=new Map}keys(e){const t=[];for(let i=Math.floor(e.minX/this.size);i<=Math.floor(e.maxX/this.size);i++)for(let r=Math.floor(e.minZ/this.size);r<=Math.floor(e.maxZ/this.size);r++)t.push(`${i},${r}`);return t}add(e){const t=this.keys(e);if(this.entries.set(e,t),t.length>64){this.global.add(e);return}for(const i of t)this.cells.has(i)||this.cells.set(i,new Set),this.cells.get(i).add(e)}remove(e){for(const t of this.entries.get(e)||[]){const i=this.cells.get(t);i==null||i.delete(e),i!=null&&i.size||this.cells.delete(t)}this.global.delete(e),this.entries.delete(e)}query(e){const t=new Set(this.global);for(const i of this.keys(e))for(const r of this.cells.get(i)||[])t.add(r);return[...t].filter(i=>i.minX<=e.maxX&&i.maxX>=e.minX&&i.minZ<=e.maxZ&&i.maxZ>=e.minZ&&i.minY<=e.maxY&&i.maxY>=e.minY)}}const Ki=(n,e=2)=>({minX:n.x-e,maxX:n.x+e,minZ:n.z-e,maxZ:n.z+e,minY:-1,maxY:(n.y||0)+30}),Bt=et.halfSize,ja=et.maxBlocks,_n=.28,Ka=1.65,Rs=["wood","brick","stone","glass"],zi=["flowers","lantern","bench"],Cs=[...Rs,...zi],Ni=(n,e,t)=>Math.max(e,Math.min(t,n)),Ar=n=>`${n.x},${n.y},${n.z}`,ct=n=>{const e=(n.rotation||0)*Math.PI/180,t=Math.abs(Math.cos(e)),i=Math.abs(Math.sin(e)),r=n.type==="bench"?Math.max(0,(.94*t+.64*i-1)/2):0,s=n.type==="bench"?Math.max(0,(.94*i+.64*t-1)/2):0;return{minX:n.x-r,minY:n.y,minZ:n.z-s,maxX:n.x+1+r,maxY:n.y+1,maxZ:n.z+1+s}},yi=n=>({minX:n.x-_n,minY:n.y+.001,minZ:n.z-_n,maxX:n.x+_n,maxY:n.y+Ka,maxZ:n.z+_n});function lo(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function ui(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:Ni((i.length/2-o)/i.length,0,1)*i.rise}function vt(n,e){if(e.ramp){const a=ui(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return vt(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=lo(n),i=lo(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const c=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),l=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=c+l-1e-5)return!1}return!0}const Bn=(n,e)=>e.some(t=>vt(yi(n),t)),$a={x:-14.4,y:0,z:-1.2,yaw:0,pitch:0};function Qc(){return{version:et.saveVersion,world:et.id,blocks:[],inventory:{flowers:0,lantern:0,bench:0},selected:"hand",player:{...$a},doors:{},doorSwings:{}}}function ho(n,e){let t=0;for(const i of e){const r=ui(i,n.x,n.z),s=r===null?i:{...i,maxY:r};i.ramp&&r===null||s.maxY<=n.y+.02&&s.maxY>t&&n.x+_n>s.minX+.01&&n.x-_n<s.maxX-.01&&n.z+_n>s.minZ+.01&&n.z-_n<s.maxZ-.01&&(t=s.maxY)}return t}function uo(n,e){return n.y<=.35?!0:[-.12,.12].every(t=>[-.12,.12].every(i=>e.some(r=>{const s=ui(r,n.x+t,n.z+i);if(r.ramp)return s!==null&&Math.abs(s-n.y)<.3;if(r.maxY>n.y+.025||r.maxY<n.y-.3)return!1;const a={minX:n.x+t-.001,maxX:n.x+t+.001,minZ:n.z+i-.001,maxZ:n.z+i+.001,minY:r.maxY-.003,maxY:r.maxY+.003};return vt(a,r)})))}function fo(n,e){let t=1/0;for(const i of e){if(i.maxY>n.y+.025||i.maxY<n.y-.3)continue;const r=Math.max(i.minX+.12-n.x,0,n.x-(i.maxX-.12)),s=Math.max(i.minZ+.12-n.z,0,n.z-(i.maxZ-.12));t=Math.min(t,r*r+s*s)}return t}function el(n,e,t,i){const r=Math.ceil(Math.min(t,.1)/.012),s=Math.min(t,.1)/r,a=Za(e.walkSpeed);let o=Ni(e.forward||0,-1,1),c=Ni(e.right||0,-1,1),l=Math.max(1,Math.hypot(o,c));const d=(-Math.sin(n.yaw)*o+Math.cos(n.yaw)*c)*a/l,h=(-Math.cos(n.yaw)*o-Math.sin(n.yaw)*c)*a/l;for(let u=0;u<r;u++){const m=ho(n,i);(n.vy||0)<=0&&n.y>=m-.002&&n.y-m<.035&&(n.y=m,n.vy=0,n.grounded=!0);for(const[p,f]of[["x",d],["z",h]]){const _=n[p];n[p]=Ni(_+f*s,-Bt+.4,Bt-.4);const x=n.y;if(n.grounded)for(const v of i){const R=ui(v,n.x,n.z),L=ui(v,p==="x"?_:n.x,p==="z"?_:n.z);R!==null&&R-n.y<=.09&&R-n.y>=-.12&&(L!==null||n.y<.1||Math.abs(n.y-v.maxY)<.1)&&(n.y=R)}if(Bn(n,i)&&(n[p]=_,n.y=x),e.edgeProtection&&n.grounded&&!e.allowDrop&&n.y>.35&&!uo(n,i)){const v={...n,[p]:_};(uo(v,i)||fo(n,i)>=fo(v,i)-1e-6)&&(n[p]=_)}}n.vy=(n.vy||0)-16*s;const M=n.y;if(n.y+=n.vy*s,n.y<=0)n.y=0,n.vy=0,n.grounded=!0;else if(Bn(n,i)){const p=i.filter(f=>vt(yi(n),f));n.vy<0?(n.y=Math.max(...p.map(f=>ui(f,n.x,n.z)??f.maxY)),n.grounded=!0):(n.y=Math.min(...p.map(f=>f.minY))-Ka-.002,n.grounded=!1),(n.y<0||Bn(n,i))&&(n.y=M),n.vy=0}else n.grounded=!1;const g=ho(n,i);n.vy<=0&&n.y>=g-.002&&n.y-g<.035&&(n.y=g,n.vy=0,n.grounded=!0)}}function tl(n,e,t,i,r=!0){if(!n||!Cs.includes(n.type)||![n.x,n.y,n.z].every(Number.isInteger))return"Choose a building piece";if(n.x<-Bt||n.x>=Bt||n.z<-Bt||n.z>=Bt||n.y<0||n.y>=et.buildHeight)return"Build inside the world, up to 24 blocks high";if(e.blocks.length>=ja)return"Your world is full. Remove a piece to make room";const s=ct(n);return t.some(a=>vt(s,a.ramp?{...a,ramp:null}:a))||e.blocks.some(a=>vt(s,ct(a)))?"Find a clear space":i&&vt(s,yi(i))?"Take a little step back":r&&i&&Math.hypot(n.x+.5-i.x,n.y+.5-i.y,n.z+.5-i.z)>6?"Move a little closer":n.y>0&&!e.blocks.some(a=>Math.abs(a.x-n.x)+Math.abs(a.y-n.y)+Math.abs(a.z-n.z)===1)?"Join this piece to another block":zi.includes(n.type)&&e.inventory[n.type]<=0?"Make this at your crafting table":""}function Ja(n,e=[]){var l,d,h;if(!n||![1,2,3,et.saveVersion].includes(n.version)||n.version===et.saveVersion&&n.world!==et.id||n.version===2&&n.world!=="little-block-world-04"||n.version===3&&n.world!=="little-block-world-05"||!Array.isArray(n.blocks)||n.blocks.length>ja)throw Error("This is not a supported BlockWorld save");const t=n.version===1,i=n.version===2;if(t&&n.blocks.length>800)throw Error("Older saves support up to 800 pieces");const r=Qc(),s=new Set,a=new Oi(4),o=new Oi;for(const u of e)o.add(u);for(const u of n.blocks){if(!u||!Cs.includes(u.type)||![u.x,u.y,u.z].every(Number.isInteger)||u.y<0||u.y>=et.buildHeight||u.x<-Bt||u.x>=Bt||u.z<-Bt||u.z>=Bt||t&&(Math.abs(u.x)>31||u.x===31||Math.abs(u.z)>31||u.z===31||u.y>9)||i&&(u.x<-125||u.x>=125||u.z<-125||u.z>=125)||s.has(Ar(u)))throw Error("The save contains an invalid piece");if(o.query(ct(u)).some(g=>vt(ct(u),g.ramp?{...g,ramp:null}:g)))throw Error("A saved piece overlaps the neighborhood");const m=ct(u);if(a.query(m).some(g=>vt(m,g)))throw Error("Saved pieces overlap");a.add(m),s.add(Ar(u));const M=u.rotation??0;if(!Number.isFinite(M)||Math.abs(M)>36e3)throw Error("The piece rotation is invalid");r.blocks.push({x:u.x,y:u.y,z:u.z,type:u.type,...zi.includes(u.type)?{rotation:(M%360+360)%360}:{}})}for(const u of zi){const m=((l=n.inventory)==null?void 0:l[u])??0;if(!Number.isInteger(m)||m<0||m>999)throw Error("The inventory is invalid");r.inventory[u]=m}const c=n.player;c&&["x","y","z","yaw","pitch"].every(u=>Number.isFinite(c[u]))&&Math.abs(c.x)<Bt&&Math.abs(c.z)<Bt&&c.y>=0&&c.y<=et.buildHeight+2&&(r.player={x:c.x,y:c.y,z:c.z,yaw:c.yaw%(Math.PI*2),pitch:Ni(c.pitch,-1.3,1.3)}),(n.selected==="hand"||Cs.includes(n.selected))&&(r.selected=n.selected);for(const u of Object.keys(n.doors||{}).filter(m=>/^[a-z][a-z0-9-]{0,39}$/.test(m)&&!["constructor","prototype"].includes(m)))r.doors[u]=((d=n.doors)==null?void 0:d[u])===!0,r.doorSwings[u]=((h=n.doorSwings)==null?void 0:h[u])===1?1:-1;return Bn(r.player,[...e,...r.blocks.map(ct)])&&(r.player={...$a}),r}/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Ws="160",nl=0,po=1,il=2,Qa=1,rl=2,on=3,cn=0,Pt=1,ht=2,Mn=0,di=1,mo=2,go=3,_o=4,sl=5,On=100,ol=101,al=102,xo=103,vo=104,cl=200,ll=201,hl=202,ul=203,Ls=204,Ps=205,dl=206,fl=207,pl=208,ml=209,gl=210,_l=211,xl=212,vl=213,Ml=214,yl=0,Sl=1,El=2,Rr=3,bl=4,wl=5,Tl=6,Al=7,Xs=0,Rl=1,Cl=2,yn=0,Ll=1,Pl=2,Dl=3,Ul=4,Il=5,Nl=6,ec=300,gi=301,_i=302,Ds=303,Us=304,Fr=306,Is=1e3,Yt=1001,Ns=1002,At=1003,Mo=1004,Zr=1005,kt=1006,Fl=1007,Bi=1008,Sn=1009,Ol=1010,zl=1011,qs=1012,tc=1013,xn=1014,vn=1015,ki=1016,nc=1017,ic=1018,kn=1020,Bl=1021,Zt=1023,kl=1024,Gl=1025,Gn=1026,xi=1027,Hl=1028,rc=1029,Vl=1030,sc=1031,oc=1033,jr=33776,Kr=33777,$r=33778,Jr=33779,yo=35840,So=35841,Eo=35842,bo=35843,ac=36196,wo=37492,To=37496,Ao=37808,Ro=37809,Co=37810,Lo=37811,Po=37812,Do=37813,Uo=37814,Io=37815,No=37816,Fo=37817,Oo=37818,zo=37819,Bo=37820,ko=37821,Qr=36492,Go=36494,Ho=36495,Wl=36283,Vo=36284,Wo=36285,Xo=36286,cc=3e3,Hn=3001,Xl=3200,ql=3201,lc=0,Yl=1,Ht="",lt="srgb",ln="srgb-linear",Ys="display-p3",Or="display-p3-linear",Cr="linear",tt="srgb",Lr="rec709",Pr="p3",qn=7680,qo=519,Zl=512,jl=513,Kl=514,hc=515,$l=516,Jl=517,Ql=518,eh=519,Yo=35044,Zo="300 es",Fs=1035,an=2e3,Dr=2001;class Si{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const r=this._listeners[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const St=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],es=Math.PI/180,Os=180/Math.PI;function Vi(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(St[n&255]+St[n>>8&255]+St[n>>16&255]+St[n>>24&255]+"-"+St[e&255]+St[e>>8&255]+"-"+St[e>>16&15|64]+St[e>>24&255]+"-"+St[t&63|128]+St[t>>8&255]+"-"+St[t>>16&255]+St[t>>24&255]+St[i&255]+St[i>>8&255]+St[i>>16&255]+St[i>>24&255]).toLowerCase()}function Lt(n,e,t){return Math.max(e,Math.min(t,n))}function th(n,e){return(n%e+e)%e}function ts(n,e,t){return(1-t)*n+t*e}function jo(n){return(n&n-1)===0&&n!==0}function zs(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function wi(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function Rt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}class qe{constructor(e=0,t=0){qe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Lt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*r+e.x,this.y=s*r+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class He{constructor(e,t,i,r,s,a,o,c,l){He.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,c,l)}set(e,t,i,r,s,a,o,c,l){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=c,d[6]=i,d[7]=a,d[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],d=i[4],h=i[7],u=i[2],m=i[5],M=i[8],g=r[0],p=r[3],f=r[6],_=r[1],x=r[4],v=r[7],R=r[2],L=r[5],C=r[8];return s[0]=a*g+o*_+c*R,s[3]=a*p+o*x+c*L,s[6]=a*f+o*v+c*C,s[1]=l*g+d*_+h*R,s[4]=l*p+d*x+h*L,s[7]=l*f+d*v+h*C,s[2]=u*g+m*_+M*R,s[5]=u*p+m*x+M*L,s[8]=u*f+m*v+M*C,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8];return t*a*d-t*o*l-i*s*d+i*o*c+r*s*l-r*a*c}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8],h=d*a-o*l,u=o*c-d*s,m=l*s-a*c,M=t*h+i*u+r*m;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const g=1/M;return e[0]=h*g,e[1]=(r*l-d*i)*g,e[2]=(o*i-r*a)*g,e[3]=u*g,e[4]=(d*t-r*c)*g,e[5]=(r*s-o*t)*g,e[6]=m*g,e[7]=(i*c-l*t)*g,e[8]=(a*t-i*s)*g,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,a,o){const c=Math.cos(s),l=Math.sin(s);return this.set(i*c,i*l,-i*(c*a+l*o)+a+e,-r*l,r*c,-r*(-l*a+c*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(ns.makeScale(e,t)),this}rotate(e){return this.premultiply(ns.makeRotation(-e)),this}translate(e,t){return this.premultiply(ns.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const ns=new He;function uc(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function Ur(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function nh(){const n=Ur("canvas");return n.style.display="block",n}const Ko={};function Fi(n){n in Ko||(Ko[n]=!0,console.warn(n))}const $o=new He().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Jo=new He().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),$i={[ln]:{transfer:Cr,primaries:Lr,toReference:n=>n,fromReference:n=>n},[lt]:{transfer:tt,primaries:Lr,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[Or]:{transfer:Cr,primaries:Pr,toReference:n=>n.applyMatrix3(Jo),fromReference:n=>n.applyMatrix3($o)},[Ys]:{transfer:tt,primaries:Pr,toReference:n=>n.convertSRGBToLinear().applyMatrix3(Jo),fromReference:n=>n.applyMatrix3($o).convertLinearToSRGB()}},ih=new Set([ln,Or]),je={enabled:!0,_workingColorSpace:ln,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!ih.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,e,t){if(this.enabled===!1||e===t||!e||!t)return n;const i=$i[e].toReference,r=$i[t].fromReference;return r(i(n))},fromWorkingColorSpace:function(n,e){return this.convert(n,this._workingColorSpace,e)},toWorkingColorSpace:function(n,e){return this.convert(n,e,this._workingColorSpace)},getPrimaries:function(n){return $i[n].primaries},getTransfer:function(n){return n===Ht?Cr:$i[n].transfer}};function fi(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function is(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let Yn;class dc{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Yn===void 0&&(Yn=Ur("canvas")),Yn.width=e.width,Yn.height=e.height;const i=Yn.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=Yn}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Ur("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=fi(s[a]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(fi(t[i]/255)*255):t[i]=fi(t[i]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let rh=0;class fc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:rh++}),this.uuid=Vi(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(rs(r[a].image)):s.push(rs(r[a]))}else s=rs(r);i.url=s}return t||(e.images[this.uuid]=i),i}}function rs(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?dc.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let sh=0;class Dt extends Si{constructor(e=Dt.DEFAULT_IMAGE,t=Dt.DEFAULT_MAPPING,i=Yt,r=Yt,s=kt,a=Bi,o=Zt,c=Sn,l=Dt.DEFAULT_ANISOTROPY,d=Ht){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:sh++}),this.uuid=Vi(),this.name="",this.source=new fc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new qe(0,0),this.repeat=new qe(1,1),this.center=new qe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new He,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof d=="string"?this.colorSpace=d:(Fi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=d===Hn?lt:Ht),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==ec)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Is:e.x=e.x-Math.floor(e.x);break;case Yt:e.x=e.x<0?0:1;break;case Ns:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Is:e.y=e.y-Math.floor(e.y);break;case Yt:e.y=e.y<0?0:1;break;case Ns:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return Fi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===lt?Hn:cc}set encoding(e){Fi("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===Hn?lt:Ht}}Dt.DEFAULT_IMAGE=null;Dt.DEFAULT_MAPPING=ec;Dt.DEFAULT_ANISOTROPY=1;class _t{constructor(e=0,t=0,i=0,r=1){_t.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*r+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s;const c=e.elements,l=c[0],d=c[4],h=c[8],u=c[1],m=c[5],M=c[9],g=c[2],p=c[6],f=c[10];if(Math.abs(d-u)<.01&&Math.abs(h-g)<.01&&Math.abs(M-p)<.01){if(Math.abs(d+u)<.1&&Math.abs(h+g)<.1&&Math.abs(M+p)<.1&&Math.abs(l+m+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const x=(l+1)/2,v=(m+1)/2,R=(f+1)/2,L=(d+u)/4,C=(h+g)/4,z=(M+p)/4;return x>v&&x>R?x<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(x),r=L/i,s=C/i):v>R?v<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(v),i=L/r,s=z/r):R<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(R),i=C/s,r=z/s),this.set(i,r,s,t),this}let _=Math.sqrt((p-M)*(p-M)+(h-g)*(h-g)+(u-d)*(u-d));return Math.abs(_)<.001&&(_=1),this.x=(p-M)/_,this.y=(h-g)/_,this.z=(u-d)/_,this.w=Math.acos((l+m+f-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class oh extends Si{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new _t(0,0,e,t),this.scissorTest=!1,this.viewport=new _t(0,0,e,t);const r={width:e,height:t,depth:1};i.encoding!==void 0&&(Fi("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===Hn?lt:Ht),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:kt,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Dt(r,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){(this.width!==e||this.height!==t||this.depth!==i)&&(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new fc(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Vn extends oh{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class pc extends Dt{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=At,this.minFilter=At,this.wrapR=Yt,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class ah extends Dt{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=At,this.minFilter=At,this.wrapR=Yt,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Wi{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,a,o){let c=i[r+0],l=i[r+1],d=i[r+2],h=i[r+3];const u=s[a+0],m=s[a+1],M=s[a+2],g=s[a+3];if(o===0){e[t+0]=c,e[t+1]=l,e[t+2]=d,e[t+3]=h;return}if(o===1){e[t+0]=u,e[t+1]=m,e[t+2]=M,e[t+3]=g;return}if(h!==g||c!==u||l!==m||d!==M){let p=1-o;const f=c*u+l*m+d*M+h*g,_=f>=0?1:-1,x=1-f*f;if(x>Number.EPSILON){const R=Math.sqrt(x),L=Math.atan2(R,f*_);p=Math.sin(p*L)/R,o=Math.sin(o*L)/R}const v=o*_;if(c=c*p+u*v,l=l*p+m*v,d=d*p+M*v,h=h*p+g*v,p===1-o){const R=1/Math.sqrt(c*c+l*l+d*d+h*h);c*=R,l*=R,d*=R,h*=R}}e[t]=c,e[t+1]=l,e[t+2]=d,e[t+3]=h}static multiplyQuaternionsFlat(e,t,i,r,s,a){const o=i[r],c=i[r+1],l=i[r+2],d=i[r+3],h=s[a],u=s[a+1],m=s[a+2],M=s[a+3];return e[t]=o*M+d*h+c*m-l*u,e[t+1]=c*M+d*u+l*h-o*m,e[t+2]=l*M+d*m+o*u-c*h,e[t+3]=d*M-o*h-c*u-l*m,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,c=Math.sin,l=o(i/2),d=o(r/2),h=o(s/2),u=c(i/2),m=c(r/2),M=c(s/2);switch(a){case"XYZ":this._x=u*d*h+l*m*M,this._y=l*m*h-u*d*M,this._z=l*d*M+u*m*h,this._w=l*d*h-u*m*M;break;case"YXZ":this._x=u*d*h+l*m*M,this._y=l*m*h-u*d*M,this._z=l*d*M-u*m*h,this._w=l*d*h+u*m*M;break;case"ZXY":this._x=u*d*h-l*m*M,this._y=l*m*h+u*d*M,this._z=l*d*M+u*m*h,this._w=l*d*h-u*m*M;break;case"ZYX":this._x=u*d*h-l*m*M,this._y=l*m*h+u*d*M,this._z=l*d*M-u*m*h,this._w=l*d*h+u*m*M;break;case"YZX":this._x=u*d*h+l*m*M,this._y=l*m*h+u*d*M,this._z=l*d*M-u*m*h,this._w=l*d*h-u*m*M;break;case"XZY":this._x=u*d*h-l*m*M,this._y=l*m*h-u*d*M,this._z=l*d*M+u*m*h,this._w=l*d*h+u*m*M;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],r=t[4],s=t[8],a=t[1],o=t[5],c=t[9],l=t[2],d=t[6],h=t[10],u=i+o+h;if(u>0){const m=.5/Math.sqrt(u+1);this._w=.25/m,this._x=(d-c)*m,this._y=(s-l)*m,this._z=(a-r)*m}else if(i>o&&i>h){const m=2*Math.sqrt(1+i-o-h);this._w=(d-c)/m,this._x=.25*m,this._y=(r+a)/m,this._z=(s+l)/m}else if(o>h){const m=2*Math.sqrt(1+o-i-h);this._w=(s-l)/m,this._x=(r+a)/m,this._y=.25*m,this._z=(c+d)/m}else{const m=2*Math.sqrt(1+h-i-o);this._w=(a-r)/m,this._x=(s+l)/m,this._y=(c+d)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Lt(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,r=e._y,s=e._z,a=e._w,o=t._x,c=t._y,l=t._z,d=t._w;return this._x=i*d+a*o+r*l-s*c,this._y=r*d+a*c+s*o-i*l,this._z=s*d+a*l+i*c-r*o,this._w=a*d-i*o-r*c-s*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const i=this._x,r=this._y,s=this._z,a=this._w;let o=a*e._w+i*e._x+r*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=r,this._z=s,this;const c=1-o*o;if(c<=Number.EPSILON){const m=1-t;return this._w=m*a+t*this._w,this._x=m*i+t*this._x,this._y=m*r+t*this._y,this._z=m*s+t*this._z,this.normalize(),this}const l=Math.sqrt(c),d=Math.atan2(l,o),h=Math.sin((1-t)*d)/l,u=Math.sin(t*d)/l;return this._w=a*h+this._w*u,this._x=i*h+this._x*u,this._y=r*h+this._y*u,this._z=s*h+this._z*u,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),r=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(r),i*Math.sin(s),i*Math.cos(s),t*Math.sin(r))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class O{constructor(e=0,t=0,i=0){O.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Qo.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Qo.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,r=this.z,s=e.x,a=e.y,o=e.z,c=e.w,l=2*(a*r-o*i),d=2*(o*t-s*r),h=2*(s*i-a*t);return this.x=t+c*l+a*h-o*d,this.y=i+c*d+o*l-s*h,this.z=r+c*h+s*d-a*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,r=e.y,s=e.z,a=t.x,o=t.y,c=t.z;return this.x=r*c-s*o,this.y=s*a-i*c,this.z=i*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return ss.copy(this).projectOnVector(e),this.sub(ss)}reflect(e){return this.sub(ss.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Lt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const ss=new O,Qo=new Wi;class wn{constructor(e=new O(1/0,1/0,1/0),t=new O(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(Vt.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(Vt.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=Vt.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Vt):Vt.fromBufferAttribute(s,a),Vt.applyMatrix4(e.matrixWorld),this.expandByPoint(Vt);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Ji.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Ji.copy(i.boundingBox)),Ji.applyMatrix4(e.matrixWorld),this.union(Ji)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,Vt),Vt.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Ti),Qi.subVectors(this.max,Ti),Zn.subVectors(e.a,Ti),jn.subVectors(e.b,Ti),Kn.subVectors(e.c,Ti),hn.subVectors(jn,Zn),un.subVectors(Kn,jn),Ln.subVectors(Zn,Kn);let t=[0,-hn.z,hn.y,0,-un.z,un.y,0,-Ln.z,Ln.y,hn.z,0,-hn.x,un.z,0,-un.x,Ln.z,0,-Ln.x,-hn.y,hn.x,0,-un.y,un.x,0,-Ln.y,Ln.x,0];return!os(t,Zn,jn,Kn,Qi)||(t=[1,0,0,0,1,0,0,0,1],!os(t,Zn,jn,Kn,Qi))?!1:(er.crossVectors(hn,un),t=[er.x,er.y,er.z],os(t,Zn,jn,Kn,Qi))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Vt).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Vt).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(en[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),en[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),en[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),en[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),en[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),en[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),en[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),en[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(en),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const en=[new O,new O,new O,new O,new O,new O,new O,new O],Vt=new O,Ji=new wn,Zn=new O,jn=new O,Kn=new O,hn=new O,un=new O,Ln=new O,Ti=new O,Qi=new O,er=new O,Pn=new O;function os(n,e,t,i,r){for(let s=0,a=n.length-3;s<=a;s+=3){Pn.fromArray(n,s);const o=r.x*Math.abs(Pn.x)+r.y*Math.abs(Pn.y)+r.z*Math.abs(Pn.z),c=e.dot(Pn),l=t.dot(Pn),d=i.dot(Pn);if(Math.max(-Math.max(c,l,d),Math.min(c,l,d))>o)return!1}return!0}const ch=new wn,Ai=new O,as=new O;class Xi{constructor(e=new O,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):ch.setFromPoints(e).getCenter(i);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ai.subVectors(e,this.center);const t=Ai.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(Ai,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(as.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ai.copy(e.center).add(as)),this.expandByPoint(Ai.copy(e.center).sub(as))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const tn=new O,cs=new O,tr=new O,dn=new O,ls=new O,nr=new O,hs=new O;class zr{constructor(e=new O,t=new O(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,tn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=tn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(tn.copy(this.origin).addScaledVector(this.direction,t),tn.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){cs.copy(e).add(t).multiplyScalar(.5),tr.copy(t).sub(e).normalize(),dn.copy(this.origin).sub(cs);const s=e.distanceTo(t)*.5,a=-this.direction.dot(tr),o=dn.dot(this.direction),c=-dn.dot(tr),l=dn.lengthSq(),d=Math.abs(1-a*a);let h,u,m,M;if(d>0)if(h=a*c-o,u=a*o-c,M=s*d,h>=0)if(u>=-M)if(u<=M){const g=1/d;h*=g,u*=g,m=h*(h+a*u+2*o)+u*(a*h+u+2*c)+l}else u=s,h=Math.max(0,-(a*u+o)),m=-h*h+u*(u+2*c)+l;else u=-s,h=Math.max(0,-(a*u+o)),m=-h*h+u*(u+2*c)+l;else u<=-M?(h=Math.max(0,-(-a*s+o)),u=h>0?-s:Math.min(Math.max(-s,-c),s),m=-h*h+u*(u+2*c)+l):u<=M?(h=0,u=Math.min(Math.max(-s,-c),s),m=u*(u+2*c)+l):(h=Math.max(0,-(a*s+o)),u=h>0?s:Math.min(Math.max(-s,-c),s),m=-h*h+u*(u+2*c)+l);else u=a>0?-s:s,h=Math.max(0,-(a*u+o)),m=-h*h+u*(u+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,h),r&&r.copy(cs).addScaledVector(tr,u),m}intersectSphere(e,t){tn.subVectors(e.center,this.origin);const i=tn.dot(this.direction),r=tn.dot(tn)-i*i,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,a,o,c;const l=1/this.direction.x,d=1/this.direction.y,h=1/this.direction.z,u=this.origin;return l>=0?(i=(e.min.x-u.x)*l,r=(e.max.x-u.x)*l):(i=(e.max.x-u.x)*l,r=(e.min.x-u.x)*l),d>=0?(s=(e.min.y-u.y)*d,a=(e.max.y-u.y)*d):(s=(e.max.y-u.y)*d,a=(e.min.y-u.y)*d),i>a||s>r||((s>i||isNaN(i))&&(i=s),(a<r||isNaN(r))&&(r=a),h>=0?(o=(e.min.z-u.z)*h,c=(e.max.z-u.z)*h):(o=(e.max.z-u.z)*h,c=(e.min.z-u.z)*h),i>c||o>r)||((o>i||i!==i)&&(i=o),(c<r||r!==r)&&(r=c),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,tn)!==null}intersectTriangle(e,t,i,r,s){ls.subVectors(t,e),nr.subVectors(i,e),hs.crossVectors(ls,nr);let a=this.direction.dot(hs),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;dn.subVectors(this.origin,e);const c=o*this.direction.dot(nr.crossVectors(dn,nr));if(c<0)return null;const l=o*this.direction.dot(ls.cross(dn));if(l<0||c+l>a)return null;const d=-o*dn.dot(hs);return d<0?null:this.at(d/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Ke{constructor(e,t,i,r,s,a,o,c,l,d,h,u,m,M,g,p){Ke.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,c,l,d,h,u,m,M,g,p)}set(e,t,i,r,s,a,o,c,l,d,h,u,m,M,g,p){const f=this.elements;return f[0]=e,f[4]=t,f[8]=i,f[12]=r,f[1]=s,f[5]=a,f[9]=o,f[13]=c,f[2]=l,f[6]=d,f[10]=h,f[14]=u,f[3]=m,f[7]=M,f[11]=g,f[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ke().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,r=1/$n.setFromMatrixColumn(e,0).length(),s=1/$n.setFromMatrixColumn(e,1).length(),a=1/$n.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,r=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(r),l=Math.sin(r),d=Math.cos(s),h=Math.sin(s);if(e.order==="XYZ"){const u=a*d,m=a*h,M=o*d,g=o*h;t[0]=c*d,t[4]=-c*h,t[8]=l,t[1]=m+M*l,t[5]=u-g*l,t[9]=-o*c,t[2]=g-u*l,t[6]=M+m*l,t[10]=a*c}else if(e.order==="YXZ"){const u=c*d,m=c*h,M=l*d,g=l*h;t[0]=u+g*o,t[4]=M*o-m,t[8]=a*l,t[1]=a*h,t[5]=a*d,t[9]=-o,t[2]=m*o-M,t[6]=g+u*o,t[10]=a*c}else if(e.order==="ZXY"){const u=c*d,m=c*h,M=l*d,g=l*h;t[0]=u-g*o,t[4]=-a*h,t[8]=M+m*o,t[1]=m+M*o,t[5]=a*d,t[9]=g-u*o,t[2]=-a*l,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){const u=a*d,m=a*h,M=o*d,g=o*h;t[0]=c*d,t[4]=M*l-m,t[8]=u*l+g,t[1]=c*h,t[5]=g*l+u,t[9]=m*l-M,t[2]=-l,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){const u=a*c,m=a*l,M=o*c,g=o*l;t[0]=c*d,t[4]=g-u*h,t[8]=M*h+m,t[1]=h,t[5]=a*d,t[9]=-o*d,t[2]=-l*d,t[6]=m*h+M,t[10]=u-g*h}else if(e.order==="XZY"){const u=a*c,m=a*l,M=o*c,g=o*l;t[0]=c*d,t[4]=-h,t[8]=l*d,t[1]=u*h+g,t[5]=a*d,t[9]=m*h-M,t[2]=M*h-m,t[6]=o*d,t[10]=g*h+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(lh,e,hh)}lookAt(e,t,i){const r=this.elements;return It.subVectors(e,t),It.lengthSq()===0&&(It.z=1),It.normalize(),fn.crossVectors(i,It),fn.lengthSq()===0&&(Math.abs(i.z)===1?It.x+=1e-4:It.z+=1e-4,It.normalize(),fn.crossVectors(i,It)),fn.normalize(),ir.crossVectors(It,fn),r[0]=fn.x,r[4]=ir.x,r[8]=It.x,r[1]=fn.y,r[5]=ir.y,r[9]=It.y,r[2]=fn.z,r[6]=ir.z,r[10]=It.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],d=i[1],h=i[5],u=i[9],m=i[13],M=i[2],g=i[6],p=i[10],f=i[14],_=i[3],x=i[7],v=i[11],R=i[15],L=r[0],C=r[4],z=r[8],b=r[12],T=r[1],H=r[5],U=r[9],Y=r[13],D=r[2],I=r[6],G=r[10],X=r[14],Q=r[3],ne=r[7],te=r[11],he=r[15];return s[0]=a*L+o*T+c*D+l*Q,s[4]=a*C+o*H+c*I+l*ne,s[8]=a*z+o*U+c*G+l*te,s[12]=a*b+o*Y+c*X+l*he,s[1]=d*L+h*T+u*D+m*Q,s[5]=d*C+h*H+u*I+m*ne,s[9]=d*z+h*U+u*G+m*te,s[13]=d*b+h*Y+u*X+m*he,s[2]=M*L+g*T+p*D+f*Q,s[6]=M*C+g*H+p*I+f*ne,s[10]=M*z+g*U+p*G+f*te,s[14]=M*b+g*Y+p*X+f*he,s[3]=_*L+x*T+v*D+R*Q,s[7]=_*C+x*H+v*I+R*ne,s[11]=_*z+x*U+v*G+R*te,s[15]=_*b+x*Y+v*X+R*he,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],a=e[1],o=e[5],c=e[9],l=e[13],d=e[2],h=e[6],u=e[10],m=e[14],M=e[3],g=e[7],p=e[11],f=e[15];return M*(+s*c*h-r*l*h-s*o*u+i*l*u+r*o*m-i*c*m)+g*(+t*c*m-t*l*u+s*a*u-r*a*m+r*l*d-s*c*d)+p*(+t*l*h-t*o*m-s*a*h+i*a*m+s*o*d-i*l*d)+f*(-r*o*d-t*c*h+t*o*u+r*a*h-i*a*u+i*c*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8],h=e[9],u=e[10],m=e[11],M=e[12],g=e[13],p=e[14],f=e[15],_=h*p*l-g*u*l+g*c*m-o*p*m-h*c*f+o*u*f,x=M*u*l-d*p*l-M*c*m+a*p*m+d*c*f-a*u*f,v=d*g*l-M*h*l+M*o*m-a*g*m-d*o*f+a*h*f,R=M*h*c-d*g*c-M*o*u+a*g*u+d*o*p-a*h*p,L=t*_+i*x+r*v+s*R;if(L===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const C=1/L;return e[0]=_*C,e[1]=(g*u*s-h*p*s-g*r*m+i*p*m+h*r*f-i*u*f)*C,e[2]=(o*p*s-g*c*s+g*r*l-i*p*l-o*r*f+i*c*f)*C,e[3]=(h*c*s-o*u*s-h*r*l+i*u*l+o*r*m-i*c*m)*C,e[4]=x*C,e[5]=(d*p*s-M*u*s+M*r*m-t*p*m-d*r*f+t*u*f)*C,e[6]=(M*c*s-a*p*s-M*r*l+t*p*l+a*r*f-t*c*f)*C,e[7]=(a*u*s-d*c*s+d*r*l-t*u*l-a*r*m+t*c*m)*C,e[8]=v*C,e[9]=(M*h*s-d*g*s-M*i*m+t*g*m+d*i*f-t*h*f)*C,e[10]=(a*g*s-M*o*s+M*i*l-t*g*l-a*i*f+t*o*f)*C,e[11]=(d*o*s-a*h*s-d*i*l+t*h*l+a*i*m-t*o*m)*C,e[12]=R*C,e[13]=(d*g*r-M*h*r+M*i*u-t*g*u-d*i*p+t*h*p)*C,e[14]=(M*o*r-a*g*r-M*i*c+t*g*c+a*i*p-t*o*p)*C,e[15]=(a*h*r-d*o*r+d*i*c-t*h*c-a*i*u+t*o*u)*C,this}scale(e){const t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),r=Math.sin(t),s=1-i,a=e.x,o=e.y,c=e.z,l=s*a,d=s*o;return this.set(l*a+i,l*o-r*c,l*c+r*o,0,l*o+r*c,d*o+i,d*c-r*a,0,l*c-r*o,d*c+r*a,s*c*c+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,a){return this.set(1,i,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){const r=this.elements,s=t._x,a=t._y,o=t._z,c=t._w,l=s+s,d=a+a,h=o+o,u=s*l,m=s*d,M=s*h,g=a*d,p=a*h,f=o*h,_=c*l,x=c*d,v=c*h,R=i.x,L=i.y,C=i.z;return r[0]=(1-(g+f))*R,r[1]=(m+v)*R,r[2]=(M-x)*R,r[3]=0,r[4]=(m-v)*L,r[5]=(1-(u+f))*L,r[6]=(p+_)*L,r[7]=0,r[8]=(M+x)*C,r[9]=(p-_)*C,r[10]=(1-(u+g))*C,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){const r=this.elements;let s=$n.set(r[0],r[1],r[2]).length();const a=$n.set(r[4],r[5],r[6]).length(),o=$n.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],Wt.copy(this);const l=1/s,d=1/a,h=1/o;return Wt.elements[0]*=l,Wt.elements[1]*=l,Wt.elements[2]*=l,Wt.elements[4]*=d,Wt.elements[5]*=d,Wt.elements[6]*=d,Wt.elements[8]*=h,Wt.elements[9]*=h,Wt.elements[10]*=h,t.setFromRotationMatrix(Wt),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,r,s,a,o=an){const c=this.elements,l=2*s/(t-e),d=2*s/(i-r),h=(t+e)/(t-e),u=(i+r)/(i-r);let m,M;if(o===an)m=-(a+s)/(a-s),M=-2*a*s/(a-s);else if(o===Dr)m=-a/(a-s),M=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=d,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=m,c[14]=M,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,i,r,s,a,o=an){const c=this.elements,l=1/(t-e),d=1/(i-r),h=1/(a-s),u=(t+e)*l,m=(i+r)*d;let M,g;if(o===an)M=(a+s)*h,g=-2*h;else if(o===Dr)M=s*h,g=-1*h;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-u,c[1]=0,c[5]=2*d,c[9]=0,c[13]=-m,c[2]=0,c[6]=0,c[10]=g,c[14]=-M,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const $n=new O,Wt=new Ke,lh=new O(0,0,0),hh=new O(1,1,1),fn=new O,ir=new O,It=new O,ea=new Ke,ta=new Wi;class Br{constructor(e=0,t=0,i=0,r=Br.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],c=r[1],l=r[5],d=r[9],h=r[2],u=r[6],m=r[10];switch(t){case"XYZ":this._y=Math.asin(Lt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,m),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Lt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-h,s),this._z=0);break;case"ZXY":this._x=Math.asin(Lt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,m),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-Lt(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,m),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Lt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-d,l),this._y=Math.atan2(-h,s)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-Lt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return ea.makeRotationFromQuaternion(e),this.setFromRotationMatrix(ea,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return ta.setFromEuler(this),this.setFromQuaternion(ta,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Br.DEFAULT_ORDER="XYZ";class Zs{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let uh=0;const na=new O,Jn=new Wi,nn=new Ke,rr=new O,Ri=new O,dh=new O,fh=new Wi,ia=new O(1,0,0),ra=new O(0,1,0),sa=new O(0,0,1),ph={type:"added"},mh={type:"removed"};class ut extends Si{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:uh++}),this.uuid=Vi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ut.DEFAULT_UP.clone();const e=new O,t=new Br,i=new Wi,r=new O(1,1,1);function s(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new Ke},normalMatrix:{value:new He}}),this.matrix=new Ke,this.matrixWorld=new Ke,this.matrixAutoUpdate=ut.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Zs,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Jn.setFromAxisAngle(e,t),this.quaternion.multiply(Jn),this}rotateOnWorldAxis(e,t){return Jn.setFromAxisAngle(e,t),this.quaternion.premultiply(Jn),this}rotateX(e){return this.rotateOnAxis(ia,e)}rotateY(e){return this.rotateOnAxis(ra,e)}rotateZ(e){return this.rotateOnAxis(sa,e)}translateOnAxis(e,t){return na.copy(e).applyQuaternion(this.quaternion),this.position.add(na.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(ia,e)}translateY(e){return this.translateOnAxis(ra,e)}translateZ(e){return this.translateOnAxis(sa,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(nn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?rr.copy(e):rr.set(e,t,i);const r=this.parent;this.updateWorldMatrix(!0,!1),Ri.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?nn.lookAt(Ri,rr,this.up):nn.lookAt(rr,Ri,this.up),this.quaternion.setFromRotationMatrix(nn),r&&(nn.extractRotation(r.matrixWorld),Jn.setFromRotationMatrix(nn),this.quaternion.premultiply(Jn.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(ph)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(mh)),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),nn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),nn.multiply(e.parent.matrixWorld)),e.applyMatrix4(nn),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ri,e,dh),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Ri,fh,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,r=t.length;i<r;i++){const s=t[i];(s.matrixWorldAutoUpdate===!0||e===!0)&&s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){const r=this.children;for(let s=0,a=r.length;s<a;s++){const o=r[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.visibility=this._visibility,r.active=this._active,r.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),r.maxGeometryCount=this._maxGeometryCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.geometryCount=this._geometryCount,r.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(r.boundingSphere={center:r.boundingSphere.center.toArray(),radius:r.boundingSphere.radius}),this.boundingBox!==null&&(r.boundingBox={min:r.boundingBox.min.toArray(),max:r.boundingBox.max.toArray()}));function s(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const c=o.shapes;if(Array.isArray(c))for(let l=0,d=c.length;l<d;l++){const h=c[l];s(e.shapes,h)}else s(e.shapes,c)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(s(e.materials,this.material[c]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const c=this.animations[o];r.animations.push(s(e.animations,c))}}if(t){const o=a(e.geometries),c=a(e.materials),l=a(e.textures),d=a(e.images),h=a(e.shapes),u=a(e.skeletons),m=a(e.animations),M=a(e.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),d.length>0&&(i.images=d),h.length>0&&(i.shapes=h),u.length>0&&(i.skeletons=u),m.length>0&&(i.animations=m),M.length>0&&(i.nodes=M)}return i.object=r,i;function a(o){const c=[];for(const l in o){const d=o[l];delete d.metadata,c.push(d)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}}ut.DEFAULT_UP=new O(0,1,0);ut.DEFAULT_MATRIX_AUTO_UPDATE=!0;ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Xt=new O,rn=new O,us=new O,sn=new O,Qn=new O,ei=new O,oa=new O,ds=new O,fs=new O,ps=new O;let sr=!1;class qt{constructor(e=new O,t=new O,i=new O){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),Xt.subVectors(e,t),r.cross(Xt);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){Xt.subVectors(r,t),rn.subVectors(i,t),us.subVectors(e,t);const a=Xt.dot(Xt),o=Xt.dot(rn),c=Xt.dot(us),l=rn.dot(rn),d=rn.dot(us),h=a*l-o*o;if(h===0)return s.set(0,0,0),null;const u=1/h,m=(l*c-o*d)*u,M=(a*d-o*c)*u;return s.set(1-m-M,M,m)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,sn)===null?!1:sn.x>=0&&sn.y>=0&&sn.x+sn.y<=1}static getUV(e,t,i,r,s,a,o,c){return sr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),sr=!0),this.getInterpolation(e,t,i,r,s,a,o,c)}static getInterpolation(e,t,i,r,s,a,o,c){return this.getBarycoord(e,t,i,r,sn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,sn.x),c.addScaledVector(a,sn.y),c.addScaledVector(o,sn.z),c)}static isFrontFacing(e,t,i,r){return Xt.subVectors(i,t),rn.subVectors(e,t),Xt.cross(rn).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Xt.subVectors(this.c,this.b),rn.subVectors(this.a,this.b),Xt.cross(rn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return qt.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return qt.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,r,s){return sr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),sr=!0),qt.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}getInterpolation(e,t,i,r,s){return qt.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return qt.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return qt.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,r=this.b,s=this.c;let a,o;Qn.subVectors(r,i),ei.subVectors(s,i),ds.subVectors(e,i);const c=Qn.dot(ds),l=ei.dot(ds);if(c<=0&&l<=0)return t.copy(i);fs.subVectors(e,r);const d=Qn.dot(fs),h=ei.dot(fs);if(d>=0&&h<=d)return t.copy(r);const u=c*h-d*l;if(u<=0&&c>=0&&d<=0)return a=c/(c-d),t.copy(i).addScaledVector(Qn,a);ps.subVectors(e,s);const m=Qn.dot(ps),M=ei.dot(ps);if(M>=0&&m<=M)return t.copy(s);const g=m*l-c*M;if(g<=0&&l>=0&&M<=0)return o=l/(l-M),t.copy(i).addScaledVector(ei,o);const p=d*M-m*h;if(p<=0&&h-d>=0&&m-M>=0)return oa.subVectors(s,r),o=(h-d)/(h-d+(m-M)),t.copy(r).addScaledVector(oa,o);const f=1/(p+g+u);return a=g*f,o=u*f,t.copy(i).addScaledVector(Qn,a).addScaledVector(ei,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const mc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},pn={h:0,s:0,l:0},or={h:0,s:0,l:0};function ms(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class Ze{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=lt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,je.toWorkingColorSpace(this,t),this}setRGB(e,t,i,r=je.workingColorSpace){return this.r=e,this.g=t,this.b=i,je.toWorkingColorSpace(this,r),this}setHSL(e,t,i,r=je.workingColorSpace){if(e=th(e,1),t=Lt(t,0,1),i=Lt(i,0,1),t===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=ms(a,s,e+1/3),this.g=ms(a,s,e),this.b=ms(a,s,e-1/3)}return je.toWorkingColorSpace(this,r),this}setStyle(e,t=lt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=lt){const i=mc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=fi(e.r),this.g=fi(e.g),this.b=fi(e.b),this}copyLinearToSRGB(e){return this.r=is(e.r),this.g=is(e.g),this.b=is(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=lt){return je.fromWorkingColorSpace(Et.copy(this),e),Math.round(Lt(Et.r*255,0,255))*65536+Math.round(Lt(Et.g*255,0,255))*256+Math.round(Lt(Et.b*255,0,255))}getHexString(e=lt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=je.workingColorSpace){je.fromWorkingColorSpace(Et.copy(this),t);const i=Et.r,r=Et.g,s=Et.b,a=Math.max(i,r,s),o=Math.min(i,r,s);let c,l;const d=(o+a)/2;if(o===a)c=0,l=0;else{const h=a-o;switch(l=d<=.5?h/(a+o):h/(2-a-o),a){case i:c=(r-s)/h+(r<s?6:0);break;case r:c=(s-i)/h+2;break;case s:c=(i-r)/h+4;break}c/=6}return e.h=c,e.s=l,e.l=d,e}getRGB(e,t=je.workingColorSpace){return je.fromWorkingColorSpace(Et.copy(this),t),e.r=Et.r,e.g=Et.g,e.b=Et.b,e}getStyle(e=lt){je.fromWorkingColorSpace(Et.copy(this),e);const t=Et.r,i=Et.g,r=Et.b;return e!==lt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL(pn),this.setHSL(pn.h+e,pn.s+t,pn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(pn),e.getHSL(or);const i=ts(pn.h,or.h,t),r=ts(pn.s,or.s,t),s=ts(pn.l,or.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Et=new Ze;Ze.NAMES=mc;let gh=0;class qi extends Si{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:gh++}),this.uuid=Vi(),this.name="",this.type="Material",this.blending=di,this.side=cn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Ls,this.blendDst=Ps,this.blendEquation=On,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ze(0,0,0),this.blendAlpha=0,this.depthFunc=Rr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=qn,this.stencilZFail=qn,this.stencilZPass=qn,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==di&&(i.blending=this.blending),this.side!==cn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Ls&&(i.blendSrc=this.blendSrc),this.blendDst!==Ps&&(i.blendDst=this.blendDst),this.blendEquation!==On&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==Rr&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==qo&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==qn&&(i.stencilFail=this.stencilFail),this.stencilZFail!==qn&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==qn&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){const a=[];for(const o in s){const c=s[o];delete c.metadata,a.push(c)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class pi extends qi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ze(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Xs,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const at=new O,ar=new qe;class jt{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Yo,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=vn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)ar.fromBufferAttribute(this,t),ar.applyMatrix3(e),this.setXY(t,ar.x,ar.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)at.fromBufferAttribute(this,t),at.applyMatrix3(e),this.setXYZ(t,at.x,at.y,at.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)at.fromBufferAttribute(this,t),at.applyMatrix4(e),this.setXYZ(t,at.x,at.y,at.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)at.fromBufferAttribute(this,t),at.applyNormalMatrix(e),this.setXYZ(t,at.x,at.y,at.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)at.fromBufferAttribute(this,t),at.transformDirection(e),this.setXYZ(t,at.x,at.y,at.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=wi(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Rt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=wi(t,this.array)),t}setX(e,t){return this.normalized&&(t=Rt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=wi(t,this.array)),t}setY(e,t){return this.normalized&&(t=Rt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=wi(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Rt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=wi(t,this.array)),t}setW(e,t){return this.normalized&&(t=Rt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=Rt(t,this.array),i=Rt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=Rt(t,this.array),i=Rt(i,this.array),r=Rt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=Rt(t,this.array),i=Rt(i,this.array),r=Rt(r,this.array),s=Rt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Yo&&(e.usage=this.usage),e}}class gc extends jt{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class _c extends jt{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class Xe extends jt{constructor(e,t,i){super(new Float32Array(e),t,i)}}let _h=0;const zt=new Ke,gs=new ut,ti=new O,Nt=new wn,Ci=new wn,gt=new O;class it extends Si{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:_h++}),this.uuid=Vi(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(uc(e)?_c:gc)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new He().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return zt.makeRotationFromQuaternion(e),this.applyMatrix4(zt),this}rotateX(e){return zt.makeRotationX(e),this.applyMatrix4(zt),this}rotateY(e){return zt.makeRotationY(e),this.applyMatrix4(zt),this}rotateZ(e){return zt.makeRotationZ(e),this.applyMatrix4(zt),this}translate(e,t,i){return zt.makeTranslation(e,t,i),this.applyMatrix4(zt),this}scale(e,t,i){return zt.makeScale(e,t,i),this.applyMatrix4(zt),this}lookAt(e){return gs.lookAt(e),gs.updateMatrix(),this.applyMatrix4(gs.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(ti).negate(),this.translate(ti.x,ti.y,ti.z),this}setFromPoints(e){const t=[];for(let i=0,r=e.length;i<r;i++){const s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Xe(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new wn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new O(-1/0,-1/0,-1/0),new O(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){const s=t[i];Nt.setFromBufferAttribute(s),this.morphTargetsRelative?(gt.addVectors(this.boundingBox.min,Nt.min),this.boundingBox.expandByPoint(gt),gt.addVectors(this.boundingBox.max,Nt.max),this.boundingBox.expandByPoint(gt)):(this.boundingBox.expandByPoint(Nt.min),this.boundingBox.expandByPoint(Nt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Xi);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new O,1/0);return}if(e){const i=this.boundingSphere.center;if(Nt.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];Ci.setFromBufferAttribute(o),this.morphTargetsRelative?(gt.addVectors(Nt.min,Ci.min),Nt.expandByPoint(gt),gt.addVectors(Nt.max,Ci.max),Nt.expandByPoint(gt)):(Nt.expandByPoint(Ci.min),Nt.expandByPoint(Ci.max))}Nt.getCenter(i);let r=0;for(let s=0,a=e.count;s<a;s++)gt.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(gt));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],c=this.morphTargetsRelative;for(let l=0,d=o.count;l<d;l++)gt.fromBufferAttribute(o,l),c&&(ti.fromBufferAttribute(e,l),gt.add(ti)),r=Math.max(r,i.distanceToSquared(gt))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=e.array,r=t.position.array,s=t.normal.array,a=t.uv.array,o=r.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new jt(new Float32Array(4*o),4));const c=this.getAttribute("tangent").array,l=[],d=[];for(let T=0;T<o;T++)l[T]=new O,d[T]=new O;const h=new O,u=new O,m=new O,M=new qe,g=new qe,p=new qe,f=new O,_=new O;function x(T,H,U){h.fromArray(r,T*3),u.fromArray(r,H*3),m.fromArray(r,U*3),M.fromArray(a,T*2),g.fromArray(a,H*2),p.fromArray(a,U*2),u.sub(h),m.sub(h),g.sub(M),p.sub(M);const Y=1/(g.x*p.y-p.x*g.y);isFinite(Y)&&(f.copy(u).multiplyScalar(p.y).addScaledVector(m,-g.y).multiplyScalar(Y),_.copy(m).multiplyScalar(g.x).addScaledVector(u,-p.x).multiplyScalar(Y),l[T].add(f),l[H].add(f),l[U].add(f),d[T].add(_),d[H].add(_),d[U].add(_))}let v=this.groups;v.length===0&&(v=[{start:0,count:i.length}]);for(let T=0,H=v.length;T<H;++T){const U=v[T],Y=U.start,D=U.count;for(let I=Y,G=Y+D;I<G;I+=3)x(i[I+0],i[I+1],i[I+2])}const R=new O,L=new O,C=new O,z=new O;function b(T){C.fromArray(s,T*3),z.copy(C);const H=l[T];R.copy(H),R.sub(C.multiplyScalar(C.dot(H))).normalize(),L.crossVectors(z,H);const Y=L.dot(d[T])<0?-1:1;c[T*4]=R.x,c[T*4+1]=R.y,c[T*4+2]=R.z,c[T*4+3]=Y}for(let T=0,H=v.length;T<H;++T){const U=v[T],Y=U.start,D=U.count;for(let I=Y,G=Y+D;I<G;I+=3)b(i[I+0]),b(i[I+1]),b(i[I+2])}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new jt(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let u=0,m=i.count;u<m;u++)i.setXYZ(u,0,0,0);const r=new O,s=new O,a=new O,o=new O,c=new O,l=new O,d=new O,h=new O;if(e)for(let u=0,m=e.count;u<m;u+=3){const M=e.getX(u+0),g=e.getX(u+1),p=e.getX(u+2);r.fromBufferAttribute(t,M),s.fromBufferAttribute(t,g),a.fromBufferAttribute(t,p),d.subVectors(a,s),h.subVectors(r,s),d.cross(h),o.fromBufferAttribute(i,M),c.fromBufferAttribute(i,g),l.fromBufferAttribute(i,p),o.add(d),c.add(d),l.add(d),i.setXYZ(M,o.x,o.y,o.z),i.setXYZ(g,c.x,c.y,c.z),i.setXYZ(p,l.x,l.y,l.z)}else for(let u=0,m=t.count;u<m;u+=3)r.fromBufferAttribute(t,u+0),s.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),d.subVectors(a,s),h.subVectors(r,s),d.cross(h),i.setXYZ(u+0,d.x,d.y,d.z),i.setXYZ(u+1,d.x,d.y,d.z),i.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)gt.fromBufferAttribute(e,t),gt.normalize(),e.setXYZ(t,gt.x,gt.y,gt.z)}toNonIndexed(){function e(o,c){const l=o.array,d=o.itemSize,h=o.normalized,u=new l.constructor(c.length*d);let m=0,M=0;for(let g=0,p=c.length;g<p;g++){o.isInterleavedBufferAttribute?m=c[g]*o.data.stride+o.offset:m=c[g]*d;for(let f=0;f<d;f++)u[M++]=l[m++]}return new jt(u,d,h)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new it,i=this.index.array,r=this.attributes;for(const o in r){const c=r[o],l=e(c,i);t.setAttribute(o,l)}const s=this.morphAttributes;for(const o in s){const c=[],l=s[o];for(let d=0,h=l.length;d<h;d++){const u=l[d],m=e(u,i);c.push(m)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,c=a.length;o<c;o++){const l=a[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const c in i){const l=i[c];e.data.attributes[c]=l.toJSON(e.data)}const r={};let s=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],d=[];for(let h=0,u=l.length;h<u;h++){const m=l[h];d.push(m.toJSON(e.data))}d.length>0&&(r[c]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(t));const r=e.attributes;for(const l in r){const d=r[l];this.setAttribute(l,d.clone(t))}const s=e.morphAttributes;for(const l in s){const d=[],h=s[l];for(let u=0,m=h.length;u<m;u++)d.push(h[u].clone(t));this.morphAttributes[l]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let l=0,d=a.length;l<d;l++){const h=a[l];this.addGroup(h.start,h.count,h.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const aa=new Ke,Dn=new zr,cr=new Xi,ca=new O,ni=new O,ii=new O,ri=new O,_s=new O,lr=new O,hr=new qe,ur=new qe,dr=new qe,la=new O,ha=new O,ua=new O,fr=new O,pr=new O;class Ne extends ut{constructor(e=new it,t=new pi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){lr.set(0,0,0);for(let c=0,l=s.length;c<l;c++){const d=o[c],h=s[c];d!==0&&(_s.fromBufferAttribute(h,e),a?lr.addScaledVector(_s,d):lr.addScaledVector(_s.sub(t),d))}t.add(lr)}return t}raycast(e,t){const i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),cr.copy(i.boundingSphere),cr.applyMatrix4(s),Dn.copy(e.ray).recast(e.near),!(cr.containsPoint(Dn.origin)===!1&&(Dn.intersectSphere(cr,ca)===null||Dn.origin.distanceToSquared(ca)>(e.far-e.near)**2))&&(aa.copy(s).invert(),Dn.copy(e.ray).applyMatrix4(aa),!(i.boundingBox!==null&&Dn.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,Dn)))}_computeIntersections(e,t,i){let r;const s=this.geometry,a=this.material,o=s.index,c=s.attributes.position,l=s.attributes.uv,d=s.attributes.uv1,h=s.attributes.normal,u=s.groups,m=s.drawRange;if(o!==null)if(Array.isArray(a))for(let M=0,g=u.length;M<g;M++){const p=u[M],f=a[p.materialIndex],_=Math.max(p.start,m.start),x=Math.min(o.count,Math.min(p.start+p.count,m.start+m.count));for(let v=_,R=x;v<R;v+=3){const L=o.getX(v),C=o.getX(v+1),z=o.getX(v+2);r=mr(this,f,e,i,l,d,h,L,C,z),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const M=Math.max(0,m.start),g=Math.min(o.count,m.start+m.count);for(let p=M,f=g;p<f;p+=3){const _=o.getX(p),x=o.getX(p+1),v=o.getX(p+2);r=mr(this,a,e,i,l,d,h,_,x,v),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}else if(c!==void 0)if(Array.isArray(a))for(let M=0,g=u.length;M<g;M++){const p=u[M],f=a[p.materialIndex],_=Math.max(p.start,m.start),x=Math.min(c.count,Math.min(p.start+p.count,m.start+m.count));for(let v=_,R=x;v<R;v+=3){const L=v,C=v+1,z=v+2;r=mr(this,f,e,i,l,d,h,L,C,z),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const M=Math.max(0,m.start),g=Math.min(c.count,m.start+m.count);for(let p=M,f=g;p<f;p+=3){const _=p,x=p+1,v=p+2;r=mr(this,a,e,i,l,d,h,_,x,v),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}}}function xh(n,e,t,i,r,s,a,o){let c;if(e.side===Pt?c=i.intersectTriangle(a,s,r,!0,o):c=i.intersectTriangle(r,s,a,e.side===cn,o),c===null)return null;pr.copy(o),pr.applyMatrix4(n.matrixWorld);const l=t.ray.origin.distanceTo(pr);return l<t.near||l>t.far?null:{distance:l,point:pr.clone(),object:n}}function mr(n,e,t,i,r,s,a,o,c,l){n.getVertexPosition(o,ni),n.getVertexPosition(c,ii),n.getVertexPosition(l,ri);const d=xh(n,e,t,i,ni,ii,ri,fr);if(d){r&&(hr.fromBufferAttribute(r,o),ur.fromBufferAttribute(r,c),dr.fromBufferAttribute(r,l),d.uv=qt.getInterpolation(fr,ni,ii,ri,hr,ur,dr,new qe)),s&&(hr.fromBufferAttribute(s,o),ur.fromBufferAttribute(s,c),dr.fromBufferAttribute(s,l),d.uv1=qt.getInterpolation(fr,ni,ii,ri,hr,ur,dr,new qe),d.uv2=d.uv1),a&&(la.fromBufferAttribute(a,o),ha.fromBufferAttribute(a,c),ua.fromBufferAttribute(a,l),d.normal=qt.getInterpolation(fr,ni,ii,ri,la,ha,ua,new O),d.normal.dot(i.direction)>0&&d.normal.multiplyScalar(-1));const h={a:o,b:c,c:l,normal:new O,materialIndex:0};qt.getNormal(ni,ii,ri,h.normal),d.face=h}return d}class Mt extends it{constructor(e=1,t=1,i=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const c=[],l=[],d=[],h=[];let u=0,m=0;M("z","y","x",-1,-1,i,t,e,a,s,0),M("z","y","x",1,-1,i,t,-e,a,s,1),M("x","z","y",1,1,e,i,t,r,a,2),M("x","z","y",1,-1,e,i,-t,r,a,3),M("x","y","z",1,-1,e,t,i,r,s,4),M("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(c),this.setAttribute("position",new Xe(l,3)),this.setAttribute("normal",new Xe(d,3)),this.setAttribute("uv",new Xe(h,2));function M(g,p,f,_,x,v,R,L,C,z,b){const T=v/C,H=R/z,U=v/2,Y=R/2,D=L/2,I=C+1,G=z+1;let X=0,Q=0;const ne=new O;for(let te=0;te<G;te++){const he=te*H-Y;for(let fe=0;fe<I;fe++){const K=fe*T-U;ne[g]=K*_,ne[p]=he*x,ne[f]=D,l.push(ne.x,ne.y,ne.z),ne[g]=0,ne[p]=0,ne[f]=L>0?1:-1,d.push(ne.x,ne.y,ne.z),h.push(fe/C),h.push(1-te/z),X+=1}}for(let te=0;te<z;te++)for(let he=0;he<C;he++){const fe=u+he+I*te,K=u+he+I*(te+1),re=u+(he+1)+I*(te+1),me=u+(he+1)+I*te;c.push(fe,K,me),c.push(K,re,me),Q+=6}o.addGroup(m,Q,b),m+=Q,u+=X}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Mt(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function vi(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const r=n[t][i];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone():Array.isArray(r)?e[t][i]=r.slice():e[t][i]=r}}return e}function Tt(n){const e={};for(let t=0;t<n.length;t++){const i=vi(n[t]);for(const r in i)e[r]=i[r]}return e}function vh(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function xc(n){return n.getRenderTarget()===null?n.outputColorSpace:je.workingColorSpace}const Mh={clone:vi,merge:Tt};var yh=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Sh=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Wn extends qi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=yh,this.fragmentShader=Sh,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=vi(e.uniforms),this.uniformsGroups=vh(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class vc extends ut{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ke,this.projectionMatrix=new Ke,this.projectionMatrixInverse=new Ke,this.coordinateSystem=an}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class Gt extends vc{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Os*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(es*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Os*2*Math.atan(Math.tan(es*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(es*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*r/c,t-=a.offsetY*i/l,r*=a.width/c,i*=a.height/l}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const si=-90,oi=1;class Eh extends ut{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Gt(si,oi,e,t);r.layers=this.layers,this.add(r);const s=new Gt(si,oi,e,t);s.layers=this.layers,this.add(s);const a=new Gt(si,oi,e,t);a.layers=this.layers,this.add(a);const o=new Gt(si,oi,e,t);o.layers=this.layers,this.add(o);const c=new Gt(si,oi,e,t);c.layers=this.layers,this.add(c);const l=new Gt(si,oi,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,r,s,a,o,c]=t;for(const l of t)this.remove(l);if(e===an)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===Dr)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,c,l,d]=this.children,h=e.getRenderTarget(),u=e.getActiveCubeFace(),m=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const g=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,r),e.render(t,s),e.setRenderTarget(i,1,r),e.render(t,a),e.setRenderTarget(i,2,r),e.render(t,o),e.setRenderTarget(i,3,r),e.render(t,c),e.setRenderTarget(i,4,r),e.render(t,l),i.texture.generateMipmaps=g,e.setRenderTarget(i,5,r),e.render(t,d),e.setRenderTarget(h,u,m),e.xr.enabled=M,i.texture.needsPMREMUpdate=!0}}class Mc extends Dt{constructor(e,t,i,r,s,a,o,c,l,d){e=e!==void 0?e:[],t=t!==void 0?t:gi,super(e,t,i,r,s,a,o,c,l,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class bh extends Vn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];t.encoding!==void 0&&(Fi("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===Hn?lt:Ht),this.texture=new Mc(r,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:kt}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Mt(5,5,5),s=new Wn({name:"CubemapFromEquirect",uniforms:vi(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Pt,blending:Mn});s.uniforms.tEquirect.value=t;const a=new Ne(r,s),o=t.minFilter;return t.minFilter===Bi&&(t.minFilter=kt),new Eh(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,r){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,r);e.setRenderTarget(s)}}const xs=new O,wh=new O,Th=new He;class Nn{constructor(e=new O(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const r=xs.subVectors(i,t).cross(wh.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(xs),r=this.normal.dot(i);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||Th.getNormalMatrix(e),r=this.coplanarPoint(xs).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Un=new Xi,gr=new O;class js{constructor(e=new Nn,t=new Nn,i=new Nn,r=new Nn,s=new Nn,a=new Nn){this.planes=[e,t,i,r,s,a]}set(e,t,i,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=an){const i=this.planes,r=e.elements,s=r[0],a=r[1],o=r[2],c=r[3],l=r[4],d=r[5],h=r[6],u=r[7],m=r[8],M=r[9],g=r[10],p=r[11],f=r[12],_=r[13],x=r[14],v=r[15];if(i[0].setComponents(c-s,u-l,p-m,v-f).normalize(),i[1].setComponents(c+s,u+l,p+m,v+f).normalize(),i[2].setComponents(c+a,u+d,p+M,v+_).normalize(),i[3].setComponents(c-a,u-d,p-M,v-_).normalize(),i[4].setComponents(c-o,u-h,p-g,v-x).normalize(),t===an)i[5].setComponents(c+o,u+h,p+g,v+x).normalize();else if(t===Dr)i[5].setComponents(o,h,g,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Un.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Un.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Un)}intersectsSprite(e){return Un.center.set(0,0,0),Un.radius=.7071067811865476,Un.applyMatrix4(e.matrixWorld),this.intersectsSphere(Un)}intersectsSphere(e){const t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const r=t[i];if(gr.x=r.normal.x>0?e.max.x:e.min.x,gr.y=r.normal.y>0?e.max.y:e.min.y,gr.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(gr)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function yc(){let n=null,e=!1,t=null,i=null;function r(s,a){t(s,a),i=n.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function Ah(n,e){const t=e.isWebGL2,i=new WeakMap;function r(l,d){const h=l.array,u=l.usage,m=h.byteLength,M=n.createBuffer();n.bindBuffer(d,M),n.bufferData(d,h,u),l.onUploadCallback();let g;if(h instanceof Float32Array)g=n.FLOAT;else if(h instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(t)g=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else g=n.UNSIGNED_SHORT;else if(h instanceof Int16Array)g=n.SHORT;else if(h instanceof Uint32Array)g=n.UNSIGNED_INT;else if(h instanceof Int32Array)g=n.INT;else if(h instanceof Int8Array)g=n.BYTE;else if(h instanceof Uint8Array)g=n.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)g=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:M,type:g,bytesPerElement:h.BYTES_PER_ELEMENT,version:l.version,size:m}}function s(l,d,h){const u=d.array,m=d._updateRange,M=d.updateRanges;if(n.bindBuffer(h,l),m.count===-1&&M.length===0&&n.bufferSubData(h,0,u),M.length!==0){for(let g=0,p=M.length;g<p;g++){const f=M[g];t?n.bufferSubData(h,f.start*u.BYTES_PER_ELEMENT,u,f.start,f.count):n.bufferSubData(h,f.start*u.BYTES_PER_ELEMENT,u.subarray(f.start,f.start+f.count))}d.clearUpdateRanges()}m.count!==-1&&(t?n.bufferSubData(h,m.offset*u.BYTES_PER_ELEMENT,u,m.offset,m.count):n.bufferSubData(h,m.offset*u.BYTES_PER_ELEMENT,u.subarray(m.offset,m.offset+m.count)),m.count=-1),d.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);const d=i.get(l);d&&(n.deleteBuffer(d.buffer),i.delete(l))}function c(l,d){if(l.isGLBufferAttribute){const u=i.get(l);(!u||u.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);const h=i.get(l);if(h===void 0)i.set(l,r(l,d));else if(h.version<l.version){if(h.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(h.buffer,l,d),h.version=l.version}}return{get:a,remove:o,update:c}}class En extends it{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(i),c=Math.floor(r),l=o+1,d=c+1,h=e/o,u=t/c,m=[],M=[],g=[],p=[];for(let f=0;f<d;f++){const _=f*u-a;for(let x=0;x<l;x++){const v=x*h-s;M.push(v,-_,0),g.push(0,0,1),p.push(x/o),p.push(1-f/c)}}for(let f=0;f<c;f++)for(let _=0;_<o;_++){const x=_+l*f,v=_+l*(f+1),R=_+1+l*(f+1),L=_+1+l*f;m.push(x,v,L),m.push(v,R,L)}this.setIndex(m),this.setAttribute("position",new Xe(M,3)),this.setAttribute("normal",new Xe(g,3)),this.setAttribute("uv",new Xe(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new En(e.width,e.height,e.widthSegments,e.heightSegments)}}var Rh=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Ch=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Lh=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Ph=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Dh=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Uh=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ih=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Nh=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Fh=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Oh=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,zh=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Bh=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,kh=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Gh=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Hh=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Vh=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Wh=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Xh=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,qh=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Yh=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Zh=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,jh=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Kh=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,$h=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Jh=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,Qh=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,eu=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,tu=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,nu=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,iu=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,ru="gl_FragColor = linearToOutputTexel( gl_FragColor );",su=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,ou=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,au=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,cu=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,lu=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,hu=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,uu=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,du=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fu=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,pu=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,mu=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,gu=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,_u=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,xu=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,vu=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Mu=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,yu=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Su=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Eu=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,bu=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,wu=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Tu=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Au=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Ru=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Cu=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Lu=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Pu=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Du=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Uu=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,Iu=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Nu=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Fu=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Ou=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,zu=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Bu=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,ku=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Gu=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Hu=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Vu=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Wu=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Xu=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,qu=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Yu=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Zu=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ju=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Ku=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,$u=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Ju=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Qu=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,ed=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,td=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,nd=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,id=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,rd=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,sd=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,od=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,ad=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,cd=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,ld=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,hd=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,ud=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,dd=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,fd=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,pd=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,md=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,gd=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,_d=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,xd=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,vd=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Md=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,yd=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Sd=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Ed=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,bd=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,wd=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Td=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Ad=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Rd=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Cd=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ld=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Pd=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Dd=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ud=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Id=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,Nd=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Fd=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Od=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,zd=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Bd=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,kd=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Gd=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Hd=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Vd=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Wd=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xd=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,qd=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yd=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Zd=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,jd=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Kd=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,$d=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Jd=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Qd=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ef=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,tf=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,nf=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,rf=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,sf=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,of=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,af=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ge={alphahash_fragment:Rh,alphahash_pars_fragment:Ch,alphamap_fragment:Lh,alphamap_pars_fragment:Ph,alphatest_fragment:Dh,alphatest_pars_fragment:Uh,aomap_fragment:Ih,aomap_pars_fragment:Nh,batching_pars_vertex:Fh,batching_vertex:Oh,begin_vertex:zh,beginnormal_vertex:Bh,bsdfs:kh,iridescence_fragment:Gh,bumpmap_pars_fragment:Hh,clipping_planes_fragment:Vh,clipping_planes_pars_fragment:Wh,clipping_planes_pars_vertex:Xh,clipping_planes_vertex:qh,color_fragment:Yh,color_pars_fragment:Zh,color_pars_vertex:jh,color_vertex:Kh,common:$h,cube_uv_reflection_fragment:Jh,defaultnormal_vertex:Qh,displacementmap_pars_vertex:eu,displacementmap_vertex:tu,emissivemap_fragment:nu,emissivemap_pars_fragment:iu,colorspace_fragment:ru,colorspace_pars_fragment:su,envmap_fragment:ou,envmap_common_pars_fragment:au,envmap_pars_fragment:cu,envmap_pars_vertex:lu,envmap_physical_pars_fragment:yu,envmap_vertex:hu,fog_vertex:uu,fog_pars_vertex:du,fog_fragment:fu,fog_pars_fragment:pu,gradientmap_pars_fragment:mu,lightmap_fragment:gu,lightmap_pars_fragment:_u,lights_lambert_fragment:xu,lights_lambert_pars_fragment:vu,lights_pars_begin:Mu,lights_toon_fragment:Su,lights_toon_pars_fragment:Eu,lights_phong_fragment:bu,lights_phong_pars_fragment:wu,lights_physical_fragment:Tu,lights_physical_pars_fragment:Au,lights_fragment_begin:Ru,lights_fragment_maps:Cu,lights_fragment_end:Lu,logdepthbuf_fragment:Pu,logdepthbuf_pars_fragment:Du,logdepthbuf_pars_vertex:Uu,logdepthbuf_vertex:Iu,map_fragment:Nu,map_pars_fragment:Fu,map_particle_fragment:Ou,map_particle_pars_fragment:zu,metalnessmap_fragment:Bu,metalnessmap_pars_fragment:ku,morphcolor_vertex:Gu,morphnormal_vertex:Hu,morphtarget_pars_vertex:Vu,morphtarget_vertex:Wu,normal_fragment_begin:Xu,normal_fragment_maps:qu,normal_pars_fragment:Yu,normal_pars_vertex:Zu,normal_vertex:ju,normalmap_pars_fragment:Ku,clearcoat_normal_fragment_begin:$u,clearcoat_normal_fragment_maps:Ju,clearcoat_pars_fragment:Qu,iridescence_pars_fragment:ed,opaque_fragment:td,packing:nd,premultiplied_alpha_fragment:id,project_vertex:rd,dithering_fragment:sd,dithering_pars_fragment:od,roughnessmap_fragment:ad,roughnessmap_pars_fragment:cd,shadowmap_pars_fragment:ld,shadowmap_pars_vertex:hd,shadowmap_vertex:ud,shadowmask_pars_fragment:dd,skinbase_vertex:fd,skinning_pars_vertex:pd,skinning_vertex:md,skinnormal_vertex:gd,specularmap_fragment:_d,specularmap_pars_fragment:xd,tonemapping_fragment:vd,tonemapping_pars_fragment:Md,transmission_fragment:yd,transmission_pars_fragment:Sd,uv_pars_fragment:Ed,uv_pars_vertex:bd,uv_vertex:wd,worldpos_vertex:Td,background_vert:Ad,background_frag:Rd,backgroundCube_vert:Cd,backgroundCube_frag:Ld,cube_vert:Pd,cube_frag:Dd,depth_vert:Ud,depth_frag:Id,distanceRGBA_vert:Nd,distanceRGBA_frag:Fd,equirect_vert:Od,equirect_frag:zd,linedashed_vert:Bd,linedashed_frag:kd,meshbasic_vert:Gd,meshbasic_frag:Hd,meshlambert_vert:Vd,meshlambert_frag:Wd,meshmatcap_vert:Xd,meshmatcap_frag:qd,meshnormal_vert:Yd,meshnormal_frag:Zd,meshphong_vert:jd,meshphong_frag:Kd,meshphysical_vert:$d,meshphysical_frag:Jd,meshtoon_vert:Qd,meshtoon_frag:ef,points_vert:tf,points_frag:nf,shadow_vert:rf,shadow_frag:sf,sprite_vert:of,sprite_frag:af},_e={common:{diffuse:{value:new Ze(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new He},alphaMap:{value:null},alphaMapTransform:{value:new He},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new He}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new He}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new He}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new He},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new He},normalScale:{value:new qe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new He},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new He}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new He}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new He}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ze(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ze(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new He},alphaTest:{value:0},uvTransform:{value:new He}},sprite:{diffuse:{value:new Ze(16777215)},opacity:{value:1},center:{value:new qe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new He},alphaMap:{value:null},alphaMapTransform:{value:new He},alphaTest:{value:0}}},Jt={basic:{uniforms:Tt([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.fog]),vertexShader:Ge.meshbasic_vert,fragmentShader:Ge.meshbasic_frag},lambert:{uniforms:Tt([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,_e.lights,{emissive:{value:new Ze(0)}}]),vertexShader:Ge.meshlambert_vert,fragmentShader:Ge.meshlambert_frag},phong:{uniforms:Tt([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,_e.lights,{emissive:{value:new Ze(0)},specular:{value:new Ze(1118481)},shininess:{value:30}}]),vertexShader:Ge.meshphong_vert,fragmentShader:Ge.meshphong_frag},standard:{uniforms:Tt([_e.common,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.roughnessmap,_e.metalnessmap,_e.fog,_e.lights,{emissive:{value:new Ze(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ge.meshphysical_vert,fragmentShader:Ge.meshphysical_frag},toon:{uniforms:Tt([_e.common,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.gradientmap,_e.fog,_e.lights,{emissive:{value:new Ze(0)}}]),vertexShader:Ge.meshtoon_vert,fragmentShader:Ge.meshtoon_frag},matcap:{uniforms:Tt([_e.common,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,{matcap:{value:null}}]),vertexShader:Ge.meshmatcap_vert,fragmentShader:Ge.meshmatcap_frag},points:{uniforms:Tt([_e.points,_e.fog]),vertexShader:Ge.points_vert,fragmentShader:Ge.points_frag},dashed:{uniforms:Tt([_e.common,_e.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ge.linedashed_vert,fragmentShader:Ge.linedashed_frag},depth:{uniforms:Tt([_e.common,_e.displacementmap]),vertexShader:Ge.depth_vert,fragmentShader:Ge.depth_frag},normal:{uniforms:Tt([_e.common,_e.bumpmap,_e.normalmap,_e.displacementmap,{opacity:{value:1}}]),vertexShader:Ge.meshnormal_vert,fragmentShader:Ge.meshnormal_frag},sprite:{uniforms:Tt([_e.sprite,_e.fog]),vertexShader:Ge.sprite_vert,fragmentShader:Ge.sprite_frag},background:{uniforms:{uvTransform:{value:new He},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ge.background_vert,fragmentShader:Ge.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ge.backgroundCube_vert,fragmentShader:Ge.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ge.cube_vert,fragmentShader:Ge.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ge.equirect_vert,fragmentShader:Ge.equirect_frag},distanceRGBA:{uniforms:Tt([_e.common,_e.displacementmap,{referencePosition:{value:new O},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ge.distanceRGBA_vert,fragmentShader:Ge.distanceRGBA_frag},shadow:{uniforms:Tt([_e.lights,_e.fog,{color:{value:new Ze(0)},opacity:{value:1}}]),vertexShader:Ge.shadow_vert,fragmentShader:Ge.shadow_frag}};Jt.physical={uniforms:Tt([Jt.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new He},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new He},clearcoatNormalScale:{value:new qe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new He},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new He},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new He},sheen:{value:0},sheenColor:{value:new Ze(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new He},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new He},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new He},transmissionSamplerSize:{value:new qe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new He},attenuationDistance:{value:0},attenuationColor:{value:new Ze(0)},specularColor:{value:new Ze(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new He},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new He},anisotropyVector:{value:new qe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new He}}]),vertexShader:Ge.meshphysical_vert,fragmentShader:Ge.meshphysical_frag};const _r={r:0,b:0,g:0};function cf(n,e,t,i,r,s,a){const o=new Ze(0);let c=s===!0?0:1,l,d,h=null,u=0,m=null;function M(p,f){let _=!1,x=f.isScene===!0?f.background:null;x&&x.isTexture&&(x=(f.backgroundBlurriness>0?t:e).get(x)),x===null?g(o,c):x&&x.isColor&&(g(x,1),_=!0);const v=n.xr.getEnvironmentBlendMode();v==="additive"?i.buffers.color.setClear(0,0,0,1,a):v==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||_)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),x&&(x.isCubeTexture||x.mapping===Fr)?(d===void 0&&(d=new Ne(new Mt(1,1,1),new Wn({name:"BackgroundCubeMaterial",uniforms:vi(Jt.backgroundCube.uniforms),vertexShader:Jt.backgroundCube.vertexShader,fragmentShader:Jt.backgroundCube.fragmentShader,side:Pt,depthTest:!1,depthWrite:!1,fog:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(R,L,C){this.matrixWorld.copyPosition(C.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(d)),d.material.uniforms.envMap.value=x,d.material.uniforms.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,d.material.toneMapped=je.getTransfer(x.colorSpace)!==tt,(h!==x||u!==x.version||m!==n.toneMapping)&&(d.material.needsUpdate=!0,h=x,u=x.version,m=n.toneMapping),d.layers.enableAll(),p.unshift(d,d.geometry,d.material,0,0,null)):x&&x.isTexture&&(l===void 0&&(l=new Ne(new En(2,2),new Wn({name:"BackgroundMaterial",uniforms:vi(Jt.background.uniforms),vertexShader:Jt.background.vertexShader,fragmentShader:Jt.background.fragmentShader,side:cn,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(l)),l.material.uniforms.t2D.value=x,l.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,l.material.toneMapped=je.getTransfer(x.colorSpace)!==tt,x.matrixAutoUpdate===!0&&x.updateMatrix(),l.material.uniforms.uvTransform.value.copy(x.matrix),(h!==x||u!==x.version||m!==n.toneMapping)&&(l.material.needsUpdate=!0,h=x,u=x.version,m=n.toneMapping),l.layers.enableAll(),p.unshift(l,l.geometry,l.material,0,0,null))}function g(p,f){p.getRGB(_r,xc(n)),i.buffers.color.setClear(_r.r,_r.g,_r.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(p,f=1){o.set(p),c=f,g(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(p){c=p,g(o,c)},render:M}}function lf(n,e,t,i){const r=n.getParameter(n.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},c=p(null);let l=c,d=!1;function h(D,I,G,X,Q){let ne=!1;if(a){const te=g(X,G,I);l!==te&&(l=te,m(l.object)),ne=f(D,X,G,Q),ne&&_(D,X,G,Q)}else{const te=I.wireframe===!0;(l.geometry!==X.id||l.program!==G.id||l.wireframe!==te)&&(l.geometry=X.id,l.program=G.id,l.wireframe=te,ne=!0)}Q!==null&&t.update(Q,n.ELEMENT_ARRAY_BUFFER),(ne||d)&&(d=!1,z(D,I,G,X),Q!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,t.get(Q).buffer))}function u(){return i.isWebGL2?n.createVertexArray():s.createVertexArrayOES()}function m(D){return i.isWebGL2?n.bindVertexArray(D):s.bindVertexArrayOES(D)}function M(D){return i.isWebGL2?n.deleteVertexArray(D):s.deleteVertexArrayOES(D)}function g(D,I,G){const X=G.wireframe===!0;let Q=o[D.id];Q===void 0&&(Q={},o[D.id]=Q);let ne=Q[I.id];ne===void 0&&(ne={},Q[I.id]=ne);let te=ne[X];return te===void 0&&(te=p(u()),ne[X]=te),te}function p(D){const I=[],G=[],X=[];for(let Q=0;Q<r;Q++)I[Q]=0,G[Q]=0,X[Q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:G,attributeDivisors:X,object:D,attributes:{},index:null}}function f(D,I,G,X){const Q=l.attributes,ne=I.attributes;let te=0;const he=G.getAttributes();for(const fe in he)if(he[fe].location>=0){const re=Q[fe];let me=ne[fe];if(me===void 0&&(fe==="instanceMatrix"&&D.instanceMatrix&&(me=D.instanceMatrix),fe==="instanceColor"&&D.instanceColor&&(me=D.instanceColor)),re===void 0||re.attribute!==me||me&&re.data!==me.data)return!0;te++}return l.attributesNum!==te||l.index!==X}function _(D,I,G,X){const Q={},ne=I.attributes;let te=0;const he=G.getAttributes();for(const fe in he)if(he[fe].location>=0){let re=ne[fe];re===void 0&&(fe==="instanceMatrix"&&D.instanceMatrix&&(re=D.instanceMatrix),fe==="instanceColor"&&D.instanceColor&&(re=D.instanceColor));const me={};me.attribute=re,re&&re.data&&(me.data=re.data),Q[fe]=me,te++}l.attributes=Q,l.attributesNum=te,l.index=X}function x(){const D=l.newAttributes;for(let I=0,G=D.length;I<G;I++)D[I]=0}function v(D){R(D,0)}function R(D,I){const G=l.newAttributes,X=l.enabledAttributes,Q=l.attributeDivisors;G[D]=1,X[D]===0&&(n.enableVertexAttribArray(D),X[D]=1),Q[D]!==I&&((i.isWebGL2?n:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](D,I),Q[D]=I)}function L(){const D=l.newAttributes,I=l.enabledAttributes;for(let G=0,X=I.length;G<X;G++)I[G]!==D[G]&&(n.disableVertexAttribArray(G),I[G]=0)}function C(D,I,G,X,Q,ne,te){te===!0?n.vertexAttribIPointer(D,I,G,Q,ne):n.vertexAttribPointer(D,I,G,X,Q,ne)}function z(D,I,G,X){if(i.isWebGL2===!1&&(D.isInstancedMesh||X.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;x();const Q=X.attributes,ne=G.getAttributes(),te=I.defaultAttributeValues;for(const he in ne){const fe=ne[he];if(fe.location>=0){let K=Q[he];if(K===void 0&&(he==="instanceMatrix"&&D.instanceMatrix&&(K=D.instanceMatrix),he==="instanceColor"&&D.instanceColor&&(K=D.instanceColor)),K!==void 0){const re=K.normalized,me=K.itemSize,we=t.get(K);if(we===void 0)continue;const Se=we.buffer,Fe=we.type,Oe=we.bytesPerElement,Le=i.isWebGL2===!0&&(Fe===n.INT||Fe===n.UNSIGNED_INT||K.gpuType===tc);if(K.isInterleavedBufferAttribute){const S=K.data,y=S.stride,k=K.offset;if(S.isInstancedInterleavedBuffer){for(let N=0;N<fe.locationSize;N++)R(fe.location+N,S.meshPerAttribute);D.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=S.meshPerAttribute*S.count)}else for(let N=0;N<fe.locationSize;N++)v(fe.location+N);n.bindBuffer(n.ARRAY_BUFFER,Se);for(let N=0;N<fe.locationSize;N++)C(fe.location+N,me/fe.locationSize,Fe,re,y*Oe,(k+me/fe.locationSize*N)*Oe,Le)}else{if(K.isInstancedBufferAttribute){for(let S=0;S<fe.locationSize;S++)R(fe.location+S,K.meshPerAttribute);D.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=K.meshPerAttribute*K.count)}else for(let S=0;S<fe.locationSize;S++)v(fe.location+S);n.bindBuffer(n.ARRAY_BUFFER,Se);for(let S=0;S<fe.locationSize;S++)C(fe.location+S,me/fe.locationSize,Fe,re,me*Oe,me/fe.locationSize*S*Oe,Le)}}else if(te!==void 0){const re=te[he];if(re!==void 0)switch(re.length){case 2:n.vertexAttrib2fv(fe.location,re);break;case 3:n.vertexAttrib3fv(fe.location,re);break;case 4:n.vertexAttrib4fv(fe.location,re);break;default:n.vertexAttrib1fv(fe.location,re)}}}}L()}function b(){U();for(const D in o){const I=o[D];for(const G in I){const X=I[G];for(const Q in X)M(X[Q].object),delete X[Q];delete I[G]}delete o[D]}}function T(D){if(o[D.id]===void 0)return;const I=o[D.id];for(const G in I){const X=I[G];for(const Q in X)M(X[Q].object),delete X[Q];delete I[G]}delete o[D.id]}function H(D){for(const I in o){const G=o[I];if(G[D.id]===void 0)continue;const X=G[D.id];for(const Q in X)M(X[Q].object),delete X[Q];delete G[D.id]}}function U(){Y(),d=!0,l!==c&&(l=c,m(l.object))}function Y(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:h,reset:U,resetDefaultState:Y,dispose:b,releaseStatesOfGeometry:T,releaseStatesOfProgram:H,initAttributes:x,enableAttribute:v,disableUnusedAttributes:L}}function hf(n,e,t,i){const r=i.isWebGL2;let s;function a(d){s=d}function o(d,h){n.drawArrays(s,d,h),t.update(h,s,1)}function c(d,h,u){if(u===0)return;let m,M;if(r)m=n,M="drawArraysInstanced";else if(m=e.get("ANGLE_instanced_arrays"),M="drawArraysInstancedANGLE",m===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[M](s,d,h,u),t.update(h,s,u)}function l(d,h,u){if(u===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let M=0;M<u;M++)this.render(d[M],h[M]);else{m.multiDrawArraysWEBGL(s,d,0,h,0,u);let M=0;for(let g=0;g<u;g++)M+=h[g];t.update(M,s,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function uf(n,e,t){let i;function r(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const C=e.get("EXT_texture_filter_anisotropic");i=n.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function s(C){if(C==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext";let o=t.precision!==void 0?t.precision:"highp";const c=s(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);const l=a||e.has("WEBGL_draw_buffers"),d=t.logarithmicDepthBuffer===!0,h=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),u=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),m=n.getParameter(n.MAX_TEXTURE_SIZE),M=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),g=n.getParameter(n.MAX_VERTEX_ATTRIBS),p=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),f=n.getParameter(n.MAX_VARYING_VECTORS),_=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),x=u>0,v=a||e.has("OES_texture_float"),R=x&&v,L=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:r,getMaxPrecision:s,precision:o,logarithmicDepthBuffer:d,maxTextures:h,maxVertexTextures:u,maxTextureSize:m,maxCubemapSize:M,maxAttributes:g,maxVertexUniforms:p,maxVaryings:f,maxFragmentUniforms:_,vertexTextures:x,floatFragmentTextures:v,floatVertexTextures:R,maxSamples:L}}function df(n){const e=this;let t=null,i=0,r=!1,s=!1;const a=new Nn,o=new He,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const m=h.length!==0||u||i!==0||r;return r=u,i=h.length,m},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(h,u){t=d(h,u,0)},this.setState=function(h,u,m){const M=h.clippingPlanes,g=h.clipIntersection,p=h.clipShadows,f=n.get(h);if(!r||M===null||M.length===0||s&&!p)s?d(null):l();else{const _=s?0:i,x=_*4;let v=f.clippingState||null;c.value=v,v=d(M,u,x,m);for(let R=0;R!==x;++R)v[R]=t[R];f.clippingState=v,this.numIntersection=g?this.numPlanes:0,this.numPlanes+=_}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function d(h,u,m,M){const g=h!==null?h.length:0;let p=null;if(g!==0){if(p=c.value,M!==!0||p===null){const f=m+g*4,_=u.matrixWorldInverse;o.getNormalMatrix(_),(p===null||p.length<f)&&(p=new Float32Array(f));for(let x=0,v=m;x!==g;++x,v+=4)a.copy(h[x]).applyMatrix4(_,o),a.normal.toArray(p,v),p[v+3]=a.constant}c.value=p,c.needsUpdate=!0}return e.numPlanes=g,e.numIntersection=0,p}}function ff(n){let e=new WeakMap;function t(a,o){return o===Ds?a.mapping=gi:o===Us&&(a.mapping=_i),a}function i(a){if(a&&a.isTexture){const o=a.mapping;if(o===Ds||o===Us)if(e.has(a)){const c=e.get(a).texture;return t(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new bh(c.height/2);return l.fromEquirectangularTexture(n,a),e.set(a,l),a.addEventListener("dispose",r),t(l.texture,a.mapping)}else return null}}return a}function r(a){const o=a.target;o.removeEventListener("dispose",r);const c=e.get(o);c!==void 0&&(e.delete(o),c.dispose())}function s(){e=new WeakMap}return{get:i,dispose:s}}class Sc extends vc{constructor(e=-1,t=1,i=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=i-e,a=i+e,o=r+t,c=r-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,o-=d*this.view.offsetY,c=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const li=4,da=[.125,.215,.35,.446,.526,.582],zn=20,vs=new Sc,fa=new Ze;let Ms=null,ys=0,Ss=0;const Fn=(1+Math.sqrt(5))/2,ai=1/Fn,pa=[new O(1,1,1),new O(-1,1,1),new O(1,1,-1),new O(-1,1,-1),new O(0,Fn,ai),new O(0,Fn,-ai),new O(ai,0,Fn),new O(-ai,0,Fn),new O(Fn,ai,0),new O(-Fn,ai,0)];class ma{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,r=100){Ms=this._renderer.getRenderTarget(),ys=this._renderer.getActiveCubeFace(),Ss=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,r,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=xa(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=_a(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Ms,ys,Ss),e.scissorTest=!1,xr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===gi||e.mapping===_i?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Ms=this._renderer.getRenderTarget(),ys=this._renderer.getActiveCubeFace(),Ss=this._renderer.getActiveMipmapLevel();const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:kt,minFilter:kt,generateMipmaps:!1,type:ki,format:Zt,colorSpace:ln,depthBuffer:!1},r=ga(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=ga(e,t,i);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=pf(s)),this._blurMaterial=mf(s,e,t)}return r}_compileMaterial(e){const t=new Ne(this._lodPlanes[0],e);this._renderer.compile(t,vs)}_sceneToCubeUV(e,t,i,r){const o=new Gt(90,1,t,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],d=this._renderer,h=d.autoClear,u=d.toneMapping;d.getClearColor(fa),d.toneMapping=yn,d.autoClear=!1;const m=new pi({name:"PMREM.Background",side:Pt,depthWrite:!1,depthTest:!1}),M=new Ne(new Mt,m);let g=!1;const p=e.background;p?p.isColor&&(m.color.copy(p),e.background=null,g=!0):(m.color.copy(fa),g=!0);for(let f=0;f<6;f++){const _=f%3;_===0?(o.up.set(0,c[f],0),o.lookAt(l[f],0,0)):_===1?(o.up.set(0,0,c[f]),o.lookAt(0,l[f],0)):(o.up.set(0,c[f],0),o.lookAt(0,0,l[f]));const x=this._cubeSize;xr(r,_*x,f>2?x:0,x,x),d.setRenderTarget(r),g&&d.render(M,o),d.render(e,o)}M.geometry.dispose(),M.material.dispose(),d.toneMapping=u,d.autoClear=h,e.background=p}_textureToCubeUV(e,t){const i=this._renderer,r=e.mapping===gi||e.mapping===_i;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=xa()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=_a());const s=r?this._cubemapMaterial:this._equirectMaterial,a=new Ne(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;const c=this._cubeSize;xr(t,0,0,3*c,2*c),i.setRenderTarget(t),i.render(a,vs)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let r=1;r<this._lodPlanes.length;r++){const s=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=pa[(r-1)%pa.length];this._blur(e,r-1,r,s,a)}t.autoClear=i}_blur(e,t,i,r,s){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,r,"latitudinal",s),this._halfBlur(a,e,i,i,r,"longitudinal",s)}_halfBlur(e,t,i,r,s,a,o){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,h=new Ne(this._lodPlanes[r],l),u=l.uniforms,m=this._sizeLods[i]-1,M=isFinite(s)?Math.PI/(2*m):2*Math.PI/(2*zn-1),g=s/M,p=isFinite(s)?1+Math.floor(d*g):zn;p>zn&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${zn}`);const f=[];let _=0;for(let C=0;C<zn;++C){const z=C/g,b=Math.exp(-z*z/2);f.push(b),C===0?_+=b:C<p&&(_+=2*b)}for(let C=0;C<f.length;C++)f[C]=f[C]/_;u.envMap.value=e.texture,u.samples.value=p,u.weights.value=f,u.latitudinal.value=a==="latitudinal",o&&(u.poleAxis.value=o);const{_lodMax:x}=this;u.dTheta.value=M,u.mipInt.value=x-i;const v=this._sizeLods[r],R=3*v*(r>x-li?r-x+li:0),L=4*(this._cubeSize-v);xr(t,R,L,3*v,2*v),c.setRenderTarget(t),c.render(h,vs)}}function pf(n){const e=[],t=[],i=[];let r=n;const s=n-li+1+da.length;for(let a=0;a<s;a++){const o=Math.pow(2,r);t.push(o);let c=1/o;a>n-li?c=da[a-n+li-1]:a===0&&(c=0),i.push(c);const l=1/(o-2),d=-l,h=1+l,u=[d,d,h,d,h,h,d,d,h,h,d,h],m=6,M=6,g=3,p=2,f=1,_=new Float32Array(g*M*m),x=new Float32Array(p*M*m),v=new Float32Array(f*M*m);for(let L=0;L<m;L++){const C=L%3*2/3-1,z=L>2?0:-1,b=[C,z,0,C+2/3,z,0,C+2/3,z+1,0,C,z,0,C+2/3,z+1,0,C,z+1,0];_.set(b,g*M*L),x.set(u,p*M*L);const T=[L,L,L,L,L,L];v.set(T,f*M*L)}const R=new it;R.setAttribute("position",new jt(_,g)),R.setAttribute("uv",new jt(x,p)),R.setAttribute("faceIndex",new jt(v,f)),e.push(R),r>li&&r--}return{lodPlanes:e,sizeLods:t,sigmas:i}}function ga(n,e,t){const i=new Vn(n,e,t);return i.texture.mapping=Fr,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function xr(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function mf(n,e,t){const i=new Float32Array(zn),r=new O(0,1,0);return new Wn({name:"SphericalGaussianBlur",defines:{n:zn,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Ks(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function _a(){return new Wn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ks(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function xa(){return new Wn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ks(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Mn,depthTest:!1,depthWrite:!1})}function Ks(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function gf(n){let e=new WeakMap,t=null;function i(o){if(o&&o.isTexture){const c=o.mapping,l=c===Ds||c===Us,d=c===gi||c===_i;if(l||d)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let h=e.get(o);return t===null&&(t=new ma(n)),h=l?t.fromEquirectangular(o,h):t.fromCubemap(o,h),e.set(o,h),h.texture}else{if(e.has(o))return e.get(o).texture;{const h=o.image;if(l&&h&&h.height>0||d&&h&&r(h)){t===null&&(t=new ma(n));const u=l?t.fromEquirectangular(o):t.fromCubemap(o);return e.set(o,u),o.addEventListener("dispose",s),u.texture}else return null}}}return o}function r(o){let c=0;const l=6;for(let d=0;d<l;d++)o[d]!==void 0&&c++;return c===l}function s(o){const c=o.target;c.removeEventListener("dispose",s);const l=e.get(c);l!==void 0&&(e.delete(c),l.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:a}}function _f(n){const e={};function t(i){if(e[i]!==void 0)return e[i];let r;switch(i){case"WEBGL_depth_texture":r=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=n.getExtension(i)}return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){const r=t(i);return r===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),r}}}function xf(n,e,t,i){const r={},s=new WeakMap;function a(h){const u=h.target;u.index!==null&&e.remove(u.index);for(const M in u.attributes)e.remove(u.attributes[M]);for(const M in u.morphAttributes){const g=u.morphAttributes[M];for(let p=0,f=g.length;p<f;p++)e.remove(g[p])}u.removeEventListener("dispose",a),delete r[u.id];const m=s.get(u);m&&(e.remove(m),s.delete(u)),i.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,t.memory.geometries--}function o(h,u){return r[u.id]===!0||(u.addEventListener("dispose",a),r[u.id]=!0,t.memory.geometries++),u}function c(h){const u=h.attributes;for(const M in u)e.update(u[M],n.ARRAY_BUFFER);const m=h.morphAttributes;for(const M in m){const g=m[M];for(let p=0,f=g.length;p<f;p++)e.update(g[p],n.ARRAY_BUFFER)}}function l(h){const u=[],m=h.index,M=h.attributes.position;let g=0;if(m!==null){const _=m.array;g=m.version;for(let x=0,v=_.length;x<v;x+=3){const R=_[x+0],L=_[x+1],C=_[x+2];u.push(R,L,L,C,C,R)}}else if(M!==void 0){const _=M.array;g=M.version;for(let x=0,v=_.length/3-1;x<v;x+=3){const R=x+0,L=x+1,C=x+2;u.push(R,L,L,C,C,R)}}else return;const p=new(uc(u)?_c:gc)(u,1);p.version=g;const f=s.get(h);f&&e.remove(f),s.set(h,p)}function d(h){const u=s.get(h);if(u){const m=h.index;m!==null&&u.version<m.version&&l(h)}else l(h);return s.get(h)}return{get:o,update:c,getWireframeAttribute:d}}function vf(n,e,t,i){const r=i.isWebGL2;let s;function a(m){s=m}let o,c;function l(m){o=m.type,c=m.bytesPerElement}function d(m,M){n.drawElements(s,M,o,m*c),t.update(M,s,1)}function h(m,M,g){if(g===0)return;let p,f;if(r)p=n,f="drawElementsInstanced";else if(p=e.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",p===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[f](s,M,o,m*c,g),t.update(M,s,g)}function u(m,M,g){if(g===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let f=0;f<g;f++)this.render(m[f]/c,M[f]);else{p.multiDrawElementsWEBGL(s,M,0,o,m,0,g);let f=0;for(let _=0;_<g;_++)f+=M[_];t.update(f,s,1)}}this.setMode=a,this.setIndex=l,this.render=d,this.renderInstances=h,this.renderMultiDraw=u}function Mf(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,a,o){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=o*(s/3);break;case n.LINES:t.lines+=o*(s/2);break;case n.LINE_STRIP:t.lines+=o*(s-1);break;case n.LINE_LOOP:t.lines+=o*s;break;case n.POINTS:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function yf(n,e){return n[0]-e[0]}function Sf(n,e){return Math.abs(e[1])-Math.abs(n[1])}function Ef(n,e,t){const i={},r=new Float32Array(8),s=new WeakMap,a=new _t,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,d,h){const u=l.morphTargetInfluences;if(e.isWebGL2===!0){const M=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,g=M!==void 0?M.length:0;let p=s.get(d);if(p===void 0||p.count!==g){let I=function(){Y.dispose(),s.delete(d),d.removeEventListener("dispose",I)};var m=I;p!==void 0&&p.texture.dispose();const x=d.morphAttributes.position!==void 0,v=d.morphAttributes.normal!==void 0,R=d.morphAttributes.color!==void 0,L=d.morphAttributes.position||[],C=d.morphAttributes.normal||[],z=d.morphAttributes.color||[];let b=0;x===!0&&(b=1),v===!0&&(b=2),R===!0&&(b=3);let T=d.attributes.position.count*b,H=1;T>e.maxTextureSize&&(H=Math.ceil(T/e.maxTextureSize),T=e.maxTextureSize);const U=new Float32Array(T*H*4*g),Y=new pc(U,T,H,g);Y.type=vn,Y.needsUpdate=!0;const D=b*4;for(let G=0;G<g;G++){const X=L[G],Q=C[G],ne=z[G],te=T*H*4*G;for(let he=0;he<X.count;he++){const fe=he*D;x===!0&&(a.fromBufferAttribute(X,he),U[te+fe+0]=a.x,U[te+fe+1]=a.y,U[te+fe+2]=a.z,U[te+fe+3]=0),v===!0&&(a.fromBufferAttribute(Q,he),U[te+fe+4]=a.x,U[te+fe+5]=a.y,U[te+fe+6]=a.z,U[te+fe+7]=0),R===!0&&(a.fromBufferAttribute(ne,he),U[te+fe+8]=a.x,U[te+fe+9]=a.y,U[te+fe+10]=a.z,U[te+fe+11]=ne.itemSize===4?a.w:1)}}p={count:g,texture:Y,size:new qe(T,H)},s.set(d,p),d.addEventListener("dispose",I)}let f=0;for(let x=0;x<u.length;x++)f+=u[x];const _=d.morphTargetsRelative?1:1-f;h.getUniforms().setValue(n,"morphTargetBaseInfluence",_),h.getUniforms().setValue(n,"morphTargetInfluences",u),h.getUniforms().setValue(n,"morphTargetsTexture",p.texture,t),h.getUniforms().setValue(n,"morphTargetsTextureSize",p.size)}else{const M=u===void 0?0:u.length;let g=i[d.id];if(g===void 0||g.length!==M){g=[];for(let v=0;v<M;v++)g[v]=[v,0];i[d.id]=g}for(let v=0;v<M;v++){const R=g[v];R[0]=v,R[1]=u[v]}g.sort(Sf);for(let v=0;v<8;v++)v<M&&g[v][1]?(o[v][0]=g[v][0],o[v][1]=g[v][1]):(o[v][0]=Number.MAX_SAFE_INTEGER,o[v][1]=0);o.sort(yf);const p=d.morphAttributes.position,f=d.morphAttributes.normal;let _=0;for(let v=0;v<8;v++){const R=o[v],L=R[0],C=R[1];L!==Number.MAX_SAFE_INTEGER&&C?(p&&d.getAttribute("morphTarget"+v)!==p[L]&&d.setAttribute("morphTarget"+v,p[L]),f&&d.getAttribute("morphNormal"+v)!==f[L]&&d.setAttribute("morphNormal"+v,f[L]),r[v]=C,_+=C):(p&&d.hasAttribute("morphTarget"+v)===!0&&d.deleteAttribute("morphTarget"+v),f&&d.hasAttribute("morphNormal"+v)===!0&&d.deleteAttribute("morphNormal"+v),r[v]=0)}const x=d.morphTargetsRelative?1:1-_;h.getUniforms().setValue(n,"morphTargetBaseInfluence",x),h.getUniforms().setValue(n,"morphTargetInfluences",r)}}return{update:c}}function bf(n,e,t,i){let r=new WeakMap;function s(c){const l=i.render.frame,d=c.geometry,h=e.get(c,d);if(r.get(h)!==l&&(e.update(h),r.set(h,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),r.get(c)!==l&&(t.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,n.ARRAY_BUFFER),r.set(c,l))),c.isSkinnedMesh){const u=c.skeleton;r.get(u)!==l&&(u.update(),r.set(u,l))}return h}function a(){r=new WeakMap}function o(c){const l=c.target;l.removeEventListener("dispose",o),t.remove(l.instanceMatrix),l.instanceColor!==null&&t.remove(l.instanceColor)}return{update:s,dispose:a}}class Ec extends Dt{constructor(e,t,i,r,s,a,o,c,l,d){if(d=d!==void 0?d:Gn,d!==Gn&&d!==xi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&d===Gn&&(i=xn),i===void 0&&d===xi&&(i=kn),super(null,r,s,a,o,c,d,i,l),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:At,this.minFilter=c!==void 0?c:At,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const bc=new Dt,wc=new Ec(1,1);wc.compareFunction=hc;const Tc=new pc,Ac=new ah,Rc=new Mc,va=[],Ma=[],ya=new Float32Array(16),Sa=new Float32Array(9),Ea=new Float32Array(4);function Ei(n,e,t){const i=n[0];if(i<=0||i>0)return n;const r=e*t;let s=va[r];if(s===void 0&&(s=new Float32Array(r),va[r]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,n[a].toArray(s,o)}return s}function dt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function ft(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function kr(n,e){let t=Ma[e];t===void 0&&(t=new Int32Array(e),Ma[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function wf(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function Tf(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(dt(t,e))return;n.uniform2fv(this.addr,e),ft(t,e)}}function Af(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(dt(t,e))return;n.uniform3fv(this.addr,e),ft(t,e)}}function Rf(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(dt(t,e))return;n.uniform4fv(this.addr,e),ft(t,e)}}function Cf(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(dt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),ft(t,e)}else{if(dt(t,i))return;Ea.set(i),n.uniformMatrix2fv(this.addr,!1,Ea),ft(t,i)}}function Lf(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(dt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),ft(t,e)}else{if(dt(t,i))return;Sa.set(i),n.uniformMatrix3fv(this.addr,!1,Sa),ft(t,i)}}function Pf(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(dt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),ft(t,e)}else{if(dt(t,i))return;ya.set(i),n.uniformMatrix4fv(this.addr,!1,ya),ft(t,i)}}function Df(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function Uf(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(dt(t,e))return;n.uniform2iv(this.addr,e),ft(t,e)}}function If(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(dt(t,e))return;n.uniform3iv(this.addr,e),ft(t,e)}}function Nf(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(dt(t,e))return;n.uniform4iv(this.addr,e),ft(t,e)}}function Ff(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function Of(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(dt(t,e))return;n.uniform2uiv(this.addr,e),ft(t,e)}}function zf(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(dt(t,e))return;n.uniform3uiv(this.addr,e),ft(t,e)}}function Bf(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(dt(t,e))return;n.uniform4uiv(this.addr,e),ft(t,e)}}function kf(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);const s=this.type===n.SAMPLER_2D_SHADOW?wc:bc;t.setTexture2D(e||s,r)}function Gf(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||Ac,r)}function Hf(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||Rc,r)}function Vf(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||Tc,r)}function Wf(n){switch(n){case 5126:return wf;case 35664:return Tf;case 35665:return Af;case 35666:return Rf;case 35674:return Cf;case 35675:return Lf;case 35676:return Pf;case 5124:case 35670:return Df;case 35667:case 35671:return Uf;case 35668:case 35672:return If;case 35669:case 35673:return Nf;case 5125:return Ff;case 36294:return Of;case 36295:return zf;case 36296:return Bf;case 35678:case 36198:case 36298:case 36306:case 35682:return kf;case 35679:case 36299:case 36307:return Gf;case 35680:case 36300:case 36308:case 36293:return Hf;case 36289:case 36303:case 36311:case 36292:return Vf}}function Xf(n,e){n.uniform1fv(this.addr,e)}function qf(n,e){const t=Ei(e,this.size,2);n.uniform2fv(this.addr,t)}function Yf(n,e){const t=Ei(e,this.size,3);n.uniform3fv(this.addr,t)}function Zf(n,e){const t=Ei(e,this.size,4);n.uniform4fv(this.addr,t)}function jf(n,e){const t=Ei(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function Kf(n,e){const t=Ei(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function $f(n,e){const t=Ei(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function Jf(n,e){n.uniform1iv(this.addr,e)}function Qf(n,e){n.uniform2iv(this.addr,e)}function ep(n,e){n.uniform3iv(this.addr,e)}function tp(n,e){n.uniform4iv(this.addr,e)}function np(n,e){n.uniform1uiv(this.addr,e)}function ip(n,e){n.uniform2uiv(this.addr,e)}function rp(n,e){n.uniform3uiv(this.addr,e)}function sp(n,e){n.uniform4uiv(this.addr,e)}function op(n,e,t){const i=this.cache,r=e.length,s=kr(t,r);dt(i,s)||(n.uniform1iv(this.addr,s),ft(i,s));for(let a=0;a!==r;++a)t.setTexture2D(e[a]||bc,s[a])}function ap(n,e,t){const i=this.cache,r=e.length,s=kr(t,r);dt(i,s)||(n.uniform1iv(this.addr,s),ft(i,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||Ac,s[a])}function cp(n,e,t){const i=this.cache,r=e.length,s=kr(t,r);dt(i,s)||(n.uniform1iv(this.addr,s),ft(i,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||Rc,s[a])}function lp(n,e,t){const i=this.cache,r=e.length,s=kr(t,r);dt(i,s)||(n.uniform1iv(this.addr,s),ft(i,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||Tc,s[a])}function hp(n){switch(n){case 5126:return Xf;case 35664:return qf;case 35665:return Yf;case 35666:return Zf;case 35674:return jf;case 35675:return Kf;case 35676:return $f;case 5124:case 35670:return Jf;case 35667:case 35671:return Qf;case 35668:case 35672:return ep;case 35669:case 35673:return tp;case 5125:return np;case 36294:return ip;case 36295:return rp;case 36296:return sp;case 35678:case 36198:case 36298:case 36306:case 35682:return op;case 35679:case 36299:case 36307:return ap;case 35680:case 36300:case 36308:case 36293:return cp;case 36289:case 36303:case 36311:case 36292:return lp}}class up{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=Wf(t.type)}}class dp{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=hp(t.type)}}class fp{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],i)}}}const Es=/(\w+)(\])?(\[|\.)?/g;function ba(n,e){n.seq.push(e),n.map[e.id]=e}function pp(n,e,t){const i=n.name,r=i.length;for(Es.lastIndex=0;;){const s=Es.exec(i),a=Es.lastIndex;let o=s[1];const c=s[2]==="]",l=s[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===r){ba(t,l===void 0?new up(o,n,e):new dp(o,n,e));break}else{let h=t.map[o];h===void 0&&(h=new fp(o),ba(t,h)),t=h}}}class br{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<i;++r){const s=e.getActiveUniform(t,r),a=e.getUniformLocation(t,s.name);pp(s,a,this)}}setValue(e,t,i,r){const s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){const r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],c=i[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,r)}}static seqWithValue(e,t){const i=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&i.push(a)}return i}}function wa(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const mp=37297;let gp=0;function _p(n,e){const t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;i.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return i.join(`
`)}function xp(n){const e=je.getPrimaries(je.workingColorSpace),t=je.getPrimaries(n);let i;switch(e===t?i="":e===Pr&&t===Lr?i="LinearDisplayP3ToLinearSRGB":e===Lr&&t===Pr&&(i="LinearSRGBToLinearDisplayP3"),n){case ln:case Or:return[i,"LinearTransferOETF"];case lt:case Ys:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function Ta(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=n.getShaderInfoLog(e).trim();if(i&&r==="")return"";const s=/ERROR: 0:(\d+)/.exec(r);if(s){const a=parseInt(s[1]);return t.toUpperCase()+`

`+r+`

`+_p(n.getShaderSource(e),a)}else return r}function vp(n,e){const t=xp(e);return`vec4 ${n}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function Mp(n,e){let t;switch(e){case Ll:t="Linear";break;case Pl:t="Reinhard";break;case Dl:t="OptimizedCineon";break;case Ul:t="ACESFilmic";break;case Nl:t="AgX";break;case Il:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function yp(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(hi).join(`
`)}function Sp(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(hi).join(`
`)}function Ep(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function bp(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const s=n.getActiveAttrib(e,r),a=s.name;let o=1;s.type===n.FLOAT_MAT2&&(o=2),s.type===n.FLOAT_MAT3&&(o=3),s.type===n.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:n.getAttribLocation(e,a),locationSize:o}}return t}function hi(n){return n!==""}function Aa(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Ra(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const wp=/^[ \t]*#include +<([\w\d./]+)>/gm;function Bs(n){return n.replace(wp,Ap)}const Tp=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Ap(n,e){let t=Ge[e];if(t===void 0){const i=Tp.get(e);if(i!==void 0)t=Ge[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return Bs(t)}const Rp=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Ca(n){return n.replace(Rp,Cp)}function Cp(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function La(n){let e="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Lp(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===Qa?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===rl?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===on&&(e="SHADOWMAP_TYPE_VSM"),e}function Pp(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case gi:case _i:e="ENVMAP_TYPE_CUBE";break;case Fr:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Dp(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case _i:e="ENVMAP_MODE_REFRACTION";break}return e}function Up(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Xs:e="ENVMAP_BLENDING_MULTIPLY";break;case Rl:e="ENVMAP_BLENDING_MIX";break;case Cl:e="ENVMAP_BLENDING_ADD";break}return e}function Ip(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Np(n,e,t,i){const r=n.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const c=Lp(t),l=Pp(t),d=Dp(t),h=Up(t),u=Ip(t),m=t.isWebGL2?"":yp(t),M=Sp(t),g=Ep(s),p=r.createProgram();let f,_,x=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(hi).join(`
`),f.length>0&&(f+=`
`),_=[m,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(hi).join(`
`),_.length>0&&(_+=`
`)):(f=[La(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(hi).join(`
`),_=[m,La(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+d:"",t.envMap?"#define "+h:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==yn?"#define TONE_MAPPING":"",t.toneMapping!==yn?Ge.tonemapping_pars_fragment:"",t.toneMapping!==yn?Mp("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ge.colorspace_pars_fragment,vp("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(hi).join(`
`)),a=Bs(a),a=Aa(a,t),a=Ra(a,t),o=Bs(o),o=Aa(o,t),o=Ra(o,t),a=Ca(a),o=Ca(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(x=`#version 300 es
`,f=[M,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,_=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===Zo?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Zo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const v=x+f+a,R=x+_+o,L=wa(r,r.VERTEX_SHADER,v),C=wa(r,r.FRAGMENT_SHADER,R);r.attachShader(p,L),r.attachShader(p,C),t.index0AttributeName!==void 0?r.bindAttribLocation(p,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(p,0,"position"),r.linkProgram(p);function z(U){if(n.debug.checkShaderErrors){const Y=r.getProgramInfoLog(p).trim(),D=r.getShaderInfoLog(L).trim(),I=r.getShaderInfoLog(C).trim();let G=!0,X=!0;if(r.getProgramParameter(p,r.LINK_STATUS)===!1)if(G=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,p,L,C);else{const Q=Ta(r,L,"vertex"),ne=Ta(r,C,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(p,r.VALIDATE_STATUS)+`

Program Info Log: `+Y+`
`+Q+`
`+ne)}else Y!==""?console.warn("THREE.WebGLProgram: Program Info Log:",Y):(D===""||I==="")&&(X=!1);X&&(U.diagnostics={runnable:G,programLog:Y,vertexShader:{log:D,prefix:f},fragmentShader:{log:I,prefix:_}})}r.deleteShader(L),r.deleteShader(C),b=new br(r,p),T=bp(r,p)}let b;this.getUniforms=function(){return b===void 0&&z(this),b};let T;this.getAttributes=function(){return T===void 0&&z(this),T};let H=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return H===!1&&(H=r.getProgramParameter(p,mp)),H},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(p),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=gp++,this.cacheKey=e,this.usedTimes=1,this.program=p,this.vertexShader=L,this.fragmentShader=C,this}let Fp=0;class Op{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(r)===!1&&(a.add(r),r.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new zp(e),t.set(e,i)),i}}class zp{constructor(e){this.id=Fp++,this.code=e,this.usedTimes=0}}function Bp(n,e,t,i,r,s,a){const o=new Zs,c=new Op,l=[],d=r.isWebGL2,h=r.logarithmicDepthBuffer,u=r.vertexTextures;let m=r.precision;const M={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function g(b){return b===0?"uv":`uv${b}`}function p(b,T,H,U,Y){const D=U.fog,I=Y.geometry,G=b.isMeshStandardMaterial?U.environment:null,X=(b.isMeshStandardMaterial?t:e).get(b.envMap||G),Q=X&&X.mapping===Fr?X.image.height:null,ne=M[b.type];b.precision!==null&&(m=r.getMaxPrecision(b.precision),m!==b.precision&&console.warn("THREE.WebGLProgram.getParameters:",b.precision,"not supported, using",m,"instead."));const te=I.morphAttributes.position||I.morphAttributes.normal||I.morphAttributes.color,he=te!==void 0?te.length:0;let fe=0;I.morphAttributes.position!==void 0&&(fe=1),I.morphAttributes.normal!==void 0&&(fe=2),I.morphAttributes.color!==void 0&&(fe=3);let K,re,me,we;if(ne){const bt=Jt[ne];K=bt.vertexShader,re=bt.fragmentShader}else K=b.vertexShader,re=b.fragmentShader,c.update(b),me=c.getVertexShaderID(b),we=c.getFragmentShaderID(b);const Se=n.getRenderTarget(),Fe=Y.isInstancedMesh===!0,Oe=Y.isBatchedMesh===!0,Le=!!b.map,S=!!b.matcap,y=!!X,k=!!b.aoMap,N=!!b.lightMap,se=!!b.bumpMap,oe=!!b.normalMap,J=!!b.displacementMap,pe=!!b.emissiveMap,w=!!b.metalnessMap,E=!!b.roughnessMap,F=b.anisotropy>0,$=b.clearcoat>0,q=b.iridescence>0,ee=b.sheen>0,xe=b.transmission>0,ge=F&&!!b.anisotropyMap,ve=$&&!!b.clearcoatMap,Ee=$&&!!b.clearcoatNormalMap,Pe=$&&!!b.clearcoatRoughnessMap,ce=q&&!!b.iridescenceMap,Ye=q&&!!b.iridescenceThicknessMap,ke=ee&&!!b.sheenColorMap,De=ee&&!!b.sheenRoughnessMap,Ae=!!b.specularMap,ye=!!b.specularColorMap,Ue=!!b.specularIntensityMap,ie=xe&&!!b.transmissionMap,ae=xe&&!!b.thicknessMap,ue=!!b.gradientMap,Z=!!b.alphaMap,P=b.alphaTest>0,le=!!b.alphaHash,de=!!b.extensions,be=!!I.attributes.uv1,Re=!!I.attributes.uv2,$e=!!I.attributes.uv3;let Je=yn;return b.toneMapped&&(Se===null||Se.isXRRenderTarget===!0)&&(Je=n.toneMapping),{isWebGL2:d,shaderID:ne,shaderType:b.type,shaderName:b.name,vertexShader:K,fragmentShader:re,defines:b.defines,customVertexShaderID:me,customFragmentShaderID:we,isRawShaderMaterial:b.isRawShaderMaterial===!0,glslVersion:b.glslVersion,precision:m,batching:Oe,instancing:Fe,instancingColor:Fe&&Y.instanceColor!==null,supportsVertexTextures:u,outputColorSpace:Se===null?n.outputColorSpace:Se.isXRRenderTarget===!0?Se.texture.colorSpace:ln,map:Le,matcap:S,envMap:y,envMapMode:y&&X.mapping,envMapCubeUVHeight:Q,aoMap:k,lightMap:N,bumpMap:se,normalMap:oe,displacementMap:u&&J,emissiveMap:pe,normalMapObjectSpace:oe&&b.normalMapType===Yl,normalMapTangentSpace:oe&&b.normalMapType===lc,metalnessMap:w,roughnessMap:E,anisotropy:F,anisotropyMap:ge,clearcoat:$,clearcoatMap:ve,clearcoatNormalMap:Ee,clearcoatRoughnessMap:Pe,iridescence:q,iridescenceMap:ce,iridescenceThicknessMap:Ye,sheen:ee,sheenColorMap:ke,sheenRoughnessMap:De,specularMap:Ae,specularColorMap:ye,specularIntensityMap:Ue,transmission:xe,transmissionMap:ie,thicknessMap:ae,gradientMap:ue,opaque:b.transparent===!1&&b.blending===di,alphaMap:Z,alphaTest:P,alphaHash:le,combine:b.combine,mapUv:Le&&g(b.map.channel),aoMapUv:k&&g(b.aoMap.channel),lightMapUv:N&&g(b.lightMap.channel),bumpMapUv:se&&g(b.bumpMap.channel),normalMapUv:oe&&g(b.normalMap.channel),displacementMapUv:J&&g(b.displacementMap.channel),emissiveMapUv:pe&&g(b.emissiveMap.channel),metalnessMapUv:w&&g(b.metalnessMap.channel),roughnessMapUv:E&&g(b.roughnessMap.channel),anisotropyMapUv:ge&&g(b.anisotropyMap.channel),clearcoatMapUv:ve&&g(b.clearcoatMap.channel),clearcoatNormalMapUv:Ee&&g(b.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Pe&&g(b.clearcoatRoughnessMap.channel),iridescenceMapUv:ce&&g(b.iridescenceMap.channel),iridescenceThicknessMapUv:Ye&&g(b.iridescenceThicknessMap.channel),sheenColorMapUv:ke&&g(b.sheenColorMap.channel),sheenRoughnessMapUv:De&&g(b.sheenRoughnessMap.channel),specularMapUv:Ae&&g(b.specularMap.channel),specularColorMapUv:ye&&g(b.specularColorMap.channel),specularIntensityMapUv:Ue&&g(b.specularIntensityMap.channel),transmissionMapUv:ie&&g(b.transmissionMap.channel),thicknessMapUv:ae&&g(b.thicknessMap.channel),alphaMapUv:Z&&g(b.alphaMap.channel),vertexTangents:!!I.attributes.tangent&&(oe||F),vertexColors:b.vertexColors,vertexAlphas:b.vertexColors===!0&&!!I.attributes.color&&I.attributes.color.itemSize===4,vertexUv1s:be,vertexUv2s:Re,vertexUv3s:$e,pointsUvs:Y.isPoints===!0&&!!I.attributes.uv&&(Le||Z),fog:!!D,useFog:b.fog===!0,fogExp2:D&&D.isFogExp2,flatShading:b.flatShading===!0,sizeAttenuation:b.sizeAttenuation===!0,logarithmicDepthBuffer:h,skinning:Y.isSkinnedMesh===!0,morphTargets:I.morphAttributes.position!==void 0,morphNormals:I.morphAttributes.normal!==void 0,morphColors:I.morphAttributes.color!==void 0,morphTargetsCount:he,morphTextureStride:fe,numDirLights:T.directional.length,numPointLights:T.point.length,numSpotLights:T.spot.length,numSpotLightMaps:T.spotLightMap.length,numRectAreaLights:T.rectArea.length,numHemiLights:T.hemi.length,numDirLightShadows:T.directionalShadowMap.length,numPointLightShadows:T.pointShadowMap.length,numSpotLightShadows:T.spotShadowMap.length,numSpotLightShadowsWithMaps:T.numSpotLightShadowsWithMaps,numLightProbes:T.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:b.dithering,shadowMapEnabled:n.shadowMap.enabled&&H.length>0,shadowMapType:n.shadowMap.type,toneMapping:Je,useLegacyLights:n._useLegacyLights,decodeVideoTexture:Le&&b.map.isVideoTexture===!0&&je.getTransfer(b.map.colorSpace)===tt,premultipliedAlpha:b.premultipliedAlpha,doubleSided:b.side===ht,flipSided:b.side===Pt,useDepthPacking:b.depthPacking>=0,depthPacking:b.depthPacking||0,index0AttributeName:b.index0AttributeName,extensionDerivatives:de&&b.extensions.derivatives===!0,extensionFragDepth:de&&b.extensions.fragDepth===!0,extensionDrawBuffers:de&&b.extensions.drawBuffers===!0,extensionShaderTextureLOD:de&&b.extensions.shaderTextureLOD===!0,extensionClipCullDistance:de&&b.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:d||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:d||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:d||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:b.customProgramCacheKey()}}function f(b){const T=[];if(b.shaderID?T.push(b.shaderID):(T.push(b.customVertexShaderID),T.push(b.customFragmentShaderID)),b.defines!==void 0)for(const H in b.defines)T.push(H),T.push(b.defines[H]);return b.isRawShaderMaterial===!1&&(_(T,b),x(T,b),T.push(n.outputColorSpace)),T.push(b.customProgramCacheKey),T.join()}function _(b,T){b.push(T.precision),b.push(T.outputColorSpace),b.push(T.envMapMode),b.push(T.envMapCubeUVHeight),b.push(T.mapUv),b.push(T.alphaMapUv),b.push(T.lightMapUv),b.push(T.aoMapUv),b.push(T.bumpMapUv),b.push(T.normalMapUv),b.push(T.displacementMapUv),b.push(T.emissiveMapUv),b.push(T.metalnessMapUv),b.push(T.roughnessMapUv),b.push(T.anisotropyMapUv),b.push(T.clearcoatMapUv),b.push(T.clearcoatNormalMapUv),b.push(T.clearcoatRoughnessMapUv),b.push(T.iridescenceMapUv),b.push(T.iridescenceThicknessMapUv),b.push(T.sheenColorMapUv),b.push(T.sheenRoughnessMapUv),b.push(T.specularMapUv),b.push(T.specularColorMapUv),b.push(T.specularIntensityMapUv),b.push(T.transmissionMapUv),b.push(T.thicknessMapUv),b.push(T.combine),b.push(T.fogExp2),b.push(T.sizeAttenuation),b.push(T.morphTargetsCount),b.push(T.morphAttributeCount),b.push(T.numDirLights),b.push(T.numPointLights),b.push(T.numSpotLights),b.push(T.numSpotLightMaps),b.push(T.numHemiLights),b.push(T.numRectAreaLights),b.push(T.numDirLightShadows),b.push(T.numPointLightShadows),b.push(T.numSpotLightShadows),b.push(T.numSpotLightShadowsWithMaps),b.push(T.numLightProbes),b.push(T.shadowMapType),b.push(T.toneMapping),b.push(T.numClippingPlanes),b.push(T.numClipIntersection),b.push(T.depthPacking)}function x(b,T){o.disableAll(),T.isWebGL2&&o.enable(0),T.supportsVertexTextures&&o.enable(1),T.instancing&&o.enable(2),T.instancingColor&&o.enable(3),T.matcap&&o.enable(4),T.envMap&&o.enable(5),T.normalMapObjectSpace&&o.enable(6),T.normalMapTangentSpace&&o.enable(7),T.clearcoat&&o.enable(8),T.iridescence&&o.enable(9),T.alphaTest&&o.enable(10),T.vertexColors&&o.enable(11),T.vertexAlphas&&o.enable(12),T.vertexUv1s&&o.enable(13),T.vertexUv2s&&o.enable(14),T.vertexUv3s&&o.enable(15),T.vertexTangents&&o.enable(16),T.anisotropy&&o.enable(17),T.alphaHash&&o.enable(18),T.batching&&o.enable(19),b.push(o.mask),o.disableAll(),T.fog&&o.enable(0),T.useFog&&o.enable(1),T.flatShading&&o.enable(2),T.logarithmicDepthBuffer&&o.enable(3),T.skinning&&o.enable(4),T.morphTargets&&o.enable(5),T.morphNormals&&o.enable(6),T.morphColors&&o.enable(7),T.premultipliedAlpha&&o.enable(8),T.shadowMapEnabled&&o.enable(9),T.useLegacyLights&&o.enable(10),T.doubleSided&&o.enable(11),T.flipSided&&o.enable(12),T.useDepthPacking&&o.enable(13),T.dithering&&o.enable(14),T.transmission&&o.enable(15),T.sheen&&o.enable(16),T.opaque&&o.enable(17),T.pointsUvs&&o.enable(18),T.decodeVideoTexture&&o.enable(19),b.push(o.mask)}function v(b){const T=M[b.type];let H;if(T){const U=Jt[T];H=Mh.clone(U.uniforms)}else H=b.uniforms;return H}function R(b,T){let H;for(let U=0,Y=l.length;U<Y;U++){const D=l[U];if(D.cacheKey===T){H=D,++H.usedTimes;break}}return H===void 0&&(H=new Np(n,T,b,s),l.push(H)),H}function L(b){if(--b.usedTimes===0){const T=l.indexOf(b);l[T]=l[l.length-1],l.pop(),b.destroy()}}function C(b){c.remove(b)}function z(){c.dispose()}return{getParameters:p,getProgramCacheKey:f,getUniforms:v,acquireProgram:R,releaseProgram:L,releaseShaderCache:C,programs:l,dispose:z}}function kp(){let n=new WeakMap;function e(s){let a=n.get(s);return a===void 0&&(a={},n.set(s,a)),a}function t(s){n.delete(s)}function i(s,a,o){n.get(s)[a]=o}function r(){n=new WeakMap}return{get:e,remove:t,update:i,dispose:r}}function Gp(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function Pa(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function Da(){const n=[];let e=0;const t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function a(h,u,m,M,g,p){let f=n[e];return f===void 0?(f={id:h.id,object:h,geometry:u,material:m,groupOrder:M,renderOrder:h.renderOrder,z:g,group:p},n[e]=f):(f.id=h.id,f.object=h,f.geometry=u,f.material=m,f.groupOrder=M,f.renderOrder=h.renderOrder,f.z=g,f.group=p),e++,f}function o(h,u,m,M,g,p){const f=a(h,u,m,M,g,p);m.transmission>0?i.push(f):m.transparent===!0?r.push(f):t.push(f)}function c(h,u,m,M,g,p){const f=a(h,u,m,M,g,p);m.transmission>0?i.unshift(f):m.transparent===!0?r.unshift(f):t.unshift(f)}function l(h,u){t.length>1&&t.sort(h||Gp),i.length>1&&i.sort(u||Pa),r.length>1&&r.sort(u||Pa)}function d(){for(let h=e,u=n.length;h<u;h++){const m=n[h];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:o,unshift:c,finish:d,sort:l}}function Hp(){let n=new WeakMap;function e(i,r){const s=n.get(i);let a;return s===void 0?(a=new Da,n.set(i,[a])):r>=s.length?(a=new Da,s.push(a)):a=s[r],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function Vp(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new O,color:new Ze};break;case"SpotLight":t={position:new O,direction:new O,color:new Ze,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new O,color:new Ze,distance:0,decay:0};break;case"HemisphereLight":t={direction:new O,skyColor:new Ze,groundColor:new Ze};break;case"RectAreaLight":t={color:new Ze,position:new O,halfWidth:new O,halfHeight:new O};break}return n[e.id]=t,t}}}function Wp(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new qe};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new qe};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new qe,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let Xp=0;function qp(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function Yp(n,e){const t=new Vp,i=Wp(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)r.probe.push(new O);const s=new O,a=new Ke,o=new Ke;function c(d,h){let u=0,m=0,M=0;for(let U=0;U<9;U++)r.probe[U].set(0,0,0);let g=0,p=0,f=0,_=0,x=0,v=0,R=0,L=0,C=0,z=0,b=0;d.sort(qp);const T=h===!0?Math.PI:1;for(let U=0,Y=d.length;U<Y;U++){const D=d[U],I=D.color,G=D.intensity,X=D.distance,Q=D.shadow&&D.shadow.map?D.shadow.map.texture:null;if(D.isAmbientLight)u+=I.r*G*T,m+=I.g*G*T,M+=I.b*G*T;else if(D.isLightProbe){for(let ne=0;ne<9;ne++)r.probe[ne].addScaledVector(D.sh.coefficients[ne],G);b++}else if(D.isDirectionalLight){const ne=t.get(D);if(ne.color.copy(D.color).multiplyScalar(D.intensity*T),D.castShadow){const te=D.shadow,he=i.get(D);he.shadowBias=te.bias,he.shadowNormalBias=te.normalBias,he.shadowRadius=te.radius,he.shadowMapSize=te.mapSize,r.directionalShadow[g]=he,r.directionalShadowMap[g]=Q,r.directionalShadowMatrix[g]=D.shadow.matrix,v++}r.directional[g]=ne,g++}else if(D.isSpotLight){const ne=t.get(D);ne.position.setFromMatrixPosition(D.matrixWorld),ne.color.copy(I).multiplyScalar(G*T),ne.distance=X,ne.coneCos=Math.cos(D.angle),ne.penumbraCos=Math.cos(D.angle*(1-D.penumbra)),ne.decay=D.decay,r.spot[f]=ne;const te=D.shadow;if(D.map&&(r.spotLightMap[C]=D.map,C++,te.updateMatrices(D),D.castShadow&&z++),r.spotLightMatrix[f]=te.matrix,D.castShadow){const he=i.get(D);he.shadowBias=te.bias,he.shadowNormalBias=te.normalBias,he.shadowRadius=te.radius,he.shadowMapSize=te.mapSize,r.spotShadow[f]=he,r.spotShadowMap[f]=Q,L++}f++}else if(D.isRectAreaLight){const ne=t.get(D);ne.color.copy(I).multiplyScalar(G),ne.halfWidth.set(D.width*.5,0,0),ne.halfHeight.set(0,D.height*.5,0),r.rectArea[_]=ne,_++}else if(D.isPointLight){const ne=t.get(D);if(ne.color.copy(D.color).multiplyScalar(D.intensity*T),ne.distance=D.distance,ne.decay=D.decay,D.castShadow){const te=D.shadow,he=i.get(D);he.shadowBias=te.bias,he.shadowNormalBias=te.normalBias,he.shadowRadius=te.radius,he.shadowMapSize=te.mapSize,he.shadowCameraNear=te.camera.near,he.shadowCameraFar=te.camera.far,r.pointShadow[p]=he,r.pointShadowMap[p]=Q,r.pointShadowMatrix[p]=D.shadow.matrix,R++}r.point[p]=ne,p++}else if(D.isHemisphereLight){const ne=t.get(D);ne.skyColor.copy(D.color).multiplyScalar(G*T),ne.groundColor.copy(D.groundColor).multiplyScalar(G*T),r.hemi[x]=ne,x++}}_>0&&(e.isWebGL2?n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_FLOAT_1,r.rectAreaLTC2=_e.LTC_FLOAT_2):(r.rectAreaLTC1=_e.LTC_HALF_1,r.rectAreaLTC2=_e.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_FLOAT_1,r.rectAreaLTC2=_e.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_HALF_1,r.rectAreaLTC2=_e.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),r.ambient[0]=u,r.ambient[1]=m,r.ambient[2]=M;const H=r.hash;(H.directionalLength!==g||H.pointLength!==p||H.spotLength!==f||H.rectAreaLength!==_||H.hemiLength!==x||H.numDirectionalShadows!==v||H.numPointShadows!==R||H.numSpotShadows!==L||H.numSpotMaps!==C||H.numLightProbes!==b)&&(r.directional.length=g,r.spot.length=f,r.rectArea.length=_,r.point.length=p,r.hemi.length=x,r.directionalShadow.length=v,r.directionalShadowMap.length=v,r.pointShadow.length=R,r.pointShadowMap.length=R,r.spotShadow.length=L,r.spotShadowMap.length=L,r.directionalShadowMatrix.length=v,r.pointShadowMatrix.length=R,r.spotLightMatrix.length=L+C-z,r.spotLightMap.length=C,r.numSpotLightShadowsWithMaps=z,r.numLightProbes=b,H.directionalLength=g,H.pointLength=p,H.spotLength=f,H.rectAreaLength=_,H.hemiLength=x,H.numDirectionalShadows=v,H.numPointShadows=R,H.numSpotShadows=L,H.numSpotMaps=C,H.numLightProbes=b,r.version=Xp++)}function l(d,h){let u=0,m=0,M=0,g=0,p=0;const f=h.matrixWorldInverse;for(let _=0,x=d.length;_<x;_++){const v=d[_];if(v.isDirectionalLight){const R=r.directional[u];R.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(f),u++}else if(v.isSpotLight){const R=r.spot[M];R.position.setFromMatrixPosition(v.matrixWorld),R.position.applyMatrix4(f),R.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(f),M++}else if(v.isRectAreaLight){const R=r.rectArea[g];R.position.setFromMatrixPosition(v.matrixWorld),R.position.applyMatrix4(f),o.identity(),a.copy(v.matrixWorld),a.premultiply(f),o.extractRotation(a),R.halfWidth.set(v.width*.5,0,0),R.halfHeight.set(0,v.height*.5,0),R.halfWidth.applyMatrix4(o),R.halfHeight.applyMatrix4(o),g++}else if(v.isPointLight){const R=r.point[m];R.position.setFromMatrixPosition(v.matrixWorld),R.position.applyMatrix4(f),m++}else if(v.isHemisphereLight){const R=r.hemi[p];R.direction.setFromMatrixPosition(v.matrixWorld),R.direction.transformDirection(f),p++}}}return{setup:c,setupView:l,state:r}}function Ua(n,e){const t=new Yp(n,e),i=[],r=[];function s(){i.length=0,r.length=0}function a(h){i.push(h)}function o(h){r.push(h)}function c(h){t.setup(i,h)}function l(h){t.setupView(i,h)}return{init:s,state:{lightsArray:i,shadowsArray:r,lights:t},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function Zp(n,e){let t=new WeakMap;function i(s,a=0){const o=t.get(s);let c;return o===void 0?(c=new Ua(n,e),t.set(s,[c])):a>=o.length?(c=new Ua(n,e),o.push(c)):c=o[a],c}function r(){t=new WeakMap}return{get:i,dispose:r}}class jp extends qi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Xl,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Kp extends qi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const $p=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Jp=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Qp(n,e,t){let i=new js;const r=new qe,s=new qe,a=new _t,o=new jp({depthPacking:ql}),c=new Kp,l={},d=t.maxTextureSize,h={[cn]:Pt,[Pt]:cn,[ht]:ht},u=new Wn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new qe},radius:{value:4}},vertexShader:$p,fragmentShader:Jp}),m=u.clone();m.defines.HORIZONTAL_PASS=1;const M=new it;M.setAttribute("position",new jt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const g=new Ne(M,u),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Qa;let f=this.type;this.render=function(L,C,z){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||L.length===0)return;const b=n.getRenderTarget(),T=n.getActiveCubeFace(),H=n.getActiveMipmapLevel(),U=n.state;U.setBlending(Mn),U.buffers.color.setClear(1,1,1,1),U.buffers.depth.setTest(!0),U.setScissorTest(!1);const Y=f!==on&&this.type===on,D=f===on&&this.type!==on;for(let I=0,G=L.length;I<G;I++){const X=L[I],Q=X.shadow;if(Q===void 0){console.warn("THREE.WebGLShadowMap:",X,"has no shadow.");continue}if(Q.autoUpdate===!1&&Q.needsUpdate===!1)continue;r.copy(Q.mapSize);const ne=Q.getFrameExtents();if(r.multiply(ne),s.copy(Q.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/ne.x),r.x=s.x*ne.x,Q.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/ne.y),r.y=s.y*ne.y,Q.mapSize.y=s.y)),Q.map===null||Y===!0||D===!0){const he=this.type!==on?{minFilter:At,magFilter:At}:{};Q.map!==null&&Q.map.dispose(),Q.map=new Vn(r.x,r.y,he),Q.map.texture.name=X.name+".shadowMap",Q.camera.updateProjectionMatrix()}n.setRenderTarget(Q.map),n.clear();const te=Q.getViewportCount();for(let he=0;he<te;he++){const fe=Q.getViewport(he);a.set(s.x*fe.x,s.y*fe.y,s.x*fe.z,s.y*fe.w),U.viewport(a),Q.updateMatrices(X,he),i=Q.getFrustum(),v(C,z,Q.camera,X,this.type)}Q.isPointLightShadow!==!0&&this.type===on&&_(Q,z),Q.needsUpdate=!1}f=this.type,p.needsUpdate=!1,n.setRenderTarget(b,T,H)};function _(L,C){const z=e.update(g);u.defines.VSM_SAMPLES!==L.blurSamples&&(u.defines.VSM_SAMPLES=L.blurSamples,m.defines.VSM_SAMPLES=L.blurSamples,u.needsUpdate=!0,m.needsUpdate=!0),L.mapPass===null&&(L.mapPass=new Vn(r.x,r.y)),u.uniforms.shadow_pass.value=L.map.texture,u.uniforms.resolution.value=L.mapSize,u.uniforms.radius.value=L.radius,n.setRenderTarget(L.mapPass),n.clear(),n.renderBufferDirect(C,null,z,u,g,null),m.uniforms.shadow_pass.value=L.mapPass.texture,m.uniforms.resolution.value=L.mapSize,m.uniforms.radius.value=L.radius,n.setRenderTarget(L.map),n.clear(),n.renderBufferDirect(C,null,z,m,g,null)}function x(L,C,z,b){let T=null;const H=z.isPointLight===!0?L.customDistanceMaterial:L.customDepthMaterial;if(H!==void 0)T=H;else if(T=z.isPointLight===!0?c:o,n.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0){const U=T.uuid,Y=C.uuid;let D=l[U];D===void 0&&(D={},l[U]=D);let I=D[Y];I===void 0&&(I=T.clone(),D[Y]=I,C.addEventListener("dispose",R)),T=I}if(T.visible=C.visible,T.wireframe=C.wireframe,b===on?T.side=C.shadowSide!==null?C.shadowSide:C.side:T.side=C.shadowSide!==null?C.shadowSide:h[C.side],T.alphaMap=C.alphaMap,T.alphaTest=C.alphaTest,T.map=C.map,T.clipShadows=C.clipShadows,T.clippingPlanes=C.clippingPlanes,T.clipIntersection=C.clipIntersection,T.displacementMap=C.displacementMap,T.displacementScale=C.displacementScale,T.displacementBias=C.displacementBias,T.wireframeLinewidth=C.wireframeLinewidth,T.linewidth=C.linewidth,z.isPointLight===!0&&T.isMeshDistanceMaterial===!0){const U=n.properties.get(T);U.light=z}return T}function v(L,C,z,b,T){if(L.visible===!1)return;if(L.layers.test(C.layers)&&(L.isMesh||L.isLine||L.isPoints)&&(L.castShadow||L.receiveShadow&&T===on)&&(!L.frustumCulled||i.intersectsObject(L))){L.modelViewMatrix.multiplyMatrices(z.matrixWorldInverse,L.matrixWorld);const Y=e.update(L),D=L.material;if(Array.isArray(D)){const I=Y.groups;for(let G=0,X=I.length;G<X;G++){const Q=I[G],ne=D[Q.materialIndex];if(ne&&ne.visible){const te=x(L,ne,b,T);L.onBeforeShadow(n,L,C,z,Y,te,Q),n.renderBufferDirect(z,null,Y,te,L,Q),L.onAfterShadow(n,L,C,z,Y,te,Q)}}}else if(D.visible){const I=x(L,D,b,T);L.onBeforeShadow(n,L,C,z,Y,I,null),n.renderBufferDirect(z,null,Y,I,L,null),L.onAfterShadow(n,L,C,z,Y,I,null)}}const U=L.children;for(let Y=0,D=U.length;Y<D;Y++)v(U[Y],C,z,b,T)}function R(L){L.target.removeEventListener("dispose",R);for(const z in l){const b=l[z],T=L.target.uuid;T in b&&(b[T].dispose(),delete b[T])}}}function em(n,e,t){const i=t.isWebGL2;function r(){let P=!1;const le=new _t;let de=null;const be=new _t(0,0,0,0);return{setMask:function(Re){de!==Re&&!P&&(n.colorMask(Re,Re,Re,Re),de=Re)},setLocked:function(Re){P=Re},setClear:function(Re,$e,Je,pt,bt){bt===!0&&(Re*=pt,$e*=pt,Je*=pt),le.set(Re,$e,Je,pt),be.equals(le)===!1&&(n.clearColor(Re,$e,Je,pt),be.copy(le))},reset:function(){P=!1,de=null,be.set(-1,0,0,0)}}}function s(){let P=!1,le=null,de=null,be=null;return{setTest:function(Re){Re?Oe(n.DEPTH_TEST):Le(n.DEPTH_TEST)},setMask:function(Re){le!==Re&&!P&&(n.depthMask(Re),le=Re)},setFunc:function(Re){if(de!==Re){switch(Re){case yl:n.depthFunc(n.NEVER);break;case Sl:n.depthFunc(n.ALWAYS);break;case El:n.depthFunc(n.LESS);break;case Rr:n.depthFunc(n.LEQUAL);break;case bl:n.depthFunc(n.EQUAL);break;case wl:n.depthFunc(n.GEQUAL);break;case Tl:n.depthFunc(n.GREATER);break;case Al:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}de=Re}},setLocked:function(Re){P=Re},setClear:function(Re){be!==Re&&(n.clearDepth(Re),be=Re)},reset:function(){P=!1,le=null,de=null,be=null}}}function a(){let P=!1,le=null,de=null,be=null,Re=null,$e=null,Je=null,pt=null,bt=null;return{setTest:function(Qe){P||(Qe?Oe(n.STENCIL_TEST):Le(n.STENCIL_TEST))},setMask:function(Qe){le!==Qe&&!P&&(n.stencilMask(Qe),le=Qe)},setFunc:function(Qe,wt,$t){(de!==Qe||be!==wt||Re!==$t)&&(n.stencilFunc(Qe,wt,$t),de=Qe,be=wt,Re=$t)},setOp:function(Qe,wt,$t){($e!==Qe||Je!==wt||pt!==$t)&&(n.stencilOp(Qe,wt,$t),$e=Qe,Je=wt,pt=$t)},setLocked:function(Qe){P=Qe},setClear:function(Qe){bt!==Qe&&(n.clearStencil(Qe),bt=Qe)},reset:function(){P=!1,le=null,de=null,be=null,Re=null,$e=null,Je=null,pt=null,bt=null}}}const o=new r,c=new s,l=new a,d=new WeakMap,h=new WeakMap;let u={},m={},M=new WeakMap,g=[],p=null,f=!1,_=null,x=null,v=null,R=null,L=null,C=null,z=null,b=new Ze(0,0,0),T=0,H=!1,U=null,Y=null,D=null,I=null,G=null;const X=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Q=!1,ne=0;const te=n.getParameter(n.VERSION);te.indexOf("WebGL")!==-1?(ne=parseFloat(/^WebGL (\d)/.exec(te)[1]),Q=ne>=1):te.indexOf("OpenGL ES")!==-1&&(ne=parseFloat(/^OpenGL ES (\d)/.exec(te)[1]),Q=ne>=2);let he=null,fe={};const K=n.getParameter(n.SCISSOR_BOX),re=n.getParameter(n.VIEWPORT),me=new _t().fromArray(K),we=new _t().fromArray(re);function Se(P,le,de,be){const Re=new Uint8Array(4),$e=n.createTexture();n.bindTexture(P,$e),n.texParameteri(P,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(P,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let Je=0;Je<de;Je++)i&&(P===n.TEXTURE_3D||P===n.TEXTURE_2D_ARRAY)?n.texImage3D(le,0,n.RGBA,1,1,be,0,n.RGBA,n.UNSIGNED_BYTE,Re):n.texImage2D(le+Je,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Re);return $e}const Fe={};Fe[n.TEXTURE_2D]=Se(n.TEXTURE_2D,n.TEXTURE_2D,1),Fe[n.TEXTURE_CUBE_MAP]=Se(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(Fe[n.TEXTURE_2D_ARRAY]=Se(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Fe[n.TEXTURE_3D]=Se(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),Oe(n.DEPTH_TEST),c.setFunc(Rr),pe(!1),w(po),Oe(n.CULL_FACE),oe(Mn);function Oe(P){u[P]!==!0&&(n.enable(P),u[P]=!0)}function Le(P){u[P]!==!1&&(n.disable(P),u[P]=!1)}function S(P,le){return m[P]!==le?(n.bindFramebuffer(P,le),m[P]=le,i&&(P===n.DRAW_FRAMEBUFFER&&(m[n.FRAMEBUFFER]=le),P===n.FRAMEBUFFER&&(m[n.DRAW_FRAMEBUFFER]=le)),!0):!1}function y(P,le){let de=g,be=!1;if(P)if(de=M.get(le),de===void 0&&(de=[],M.set(le,de)),P.isWebGLMultipleRenderTargets){const Re=P.texture;if(de.length!==Re.length||de[0]!==n.COLOR_ATTACHMENT0){for(let $e=0,Je=Re.length;$e<Je;$e++)de[$e]=n.COLOR_ATTACHMENT0+$e;de.length=Re.length,be=!0}}else de[0]!==n.COLOR_ATTACHMENT0&&(de[0]=n.COLOR_ATTACHMENT0,be=!0);else de[0]!==n.BACK&&(de[0]=n.BACK,be=!0);be&&(t.isWebGL2?n.drawBuffers(de):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(de))}function k(P){return p!==P?(n.useProgram(P),p=P,!0):!1}const N={[On]:n.FUNC_ADD,[ol]:n.FUNC_SUBTRACT,[al]:n.FUNC_REVERSE_SUBTRACT};if(i)N[xo]=n.MIN,N[vo]=n.MAX;else{const P=e.get("EXT_blend_minmax");P!==null&&(N[xo]=P.MIN_EXT,N[vo]=P.MAX_EXT)}const se={[cl]:n.ZERO,[ll]:n.ONE,[hl]:n.SRC_COLOR,[Ls]:n.SRC_ALPHA,[gl]:n.SRC_ALPHA_SATURATE,[pl]:n.DST_COLOR,[dl]:n.DST_ALPHA,[ul]:n.ONE_MINUS_SRC_COLOR,[Ps]:n.ONE_MINUS_SRC_ALPHA,[ml]:n.ONE_MINUS_DST_COLOR,[fl]:n.ONE_MINUS_DST_ALPHA,[_l]:n.CONSTANT_COLOR,[xl]:n.ONE_MINUS_CONSTANT_COLOR,[vl]:n.CONSTANT_ALPHA,[Ml]:n.ONE_MINUS_CONSTANT_ALPHA};function oe(P,le,de,be,Re,$e,Je,pt,bt,Qe){if(P===Mn){f===!0&&(Le(n.BLEND),f=!1);return}if(f===!1&&(Oe(n.BLEND),f=!0),P!==sl){if(P!==_||Qe!==H){if((x!==On||L!==On)&&(n.blendEquation(n.FUNC_ADD),x=On,L=On),Qe)switch(P){case di:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case mo:n.blendFunc(n.ONE,n.ONE);break;case go:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case _o:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",P);break}else switch(P){case di:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case mo:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case go:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case _o:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",P);break}v=null,R=null,C=null,z=null,b.set(0,0,0),T=0,_=P,H=Qe}return}Re=Re||le,$e=$e||de,Je=Je||be,(le!==x||Re!==L)&&(n.blendEquationSeparate(N[le],N[Re]),x=le,L=Re),(de!==v||be!==R||$e!==C||Je!==z)&&(n.blendFuncSeparate(se[de],se[be],se[$e],se[Je]),v=de,R=be,C=$e,z=Je),(pt.equals(b)===!1||bt!==T)&&(n.blendColor(pt.r,pt.g,pt.b,bt),b.copy(pt),T=bt),_=P,H=!1}function J(P,le){P.side===ht?Le(n.CULL_FACE):Oe(n.CULL_FACE);let de=P.side===Pt;le&&(de=!de),pe(de),P.blending===di&&P.transparent===!1?oe(Mn):oe(P.blending,P.blendEquation,P.blendSrc,P.blendDst,P.blendEquationAlpha,P.blendSrcAlpha,P.blendDstAlpha,P.blendColor,P.blendAlpha,P.premultipliedAlpha),c.setFunc(P.depthFunc),c.setTest(P.depthTest),c.setMask(P.depthWrite),o.setMask(P.colorWrite);const be=P.stencilWrite;l.setTest(be),be&&(l.setMask(P.stencilWriteMask),l.setFunc(P.stencilFunc,P.stencilRef,P.stencilFuncMask),l.setOp(P.stencilFail,P.stencilZFail,P.stencilZPass)),F(P.polygonOffset,P.polygonOffsetFactor,P.polygonOffsetUnits),P.alphaToCoverage===!0?Oe(n.SAMPLE_ALPHA_TO_COVERAGE):Le(n.SAMPLE_ALPHA_TO_COVERAGE)}function pe(P){U!==P&&(P?n.frontFace(n.CW):n.frontFace(n.CCW),U=P)}function w(P){P!==nl?(Oe(n.CULL_FACE),P!==Y&&(P===po?n.cullFace(n.BACK):P===il?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):Le(n.CULL_FACE),Y=P}function E(P){P!==D&&(Q&&n.lineWidth(P),D=P)}function F(P,le,de){P?(Oe(n.POLYGON_OFFSET_FILL),(I!==le||G!==de)&&(n.polygonOffset(le,de),I=le,G=de)):Le(n.POLYGON_OFFSET_FILL)}function $(P){P?Oe(n.SCISSOR_TEST):Le(n.SCISSOR_TEST)}function q(P){P===void 0&&(P=n.TEXTURE0+X-1),he!==P&&(n.activeTexture(P),he=P)}function ee(P,le,de){de===void 0&&(he===null?de=n.TEXTURE0+X-1:de=he);let be=fe[de];be===void 0&&(be={type:void 0,texture:void 0},fe[de]=be),(be.type!==P||be.texture!==le)&&(he!==de&&(n.activeTexture(de),he=de),n.bindTexture(P,le||Fe[P]),be.type=P,be.texture=le)}function xe(){const P=fe[he];P!==void 0&&P.type!==void 0&&(n.bindTexture(P.type,null),P.type=void 0,P.texture=void 0)}function ge(){try{n.compressedTexImage2D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function ve(){try{n.compressedTexImage3D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function Ee(){try{n.texSubImage2D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function Pe(){try{n.texSubImage3D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function ce(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function Ye(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function ke(){try{n.texStorage2D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function De(){try{n.texStorage3D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function Ae(){try{n.texImage2D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function ye(){try{n.texImage3D.apply(n,arguments)}catch(P){console.error("THREE.WebGLState:",P)}}function Ue(P){me.equals(P)===!1&&(n.scissor(P.x,P.y,P.z,P.w),me.copy(P))}function ie(P){we.equals(P)===!1&&(n.viewport(P.x,P.y,P.z,P.w),we.copy(P))}function ae(P,le){let de=h.get(le);de===void 0&&(de=new WeakMap,h.set(le,de));let be=de.get(P);be===void 0&&(be=n.getUniformBlockIndex(le,P.name),de.set(P,be))}function ue(P,le){const be=h.get(le).get(P);d.get(le)!==be&&(n.uniformBlockBinding(le,be,P.__bindingPointIndex),d.set(le,be))}function Z(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),u={},he=null,fe={},m={},M=new WeakMap,g=[],p=null,f=!1,_=null,x=null,v=null,R=null,L=null,C=null,z=null,b=new Ze(0,0,0),T=0,H=!1,U=null,Y=null,D=null,I=null,G=null,me.set(0,0,n.canvas.width,n.canvas.height),we.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:Oe,disable:Le,bindFramebuffer:S,drawBuffers:y,useProgram:k,setBlending:oe,setMaterial:J,setFlipSided:pe,setCullFace:w,setLineWidth:E,setPolygonOffset:F,setScissorTest:$,activeTexture:q,bindTexture:ee,unbindTexture:xe,compressedTexImage2D:ge,compressedTexImage3D:ve,texImage2D:Ae,texImage3D:ye,updateUBOMapping:ae,uniformBlockBinding:ue,texStorage2D:ke,texStorage3D:De,texSubImage2D:Ee,texSubImage3D:Pe,compressedTexSubImage2D:ce,compressedTexSubImage3D:Ye,scissor:Ue,viewport:ie,reset:Z}}function tm(n,e,t,i,r,s,a){const o=r.isWebGL2,c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new WeakMap;let h;const u=new WeakMap;let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function M(w,E){return m?new OffscreenCanvas(w,E):Ur("canvas")}function g(w,E,F,$){let q=1;if((w.width>$||w.height>$)&&(q=$/Math.max(w.width,w.height)),q<1||E===!0)if(typeof HTMLImageElement<"u"&&w instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&w instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&w instanceof ImageBitmap){const ee=E?zs:Math.floor,xe=ee(q*w.width),ge=ee(q*w.height);h===void 0&&(h=M(xe,ge));const ve=F?M(xe,ge):h;return ve.width=xe,ve.height=ge,ve.getContext("2d").drawImage(w,0,0,xe,ge),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+w.width+"x"+w.height+") to ("+xe+"x"+ge+")."),ve}else return"data"in w&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+w.width+"x"+w.height+")."),w;return w}function p(w){return jo(w.width)&&jo(w.height)}function f(w){return o?!1:w.wrapS!==Yt||w.wrapT!==Yt||w.minFilter!==At&&w.minFilter!==kt}function _(w,E){return w.generateMipmaps&&E&&w.minFilter!==At&&w.minFilter!==kt}function x(w){n.generateMipmap(w)}function v(w,E,F,$,q=!1){if(o===!1)return E;if(w!==null){if(n[w]!==void 0)return n[w];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+w+"'")}let ee=E;if(E===n.RED&&(F===n.FLOAT&&(ee=n.R32F),F===n.HALF_FLOAT&&(ee=n.R16F),F===n.UNSIGNED_BYTE&&(ee=n.R8)),E===n.RED_INTEGER&&(F===n.UNSIGNED_BYTE&&(ee=n.R8UI),F===n.UNSIGNED_SHORT&&(ee=n.R16UI),F===n.UNSIGNED_INT&&(ee=n.R32UI),F===n.BYTE&&(ee=n.R8I),F===n.SHORT&&(ee=n.R16I),F===n.INT&&(ee=n.R32I)),E===n.RG&&(F===n.FLOAT&&(ee=n.RG32F),F===n.HALF_FLOAT&&(ee=n.RG16F),F===n.UNSIGNED_BYTE&&(ee=n.RG8)),E===n.RGBA){const xe=q?Cr:je.getTransfer($);F===n.FLOAT&&(ee=n.RGBA32F),F===n.HALF_FLOAT&&(ee=n.RGBA16F),F===n.UNSIGNED_BYTE&&(ee=xe===tt?n.SRGB8_ALPHA8:n.RGBA8),F===n.UNSIGNED_SHORT_4_4_4_4&&(ee=n.RGBA4),F===n.UNSIGNED_SHORT_5_5_5_1&&(ee=n.RGB5_A1)}return(ee===n.R16F||ee===n.R32F||ee===n.RG16F||ee===n.RG32F||ee===n.RGBA16F||ee===n.RGBA32F)&&e.get("EXT_color_buffer_float"),ee}function R(w,E,F){return _(w,F)===!0||w.isFramebufferTexture&&w.minFilter!==At&&w.minFilter!==kt?Math.log2(Math.max(E.width,E.height))+1:w.mipmaps!==void 0&&w.mipmaps.length>0?w.mipmaps.length:w.isCompressedTexture&&Array.isArray(w.image)?E.mipmaps.length:1}function L(w){return w===At||w===Mo||w===Zr?n.NEAREST:n.LINEAR}function C(w){const E=w.target;E.removeEventListener("dispose",C),b(E),E.isVideoTexture&&d.delete(E)}function z(w){const E=w.target;E.removeEventListener("dispose",z),H(E)}function b(w){const E=i.get(w);if(E.__webglInit===void 0)return;const F=w.source,$=u.get(F);if($){const q=$[E.__cacheKey];q.usedTimes--,q.usedTimes===0&&T(w),Object.keys($).length===0&&u.delete(F)}i.remove(w)}function T(w){const E=i.get(w);n.deleteTexture(E.__webglTexture);const F=w.source,$=u.get(F);delete $[E.__cacheKey],a.memory.textures--}function H(w){const E=w.texture,F=i.get(w),$=i.get(E);if($.__webglTexture!==void 0&&(n.deleteTexture($.__webglTexture),a.memory.textures--),w.depthTexture&&w.depthTexture.dispose(),w.isWebGLCubeRenderTarget)for(let q=0;q<6;q++){if(Array.isArray(F.__webglFramebuffer[q]))for(let ee=0;ee<F.__webglFramebuffer[q].length;ee++)n.deleteFramebuffer(F.__webglFramebuffer[q][ee]);else n.deleteFramebuffer(F.__webglFramebuffer[q]);F.__webglDepthbuffer&&n.deleteRenderbuffer(F.__webglDepthbuffer[q])}else{if(Array.isArray(F.__webglFramebuffer))for(let q=0;q<F.__webglFramebuffer.length;q++)n.deleteFramebuffer(F.__webglFramebuffer[q]);else n.deleteFramebuffer(F.__webglFramebuffer);if(F.__webglDepthbuffer&&n.deleteRenderbuffer(F.__webglDepthbuffer),F.__webglMultisampledFramebuffer&&n.deleteFramebuffer(F.__webglMultisampledFramebuffer),F.__webglColorRenderbuffer)for(let q=0;q<F.__webglColorRenderbuffer.length;q++)F.__webglColorRenderbuffer[q]&&n.deleteRenderbuffer(F.__webglColorRenderbuffer[q]);F.__webglDepthRenderbuffer&&n.deleteRenderbuffer(F.__webglDepthRenderbuffer)}if(w.isWebGLMultipleRenderTargets)for(let q=0,ee=E.length;q<ee;q++){const xe=i.get(E[q]);xe.__webglTexture&&(n.deleteTexture(xe.__webglTexture),a.memory.textures--),i.remove(E[q])}i.remove(E),i.remove(w)}let U=0;function Y(){U=0}function D(){const w=U;return w>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+w+" texture units while this GPU supports only "+r.maxTextures),U+=1,w}function I(w){const E=[];return E.push(w.wrapS),E.push(w.wrapT),E.push(w.wrapR||0),E.push(w.magFilter),E.push(w.minFilter),E.push(w.anisotropy),E.push(w.internalFormat),E.push(w.format),E.push(w.type),E.push(w.generateMipmaps),E.push(w.premultiplyAlpha),E.push(w.flipY),E.push(w.unpackAlignment),E.push(w.colorSpace),E.join()}function G(w,E){const F=i.get(w);if(w.isVideoTexture&&J(w),w.isRenderTargetTexture===!1&&w.version>0&&F.__version!==w.version){const $=w.image;if($===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if($.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{me(F,w,E);return}}t.bindTexture(n.TEXTURE_2D,F.__webglTexture,n.TEXTURE0+E)}function X(w,E){const F=i.get(w);if(w.version>0&&F.__version!==w.version){me(F,w,E);return}t.bindTexture(n.TEXTURE_2D_ARRAY,F.__webglTexture,n.TEXTURE0+E)}function Q(w,E){const F=i.get(w);if(w.version>0&&F.__version!==w.version){me(F,w,E);return}t.bindTexture(n.TEXTURE_3D,F.__webglTexture,n.TEXTURE0+E)}function ne(w,E){const F=i.get(w);if(w.version>0&&F.__version!==w.version){we(F,w,E);return}t.bindTexture(n.TEXTURE_CUBE_MAP,F.__webglTexture,n.TEXTURE0+E)}const te={[Is]:n.REPEAT,[Yt]:n.CLAMP_TO_EDGE,[Ns]:n.MIRRORED_REPEAT},he={[At]:n.NEAREST,[Mo]:n.NEAREST_MIPMAP_NEAREST,[Zr]:n.NEAREST_MIPMAP_LINEAR,[kt]:n.LINEAR,[Fl]:n.LINEAR_MIPMAP_NEAREST,[Bi]:n.LINEAR_MIPMAP_LINEAR},fe={[Zl]:n.NEVER,[eh]:n.ALWAYS,[jl]:n.LESS,[hc]:n.LEQUAL,[Kl]:n.EQUAL,[Ql]:n.GEQUAL,[$l]:n.GREATER,[Jl]:n.NOTEQUAL};function K(w,E,F){if(F?(n.texParameteri(w,n.TEXTURE_WRAP_S,te[E.wrapS]),n.texParameteri(w,n.TEXTURE_WRAP_T,te[E.wrapT]),(w===n.TEXTURE_3D||w===n.TEXTURE_2D_ARRAY)&&n.texParameteri(w,n.TEXTURE_WRAP_R,te[E.wrapR]),n.texParameteri(w,n.TEXTURE_MAG_FILTER,he[E.magFilter]),n.texParameteri(w,n.TEXTURE_MIN_FILTER,he[E.minFilter])):(n.texParameteri(w,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(w,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(w===n.TEXTURE_3D||w===n.TEXTURE_2D_ARRAY)&&n.texParameteri(w,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(E.wrapS!==Yt||E.wrapT!==Yt)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(w,n.TEXTURE_MAG_FILTER,L(E.magFilter)),n.texParameteri(w,n.TEXTURE_MIN_FILTER,L(E.minFilter)),E.minFilter!==At&&E.minFilter!==kt&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),E.compareFunction&&(n.texParameteri(w,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(w,n.TEXTURE_COMPARE_FUNC,fe[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){const $=e.get("EXT_texture_filter_anisotropic");if(E.magFilter===At||E.minFilter!==Zr&&E.minFilter!==Bi||E.type===vn&&e.has("OES_texture_float_linear")===!1||o===!1&&E.type===ki&&e.has("OES_texture_half_float_linear")===!1)return;(E.anisotropy>1||i.get(E).__currentAnisotropy)&&(n.texParameterf(w,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,r.getMaxAnisotropy())),i.get(E).__currentAnisotropy=E.anisotropy)}}function re(w,E){let F=!1;w.__webglInit===void 0&&(w.__webglInit=!0,E.addEventListener("dispose",C));const $=E.source;let q=u.get($);q===void 0&&(q={},u.set($,q));const ee=I(E);if(ee!==w.__cacheKey){q[ee]===void 0&&(q[ee]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,F=!0),q[ee].usedTimes++;const xe=q[w.__cacheKey];xe!==void 0&&(q[w.__cacheKey].usedTimes--,xe.usedTimes===0&&T(E)),w.__cacheKey=ee,w.__webglTexture=q[ee].texture}return F}function me(w,E,F){let $=n.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&($=n.TEXTURE_2D_ARRAY),E.isData3DTexture&&($=n.TEXTURE_3D);const q=re(w,E),ee=E.source;t.bindTexture($,w.__webglTexture,n.TEXTURE0+F);const xe=i.get(ee);if(ee.version!==xe.__version||q===!0){t.activeTexture(n.TEXTURE0+F);const ge=je.getPrimaries(je.workingColorSpace),ve=E.colorSpace===Ht?null:je.getPrimaries(E.colorSpace),Ee=E.colorSpace===Ht||ge===ve?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,E.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,E.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ee);const Pe=f(E)&&p(E.image)===!1;let ce=g(E.image,Pe,!1,r.maxTextureSize);ce=pe(E,ce);const Ye=p(ce)||o,ke=s.convert(E.format,E.colorSpace);let De=s.convert(E.type),Ae=v(E.internalFormat,ke,De,E.colorSpace,E.isVideoTexture);K($,E,Ye);let ye;const Ue=E.mipmaps,ie=o&&E.isVideoTexture!==!0&&Ae!==ac,ae=xe.__version===void 0||q===!0,ue=R(E,ce,Ye);if(E.isDepthTexture)Ae=n.DEPTH_COMPONENT,o?E.type===vn?Ae=n.DEPTH_COMPONENT32F:E.type===xn?Ae=n.DEPTH_COMPONENT24:E.type===kn?Ae=n.DEPTH24_STENCIL8:Ae=n.DEPTH_COMPONENT16:E.type===vn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),E.format===Gn&&Ae===n.DEPTH_COMPONENT&&E.type!==qs&&E.type!==xn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),E.type=xn,De=s.convert(E.type)),E.format===xi&&Ae===n.DEPTH_COMPONENT&&(Ae=n.DEPTH_STENCIL,E.type!==kn&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),E.type=kn,De=s.convert(E.type))),ae&&(ie?t.texStorage2D(n.TEXTURE_2D,1,Ae,ce.width,ce.height):t.texImage2D(n.TEXTURE_2D,0,Ae,ce.width,ce.height,0,ke,De,null));else if(E.isDataTexture)if(Ue.length>0&&Ye){ie&&ae&&t.texStorage2D(n.TEXTURE_2D,ue,Ae,Ue[0].width,Ue[0].height);for(let Z=0,P=Ue.length;Z<P;Z++)ye=Ue[Z],ie?t.texSubImage2D(n.TEXTURE_2D,Z,0,0,ye.width,ye.height,ke,De,ye.data):t.texImage2D(n.TEXTURE_2D,Z,Ae,ye.width,ye.height,0,ke,De,ye.data);E.generateMipmaps=!1}else ie?(ae&&t.texStorage2D(n.TEXTURE_2D,ue,Ae,ce.width,ce.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,ce.width,ce.height,ke,De,ce.data)):t.texImage2D(n.TEXTURE_2D,0,Ae,ce.width,ce.height,0,ke,De,ce.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){ie&&ae&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ue,Ae,Ue[0].width,Ue[0].height,ce.depth);for(let Z=0,P=Ue.length;Z<P;Z++)ye=Ue[Z],E.format!==Zt?ke!==null?ie?t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Z,0,0,0,ye.width,ye.height,ce.depth,ke,ye.data,0,0):t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,Z,Ae,ye.width,ye.height,ce.depth,0,ye.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ie?t.texSubImage3D(n.TEXTURE_2D_ARRAY,Z,0,0,0,ye.width,ye.height,ce.depth,ke,De,ye.data):t.texImage3D(n.TEXTURE_2D_ARRAY,Z,Ae,ye.width,ye.height,ce.depth,0,ke,De,ye.data)}else{ie&&ae&&t.texStorage2D(n.TEXTURE_2D,ue,Ae,Ue[0].width,Ue[0].height);for(let Z=0,P=Ue.length;Z<P;Z++)ye=Ue[Z],E.format!==Zt?ke!==null?ie?t.compressedTexSubImage2D(n.TEXTURE_2D,Z,0,0,ye.width,ye.height,ke,ye.data):t.compressedTexImage2D(n.TEXTURE_2D,Z,Ae,ye.width,ye.height,0,ye.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ie?t.texSubImage2D(n.TEXTURE_2D,Z,0,0,ye.width,ye.height,ke,De,ye.data):t.texImage2D(n.TEXTURE_2D,Z,Ae,ye.width,ye.height,0,ke,De,ye.data)}else if(E.isDataArrayTexture)ie?(ae&&t.texStorage3D(n.TEXTURE_2D_ARRAY,ue,Ae,ce.width,ce.height,ce.depth),t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,ce.width,ce.height,ce.depth,ke,De,ce.data)):t.texImage3D(n.TEXTURE_2D_ARRAY,0,Ae,ce.width,ce.height,ce.depth,0,ke,De,ce.data);else if(E.isData3DTexture)ie?(ae&&t.texStorage3D(n.TEXTURE_3D,ue,Ae,ce.width,ce.height,ce.depth),t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,ce.width,ce.height,ce.depth,ke,De,ce.data)):t.texImage3D(n.TEXTURE_3D,0,Ae,ce.width,ce.height,ce.depth,0,ke,De,ce.data);else if(E.isFramebufferTexture){if(ae)if(ie)t.texStorage2D(n.TEXTURE_2D,ue,Ae,ce.width,ce.height);else{let Z=ce.width,P=ce.height;for(let le=0;le<ue;le++)t.texImage2D(n.TEXTURE_2D,le,Ae,Z,P,0,ke,De,null),Z>>=1,P>>=1}}else if(Ue.length>0&&Ye){ie&&ae&&t.texStorage2D(n.TEXTURE_2D,ue,Ae,Ue[0].width,Ue[0].height);for(let Z=0,P=Ue.length;Z<P;Z++)ye=Ue[Z],ie?t.texSubImage2D(n.TEXTURE_2D,Z,0,0,ke,De,ye):t.texImage2D(n.TEXTURE_2D,Z,Ae,ke,De,ye);E.generateMipmaps=!1}else ie?(ae&&t.texStorage2D(n.TEXTURE_2D,ue,Ae,ce.width,ce.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,ke,De,ce)):t.texImage2D(n.TEXTURE_2D,0,Ae,ke,De,ce);_(E,Ye)&&x($),xe.__version=ee.version,E.onUpdate&&E.onUpdate(E)}w.__version=E.version}function we(w,E,F){if(E.image.length!==6)return;const $=re(w,E),q=E.source;t.bindTexture(n.TEXTURE_CUBE_MAP,w.__webglTexture,n.TEXTURE0+F);const ee=i.get(q);if(q.version!==ee.__version||$===!0){t.activeTexture(n.TEXTURE0+F);const xe=je.getPrimaries(je.workingColorSpace),ge=E.colorSpace===Ht?null:je.getPrimaries(E.colorSpace),ve=E.colorSpace===Ht||xe===ge?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,E.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,E.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,ve);const Ee=E.isCompressedTexture||E.image[0].isCompressedTexture,Pe=E.image[0]&&E.image[0].isDataTexture,ce=[];for(let Z=0;Z<6;Z++)!Ee&&!Pe?ce[Z]=g(E.image[Z],!1,!0,r.maxCubemapSize):ce[Z]=Pe?E.image[Z].image:E.image[Z],ce[Z]=pe(E,ce[Z]);const Ye=ce[0],ke=p(Ye)||o,De=s.convert(E.format,E.colorSpace),Ae=s.convert(E.type),ye=v(E.internalFormat,De,Ae,E.colorSpace),Ue=o&&E.isVideoTexture!==!0,ie=ee.__version===void 0||$===!0;let ae=R(E,Ye,ke);K(n.TEXTURE_CUBE_MAP,E,ke);let ue;if(Ee){Ue&&ie&&t.texStorage2D(n.TEXTURE_CUBE_MAP,ae,ye,Ye.width,Ye.height);for(let Z=0;Z<6;Z++){ue=ce[Z].mipmaps;for(let P=0;P<ue.length;P++){const le=ue[P];E.format!==Zt?De!==null?Ue?t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P,0,0,le.width,le.height,De,le.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P,ye,le.width,le.height,0,le.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ue?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P,0,0,le.width,le.height,De,Ae,le.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P,ye,le.width,le.height,0,De,Ae,le.data)}}}else{ue=E.mipmaps,Ue&&ie&&(ue.length>0&&ae++,t.texStorage2D(n.TEXTURE_CUBE_MAP,ae,ye,ce[0].width,ce[0].height));for(let Z=0;Z<6;Z++)if(Pe){Ue?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,ce[Z].width,ce[Z].height,De,Ae,ce[Z].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,ye,ce[Z].width,ce[Z].height,0,De,Ae,ce[Z].data);for(let P=0;P<ue.length;P++){const de=ue[P].image[Z].image;Ue?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P+1,0,0,de.width,de.height,De,Ae,de.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P+1,ye,de.width,de.height,0,De,Ae,de.data)}}else{Ue?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,De,Ae,ce[Z]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,ye,De,Ae,ce[Z]);for(let P=0;P<ue.length;P++){const le=ue[P];Ue?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P+1,0,0,De,Ae,le.image[Z]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,P+1,ye,De,Ae,le.image[Z])}}}_(E,ke)&&x(n.TEXTURE_CUBE_MAP),ee.__version=q.version,E.onUpdate&&E.onUpdate(E)}w.__version=E.version}function Se(w,E,F,$,q,ee){const xe=s.convert(F.format,F.colorSpace),ge=s.convert(F.type),ve=v(F.internalFormat,xe,ge,F.colorSpace);if(!i.get(E).__hasExternalTextures){const Pe=Math.max(1,E.width>>ee),ce=Math.max(1,E.height>>ee);q===n.TEXTURE_3D||q===n.TEXTURE_2D_ARRAY?t.texImage3D(q,ee,ve,Pe,ce,E.depth,0,xe,ge,null):t.texImage2D(q,ee,ve,Pe,ce,0,xe,ge,null)}t.bindFramebuffer(n.FRAMEBUFFER,w),oe(E)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,$,q,i.get(F).__webglTexture,0,se(E)):(q===n.TEXTURE_2D||q>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&q<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,$,q,i.get(F).__webglTexture,ee),t.bindFramebuffer(n.FRAMEBUFFER,null)}function Fe(w,E,F){if(n.bindRenderbuffer(n.RENDERBUFFER,w),E.depthBuffer&&!E.stencilBuffer){let $=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(F||oe(E)){const q=E.depthTexture;q&&q.isDepthTexture&&(q.type===vn?$=n.DEPTH_COMPONENT32F:q.type===xn&&($=n.DEPTH_COMPONENT24));const ee=se(E);oe(E)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ee,$,E.width,E.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,ee,$,E.width,E.height)}else n.renderbufferStorage(n.RENDERBUFFER,$,E.width,E.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,w)}else if(E.depthBuffer&&E.stencilBuffer){const $=se(E);F&&oe(E)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,$,n.DEPTH24_STENCIL8,E.width,E.height):oe(E)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,$,n.DEPTH24_STENCIL8,E.width,E.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,E.width,E.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,w)}else{const $=E.isWebGLMultipleRenderTargets===!0?E.texture:[E.texture];for(let q=0;q<$.length;q++){const ee=$[q],xe=s.convert(ee.format,ee.colorSpace),ge=s.convert(ee.type),ve=v(ee.internalFormat,xe,ge,ee.colorSpace),Ee=se(E);F&&oe(E)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ee,ve,E.width,E.height):oe(E)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ee,ve,E.width,E.height):n.renderbufferStorage(n.RENDERBUFFER,ve,E.width,E.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function Oe(w,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,w),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(E.depthTexture).__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),G(E.depthTexture,0);const $=i.get(E.depthTexture).__webglTexture,q=se(E);if(E.depthTexture.format===Gn)oe(E)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,$,0,q):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,$,0);else if(E.depthTexture.format===xi)oe(E)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,$,0,q):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,$,0);else throw new Error("Unknown depthTexture format")}function Le(w){const E=i.get(w),F=w.isWebGLCubeRenderTarget===!0;if(w.depthTexture&&!E.__autoAllocateDepthBuffer){if(F)throw new Error("target.depthTexture not supported in Cube render targets");Oe(E.__webglFramebuffer,w)}else if(F){E.__webglDepthbuffer=[];for(let $=0;$<6;$++)t.bindFramebuffer(n.FRAMEBUFFER,E.__webglFramebuffer[$]),E.__webglDepthbuffer[$]=n.createRenderbuffer(),Fe(E.__webglDepthbuffer[$],w,!1)}else t.bindFramebuffer(n.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer=n.createRenderbuffer(),Fe(E.__webglDepthbuffer,w,!1);t.bindFramebuffer(n.FRAMEBUFFER,null)}function S(w,E,F){const $=i.get(w);E!==void 0&&Se($.__webglFramebuffer,w,w.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),F!==void 0&&Le(w)}function y(w){const E=w.texture,F=i.get(w),$=i.get(E);w.addEventListener("dispose",z),w.isWebGLMultipleRenderTargets!==!0&&($.__webglTexture===void 0&&($.__webglTexture=n.createTexture()),$.__version=E.version,a.memory.textures++);const q=w.isWebGLCubeRenderTarget===!0,ee=w.isWebGLMultipleRenderTargets===!0,xe=p(w)||o;if(q){F.__webglFramebuffer=[];for(let ge=0;ge<6;ge++)if(o&&E.mipmaps&&E.mipmaps.length>0){F.__webglFramebuffer[ge]=[];for(let ve=0;ve<E.mipmaps.length;ve++)F.__webglFramebuffer[ge][ve]=n.createFramebuffer()}else F.__webglFramebuffer[ge]=n.createFramebuffer()}else{if(o&&E.mipmaps&&E.mipmaps.length>0){F.__webglFramebuffer=[];for(let ge=0;ge<E.mipmaps.length;ge++)F.__webglFramebuffer[ge]=n.createFramebuffer()}else F.__webglFramebuffer=n.createFramebuffer();if(ee)if(r.drawBuffers){const ge=w.texture;for(let ve=0,Ee=ge.length;ve<Ee;ve++){const Pe=i.get(ge[ve]);Pe.__webglTexture===void 0&&(Pe.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&w.samples>0&&oe(w)===!1){const ge=ee?E:[E];F.__webglMultisampledFramebuffer=n.createFramebuffer(),F.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,F.__webglMultisampledFramebuffer);for(let ve=0;ve<ge.length;ve++){const Ee=ge[ve];F.__webglColorRenderbuffer[ve]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,F.__webglColorRenderbuffer[ve]);const Pe=s.convert(Ee.format,Ee.colorSpace),ce=s.convert(Ee.type),Ye=v(Ee.internalFormat,Pe,ce,Ee.colorSpace,w.isXRRenderTarget===!0),ke=se(w);n.renderbufferStorageMultisample(n.RENDERBUFFER,ke,Ye,w.width,w.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ve,n.RENDERBUFFER,F.__webglColorRenderbuffer[ve])}n.bindRenderbuffer(n.RENDERBUFFER,null),w.depthBuffer&&(F.__webglDepthRenderbuffer=n.createRenderbuffer(),Fe(F.__webglDepthRenderbuffer,w,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(q){t.bindTexture(n.TEXTURE_CUBE_MAP,$.__webglTexture),K(n.TEXTURE_CUBE_MAP,E,xe);for(let ge=0;ge<6;ge++)if(o&&E.mipmaps&&E.mipmaps.length>0)for(let ve=0;ve<E.mipmaps.length;ve++)Se(F.__webglFramebuffer[ge][ve],w,E,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,ve);else Se(F.__webglFramebuffer[ge],w,E,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0);_(E,xe)&&x(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ee){const ge=w.texture;for(let ve=0,Ee=ge.length;ve<Ee;ve++){const Pe=ge[ve],ce=i.get(Pe);t.bindTexture(n.TEXTURE_2D,ce.__webglTexture),K(n.TEXTURE_2D,Pe,xe),Se(F.__webglFramebuffer,w,Pe,n.COLOR_ATTACHMENT0+ve,n.TEXTURE_2D,0),_(Pe,xe)&&x(n.TEXTURE_2D)}t.unbindTexture()}else{let ge=n.TEXTURE_2D;if((w.isWebGL3DRenderTarget||w.isWebGLArrayRenderTarget)&&(o?ge=w.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(ge,$.__webglTexture),K(ge,E,xe),o&&E.mipmaps&&E.mipmaps.length>0)for(let ve=0;ve<E.mipmaps.length;ve++)Se(F.__webglFramebuffer[ve],w,E,n.COLOR_ATTACHMENT0,ge,ve);else Se(F.__webglFramebuffer,w,E,n.COLOR_ATTACHMENT0,ge,0);_(E,xe)&&x(ge),t.unbindTexture()}w.depthBuffer&&Le(w)}function k(w){const E=p(w)||o,F=w.isWebGLMultipleRenderTargets===!0?w.texture:[w.texture];for(let $=0,q=F.length;$<q;$++){const ee=F[$];if(_(ee,E)){const xe=w.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,ge=i.get(ee).__webglTexture;t.bindTexture(xe,ge),x(xe),t.unbindTexture()}}}function N(w){if(o&&w.samples>0&&oe(w)===!1){const E=w.isWebGLMultipleRenderTargets?w.texture:[w.texture],F=w.width,$=w.height;let q=n.COLOR_BUFFER_BIT;const ee=[],xe=w.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,ge=i.get(w),ve=w.isWebGLMultipleRenderTargets===!0;if(ve)for(let Ee=0;Ee<E.length;Ee++)t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,ge.__webglMultisampledFramebuffer),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,ge.__webglFramebuffer);for(let Ee=0;Ee<E.length;Ee++){ee.push(n.COLOR_ATTACHMENT0+Ee),w.depthBuffer&&ee.push(xe);const Pe=ge.__ignoreDepthValues!==void 0?ge.__ignoreDepthValues:!1;if(Pe===!1&&(w.depthBuffer&&(q|=n.DEPTH_BUFFER_BIT),w.stencilBuffer&&(q|=n.STENCIL_BUFFER_BIT)),ve&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,ge.__webglColorRenderbuffer[Ee]),Pe===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[xe]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[xe])),ve){const ce=i.get(E[Ee]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,ce,0)}n.blitFramebuffer(0,0,F,$,0,0,F,$,q,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,ee)}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),ve)for(let Ee=0;Ee<E.length;Ee++){t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.RENDERBUFFER,ge.__webglColorRenderbuffer[Ee]);const Pe=i.get(E[Ee]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,ge.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.TEXTURE_2D,Pe,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,ge.__webglMultisampledFramebuffer)}}function se(w){return Math.min(r.maxSamples,w.samples)}function oe(w){const E=i.get(w);return o&&w.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function J(w){const E=a.render.frame;d.get(w)!==E&&(d.set(w,E),w.update())}function pe(w,E){const F=w.colorSpace,$=w.format,q=w.type;return w.isCompressedTexture===!0||w.isVideoTexture===!0||w.format===Fs||F!==ln&&F!==Ht&&(je.getTransfer(F)===tt?o===!1?e.has("EXT_sRGB")===!0&&$===Zt?(w.format=Fs,w.minFilter=kt,w.generateMipmaps=!1):E=dc.sRGBToLinear(E):($!==Zt||q!==Sn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",F)),E}this.allocateTextureUnit=D,this.resetTextureUnits=Y,this.setTexture2D=G,this.setTexture2DArray=X,this.setTexture3D=Q,this.setTextureCube=ne,this.rebindTextures=S,this.setupRenderTarget=y,this.updateRenderTargetMipmap=k,this.updateMultisampleRenderTarget=N,this.setupDepthRenderbuffer=Le,this.setupFrameBufferTexture=Se,this.useMultisampledRTT=oe}function nm(n,e,t){const i=t.isWebGL2;function r(s,a=Ht){let o;const c=je.getTransfer(a);if(s===Sn)return n.UNSIGNED_BYTE;if(s===nc)return n.UNSIGNED_SHORT_4_4_4_4;if(s===ic)return n.UNSIGNED_SHORT_5_5_5_1;if(s===Ol)return n.BYTE;if(s===zl)return n.SHORT;if(s===qs)return n.UNSIGNED_SHORT;if(s===tc)return n.INT;if(s===xn)return n.UNSIGNED_INT;if(s===vn)return n.FLOAT;if(s===ki)return i?n.HALF_FLOAT:(o=e.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(s===Bl)return n.ALPHA;if(s===Zt)return n.RGBA;if(s===kl)return n.LUMINANCE;if(s===Gl)return n.LUMINANCE_ALPHA;if(s===Gn)return n.DEPTH_COMPONENT;if(s===xi)return n.DEPTH_STENCIL;if(s===Fs)return o=e.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(s===Hl)return n.RED;if(s===rc)return n.RED_INTEGER;if(s===Vl)return n.RG;if(s===sc)return n.RG_INTEGER;if(s===oc)return n.RGBA_INTEGER;if(s===jr||s===Kr||s===$r||s===Jr)if(c===tt)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(s===jr)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Kr)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===$r)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Jr)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(s===jr)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Kr)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===$r)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Jr)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===yo||s===So||s===Eo||s===bo)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(s===yo)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===So)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Eo)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===bo)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===ac)return o=e.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===wo||s===To)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(s===wo)return c===tt?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(s===To)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Ao||s===Ro||s===Co||s===Lo||s===Po||s===Do||s===Uo||s===Io||s===No||s===Fo||s===Oo||s===zo||s===Bo||s===ko)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(s===Ao)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Ro)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Co)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Lo)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Po)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Do)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Uo)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Io)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===No)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Fo)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Oo)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===zo)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Bo)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===ko)return c===tt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Qr||s===Go||s===Ho)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(s===Qr)return c===tt?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Go)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Ho)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===Wl||s===Vo||s===Wo||s===Xo)if(o=e.get("EXT_texture_compression_rgtc"),o!==null){if(s===Qr)return o.COMPRESSED_RED_RGTC1_EXT;if(s===Vo)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===Wo)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Xo)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===kn?i?n.UNSIGNED_INT_24_8:(o=e.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[s]!==void 0?n[s]:null}return{convert:r}}class im extends Gt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class xt extends ut{constructor(){super(),this.isGroup=!0,this.type="Group"}}const rm={type:"move"};class bs{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new xt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new xt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new O,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new O),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new xt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new O,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new O),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,a=null;const o=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){a=!0;for(const g of e.hand.values()){const p=t.getJointPose(g,i),f=this._getHandJoint(l,g);p!==null&&(f.matrix.fromArray(p.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=p.radius),f.visible=p!==null}const d=l.joints["index-finger-tip"],h=l.joints["thumb-tip"],u=d.position.distanceTo(h.position),m=.02,M=.005;l.inputState.pinching&&u>m+M?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&u<=m-M&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(rm)))}return o!==null&&(o.visible=r!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new xt;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class sm extends Si{constructor(e,t){super();const i=this;let r=null,s=1,a=null,o="local-floor",c=1,l=null,d=null,h=null,u=null,m=null,M=null;const g=t.getContextAttributes();let p=null,f=null;const _=[],x=[],v=new qe;let R=null;const L=new Gt;L.layers.enable(1),L.viewport=new _t;const C=new Gt;C.layers.enable(2),C.viewport=new _t;const z=[L,C],b=new im;b.layers.enable(1),b.layers.enable(2);let T=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let re=_[K];return re===void 0&&(re=new bs,_[K]=re),re.getTargetRaySpace()},this.getControllerGrip=function(K){let re=_[K];return re===void 0&&(re=new bs,_[K]=re),re.getGripSpace()},this.getHand=function(K){let re=_[K];return re===void 0&&(re=new bs,_[K]=re),re.getHandSpace()};function U(K){const re=x.indexOf(K.inputSource);if(re===-1)return;const me=_[re];me!==void 0&&(me.update(K.inputSource,K.frame,l||a),me.dispatchEvent({type:K.type,data:K.inputSource}))}function Y(){r.removeEventListener("select",U),r.removeEventListener("selectstart",U),r.removeEventListener("selectend",U),r.removeEventListener("squeeze",U),r.removeEventListener("squeezestart",U),r.removeEventListener("squeezeend",U),r.removeEventListener("end",Y),r.removeEventListener("inputsourceschange",D);for(let K=0;K<_.length;K++){const re=x[K];re!==null&&(x[K]=null,_[K].disconnect(re))}T=null,H=null,e.setRenderTarget(p),m=null,u=null,h=null,r=null,f=null,fe.stop(),i.isPresenting=!1,e.setPixelRatio(R),e.setSize(v.width,v.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(K){s=K,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){o=K,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(K){l=K},this.getBaseLayer=function(){return u!==null?u:m},this.getBinding=function(){return h},this.getFrame=function(){return M},this.getSession=function(){return r},this.setSession=async function(K){if(r=K,r!==null){if(p=e.getRenderTarget(),r.addEventListener("select",U),r.addEventListener("selectstart",U),r.addEventListener("selectend",U),r.addEventListener("squeeze",U),r.addEventListener("squeezestart",U),r.addEventListener("squeezeend",U),r.addEventListener("end",Y),r.addEventListener("inputsourceschange",D),g.xrCompatible!==!0&&await t.makeXRCompatible(),R=e.getPixelRatio(),e.getSize(v),r.renderState.layers===void 0||e.capabilities.isWebGL2===!1){const re={antialias:r.renderState.layers===void 0?g.antialias:!0,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:s};m=new XRWebGLLayer(r,t,re),r.updateRenderState({baseLayer:m}),e.setPixelRatio(1),e.setSize(m.framebufferWidth,m.framebufferHeight,!1),f=new Vn(m.framebufferWidth,m.framebufferHeight,{format:Zt,type:Sn,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil})}else{let re=null,me=null,we=null;g.depth&&(we=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,re=g.stencil?xi:Gn,me=g.stencil?kn:xn);const Se={colorFormat:t.RGBA8,depthFormat:we,scaleFactor:s};h=new XRWebGLBinding(r,t),u=h.createProjectionLayer(Se),r.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),f=new Vn(u.textureWidth,u.textureHeight,{format:Zt,type:Sn,depthTexture:new Ec(u.textureWidth,u.textureHeight,me,void 0,void 0,void 0,void 0,void 0,void 0,re),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0});const Fe=e.properties.get(f);Fe.__ignoreDepthValues=u.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await r.requestReferenceSpace(o),fe.setContext(r),fe.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode};function D(K){for(let re=0;re<K.removed.length;re++){const me=K.removed[re],we=x.indexOf(me);we>=0&&(x[we]=null,_[we].disconnect(me))}for(let re=0;re<K.added.length;re++){const me=K.added[re];let we=x.indexOf(me);if(we===-1){for(let Fe=0;Fe<_.length;Fe++)if(Fe>=x.length){x.push(me),we=Fe;break}else if(x[Fe]===null){x[Fe]=me,we=Fe;break}if(we===-1)break}const Se=_[we];Se&&Se.connect(me)}}const I=new O,G=new O;function X(K,re,me){I.setFromMatrixPosition(re.matrixWorld),G.setFromMatrixPosition(me.matrixWorld);const we=I.distanceTo(G),Se=re.projectionMatrix.elements,Fe=me.projectionMatrix.elements,Oe=Se[14]/(Se[10]-1),Le=Se[14]/(Se[10]+1),S=(Se[9]+1)/Se[5],y=(Se[9]-1)/Se[5],k=(Se[8]-1)/Se[0],N=(Fe[8]+1)/Fe[0],se=Oe*k,oe=Oe*N,J=we/(-k+N),pe=J*-k;re.matrixWorld.decompose(K.position,K.quaternion,K.scale),K.translateX(pe),K.translateZ(J),K.matrixWorld.compose(K.position,K.quaternion,K.scale),K.matrixWorldInverse.copy(K.matrixWorld).invert();const w=Oe+J,E=Le+J,F=se-pe,$=oe+(we-pe),q=S*Le/E*w,ee=y*Le/E*w;K.projectionMatrix.makePerspective(F,$,q,ee,w,E),K.projectionMatrixInverse.copy(K.projectionMatrix).invert()}function Q(K,re){re===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(re.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(r===null)return;b.near=C.near=L.near=K.near,b.far=C.far=L.far=K.far,(T!==b.near||H!==b.far)&&(r.updateRenderState({depthNear:b.near,depthFar:b.far}),T=b.near,H=b.far);const re=K.parent,me=b.cameras;Q(b,re);for(let we=0;we<me.length;we++)Q(me[we],re);me.length===2?X(b,L,C):b.projectionMatrix.copy(L.projectionMatrix),ne(K,b,re)};function ne(K,re,me){me===null?K.matrix.copy(re.matrixWorld):(K.matrix.copy(me.matrixWorld),K.matrix.invert(),K.matrix.multiply(re.matrixWorld)),K.matrix.decompose(K.position,K.quaternion,K.scale),K.updateMatrixWorld(!0),K.projectionMatrix.copy(re.projectionMatrix),K.projectionMatrixInverse.copy(re.projectionMatrixInverse),K.isPerspectiveCamera&&(K.fov=Os*2*Math.atan(1/K.projectionMatrix.elements[5]),K.zoom=1)}this.getCamera=function(){return b},this.getFoveation=function(){if(!(u===null&&m===null))return c},this.setFoveation=function(K){c=K,u!==null&&(u.fixedFoveation=K),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=K)};let te=null;function he(K,re){if(d=re.getViewerPose(l||a),M=re,d!==null){const me=d.views;m!==null&&(e.setRenderTargetFramebuffer(f,m.framebuffer),e.setRenderTarget(f));let we=!1;me.length!==b.cameras.length&&(b.cameras.length=0,we=!0);for(let Se=0;Se<me.length;Se++){const Fe=me[Se];let Oe=null;if(m!==null)Oe=m.getViewport(Fe);else{const S=h.getViewSubImage(u,Fe);Oe=S.viewport,Se===0&&(e.setRenderTargetTextures(f,S.colorTexture,u.ignoreDepthValues?void 0:S.depthStencilTexture),e.setRenderTarget(f))}let Le=z[Se];Le===void 0&&(Le=new Gt,Le.layers.enable(Se),Le.viewport=new _t,z[Se]=Le),Le.matrix.fromArray(Fe.transform.matrix),Le.matrix.decompose(Le.position,Le.quaternion,Le.scale),Le.projectionMatrix.fromArray(Fe.projectionMatrix),Le.projectionMatrixInverse.copy(Le.projectionMatrix).invert(),Le.viewport.set(Oe.x,Oe.y,Oe.width,Oe.height),Se===0&&(b.matrix.copy(Le.matrix),b.matrix.decompose(b.position,b.quaternion,b.scale)),we===!0&&b.cameras.push(Le)}}for(let me=0;me<_.length;me++){const we=x[me],Se=_[me];we!==null&&Se!==void 0&&Se.update(we,re,l||a)}te&&te(K,re),re.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:re}),M=null}const fe=new yc;fe.setAnimationLoop(he),this.setAnimationLoop=function(K){te=K},this.dispose=function(){}}}function om(n,e){function t(p,f){p.matrixAutoUpdate===!0&&p.updateMatrix(),f.value.copy(p.matrix)}function i(p,f){f.color.getRGB(p.fogColor.value,xc(n)),f.isFog?(p.fogNear.value=f.near,p.fogFar.value=f.far):f.isFogExp2&&(p.fogDensity.value=f.density)}function r(p,f,_,x,v){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(p,f):f.isMeshToonMaterial?(s(p,f),h(p,f)):f.isMeshPhongMaterial?(s(p,f),d(p,f)):f.isMeshStandardMaterial?(s(p,f),u(p,f),f.isMeshPhysicalMaterial&&m(p,f,v)):f.isMeshMatcapMaterial?(s(p,f),M(p,f)):f.isMeshDepthMaterial?s(p,f):f.isMeshDistanceMaterial?(s(p,f),g(p,f)):f.isMeshNormalMaterial?s(p,f):f.isLineBasicMaterial?(a(p,f),f.isLineDashedMaterial&&o(p,f)):f.isPointsMaterial?c(p,f,_,x):f.isSpriteMaterial?l(p,f):f.isShadowMaterial?(p.color.value.copy(f.color),p.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(p,f){p.opacity.value=f.opacity,f.color&&p.diffuse.value.copy(f.color),f.emissive&&p.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(p.map.value=f.map,t(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.bumpMap&&(p.bumpMap.value=f.bumpMap,t(f.bumpMap,p.bumpMapTransform),p.bumpScale.value=f.bumpScale,f.side===Pt&&(p.bumpScale.value*=-1)),f.normalMap&&(p.normalMap.value=f.normalMap,t(f.normalMap,p.normalMapTransform),p.normalScale.value.copy(f.normalScale),f.side===Pt&&p.normalScale.value.negate()),f.displacementMap&&(p.displacementMap.value=f.displacementMap,t(f.displacementMap,p.displacementMapTransform),p.displacementScale.value=f.displacementScale,p.displacementBias.value=f.displacementBias),f.emissiveMap&&(p.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,p.emissiveMapTransform)),f.specularMap&&(p.specularMap.value=f.specularMap,t(f.specularMap,p.specularMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);const _=e.get(f).envMap;if(_&&(p.envMap.value=_,p.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=f.reflectivity,p.ior.value=f.ior,p.refractionRatio.value=f.refractionRatio),f.lightMap){p.lightMap.value=f.lightMap;const x=n._useLegacyLights===!0?Math.PI:1;p.lightMapIntensity.value=f.lightMapIntensity*x,t(f.lightMap,p.lightMapTransform)}f.aoMap&&(p.aoMap.value=f.aoMap,p.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,p.aoMapTransform))}function a(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,f.map&&(p.map.value=f.map,t(f.map,p.mapTransform))}function o(p,f){p.dashSize.value=f.dashSize,p.totalSize.value=f.dashSize+f.gapSize,p.scale.value=f.scale}function c(p,f,_,x){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.size.value=f.size*_,p.scale.value=x*.5,f.map&&(p.map.value=f.map,t(f.map,p.uvTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function l(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.rotation.value=f.rotation,f.map&&(p.map.value=f.map,t(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function d(p,f){p.specular.value.copy(f.specular),p.shininess.value=Math.max(f.shininess,1e-4)}function h(p,f){f.gradientMap&&(p.gradientMap.value=f.gradientMap)}function u(p,f){p.metalness.value=f.metalness,f.metalnessMap&&(p.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,p.metalnessMapTransform)),p.roughness.value=f.roughness,f.roughnessMap&&(p.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,p.roughnessMapTransform)),e.get(f).envMap&&(p.envMapIntensity.value=f.envMapIntensity)}function m(p,f,_){p.ior.value=f.ior,f.sheen>0&&(p.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),p.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(p.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,p.sheenColorMapTransform)),f.sheenRoughnessMap&&(p.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,p.sheenRoughnessMapTransform))),f.clearcoat>0&&(p.clearcoat.value=f.clearcoat,p.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(p.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,p.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(p.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Pt&&p.clearcoatNormalScale.value.negate())),f.iridescence>0&&(p.iridescence.value=f.iridescence,p.iridescenceIOR.value=f.iridescenceIOR,p.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(p.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,p.iridescenceMapTransform)),f.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),f.transmission>0&&(p.transmission.value=f.transmission,p.transmissionSamplerMap.value=_.texture,p.transmissionSamplerSize.value.set(_.width,_.height),f.transmissionMap&&(p.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,p.transmissionMapTransform)),p.thickness.value=f.thickness,f.thicknessMap&&(p.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=f.attenuationDistance,p.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(p.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(p.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=f.specularIntensity,p.specularColor.value.copy(f.specularColor),f.specularColorMap&&(p.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,p.specularColorMapTransform)),f.specularIntensityMap&&(p.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,p.specularIntensityMapTransform))}function M(p,f){f.matcap&&(p.matcap.value=f.matcap)}function g(p,f){const _=e.get(f).light;p.referencePosition.value.setFromMatrixPosition(_.matrixWorld),p.nearDistance.value=_.shadow.camera.near,p.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function am(n,e,t,i){let r={},s={},a=[];const o=t.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(_,x){const v=x.program;i.uniformBlockBinding(_,v)}function l(_,x){let v=r[_.id];v===void 0&&(M(_),v=d(_),r[_.id]=v,_.addEventListener("dispose",p));const R=x.program;i.updateUBOMapping(_,R);const L=e.render.frame;s[_.id]!==L&&(u(_),s[_.id]=L)}function d(_){const x=h();_.__bindingPointIndex=x;const v=n.createBuffer(),R=_.__size,L=_.usage;return n.bindBuffer(n.UNIFORM_BUFFER,v),n.bufferData(n.UNIFORM_BUFFER,R,L),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,x,v),v}function h(){for(let _=0;_<o;_++)if(a.indexOf(_)===-1)return a.push(_),_;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(_){const x=r[_.id],v=_.uniforms,R=_.__cache;n.bindBuffer(n.UNIFORM_BUFFER,x);for(let L=0,C=v.length;L<C;L++){const z=Array.isArray(v[L])?v[L]:[v[L]];for(let b=0,T=z.length;b<T;b++){const H=z[b];if(m(H,L,b,R)===!0){const U=H.__offset,Y=Array.isArray(H.value)?H.value:[H.value];let D=0;for(let I=0;I<Y.length;I++){const G=Y[I],X=g(G);typeof G=="number"||typeof G=="boolean"?(H.__data[0]=G,n.bufferSubData(n.UNIFORM_BUFFER,U+D,H.__data)):G.isMatrix3?(H.__data[0]=G.elements[0],H.__data[1]=G.elements[1],H.__data[2]=G.elements[2],H.__data[3]=0,H.__data[4]=G.elements[3],H.__data[5]=G.elements[4],H.__data[6]=G.elements[5],H.__data[7]=0,H.__data[8]=G.elements[6],H.__data[9]=G.elements[7],H.__data[10]=G.elements[8],H.__data[11]=0):(G.toArray(H.__data,D),D+=X.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,U,H.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function m(_,x,v,R){const L=_.value,C=x+"_"+v;if(R[C]===void 0)return typeof L=="number"||typeof L=="boolean"?R[C]=L:R[C]=L.clone(),!0;{const z=R[C];if(typeof L=="number"||typeof L=="boolean"){if(z!==L)return R[C]=L,!0}else if(z.equals(L)===!1)return z.copy(L),!0}return!1}function M(_){const x=_.uniforms;let v=0;const R=16;for(let C=0,z=x.length;C<z;C++){const b=Array.isArray(x[C])?x[C]:[x[C]];for(let T=0,H=b.length;T<H;T++){const U=b[T],Y=Array.isArray(U.value)?U.value:[U.value];for(let D=0,I=Y.length;D<I;D++){const G=Y[D],X=g(G),Q=v%R;Q!==0&&R-Q<X.boundary&&(v+=R-Q),U.__data=new Float32Array(X.storage/Float32Array.BYTES_PER_ELEMENT),U.__offset=v,v+=X.storage}}}const L=v%R;return L>0&&(v+=R-L),_.__size=v,_.__cache={},this}function g(_){const x={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(x.boundary=4,x.storage=4):_.isVector2?(x.boundary=8,x.storage=8):_.isVector3||_.isColor?(x.boundary=16,x.storage=12):_.isVector4?(x.boundary=16,x.storage=16):_.isMatrix3?(x.boundary=48,x.storage=48):_.isMatrix4?(x.boundary=64,x.storage=64):_.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",_),x}function p(_){const x=_.target;x.removeEventListener("dispose",p);const v=a.indexOf(x.__bindingPointIndex);a.splice(v,1),n.deleteBuffer(r[x.id]),delete r[x.id],delete s[x.id]}function f(){for(const _ in r)n.deleteBuffer(r[_]);a=[],r={},s={}}return{bind:c,update:l,dispose:f}}class Cc{constructor(e={}){const{canvas:t=nh(),context:i=null,depth:r=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:h=!1}=e;this.isWebGLRenderer=!0;let u;i!==null?u=i.getContextAttributes().alpha:u=a;const m=new Uint32Array(4),M=new Int32Array(4);let g=null,p=null;const f=[],_=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=lt,this._useLegacyLights=!1,this.toneMapping=yn,this.toneMappingExposure=1;const x=this;let v=!1,R=0,L=0,C=null,z=-1,b=null;const T=new _t,H=new _t;let U=null;const Y=new Ze(0);let D=0,I=t.width,G=t.height,X=1,Q=null,ne=null;const te=new _t(0,0,I,G),he=new _t(0,0,I,G);let fe=!1;const K=new js;let re=!1,me=!1,we=null;const Se=new Ke,Fe=new qe,Oe=new O,Le={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function S(){return C===null?X:1}let y=i;function k(A,B){for(let W=0;W<A.length;W++){const j=A[W],V=t.getContext(j,B);if(V!==null)return V}return null}try{const A={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:d,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Ws}`),t.addEventListener("webglcontextlost",Z,!1),t.addEventListener("webglcontextrestored",P,!1),t.addEventListener("webglcontextcreationerror",le,!1),y===null){const B=["webgl2","webgl","experimental-webgl"];if(x.isWebGL1Renderer===!0&&B.shift(),y=k(B,A),y===null)throw k(B)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&y instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),y.getShaderPrecisionFormat===void 0&&(y.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(A){throw console.error("THREE.WebGLRenderer: "+A.message),A}let N,se,oe,J,pe,w,E,F,$,q,ee,xe,ge,ve,Ee,Pe,ce,Ye,ke,De,Ae,ye,Ue,ie;function ae(){N=new _f(y),se=new uf(y,N,e),N.init(se),ye=new nm(y,N,se),oe=new em(y,N,se),J=new Mf(y),pe=new kp,w=new tm(y,N,oe,pe,se,ye,J),E=new ff(x),F=new gf(x),$=new Ah(y,se),Ue=new lf(y,N,$,se),q=new xf(y,$,J,Ue),ee=new bf(y,q,$,J),ke=new Ef(y,se,w),Pe=new df(pe),xe=new Bp(x,E,F,N,se,Ue,Pe),ge=new om(x,pe),ve=new Hp,Ee=new Zp(N,se),Ye=new cf(x,E,F,oe,ee,u,c),ce=new Qp(x,ee,se),ie=new am(y,J,se,oe),De=new hf(y,N,J,se),Ae=new vf(y,N,J,se),J.programs=xe.programs,x.capabilities=se,x.extensions=N,x.properties=pe,x.renderLists=ve,x.shadowMap=ce,x.state=oe,x.info=J}ae();const ue=new sm(x,y);this.xr=ue,this.getContext=function(){return y},this.getContextAttributes=function(){return y.getContextAttributes()},this.forceContextLoss=function(){const A=N.get("WEBGL_lose_context");A&&A.loseContext()},this.forceContextRestore=function(){const A=N.get("WEBGL_lose_context");A&&A.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(A){A!==void 0&&(X=A,this.setSize(I,G,!1))},this.getSize=function(A){return A.set(I,G)},this.setSize=function(A,B,W=!0){if(ue.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}I=A,G=B,t.width=Math.floor(A*X),t.height=Math.floor(B*X),W===!0&&(t.style.width=A+"px",t.style.height=B+"px"),this.setViewport(0,0,A,B)},this.getDrawingBufferSize=function(A){return A.set(I*X,G*X).floor()},this.setDrawingBufferSize=function(A,B,W){I=A,G=B,X=W,t.width=Math.floor(A*W),t.height=Math.floor(B*W),this.setViewport(0,0,A,B)},this.getCurrentViewport=function(A){return A.copy(T)},this.getViewport=function(A){return A.copy(te)},this.setViewport=function(A,B,W,j){A.isVector4?te.set(A.x,A.y,A.z,A.w):te.set(A,B,W,j),oe.viewport(T.copy(te).multiplyScalar(X).floor())},this.getScissor=function(A){return A.copy(he)},this.setScissor=function(A,B,W,j){A.isVector4?he.set(A.x,A.y,A.z,A.w):he.set(A,B,W,j),oe.scissor(H.copy(he).multiplyScalar(X).floor())},this.getScissorTest=function(){return fe},this.setScissorTest=function(A){oe.setScissorTest(fe=A)},this.setOpaqueSort=function(A){Q=A},this.setTransparentSort=function(A){ne=A},this.getClearColor=function(A){return A.copy(Ye.getClearColor())},this.setClearColor=function(){Ye.setClearColor.apply(Ye,arguments)},this.getClearAlpha=function(){return Ye.getClearAlpha()},this.setClearAlpha=function(){Ye.setClearAlpha.apply(Ye,arguments)},this.clear=function(A=!0,B=!0,W=!0){let j=0;if(A){let V=!1;if(C!==null){const Me=C.texture.format;V=Me===oc||Me===sc||Me===rc}if(V){const Me=C.texture.type,Te=Me===Sn||Me===xn||Me===qs||Me===kn||Me===nc||Me===ic,Ce=Ye.getClearColor(),Ie=Ye.getClearAlpha(),Ve=Ce.r,ze=Ce.g,Be=Ce.b;Te?(m[0]=Ve,m[1]=ze,m[2]=Be,m[3]=Ie,y.clearBufferuiv(y.COLOR,0,m)):(M[0]=Ve,M[1]=ze,M[2]=Be,M[3]=Ie,y.clearBufferiv(y.COLOR,0,M))}else j|=y.COLOR_BUFFER_BIT}B&&(j|=y.DEPTH_BUFFER_BIT),W&&(j|=y.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),y.clear(j)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Z,!1),t.removeEventListener("webglcontextrestored",P,!1),t.removeEventListener("webglcontextcreationerror",le,!1),ve.dispose(),Ee.dispose(),pe.dispose(),E.dispose(),F.dispose(),ee.dispose(),Ue.dispose(),ie.dispose(),xe.dispose(),ue.dispose(),ue.removeEventListener("sessionstart",bt),ue.removeEventListener("sessionend",Qe),we&&(we.dispose(),we=null),wt.stop()};function Z(A){A.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),v=!0}function P(){console.log("THREE.WebGLRenderer: Context Restored."),v=!1;const A=J.autoReset,B=ce.enabled,W=ce.autoUpdate,j=ce.needsUpdate,V=ce.type;ae(),J.autoReset=A,ce.enabled=B,ce.autoUpdate=W,ce.needsUpdate=j,ce.type=V}function le(A){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",A.statusMessage)}function de(A){const B=A.target;B.removeEventListener("dispose",de),be(B)}function be(A){Re(A),pe.remove(A)}function Re(A){const B=pe.get(A).programs;B!==void 0&&(B.forEach(function(W){xe.releaseProgram(W)}),A.isShaderMaterial&&xe.releaseShaderCache(A))}this.renderBufferDirect=function(A,B,W,j,V,Me){B===null&&(B=Le);const Te=V.isMesh&&V.matrixWorld.determinant()<0,Ce=Hc(A,B,W,j,V);oe.setMaterial(j,Te);let Ie=W.index,Ve=1;if(j.wireframe===!0){if(Ie=q.getWireframeAttribute(W),Ie===void 0)return;Ve=2}const ze=W.drawRange,Be=W.attributes.position;let ot=ze.start*Ve,Ut=(ze.start+ze.count)*Ve;Me!==null&&(ot=Math.max(ot,Me.start*Ve),Ut=Math.min(Ut,(Me.start+Me.count)*Ve)),Ie!==null?(ot=Math.max(ot,0),Ut=Math.min(Ut,Ie.count)):Be!=null&&(ot=Math.max(ot,0),Ut=Math.min(Ut,Be.count));const mt=Ut-ot;if(mt<0||mt===1/0)return;Ue.setup(V,j,Ce,W,Ie);let Qt,rt=De;if(Ie!==null&&(Qt=$.get(Ie),rt=Ae,rt.setIndex(Qt)),V.isMesh)j.wireframe===!0?(oe.setLineWidth(j.wireframeLinewidth*S()),rt.setMode(y.LINES)):rt.setMode(y.TRIANGLES);else if(V.isLine){let We=j.linewidth;We===void 0&&(We=1),oe.setLineWidth(We*S()),V.isLineSegments?rt.setMode(y.LINES):V.isLineLoop?rt.setMode(y.LINE_LOOP):rt.setMode(y.LINE_STRIP)}else V.isPoints?rt.setMode(y.POINTS):V.isSprite&&rt.setMode(y.TRIANGLES);if(V.isBatchedMesh)rt.renderMultiDraw(V._multiDrawStarts,V._multiDrawCounts,V._multiDrawCount);else if(V.isInstancedMesh)rt.renderInstances(ot,mt,V.count);else if(W.isInstancedBufferGeometry){const We=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,Vr=Math.min(W.instanceCount,We);rt.renderInstances(ot,mt,Vr)}else rt.render(ot,mt)};function $e(A,B,W){A.transparent===!0&&A.side===ht&&A.forceSinglePass===!1?(A.side=Pt,A.needsUpdate=!0,Zi(A,B,W),A.side=cn,A.needsUpdate=!0,Zi(A,B,W),A.side=ht):Zi(A,B,W)}this.compile=function(A,B,W=null){W===null&&(W=A),p=Ee.get(W),p.init(),_.push(p),W.traverseVisible(function(V){V.isLight&&V.layers.test(B.layers)&&(p.pushLight(V),V.castShadow&&p.pushShadow(V))}),A!==W&&A.traverseVisible(function(V){V.isLight&&V.layers.test(B.layers)&&(p.pushLight(V),V.castShadow&&p.pushShadow(V))}),p.setupLights(x._useLegacyLights);const j=new Set;return A.traverse(function(V){const Me=V.material;if(Me)if(Array.isArray(Me))for(let Te=0;Te<Me.length;Te++){const Ce=Me[Te];$e(Ce,W,V),j.add(Ce)}else $e(Me,W,V),j.add(Me)}),_.pop(),p=null,j},this.compileAsync=function(A,B,W=null){const j=this.compile(A,B,W);return new Promise(V=>{function Me(){if(j.forEach(function(Te){pe.get(Te).currentProgram.isReady()&&j.delete(Te)}),j.size===0){V(A);return}setTimeout(Me,10)}N.get("KHR_parallel_shader_compile")!==null?Me():setTimeout(Me,10)})};let Je=null;function pt(A){Je&&Je(A)}function bt(){wt.stop()}function Qe(){wt.start()}const wt=new yc;wt.setAnimationLoop(pt),typeof self<"u"&&wt.setContext(self),this.setAnimationLoop=function(A){Je=A,ue.setAnimationLoop(A),A===null?wt.stop():wt.start()},ue.addEventListener("sessionstart",bt),ue.addEventListener("sessionend",Qe),this.render=function(A,B){if(B!==void 0&&B.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(v===!0)return;A.matrixWorldAutoUpdate===!0&&A.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),ue.enabled===!0&&ue.isPresenting===!0&&(ue.cameraAutoUpdate===!0&&ue.updateCamera(B),B=ue.getCamera()),A.isScene===!0&&A.onBeforeRender(x,A,B,C),p=Ee.get(A,_.length),p.init(),_.push(p),Se.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),K.setFromProjectionMatrix(Se),me=this.localClippingEnabled,re=Pe.init(this.clippingPlanes,me),g=ve.get(A,f.length),g.init(),f.push(g),$t(A,B,0,x.sortObjects),g.finish(),x.sortObjects===!0&&g.sort(Q,ne),this.info.render.frame++,re===!0&&Pe.beginShadows();const W=p.state.shadowsArray;if(ce.render(W,A,B),re===!0&&Pe.endShadows(),this.info.autoReset===!0&&this.info.reset(),Ye.render(g,A),p.setupLights(x._useLegacyLights),B.isArrayCamera){const j=B.cameras;for(let V=0,Me=j.length;V<Me;V++){const Te=j[V];io(g,A,Te,Te.viewport)}}else io(g,A,B);C!==null&&(w.updateMultisampleRenderTarget(C),w.updateRenderTargetMipmap(C)),A.isScene===!0&&A.onAfterRender(x,A,B),Ue.resetDefaultState(),z=-1,b=null,_.pop(),_.length>0?p=_[_.length-1]:p=null,f.pop(),f.length>0?g=f[f.length-1]:g=null};function $t(A,B,W,j){if(A.visible===!1)return;if(A.layers.test(B.layers)){if(A.isGroup)W=A.renderOrder;else if(A.isLOD)A.autoUpdate===!0&&A.update(B);else if(A.isLight)p.pushLight(A),A.castShadow&&p.pushShadow(A);else if(A.isSprite){if(!A.frustumCulled||K.intersectsSprite(A)){j&&Oe.setFromMatrixPosition(A.matrixWorld).applyMatrix4(Se);const Te=ee.update(A),Ce=A.material;Ce.visible&&g.push(A,Te,Ce,W,Oe.z,null)}}else if((A.isMesh||A.isLine||A.isPoints)&&(!A.frustumCulled||K.intersectsObject(A))){const Te=ee.update(A),Ce=A.material;if(j&&(A.boundingSphere!==void 0?(A.boundingSphere===null&&A.computeBoundingSphere(),Oe.copy(A.boundingSphere.center)):(Te.boundingSphere===null&&Te.computeBoundingSphere(),Oe.copy(Te.boundingSphere.center)),Oe.applyMatrix4(A.matrixWorld).applyMatrix4(Se)),Array.isArray(Ce)){const Ie=Te.groups;for(let Ve=0,ze=Ie.length;Ve<ze;Ve++){const Be=Ie[Ve],ot=Ce[Be.materialIndex];ot&&ot.visible&&g.push(A,Te,ot,W,Oe.z,Be)}}else Ce.visible&&g.push(A,Te,Ce,W,Oe.z,null)}}const Me=A.children;for(let Te=0,Ce=Me.length;Te<Ce;Te++)$t(Me[Te],B,W,j)}function io(A,B,W,j){const V=A.opaque,Me=A.transmissive,Te=A.transparent;p.setupLightsView(W),re===!0&&Pe.setGlobalState(x.clippingPlanes,W),Me.length>0&&Gc(V,Me,B,W),j&&oe.viewport(T.copy(j)),V.length>0&&Yi(V,B,W),Me.length>0&&Yi(Me,B,W),Te.length>0&&Yi(Te,B,W),oe.buffers.depth.setTest(!0),oe.buffers.depth.setMask(!0),oe.buffers.color.setMask(!0),oe.setPolygonOffset(!1)}function Gc(A,B,W,j){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;const Me=se.isWebGL2;we===null&&(we=new Vn(1,1,{generateMipmaps:!0,type:N.has("EXT_color_buffer_half_float")?ki:Sn,minFilter:Bi,samples:Me?4:0})),x.getDrawingBufferSize(Fe),Me?we.setSize(Fe.x,Fe.y):we.setSize(zs(Fe.x),zs(Fe.y));const Te=x.getRenderTarget();x.setRenderTarget(we),x.getClearColor(Y),D=x.getClearAlpha(),D<1&&x.setClearColor(16777215,.5),x.clear();const Ce=x.toneMapping;x.toneMapping=yn,Yi(A,W,j),w.updateMultisampleRenderTarget(we),w.updateRenderTargetMipmap(we);let Ie=!1;for(let Ve=0,ze=B.length;Ve<ze;Ve++){const Be=B[Ve],ot=Be.object,Ut=Be.geometry,mt=Be.material,Qt=Be.group;if(mt.side===ht&&ot.layers.test(j.layers)){const rt=mt.side;mt.side=Pt,mt.needsUpdate=!0,ro(ot,W,j,Ut,mt,Qt),mt.side=rt,mt.needsUpdate=!0,Ie=!0}}Ie===!0&&(w.updateMultisampleRenderTarget(we),w.updateRenderTargetMipmap(we)),x.setRenderTarget(Te),x.setClearColor(Y,D),x.toneMapping=Ce}function Yi(A,B,W){const j=B.isScene===!0?B.overrideMaterial:null;for(let V=0,Me=A.length;V<Me;V++){const Te=A[V],Ce=Te.object,Ie=Te.geometry,Ve=j===null?Te.material:j,ze=Te.group;Ce.layers.test(W.layers)&&ro(Ce,B,W,Ie,Ve,ze)}}function ro(A,B,W,j,V,Me){A.onBeforeRender(x,B,W,j,V,Me),A.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,A.matrixWorld),A.normalMatrix.getNormalMatrix(A.modelViewMatrix),V.onBeforeRender(x,B,W,j,A,Me),V.transparent===!0&&V.side===ht&&V.forceSinglePass===!1?(V.side=Pt,V.needsUpdate=!0,x.renderBufferDirect(W,B,j,V,A,Me),V.side=cn,V.needsUpdate=!0,x.renderBufferDirect(W,B,j,V,A,Me),V.side=ht):x.renderBufferDirect(W,B,j,V,A,Me),A.onAfterRender(x,B,W,j,V,Me)}function Zi(A,B,W){B.isScene!==!0&&(B=Le);const j=pe.get(A),V=p.state.lights,Me=p.state.shadowsArray,Te=V.state.version,Ce=xe.getParameters(A,V.state,Me,B,W),Ie=xe.getProgramCacheKey(Ce);let Ve=j.programs;j.environment=A.isMeshStandardMaterial?B.environment:null,j.fog=B.fog,j.envMap=(A.isMeshStandardMaterial?F:E).get(A.envMap||j.environment),Ve===void 0&&(A.addEventListener("dispose",de),Ve=new Map,j.programs=Ve);let ze=Ve.get(Ie);if(ze!==void 0){if(j.currentProgram===ze&&j.lightsStateVersion===Te)return oo(A,Ce),ze}else Ce.uniforms=xe.getUniforms(A),A.onBuild(W,Ce,x),A.onBeforeCompile(Ce,x),ze=xe.acquireProgram(Ce,Ie),Ve.set(Ie,ze),j.uniforms=Ce.uniforms;const Be=j.uniforms;return(!A.isShaderMaterial&&!A.isRawShaderMaterial||A.clipping===!0)&&(Be.clippingPlanes=Pe.uniform),oo(A,Ce),j.needsLights=Wc(A),j.lightsStateVersion=Te,j.needsLights&&(Be.ambientLightColor.value=V.state.ambient,Be.lightProbe.value=V.state.probe,Be.directionalLights.value=V.state.directional,Be.directionalLightShadows.value=V.state.directionalShadow,Be.spotLights.value=V.state.spot,Be.spotLightShadows.value=V.state.spotShadow,Be.rectAreaLights.value=V.state.rectArea,Be.ltc_1.value=V.state.rectAreaLTC1,Be.ltc_2.value=V.state.rectAreaLTC2,Be.pointLights.value=V.state.point,Be.pointLightShadows.value=V.state.pointShadow,Be.hemisphereLights.value=V.state.hemi,Be.directionalShadowMap.value=V.state.directionalShadowMap,Be.directionalShadowMatrix.value=V.state.directionalShadowMatrix,Be.spotShadowMap.value=V.state.spotShadowMap,Be.spotLightMatrix.value=V.state.spotLightMatrix,Be.spotLightMap.value=V.state.spotLightMap,Be.pointShadowMap.value=V.state.pointShadowMap,Be.pointShadowMatrix.value=V.state.pointShadowMatrix),j.currentProgram=ze,j.uniformsList=null,ze}function so(A){if(A.uniformsList===null){const B=A.currentProgram.getUniforms();A.uniformsList=br.seqWithValue(B.seq,A.uniforms)}return A.uniformsList}function oo(A,B){const W=pe.get(A);W.outputColorSpace=B.outputColorSpace,W.batching=B.batching,W.instancing=B.instancing,W.instancingColor=B.instancingColor,W.skinning=B.skinning,W.morphTargets=B.morphTargets,W.morphNormals=B.morphNormals,W.morphColors=B.morphColors,W.morphTargetsCount=B.morphTargetsCount,W.numClippingPlanes=B.numClippingPlanes,W.numIntersection=B.numClipIntersection,W.vertexAlphas=B.vertexAlphas,W.vertexTangents=B.vertexTangents,W.toneMapping=B.toneMapping}function Hc(A,B,W,j,V){B.isScene!==!0&&(B=Le),w.resetTextureUnits();const Me=B.fog,Te=j.isMeshStandardMaterial?B.environment:null,Ce=C===null?x.outputColorSpace:C.isXRRenderTarget===!0?C.texture.colorSpace:ln,Ie=(j.isMeshStandardMaterial?F:E).get(j.envMap||Te),Ve=j.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,ze=!!W.attributes.tangent&&(!!j.normalMap||j.anisotropy>0),Be=!!W.morphAttributes.position,ot=!!W.morphAttributes.normal,Ut=!!W.morphAttributes.color;let mt=yn;j.toneMapped&&(C===null||C.isXRRenderTarget===!0)&&(mt=x.toneMapping);const Qt=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,rt=Qt!==void 0?Qt.length:0,We=pe.get(j),Vr=p.state.lights;if(re===!0&&(me===!0||A!==b)){const Ot=A===b&&j.id===z;Pe.setState(j,A,Ot)}let st=!1;j.version===We.__version?(We.needsLights&&We.lightsStateVersion!==Vr.state.version||We.outputColorSpace!==Ce||V.isBatchedMesh&&We.batching===!1||!V.isBatchedMesh&&We.batching===!0||V.isInstancedMesh&&We.instancing===!1||!V.isInstancedMesh&&We.instancing===!0||V.isSkinnedMesh&&We.skinning===!1||!V.isSkinnedMesh&&We.skinning===!0||V.isInstancedMesh&&We.instancingColor===!0&&V.instanceColor===null||V.isInstancedMesh&&We.instancingColor===!1&&V.instanceColor!==null||We.envMap!==Ie||j.fog===!0&&We.fog!==Me||We.numClippingPlanes!==void 0&&(We.numClippingPlanes!==Pe.numPlanes||We.numIntersection!==Pe.numIntersection)||We.vertexAlphas!==Ve||We.vertexTangents!==ze||We.morphTargets!==Be||We.morphNormals!==ot||We.morphColors!==Ut||We.toneMapping!==mt||se.isWebGL2===!0&&We.morphTargetsCount!==rt)&&(st=!0):(st=!0,We.__version=j.version);let Tn=We.currentProgram;st===!0&&(Tn=Zi(j,B,V));let ao=!1,bi=!1,Wr=!1;const yt=Tn.getUniforms(),An=We.uniforms;if(oe.useProgram(Tn.program)&&(ao=!0,bi=!0,Wr=!0),j.id!==z&&(z=j.id,bi=!0),ao||b!==A){yt.setValue(y,"projectionMatrix",A.projectionMatrix),yt.setValue(y,"viewMatrix",A.matrixWorldInverse);const Ot=yt.map.cameraPosition;Ot!==void 0&&Ot.setValue(y,Oe.setFromMatrixPosition(A.matrixWorld)),se.logarithmicDepthBuffer&&yt.setValue(y,"logDepthBufFC",2/(Math.log(A.far+1)/Math.LN2)),(j.isMeshPhongMaterial||j.isMeshToonMaterial||j.isMeshLambertMaterial||j.isMeshBasicMaterial||j.isMeshStandardMaterial||j.isShaderMaterial)&&yt.setValue(y,"isOrthographic",A.isOrthographicCamera===!0),b!==A&&(b=A,bi=!0,Wr=!0)}if(V.isSkinnedMesh){yt.setOptional(y,V,"bindMatrix"),yt.setOptional(y,V,"bindMatrixInverse");const Ot=V.skeleton;Ot&&(se.floatVertexTextures?(Ot.boneTexture===null&&Ot.computeBoneTexture(),yt.setValue(y,"boneTexture",Ot.boneTexture,w)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}V.isBatchedMesh&&(yt.setOptional(y,V,"batchingTexture"),yt.setValue(y,"batchingTexture",V._matricesTexture,w));const Xr=W.morphAttributes;if((Xr.position!==void 0||Xr.normal!==void 0||Xr.color!==void 0&&se.isWebGL2===!0)&&ke.update(V,W,Tn),(bi||We.receiveShadow!==V.receiveShadow)&&(We.receiveShadow=V.receiveShadow,yt.setValue(y,"receiveShadow",V.receiveShadow)),j.isMeshGouraudMaterial&&j.envMap!==null&&(An.envMap.value=Ie,An.flipEnvMap.value=Ie.isCubeTexture&&Ie.isRenderTargetTexture===!1?-1:1),bi&&(yt.setValue(y,"toneMappingExposure",x.toneMappingExposure),We.needsLights&&Vc(An,Wr),Me&&j.fog===!0&&ge.refreshFogUniforms(An,Me),ge.refreshMaterialUniforms(An,j,X,G,we),br.upload(y,so(We),An,w)),j.isShaderMaterial&&j.uniformsNeedUpdate===!0&&(br.upload(y,so(We),An,w),j.uniformsNeedUpdate=!1),j.isSpriteMaterial&&yt.setValue(y,"center",V.center),yt.setValue(y,"modelViewMatrix",V.modelViewMatrix),yt.setValue(y,"normalMatrix",V.normalMatrix),yt.setValue(y,"modelMatrix",V.matrixWorld),j.isShaderMaterial||j.isRawShaderMaterial){const Ot=j.uniformsGroups;for(let qr=0,Xc=Ot.length;qr<Xc;qr++)if(se.isWebGL2){const co=Ot[qr];ie.update(co,Tn),ie.bind(co,Tn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Tn}function Vc(A,B){A.ambientLightColor.needsUpdate=B,A.lightProbe.needsUpdate=B,A.directionalLights.needsUpdate=B,A.directionalLightShadows.needsUpdate=B,A.pointLights.needsUpdate=B,A.pointLightShadows.needsUpdate=B,A.spotLights.needsUpdate=B,A.spotLightShadows.needsUpdate=B,A.rectAreaLights.needsUpdate=B,A.hemisphereLights.needsUpdate=B}function Wc(A){return A.isMeshLambertMaterial||A.isMeshToonMaterial||A.isMeshPhongMaterial||A.isMeshStandardMaterial||A.isShadowMaterial||A.isShaderMaterial&&A.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return L},this.getRenderTarget=function(){return C},this.setRenderTargetTextures=function(A,B,W){pe.get(A.texture).__webglTexture=B,pe.get(A.depthTexture).__webglTexture=W;const j=pe.get(A);j.__hasExternalTextures=!0,j.__hasExternalTextures&&(j.__autoAllocateDepthBuffer=W===void 0,j.__autoAllocateDepthBuffer||N.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),j.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(A,B){const W=pe.get(A);W.__webglFramebuffer=B,W.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(A,B=0,W=0){C=A,R=B,L=W;let j=!0,V=null,Me=!1,Te=!1;if(A){const Ie=pe.get(A);Ie.__useDefaultFramebuffer!==void 0?(oe.bindFramebuffer(y.FRAMEBUFFER,null),j=!1):Ie.__webglFramebuffer===void 0?w.setupRenderTarget(A):Ie.__hasExternalTextures&&w.rebindTextures(A,pe.get(A.texture).__webglTexture,pe.get(A.depthTexture).__webglTexture);const Ve=A.texture;(Ve.isData3DTexture||Ve.isDataArrayTexture||Ve.isCompressedArrayTexture)&&(Te=!0);const ze=pe.get(A).__webglFramebuffer;A.isWebGLCubeRenderTarget?(Array.isArray(ze[B])?V=ze[B][W]:V=ze[B],Me=!0):se.isWebGL2&&A.samples>0&&w.useMultisampledRTT(A)===!1?V=pe.get(A).__webglMultisampledFramebuffer:Array.isArray(ze)?V=ze[W]:V=ze,T.copy(A.viewport),H.copy(A.scissor),U=A.scissorTest}else T.copy(te).multiplyScalar(X).floor(),H.copy(he).multiplyScalar(X).floor(),U=fe;if(oe.bindFramebuffer(y.FRAMEBUFFER,V)&&se.drawBuffers&&j&&oe.drawBuffers(A,V),oe.viewport(T),oe.scissor(H),oe.setScissorTest(U),Me){const Ie=pe.get(A.texture);y.framebufferTexture2D(y.FRAMEBUFFER,y.COLOR_ATTACHMENT0,y.TEXTURE_CUBE_MAP_POSITIVE_X+B,Ie.__webglTexture,W)}else if(Te){const Ie=pe.get(A.texture),Ve=B||0;y.framebufferTextureLayer(y.FRAMEBUFFER,y.COLOR_ATTACHMENT0,Ie.__webglTexture,W||0,Ve)}z=-1},this.readRenderTargetPixels=function(A,B,W,j,V,Me,Te){if(!(A&&A.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ce=pe.get(A).__webglFramebuffer;if(A.isWebGLCubeRenderTarget&&Te!==void 0&&(Ce=Ce[Te]),Ce){oe.bindFramebuffer(y.FRAMEBUFFER,Ce);try{const Ie=A.texture,Ve=Ie.format,ze=Ie.type;if(Ve!==Zt&&ye.convert(Ve)!==y.getParameter(y.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const Be=ze===ki&&(N.has("EXT_color_buffer_half_float")||se.isWebGL2&&N.has("EXT_color_buffer_float"));if(ze!==Sn&&ye.convert(ze)!==y.getParameter(y.IMPLEMENTATION_COLOR_READ_TYPE)&&!(ze===vn&&(se.isWebGL2||N.has("OES_texture_float")||N.has("WEBGL_color_buffer_float")))&&!Be){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=A.width-j&&W>=0&&W<=A.height-V&&y.readPixels(B,W,j,V,ye.convert(Ve),ye.convert(ze),Me)}finally{const Ie=C!==null?pe.get(C).__webglFramebuffer:null;oe.bindFramebuffer(y.FRAMEBUFFER,Ie)}}},this.copyFramebufferToTexture=function(A,B,W=0){const j=Math.pow(2,-W),V=Math.floor(B.image.width*j),Me=Math.floor(B.image.height*j);w.setTexture2D(B,0),y.copyTexSubImage2D(y.TEXTURE_2D,W,0,0,A.x,A.y,V,Me),oe.unbindTexture()},this.copyTextureToTexture=function(A,B,W,j=0){const V=B.image.width,Me=B.image.height,Te=ye.convert(W.format),Ce=ye.convert(W.type);w.setTexture2D(W,0),y.pixelStorei(y.UNPACK_FLIP_Y_WEBGL,W.flipY),y.pixelStorei(y.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),y.pixelStorei(y.UNPACK_ALIGNMENT,W.unpackAlignment),B.isDataTexture?y.texSubImage2D(y.TEXTURE_2D,j,A.x,A.y,V,Me,Te,Ce,B.image.data):B.isCompressedTexture?y.compressedTexSubImage2D(y.TEXTURE_2D,j,A.x,A.y,B.mipmaps[0].width,B.mipmaps[0].height,Te,B.mipmaps[0].data):y.texSubImage2D(y.TEXTURE_2D,j,A.x,A.y,Te,Ce,B.image),j===0&&W.generateMipmaps&&y.generateMipmap(y.TEXTURE_2D),oe.unbindTexture()},this.copyTextureToTexture3D=function(A,B,W,j,V=0){if(x.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const Me=A.max.x-A.min.x+1,Te=A.max.y-A.min.y+1,Ce=A.max.z-A.min.z+1,Ie=ye.convert(j.format),Ve=ye.convert(j.type);let ze;if(j.isData3DTexture)w.setTexture3D(j,0),ze=y.TEXTURE_3D;else if(j.isDataArrayTexture||j.isCompressedArrayTexture)w.setTexture2DArray(j,0),ze=y.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}y.pixelStorei(y.UNPACK_FLIP_Y_WEBGL,j.flipY),y.pixelStorei(y.UNPACK_PREMULTIPLY_ALPHA_WEBGL,j.premultiplyAlpha),y.pixelStorei(y.UNPACK_ALIGNMENT,j.unpackAlignment);const Be=y.getParameter(y.UNPACK_ROW_LENGTH),ot=y.getParameter(y.UNPACK_IMAGE_HEIGHT),Ut=y.getParameter(y.UNPACK_SKIP_PIXELS),mt=y.getParameter(y.UNPACK_SKIP_ROWS),Qt=y.getParameter(y.UNPACK_SKIP_IMAGES),rt=W.isCompressedTexture?W.mipmaps[V]:W.image;y.pixelStorei(y.UNPACK_ROW_LENGTH,rt.width),y.pixelStorei(y.UNPACK_IMAGE_HEIGHT,rt.height),y.pixelStorei(y.UNPACK_SKIP_PIXELS,A.min.x),y.pixelStorei(y.UNPACK_SKIP_ROWS,A.min.y),y.pixelStorei(y.UNPACK_SKIP_IMAGES,A.min.z),W.isDataTexture||W.isData3DTexture?y.texSubImage3D(ze,V,B.x,B.y,B.z,Me,Te,Ce,Ie,Ve,rt.data):W.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),y.compressedTexSubImage3D(ze,V,B.x,B.y,B.z,Me,Te,Ce,Ie,rt.data)):y.texSubImage3D(ze,V,B.x,B.y,B.z,Me,Te,Ce,Ie,Ve,rt),y.pixelStorei(y.UNPACK_ROW_LENGTH,Be),y.pixelStorei(y.UNPACK_IMAGE_HEIGHT,ot),y.pixelStorei(y.UNPACK_SKIP_PIXELS,Ut),y.pixelStorei(y.UNPACK_SKIP_ROWS,mt),y.pixelStorei(y.UNPACK_SKIP_IMAGES,Qt),V===0&&j.generateMipmaps&&y.generateMipmap(ze),oe.unbindTexture()},this.initTexture=function(A){A.isCubeTexture?w.setTextureCube(A,0):A.isData3DTexture?w.setTexture3D(A,0):A.isDataArrayTexture||A.isCompressedArrayTexture?w.setTexture2DArray(A,0):w.setTexture2D(A,0),oe.unbindTexture()},this.resetState=function(){R=0,L=0,C=null,oe.reset(),Ue.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return an}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=e===Ys?"display-p3":"srgb",t.unpackColorSpace=je.workingColorSpace===Or?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===lt?Hn:cc}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===Hn?lt:ln}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}}class cm extends Cc{}cm.prototype.isWebGL1Renderer=!0;class $s{constructor(e,t=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ze(e),this.near=t,this.far=i}clone(){return new $s(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class lm extends ut{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}}class Ia extends jt{constructor(e,t,i,r=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const ci=new Ke,Na=new Ke,vr=[],Fa=new wn,hm=new Ke,Li=new Ne,Pi=new Xi;class ks extends Ne{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Ia(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<i;r++)this.setMatrixAt(r,hm)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new wn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,ci),Fa.copy(e.boundingBox).applyMatrix4(ci),this.boundingBox.union(Fa)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Xi),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,ci),Pi.copy(e.boundingSphere).applyMatrix4(ci),this.boundingSphere.union(Pi)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){const i=this.matrixWorld,r=this.count;if(Li.geometry=this.geometry,Li.material=this.material,Li.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Pi.copy(this.boundingSphere),Pi.applyMatrix4(i),e.ray.intersectsSphere(Pi)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,ci),Na.multiplyMatrices(i,ci),Li.matrixWorld=Na,Li.raycast(e,vr);for(let a=0,o=vr.length;a<o;a++){const c=vr[a];c.instanceId=s,c.object=this,t.push(c)}vr.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Ia(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}}class Oa extends Dt{constructor(e,t,i,r,s,a,o,c,l){super(e,t,i,r,s,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Js extends it{constructor(e=1,t=32,i=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:r},t=Math.max(3,t);const s=[],a=[],o=[],c=[],l=new O,d=new qe;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let h=0,u=3;h<=t;h++,u+=3){const m=i+h/t*r;l.x=e*Math.cos(m),l.y=e*Math.sin(m),a.push(l.x,l.y,l.z),o.push(0,0,1),d.x=(a[u]/e+1)/2,d.y=(a[u+1]/e+1)/2,c.push(d.x,d.y)}for(let h=1;h<=t;h++)s.push(h,h+1,0);this.setIndex(s),this.setAttribute("position",new Xe(a,3)),this.setAttribute("normal",new Xe(o,3)),this.setAttribute("uv",new Xe(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Js(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Qs extends it{constructor(e=1,t=1,i=1,r=32,s=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:c};const l=this;r=Math.floor(r),s=Math.floor(s);const d=[],h=[],u=[],m=[];let M=0;const g=[],p=i/2;let f=0;_(),a===!1&&(e>0&&x(!0),t>0&&x(!1)),this.setIndex(d),this.setAttribute("position",new Xe(h,3)),this.setAttribute("normal",new Xe(u,3)),this.setAttribute("uv",new Xe(m,2));function _(){const v=new O,R=new O;let L=0;const C=(t-e)/i;for(let z=0;z<=s;z++){const b=[],T=z/s,H=T*(t-e)+e;for(let U=0;U<=r;U++){const Y=U/r,D=Y*c+o,I=Math.sin(D),G=Math.cos(D);R.x=H*I,R.y=-T*i+p,R.z=H*G,h.push(R.x,R.y,R.z),v.set(I,C,G).normalize(),u.push(v.x,v.y,v.z),m.push(Y,1-T),b.push(M++)}g.push(b)}for(let z=0;z<r;z++)for(let b=0;b<s;b++){const T=g[b][z],H=g[b+1][z],U=g[b+1][z+1],Y=g[b][z+1];d.push(T,H,Y),d.push(H,U,Y),L+=6}l.addGroup(f,L,0),f+=L}function x(v){const R=M,L=new qe,C=new O;let z=0;const b=v===!0?e:t,T=v===!0?1:-1;for(let U=1;U<=r;U++)h.push(0,p*T,0),u.push(0,T,0),m.push(.5,.5),M++;const H=M;for(let U=0;U<=r;U++){const D=U/r*c+o,I=Math.cos(D),G=Math.sin(D);C.x=b*G,C.y=p*T,C.z=b*I,h.push(C.x,C.y,C.z),u.push(0,T,0),L.x=I*.5+.5,L.y=G*.5*T+.5,m.push(L.x,L.y),M++}for(let U=0;U<r;U++){const Y=R+U,D=H+U;v===!0?d.push(D,D+1,Y):d.push(D+1,D,Y),z+=3}l.addGroup(f,z,v===!0?1:2),f+=z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Qs(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Gi extends Qs{constructor(e=1,t=1,i=32,r=1,s=!1,a=0,o=Math.PI*2){super(0,e,t,i,r,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:r,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new Gi(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class eo extends it{constructor(e=[],t=[],i=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:r};const s=[],a=[];o(r),l(i),d(),this.setAttribute("position",new Xe(s,3)),this.setAttribute("normal",new Xe(s.slice(),3)),this.setAttribute("uv",new Xe(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(_){const x=new O,v=new O,R=new O;for(let L=0;L<t.length;L+=3)m(t[L+0],x),m(t[L+1],v),m(t[L+2],R),c(x,v,R,_)}function c(_,x,v,R){const L=R+1,C=[];for(let z=0;z<=L;z++){C[z]=[];const b=_.clone().lerp(v,z/L),T=x.clone().lerp(v,z/L),H=L-z;for(let U=0;U<=H;U++)U===0&&z===L?C[z][U]=b:C[z][U]=b.clone().lerp(T,U/H)}for(let z=0;z<L;z++)for(let b=0;b<2*(L-z)-1;b++){const T=Math.floor(b/2);b%2===0?(u(C[z][T+1]),u(C[z+1][T]),u(C[z][T])):(u(C[z][T+1]),u(C[z+1][T+1]),u(C[z+1][T]))}}function l(_){const x=new O;for(let v=0;v<s.length;v+=3)x.x=s[v+0],x.y=s[v+1],x.z=s[v+2],x.normalize().multiplyScalar(_),s[v+0]=x.x,s[v+1]=x.y,s[v+2]=x.z}function d(){const _=new O;for(let x=0;x<s.length;x+=3){_.x=s[x+0],_.y=s[x+1],_.z=s[x+2];const v=p(_)/2/Math.PI+.5,R=f(_)/Math.PI+.5;a.push(v,1-R)}M(),h()}function h(){for(let _=0;_<a.length;_+=6){const x=a[_+0],v=a[_+2],R=a[_+4],L=Math.max(x,v,R),C=Math.min(x,v,R);L>.9&&C<.1&&(x<.2&&(a[_+0]+=1),v<.2&&(a[_+2]+=1),R<.2&&(a[_+4]+=1))}}function u(_){s.push(_.x,_.y,_.z)}function m(_,x){const v=_*3;x.x=e[v+0],x.y=e[v+1],x.z=e[v+2]}function M(){const _=new O,x=new O,v=new O,R=new O,L=new qe,C=new qe,z=new qe;for(let b=0,T=0;b<s.length;b+=9,T+=6){_.set(s[b+0],s[b+1],s[b+2]),x.set(s[b+3],s[b+4],s[b+5]),v.set(s[b+6],s[b+7],s[b+8]),L.set(a[T+0],a[T+1]),C.set(a[T+2],a[T+3]),z.set(a[T+4],a[T+5]),R.copy(_).add(x).add(v).divideScalar(3);const H=p(R);g(L,T+0,_,H),g(C,T+2,x,H),g(z,T+4,v,H)}}function g(_,x,v,R){R<0&&_.x===1&&(a[x]=_.x-1),v.x===0&&v.z===0&&(a[x]=R/2/Math.PI+.5)}function p(_){return Math.atan2(_.z,-_.x)}function f(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new eo(e.vertices,e.indices,e.radius,e.details)}}class Hi extends eo{constructor(e=1,t=0){const i=(1+Math.sqrt(5))/2,r=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new Hi(e.radius,e.detail)}}class Gr extends it{constructor(e=1,t=32,i=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const c=Math.min(a+o,Math.PI);let l=0;const d=[],h=new O,u=new O,m=[],M=[],g=[],p=[];for(let f=0;f<=i;f++){const _=[],x=f/i;let v=0;f===0&&a===0?v=.5/t:f===i&&c===Math.PI&&(v=-.5/t);for(let R=0;R<=t;R++){const L=R/t;h.x=-e*Math.cos(r+L*s)*Math.sin(a+x*o),h.y=e*Math.cos(a+x*o),h.z=e*Math.sin(r+L*s)*Math.sin(a+x*o),M.push(h.x,h.y,h.z),u.copy(h).normalize(),g.push(u.x,u.y,u.z),p.push(L+v,1-x),_.push(l++)}d.push(_)}for(let f=0;f<i;f++)for(let _=0;_<t;_++){const x=d[f][_+1],v=d[f][_],R=d[f+1][_],L=d[f+1][_+1];(f!==0||a>0)&&m.push(x,v,L),(f!==i-1||c<Math.PI)&&m.push(v,R,L)}this.setIndex(m),this.setAttribute("position",new Xe(M,3)),this.setAttribute("normal",new Xe(g,3)),this.setAttribute("uv",new Xe(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Gr(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Kt extends qi{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Ze(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ze(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=lc,this.normalScale=new qe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Xs,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Lc extends ut{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ze(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}}class um extends Lc{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ut.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ze(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const ws=new Ke,za=new O,Ba=new O;class dm{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new qe(512,512),this.map=null,this.mapPass=null,this.matrix=new Ke,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new js,this._frameExtents=new qe(1,1),this._viewportCount=1,this._viewports=[new _t(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,i=this.matrix;za.setFromMatrixPosition(e.matrixWorld),t.position.copy(za),Ba.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ba),t.updateMatrixWorld(),ws.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ws),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(ws)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class fm extends dm{constructor(){super(new Sc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class pm extends Lc{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ut.DEFAULT_UP),this.updateMatrix(),this.target=new ut,this.shadow=new fm}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class mm{constructor(e,t,i=0,r=1/0){this.ray=new zr(e,t),this.near=i,this.far=r,this.camera=null,this.layers=new Zs,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return Gs(e,this,i,t),i.sort(ka),i}intersectObjects(e,t=!0,i=[]){for(let r=0,s=e.length;r<s;r++)Gs(e[r],this,i,t);return i.sort(ka),i}}function ka(n,e){return n.distance-e.distance}function Gs(n,e,t,i){if(n.layers.test(e.layers)&&n.raycast(e,t),i===!0){const r=n.children;for(let s=0,a=r.length;s<a;s++)Gs(r[s],e,t,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Ws}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Ws);function Pc({scene:n,material:e,doors:t,h:i,local:r,id:s=i.id,x:a=-1.4,z:o=i.d/2,width:c=1.26,height:l=2.3}){const d=r(a-c/2,o+.03),h=r(a,o),u=new xt;u.position.set(d.x,0,d.z),u.rotation.y=i.angle;const m=new Ne(new Mt(c,l,.1),e(9726028));m.position.set(c/2,l/2,0),u.add(m);const M=new Ne(new Mt(c*.62,.65,.112),e(11980733));M.position.set(c/2,1.65,0),u.add(M);const g=new Ne(new Gr(.055,6,5),e(16768118));g.position.set(c-.16,1,.09),u.add(g),n.add(u),t.push({id:s,pivot:u,baseAngle:i.angle,open:!1,center:h,hinge:d,width:c,height:l})}function to({scene:n,material:e,doors:t,h:i,put:r,local:s}){const a=-i.w/2-2.1,o=i.d/2,c=o-2.7;r(a,.007,c,4.2,.014,5.4,12959399);for(const m of[-2.1,2.1])r(a+m,1.4,c,.2,2.8,5.4,i.wall,!0);r(a,1.4,o-5.4,4.2,2.8,.2,i.wall,!0),r(a,2.72,o,4.2,.16,.2,i.wall,!0);for(const m of[-1.92,1.92])r(a+m,1.32,o,.36,2.64,.2,i.wall,!0);r(a,2.88,c,4.6,.18,5.8,i.roof,!0);const l=s(a,o),d=new xt;d.position.set(l.x,0,l.z),d.rotation.y=i.angle;const h=new xt,u=new Ne(new Mt(3.46,2.6,.1),e(14144708));u.position.y=1.3,h.add(u);for(let m=.25;m<2.6;m+=.32){const M=new Ne(new Mt(3.42,.035,.12),e(10989475));M.position.y=m,h.add(M)}d.add(h),n.add(d),t.push({id:i.id+"-garage",kind:"roller",pivot:d,leaf:h,baseAngle:i.angle,center:l,hinge:l,width:3.46,height:2.6,open:!1})}function gm({h:n,put:e,local:t,scene:i,material:r,doors:s,solids:a,label:o,rooms:c}){const l=n.w,d=n.d,h=d/2,u=n.storeys===2,m=3.2,M=u?6.4:3,g=16774617,p=9725511,f=8501706;e(0,.007,0,l,.014,d,14006419);for(const U of[-h,h]){const Y=U>0,D=l/2-2,I=2.1,G=Y?[[-l/2,-2.1],[-.7,D-I/2],[D+I/2,l/2]]:[[-l/2,D-I/2],[D+I/2,l/2]];for(const[X,Q]of G)Q>X&&e((X+Q)/2,1.5,U,Q-X,3,.22,n.wall,!0);Y&&e(-1.4,2.68,U,1.4,.64,.22,n.wall,!0),e(D,.5,U,I,1,.22,n.wall,!0),e(D,2.65,U,I,.7,.22,n.wall,!0),e(D,1.65,U,I,1.3,.1,f,!0);for(const X of[D-I/2,D,D+I/2])e(X,1.65,U,.065,1.42,.3,g);for(const X of[1,2.3])e(D,X,U,I+.15,.07,.3,g);if(u){e(0,3.22,U,l,.44,.22,n.wall,!0);const X=1.6,Q=n.id==="manor"?[-l/2+2,-1.4,l/2-2]:[-l/2+2,l/2-2];let ne=-l/2;for(const te of Q){e((ne+te-X/2)/2,4.8,U,te-X/2-ne,3.2,.22,n.wall,!0),e(te,3.7,U,X,1,.22,n.wall,!0),e(te,5.98,U,X,.84,.22,n.wall,!0),e(te,4.88,U,X,1.36,.1,f,!0);for(const he of[te-X/2,te,te+X/2])e(he,4.88,U,.065,1.5,.3,g);for(const he of[4.2,5.56])e(te,he,U,X+.15,.07,.3,g);ne=te+X/2}e((ne+l/2)/2,4.8,U,l/2-ne,3.2,.22,n.wall,!0)}}for(const U of[-l/2,l/2])for(const Y of u?[0,m]:[0]){const D=d>10?[-d/2+2.5,d/2-2.5]:[0],I=1.6;let G=-h;for(const X of D){e(U,Y+1.5,(G+X-I/2)/2,.22,3,X-I/2-G,n.wall,!0),e(U,Y+.5,X,.22,1,I,n.wall,!0),e(U,Y+2.65,X,.22,.7,I,n.wall,!0),e(U,Y+1.65,X,.1,1.3,I,f,!0);for(const Q of[X-.8,X,X+.8])e(U,Y+1.65,Q,.3,1.42,.065,g);for(const Q of[1,2.3])e(U,Y+Q,X,.3,.07,I+.15,g);G=X+I/2}e(U,Y+1.5,(G+h)/2,.22,3,h-G,n.wall,!0),u&&(e(U,3.1,0,.22,.2,d,n.wall,!0),e(U,M-.1,0,.22,.2,d,n.wall,!0))}Pc({scene:i,material:r,doors:s,h:n,local:t});const _=M+.06,x=_+(n.id==="manor"?3.3:1.8),v=l/2+.4,R=h+.4,L=[],C=(U,Y,D,I)=>L.push(...U,...Y,...D,...U,...D,...I);if(n.style==="hip")C([-v,_,R],[v,_,R],[0,x,1],[0,x,1]),C([v,_,R],[v,_,-R],[0,x,-1],[0,x,1]),C([v,_,-R],[-v,_,-R],[0,x,-1],[0,x,-1]),C([-v,_,-R],[-v,_,R],[0,x,1],[0,x,-1]);else if(n.style==="shed"){const U=_+1.4;C([-v,_,R],[v,_,R],[v,U,-R],[-v,U,-R]);for(const Y of[-l/2,l/2]){const D=new it;D.setAttribute("position",new Xe([Y,M,-h,Y,U,-h,Y,_,h,Y,M,-h,Y,_,h,Y,M,h],3)),D.computeVertexNormals();const I=r(n.wall).clone();I.side=ht;const G=new Ne(D,I);G.position.set(n.x,0,n.z),G.rotation.y=n.angle,i.add(G)}e(0,(M+U)/2,-h,l,U-M,.22,n.wall,!0)}else{C([-v,_,R],[0,x,R],[0,x,-R],[-v,_,-R]),C([0,x,R],[v,_,R],[v,_,-R],[0,x,-R]);for(const U of[-h,h]){const Y=new it;Y.setAttribute("position",new Xe([-l/2,M,U,l/2,M,U,0,x,U],3)),Y.computeVertexNormals();const D=r(n.wall).clone();D.side=ht;const I=new Ne(Y,D);I.position.set(n.x,0,n.z),I.rotation.y=n.angle,i.add(I)}}const z=new it;z.setAttribute("position",new Xe(L,3)),z.computeVertexNormals();const b=r(n.roof).clone();b.side=ht;const T=new Ne(z,b);T.position.set(n.x,0,n.z),T.rotation.y=n.angle,i.add(T),e(0,M+.015,0,l,.09,d,g,!0),e(-1.4,2.64,h+.7,n.porch||2.4,.12,1.5,n.roof,!0);for(const U of[-2.45,-.35])e(U,1.27,h+1.3,.12,2.54,.12,g,!0);if(n.id==="manor"){for(const I of[-4.9,2.1]){e(I,3.15,h+2,.32,6.3,.32,g,!0);for(const G of[.12,6.25])e(I,G,h+2,.65,.24,.65,g,!0)}e(-1.4,6.5,h+1.1,7.9,.24,2.8,g,!0);const U=new it;U.setAttribute("position",new Xe([-5.35,6.65,h+2.55,2.55,6.65,h+2.55,-1.4,8.15,h+2.55],3)),U.computeVertexNormals();const Y=r(g).clone();Y.side=ht;const D=new Ne(U,Y);D.position.set(n.x,0,n.z),D.rotation.y=n.angle,i.add(D),e(3,.34,h-2.5,3.4,.68,1,7183771,!0),e(3,.88,h-2.96,3.4,.72,.18,7183771,!0);for(const I of[1.4,4.6])e(I,.65,h-2.5,.2,.5,1,p,!0);e(3,.36,h-4.2,1.8,.72,.8,p,!0),e(-l/2+3.3,.79,h-3,2.6,.15,1.6,p,!0);for(const I of[-1,1])for(const G of[-.55,.55])e(-l/2+3.3+I,.36,h-3+G,.12,.72,.12,p,!0)}const H=(U,Y,D=l/2-.2)=>{e((-l/2+-1.4-1.7/2)/2,U+1.5,Y,-1.4-1.7/2+l/2,3,.16,n.wall,!0),e((-1.4+1.7/2+D)/2,U+1.5,Y,D- -1.4-1.7/2,3,.16,n.wall,!0),e(-1.4,U+2.72,Y,1.7,.56,.16,g,!0)};if(n.rooms&&(H(0,-.4,u?l/2-2.2:l/2-.2),c.push({house:n.id,name:"Back room",...t(-1.4,-h+1.7),y:0})),u){const U=l/2-1.2,Y=1.65,D=h-1.4,I=-h+1.4,G=D-I,X=-l/2,Q=U-Y/2-.12;e((X+Q)/2,m-.09,0,Q-X,.18,d,14006419,!0);for(const[re,me]of[[-h+.6,1.2],[h-.6,1.2]])e((Q+l/2)/2,m-.09,re,l/2-Q,.18,me,14006419,!0);const ne=t(U,(D+I)/2),te=Math.cos(n.angle),he=Math.sin(n.angle),fe=(Y*Math.abs(te)+G*Math.abs(he))/2,K=(Y*Math.abs(he)+G*Math.abs(te))/2;a.push({minX:ne.x-fe,maxX:ne.x+fe,minZ:ne.z-K,maxZ:ne.z+K,minY:0,maxY:m,ramp:{cx:ne.x,cz:ne.z,c:te,s:he,width:Y,length:G,rise:m}});for(let re=0;re<16;re++){const me=m*(re+1)/16;e(U,me/2,D-(re+.5)*G/16,Y,me,G/16,p)}e(Q-.04,m+.48,(D+I)/2,.1,.96,G,p,!0);for(const re of[D-.15,I+.15])e(Q-.04,m+.48,re,.12,.96,.12,g,!0);H(m,-.4,Q-.25),c.push({house:n.id,name:"Upper landing",...t(U,-h+.55),y:m},{house:n.id,name:"Upstairs bedroom",...t(-1.4,-h+1.7),y:m})}for(const U of u?[0,m]:[0])e(-l/2+1.3,U+.28,-h+1.6,1.8,.56,2.4,p,!0),e(-l/2+1.3,U+.62,-h+1.6,1.75,.13,2.3,n.roof),e(-l/2+1.3,U+.73,-h+.8,1.5,.16,.5,g),e(-l/2+1.1,U+.45,h-1.1,1.5,.9,.7,p,!0);if(n.shop){e(l/2-1.5,.5,-h+1.2,2,1,1,p,!0);const U=t(0,h+.2);o(n.sign,U.x,2.9,U.z,n.angle,Math.min(l-1,5))}if(n.street){const U=l/2+1.2;e(U,.22,0,1.1,.44,d+3,5933922,!0),e(0,.38,-h-1.6,l+2,.12,.12,p,!0);for(const Y of[-l/2-1,0,l/2+1])e(Y,.35,-h-1.6,.1,.7,.1,g,!0);e(l/2-1,.18,h+1.5,2,.36,1,5933922,!0);for(const Y of[-.6,0,.6])e(l/2-1+Y,.43,h+1.5,.3,.18,.3,15118451)}n.garage&&to({scene:i,material:r,doors:s,h:n,put:e,local:t}),c.push({house:n.id,name:"Entrance",...t(-1.4,h-1.1),y:0})}function Dc(n,e){const t=new Map,i=new Ke,r=new Ke,s=new O,a=new O,o=new He,c=[...n.children].filter(g=>g.isMesh&&!e.has(g)),l=new Set,d=new Set;for(const g of c){g.updateMatrixWorld(!0);const p=g.geometry.index?g.geometry.toNonIndexed():g.geometry,f=p.attributes.position,_=p.attributes.normal,x=g.material.color,v=g.isInstancedMesh?g.count:1;for(let R=0;R<v;R++){g.isInstancedMesh?(g.getMatrixAt(R,i),r.multiplyMatrices(g.matrixWorld,i)):r.copy(g.matrixWorld);const L=r.elements[12],C=r.elements[14],z=`${Math.floor(L/et.chunkSize)},${Math.floor(C/et.chunkSize)}`;t.has(z)||t.set(z,{positions:[],normals:[],colors:[]});const b=t.get(z);o.getNormalMatrix(r);for(let T=0;T<f.count;T++)s.fromBufferAttribute(f,T).applyMatrix4(r),a.fromBufferAttribute(_,T).applyMatrix3(o).normalize(),b.positions.push(s.x,s.y,s.z),b.normals.push(a.x,a.y,a.z),b.colors.push(x.r,x.g,x.b);if(g.material.side===ht)for(let T=0;T<f.count;T+=3)for(const H of[T+2,T+1,T])s.fromBufferAttribute(f,H).applyMatrix4(r),a.fromBufferAttribute(_,H).applyMatrix3(o).normalize().negate(),b.positions.push(s.x,s.y,s.z),b.normals.push(a.x,a.y,a.z),b.colors.push(x.r,x.g,x.b)}p!==g.geometry&&p.dispose(),l.add(g.geometry),d.add(g.material),g.isInstancedMesh&&g.dispose(),n.remove(g)}const h=new Kt({vertexColors:!0,side:cn}),u=[];let m=0;for(const[g,p]of t){const f=new it;f.setAttribute("position",new Xe(p.positions,3)),f.setAttribute("normal",new Xe(p.normals,3)),f.setAttribute("color",new Xe(p.colors,3)),f.computeBoundingSphere();const _=new Ne(f,h);_.name=`scenery ${g}`,n.add(_),u.push(_),m+=p.positions.length/9}const M=new Set;n.traverse(g=>{g.isMesh&&M.add(g.material)});for(const g of l)g.dispose();for(const g of d)M.has(g)||g.dispose();return{chunks:t.size,triangles:m,hidden:0,updateVisibility(g,p,f=!0){const _=g.matrixWorldInverse.elements;let x=0;for(const v of u){const R=v.geometry.boundingSphere,L=R.center,C=-(_[2]*L.x+_[6]*L.y+_[10]*L.z+_[14])-R.radius;v.visible=!f||C<=p+.1,v.visible||x++}return this.hidden=x,x},showAll(){for(const g of u)g.visible=!0;this.hidden=0}}}function Uc(n){const e=new Map,t=new Kt({vertexColors:!0}),i=new Ke,r=new O,s=new O,a=new He;let o=0;for(const c of n){const l=c.leaf||c.pivot,d=[...l.children].filter(g=>g.isMesh);o+=d.length;const h=JSON.stringify(d.map(g=>[g.geometry.parameters,g.position.toArray(),g.rotation.toArray(),g.scale.toArray(),g.material.color.getHex()]));let u=e.get(h),m=0;if(!u){const g=[],p=[],f=[];for(const[_,x]of d.entries()){x.updateMatrix(),i.copy(x.matrix),a.getNormalMatrix(i);const v=x.geometry.index?x.geometry.toNonIndexed():x.geometry,R=v.attributes.position,L=v.attributes.normal,C=x.material.color;_===0&&(m=R.count);for(let z=0;z<R.count;z++)r.fromBufferAttribute(R,z).applyMatrix4(i),s.fromBufferAttribute(L,z).applyMatrix3(a).normalize(),g.push(r.x,r.y,r.z),p.push(s.x,s.y,s.z),f.push(C.r,C.g,C.b);v!==x.geometry&&v.dispose()}u=new it,u.setAttribute("position",new Xe(g,3)),u.setAttribute("normal",new Xe(p,3)),u.setAttribute("color",new Xe(f,3)),u.computeBoundingSphere(),u.userData.panelVertices=m,e.set(h,u)}for(const g of d)l.remove(g),g.geometry.dispose();const M=new Ne(u,t);M.name=c.id+" leaf",l.add(M)}return{partsBefore:o,meshesAfter:n.length,sharedGeometries:e.size}}function _m(n){const e=[],t=[],i=[],r=[],s=new Mt(1,1,1),a=new Map,o=u=>(a.has(u)||a.set(u,new Kt({color:u})),a.get(u));function c(u,m,M,g,p,f,_,x=!1){const v=new Ne(s,o(_));return v.position.set(u,m,M),v.scale.set(g,p,f),n.add(v),x&&e.push({minX:u-g/2,maxX:u+g/2,minY:m-p/2,maxY:m+p/2,minZ:M-f/2,maxZ:M+f/2}),v}c(0,-.1,0,500,.2,500,10864267);for(const u of[-36,4,36])c(0,.012,u,84,.024,6,8558487);for(const u of[-40,8,40])c(u,.014,0,6,.028,78,8558487);for(let u=-36;u<=36;u+=5)c(u,.03,4,2,.02,.14,16772533);for(const[u,m]of[[-20,-12],[-5,-21],[24,-20],[-22,21]]){const M={id:r.length===0?"home":["cafe","library","workshop"][r.length-1],x:u,z:m,w:12,d:10,angle:r.length===3?Math.PI:0,wall:[15780251,15251368,12111037,13944996][r.length],roof:5209465};r.push(M);const g=Math.cos(M.angle),p=Math.sin(M.angle),f=(v,R)=>({x:u+v*g+R*p,z:m-v*p+R*g}),_=(v,R,L,C,z,b,T,H=!1)=>{const U=f(v,L);return c(U.x,R,U.z,C,z,b,T,H)};_(0,.025,0,12,.05,10,15127212),_(-6,1.6,0,.22,3.2,10,M.wall,!0),_(6,1.6,0,.22,3.2,10,M.wall,!0),_(0,1.6,-5,12,3.2,.22,M.wall,!0),_(-4.05,1.6,5,3.9,3.2,.22,M.wall,!0),_(2.65,1.6,5,6.7,3.2,.22,M.wall,!0),_(-1.4,2.77,5,1.4,.86,.22,M.wall,!0),_(0,3.27,0,12.8,.2,10.8,M.roof,!0);for(const v of[1.5,4])_(v,1.75,5.15,1.6,1.2,.08,9486022),_(v,1.75,5.21,.06,1.3,.08,16773589),_(v,2.35,5.21,1.7,.08,.08,16773589);Pc({scene:n,material:o,doors:t,h:M,local:f}),i.push({id:M.id,x:u,z:m,y:0});const x=(v,R)=>{_(v,.72,R,1.6,.14,1,11501653,!0);for(const L of[-.65,.65])for(const C of[-.35,.35])_(v+L,.34,R+C,.1,.68,.1,8743505)};if(x(2,0),_(2,.36,1.3,1,.72,.65,9942170,!0),_(2,.8,1.6,1,.3,.12,9942170),M.id==="home"&&(_(-3,.32,-2,2.4,.64,3,12029801,!0),_(-3,.72,-2,2.3,.2,2.9,15846028),_(-3,.88,-3,1.8,.25,.6,16774879),_(3,.7,-3,3,1.4,.7,8496284,!0)),M.id==="cafe"&&(_(-3,.7,-2,3.5,1.4,1,12553574,!0),_(-3,1.45,-2,3.7,.1,1.1,16772304),x(2,-3)),M.id==="library")for(const v of[-4,0,4]){_(v,1.1,-3,2.3,2.2,.5,11766370,!0);for(let R=0;R<5;R++)_(v-.8+R*.38,1.45,-2.69,.25,.7,.12,[14588270,7905945,14730099][R%3])}M.id==="workshop"&&(_(-3,.85,-2,3,1.7,1.2,11055526,!0),_(3,.5,-3,2,1,1.5,14923112,!0)),M.id==="home"&&to({scene:n,material:o,doors:t,h:M,put:_,local:f})}for(const[u,m]of[[-34,15],[-10,30],[28,7],[30,31],[-32,-27],[13,-32],[34,-7],[-3,15]])c(u,1,m,.35,2,.35,10123350,!0),c(u,2.5,m,3.1,2.5,3.1,6790008);for(const[u,m]of[[17,12],[25,12]])c(u,.42,m,2.5,.16,.8,11701090,!0),c(u,.75,m+.36,2.5,.55,.12,11701090);c(30,.03,25,10,.04,8,8568778),c(15,.3,22,2,.6,2,13872254,!0),c(15,.7,22,1.8,.3,1.8,9678199);const l=new Ne(new En(500,500),new pi({visible:!1}));l.rotation.x=-Math.PI/2,n.add(l),l.updateMatrixWorld();const d=Uc(t),h=Dc(n,new Set([...t.map(u=>u.pivot),l]));return{ground:l,solids:e,doors:t,houses:r,rooms:i,roads:[],doorRender:d,staticRender:h,landmarks:[{name:"Home",icon:"⌂",x:-20,z:0},{name:"Square",icon:"☀",x:18,z:7},{name:"Library",icon:"📚",x:22.6,z:-10},{name:"Workshop",icon:"🛠",x:-20.6,z:13},{name:"Garden",icon:"🌷",x:22,z:20},{name:"Garage",icon:"🚗",x:-28,z:1}]}}function xm({box:n,bench:e,scene:t,material:i,reserved:r}){const l=(h,u)=>{n(h,.76,u,2.5,.15,1.2,9725511,!0);for(const m of[-.95,.95]){n(h,.43,u+m,2.5,.13,.45,9725511,!0);for(const M of[-.85,.85])n(h+M,.22,u+m,.12,.44,.35,5992562,!0)}for(const m of[-.8,.8])n(h+m,.36,u,.16,.72,.9,5992562,!0)},d=(h,u)=>{for(const m of[-3.3,3.3])for(const M of[-2.5,2.5])n(h+m,1.5,u+M,.18,3,.18,9725511,!0);n(h,3.08,u,7.3,.18,5.8,4488320,!0),l(h,u)};n(66,.006,46,29,.012,29,10993279),n(67,.012,43,22,.018,17,14995099);for(const h of[58,64])n(h,1.8,38,.2,3.6,.2,9725511,!0);n(61,3.55,38,6.5,.2,.22,4488320,!0);for(const h of[60,62]){for(const u of[-.3,.3])n(h+u,2.18,38,.035,2.4,.035,5992562);n(h,1,38,.85,.15,.5,11365457,!0)}for(const h of[-1,1])for(const u of[-1,1])n(73+h,1.15,39+u,.15,2.3,.15,9725511,!0);n(73,1.25,39,2.2,.15,2.2,4488320,!0);for(const h of[72,74])n(h,2,38,.12,1.4,.12,9725511,!0);n(73,2.68,39,2.6,.15,2.6,4488320,!0);for(let h=.22;h<1.3;h+=.22)n(73,h,40.1,1.5,.09,.18,16774617);if(!r({minX:74,maxX:79,minZ:38,maxZ:40,minY:0,maxY:2})){const h=new it;h.setAttribute("position",new Xe([74,1.32,38.4,74,1.32,39.6,77.8,.12,39.6,74,1.32,38.4,77.8,.12,39.6,77.8,.12,38.4],3)),h.computeVertexNormals();const u=i(15118451).clone();u.side=ht,t.add(new Ne(h,u))}n(60,.06,48,5,.12,4.2,9725511),n(60,.13,48,4.6,.14,3.8,14995099),n(69,.22,49,.6,.44,1.2,4488320,!0),n(69,.5,49,4.4,.14,.5,11365457,!0);for(const h of[67.2,70.8])n(h,.7,49,.1,.5,.1,16774617),n(h,.79,49,.4,.08,.08,16774617);e(56,44,-Math.PI/2),e(61,55,0),d(82,66);for(const h of[51,81])for(const u of[40,49])n(h,.45,u,.12,.9,.12,9725511,!0),n(h,.65,u,.12,.1,5,9725511,!0);d(195,82),l(204,91),e(204,64,0),e(178,77,-Math.PI/2),e(179,91,-Math.PI/2);for(const h of[190,202]){n(h,.18,64,3.5,.36,1.4,5933922,!0);for(const u of[-1,0,1])n(h+u,.42,64,.4,.2,.4,14728124)}l(-67,-111),n(-74,.5,-113,1.4,1,.14,9725511,!0),n(-74,1.2,-113,2.2,.6,.12,4488320)}const Ic=[{id:"orchid",name:"Orchid family house",x:-55,z:-14,w:11,d:9,angle:0,wall:14728124,roof:7042704,style:"hip",garage:!0,garden:1},{id:"cedar",name:"Cedar lodge",x:-78,z:-16,w:7,d:11,angle:0,wall:14268559,roof:4488320,style:"gable",porch:3.6,garden:2},{id:"sunflower",name:"Sunflower courtyard",x:-59,z:24,w:12,d:7,angle:Math.PI,wall:15851437,roof:11365457,style:"shed",garage:!0,garden:3},{id:"bluebell",name:"Bluebell cottage",x:-84,z:-44,w:6,d:7,angle:-Math.PI/2,wall:11914194,roof:7108992,style:"gable",garden:2},{id:"maple",name:"Maple garden house",x:-54,z:-61,w:10,d:10,angle:Math.PI,wall:15185051,roof:7042704,style:"hip",garage:!0,garden:1},{id:"fern",name:"Fern studio",x:-23,z:-62,w:6,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"shed",porch:3.2,garden:3},{id:"bakery",name:"Sunrise bakery",x:44,z:-42,w:10,d:8,angle:0,wall:15851437,roof:11365457,style:"gable",shop:!0,sign:"BAKERY",garden:0},{id:"market",name:"Village market",x:60,z:-43,w:10,d:10,angle:0,wall:12177332,roof:4488320,style:"hip",shop:!0,sign:"MARKET",garden:0},{id:"pottery",name:"Clay corner",x:32,z:-25,w:8,d:9,angle:Math.PI/2,wall:14728124,roof:7042704,style:"shed",shop:!0,sign:"POTTERY",garden:0},{id:"workshop",name:"Oak workshop",x:92,z:-17,w:11,d:10,angle:-Math.PI/2,wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,garden:0},{id:"willow",name:"Willow retreat",x:-10,z:-94,w:7,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"hip",porch:3.4,garden:2},{id:"pavilion",name:"Orchard shelter",x:103,z:90,w:8,d:6,angle:-Math.PI/2,wall:15851437,roof:11365457,style:"gable",porch:4,garden:2},...Zc],vm=[[[-124,6],[-103,6],[-85,6],[-66,3],[-49,3],[-35,6],[-20,6],[-6,6],[6,8.6],[17,9],[26,4],[35,3],[50,2],[65,-8],[72,-28],[70,-55],[52,-68],[25,-66],[-10,-77],[-45,-78],[-80,-69],[-98,-48],[-99,-18],[-85,6]],[[72,-28],[92,-52],[115,-53]],...jc],Mm=[[[-35,6],[-36,40],[-45,61],[-41,80],[-15,87],[15,86],[45,86],[66,67],[50,60],[50,33],[53,25],[50,2]],[[45,86],[66,98],[81,94],[94,91],[95,77],[108,62],[104,42],[82,30],[84,41],[84,54],[73,62],[66,67]],[[-80,-69],[-86,-90],[-65,-103],[-45,-108],[-21,-112],[-3,-105],[18,-117],[44,-109],[47,-90],[25,-66]],[[-10,-77],[-18,-89],[-14,-102],[-3,-105]],[[41,-33],[41,-18],[49,-12],[65,-8]],[[18,-117],[18,-104],[37,-103],[47,-90]],...Kc];function Ft(n,e,t){let i=1/0,r=null;for(let s=1;s<t.length;s++){const a=t[s-1],o=t[s],c=o[0]-a[0],l=o[1]-a[1],d=Math.max(0,Math.min(1,((n-a[0])*c+(e-a[1])*l)/(c*c+l*l))),h={x:a[0]+c*d,z:a[1]+l*d},u=Math.hypot(n-h.x,e-h.z);u<i&&(i=u,r=h)}return{distance:i,point:r}}function Di(n){let e=n;for(let t=0;t<2;t++){const i=[e[0]];for(let r=1;r<e.length;r++){const s=e[r-1],a=e[r];i.push([s[0]*.75+a[0]*.25,s[1]*.75+a[1]*.25],[s[0]*.25+a[0]*.75,s[1]*.25+a[1]*.75])}i.push(e.at(-1)),e=i}return e}function ym({scene:n,box:e,material:t,bench:i,disk:r,roads:s,trails:a,drives:o,houses:c,clearings:l,treeAllowed:d,treePositions:h}){e(-8,.006,-197,70,.012,18,14141609);for(const _ of[-32,-8,16])e(_,.25,-205.5,3,.5,3,11906454,!0),e(_,.54,-205.5,2.6,.08,2.6,7052647),i(_===-8?-16:_,-190,0);for(const _ of[-5,5])for(const x of[-204,-199])e(_,1.5,x,.18,3,.18,9725511,!0);for(const _ of[-204,-199])e(0,2.98,_,10.4,.18,.22,9725511,!0);for(let _=-5;_<=5;_+=1)e(_,3.08,-201.5,.15,.16,6,9725511);e(188,.006,-103,14,.012,21,14141609);for(const _ of[-116,-104,-92])i(187,_,Math.PI/2);for(const _ of[199,203,207,211])for(const x of[-27,-34]){e(_,.2,x,2.5,.4,4,9725511,!0),e(_,.43,x,2.2,.06,3.7,7052647);for(let v=0;v<4;v++)e(_,.65,x-1.2+v*.8,.4,.38,.4,v%2?15118451:14728124)}for(const _ of Er){r(_.x,_.z,_.rx+1.6,_.rz+1.6,14141609,.008),r(_.x,_.z,_.rx,_.rz,7515836,.026);for(let x=0;x<30;x++){const v=x*Math.PI*2/30,R=_.x+Math.cos(v)*(_.rx+.7),L=_.z+Math.sin(v)*(_.rz+.7);Math.abs(R-_.x)<2||(e(R,.4,L,.055,.8,.055,5474391),e(R,.85,L,.11,.18,.11,9725511))}}e(-18,.006,200,20,.012,9,14141609);for(const _ of[-76,-70,-64])for(let x=216;x<=234;x+=2)e(_,.12,x,3,.24,1.6,9725511),e(_,.38,x,2.6,.3,1.3,x%4?7052647:15118451);const m=[];for(let _=0;_<20;_++){const x=_*.56;m.push({x:-110+Math.cos(x)*(9+Math.floor(_/7)*4),z:232+Math.sin(x)*(7+Math.floor(_/7)*2),fruit:!0})}const M=[[-210,-190,26,29],[-71,-225,26,10],[181,-185,44,24],[-214,111,19,34],[66,232,43,10],[220,164,17,32],[-220,214,14,22]];let g=19052;const p=()=>(g=Math.imul(g,1664525)+1013904223>>>0,g/4294967296),f=(_,x)=>!!(Math.abs(_)<128&&Math.abs(x)<128||c.some(v=>{const R=Math.abs(Math.cos(v.angle)),L=Math.abs(Math.sin(v.angle));return Math.abs(_-v.x)<(v.w*R+v.d*L)/2+10&&Math.abs(x-v.z)<(v.w*L+v.d*R)/2+10})||[...s,...a].some(v=>Ft(_,x,v).distance<5.3)||o.some(v=>Ft(_,x,v.points).distance<4)||l.some(v=>Math.abs(_-v.x)<v.w/2+4&&Math.abs(x-v.z)<v.d/2+4)||Er.some(v=>((_-v.x)/(v.rx+5))**2+((x-v.z)/(v.rz+5))**2<1)||Ya.some(v=>Math.hypot(_-(v.signX??v.x+4),x-(v.signZ??v.z+4))<5)||Math.abs(_-197)<18&&Math.abs(x-84)<15||Math.abs(_+8)<39&&Math.abs(x+197)<14||_>-85&&_<-55&&x>208);for(let _=0;_<2100;_++){const x=M[_%M.length],v=p()*Math.PI*2,R=Math.sqrt(p()),L=x[0]+Math.cos(v)*x[2]*R,C=x[1]+Math.sin(v)*x[3]*R;f(L,C)||m.some(z=>Math.hypot(L-z.x,C-z.z)<4.1)||m.push({x:L,z:C})}for(const[_,x]of[[-223,-73],[-143,12],[-205,76],[-143,82],[91,-202],[120,-169],[199,-8],[178,123],[113,222],[-50,235],[-231,159]])for(const[v,R]of[[0,0],[5,4],[-4,6]])f(_+v,x+R)||m.push({x:_+v,z:x+R});for(const[_,x]of m.entries()){if(!d(x.x,x.z))continue;h.push({x:x.x,z:x.z});const v=x.fruit?2.2:2.8+_%4*.4;e(x.x,v/2,x.z,.4,v,.4,9725511,!0);const R=!x.fruit&&_%3===0,L=R?new Gi(2.2,4.8,7):new Hi(1,1);R||L.scale(2.2,2.05,2.2);const C=new Ne(L,t(R?5082472:_%2?7052647:5933922));if(C.position.set(x.x,v+.7,x.z),n.add(C),x.fruit)for(const z of[-1,1])e(x.x+z,v+.5,x.z+.4,.22,.22,.22,13075044)}return{trees:m.length,groves:M.length,ponds:Er.length}}function Nc(n,e){if(n.kind==="roller"){const h=Math.cos(n.baseAngle),u=Math.sin(n.baseAngle),m=n.width/2,M=.055,g=n.center.x,p=n.center.z,f=Math.abs(h)*m+Math.abs(u)*M,_=Math.abs(u)*m+Math.abs(h)*M,x=Math.min(1,Math.max(0,e/(Math.PI/2)));return{minX:g-f,maxX:g+f,minZ:p-_,maxZ:p+_,minY:n.height*x,maxY:n.height,obb:{cx:g,cz:p,c:h,s:u,halfW:m,halfD:M},door:!0}}const t=n.baseAngle+e,i=Math.cos(t),r=Math.sin(t),s=n.width/2,a=.055,o=n.hinge.x+i*s,c=n.hinge.z-r*s,l=Math.abs(i)*s+Math.abs(r)*a,d=Math.abs(r)*s+Math.abs(i)*a;return{minX:o-l,maxX:o+l,minZ:c-d,maxZ:c+d,minY:0,maxY:n.height??2.3,obb:{cx:o,cz:c,c:i,s:r,halfW:s,halfD:a},door:!0}}function Ui(n,e,t=n.swing??-1){const i=n.angle??(n.open?t*Math.PI/2:0);return Nc(n,i)}const Ga=[{id:"home",name:"Your home",x:-13,z:-9,w:8,d:7,angle:0,wall:15851437,roof:4488320,style:"gable"},{id:"peach",name:"Peach cottage",x:6,z:-10,w:7,d:8,angle:0,wall:15185051,roof:7042704,style:"hip"},{id:"sage",name:"Sage bungalow",x:-17,z:20,w:9,d:6,angle:Math.PI,wall:12177332,roof:11365457,style:"gable"},{id:"rose",name:"Rose cabin",x:17,z:20,w:6,d:8,angle:Math.PI,wall:14728124,roof:7108992,style:"shed"},...Ic,...bn];function Ct(n,e,t){const i=Math.cos(n.angle),r=Math.sin(n.angle);return{x:n.x+e*i+t*r,z:n.z-e*r+t*i}}function Sm(n,e=[]){const t=new Oi(8);for(const S of e)t.add(ct(S));const i=S=>t.query(S).some(y=>vt(y,S)),r=[],s=Ga.filter(S=>{if(!S.designed)return!0;const y=Math.max(S.w,S.d)/2+(S.garage?6:2),k=i({minX:S.x-y,maxX:S.x+y,minZ:S.z-y,maxZ:S.z+y,minY:0,maxY:10});return k&&r.push(S.id),!k}),a=[],o=[];let c=!1;const l=[],d=[],h=new Map,u=new Mt(1,1,1),m=new Map,M=S=>(m.has(S)||m.set(S,new Kt({color:S})),m.get(S)),g=new ut;function p(S,y,k,N,se,oe,J,pe=!1,w=0){const E=(Math.abs(Math.cos(w))*N+Math.abs(Math.sin(w))*oe)/2+.1,F=(Math.abs(Math.sin(w))*N+Math.abs(Math.cos(w))*oe)/2+.1;if(!(c&&se>.03&&i({minX:S-E,maxX:S+E,minZ:k-F,maxZ:k+F,minY:y-se/2,maxY:y+se/2}))&&(h.has(J)||h.set(J,[]),h.get(J).push({x:S,y,z:k,w:N,h:se,d:oe,angle:w}),pe)){const $=Math.abs(Math.cos(w)),q=Math.abs(Math.sin(w)),ee=(N*$+oe*q)/2,xe=(N*q+oe*$)/2;l.push({...Math.abs(Math.sin(w*2))>1e-6?{obb:{cx:S,cz:k,c:Math.cos(w),s:Math.sin(w),halfW:N/2,halfD:oe/2}}:{},minX:S-ee,maxX:S+ee,minY:y-se/2,maxY:y+se/2,minZ:k-xe,maxZ:k+xe})}}const f=[];function _(S,y,k,N,se=0,oe=4){if(typeof document>"u")return;const J=document.createElement("canvas");J.width=512,J.height=96;const pe=J.getContext("2d");pe.fillStyle="#fff5d9",pe.fillRect(0,0,512,96),pe.fillStyle="#496c61",pe.font="bold 48px sans-serif",pe.textAlign="center",pe.textBaseline="middle",pe.fillText(S,256,50,480);const w=new Oa(J);w.colorSpace=lt;const E=new Ne(new En(oe,oe*96/512),new pi({map:w,side:ht}));E.position.set(y,k,N),E.rotation.y=se,n.add(E),f.push(E)}const x=9418861,v=9725511,R=16774617,L=8501706;p(0,-.18,0,et.halfSize*2+2,.36,et.halfSize*2+2,x,!0);const C=vm.map(Di),z=Mm.map(Di);for(const S of As.filter((y,k)=>k!==2)){const y=Di(S);for(const k of[0,y.length-1]){const N=y[k],se=Ft(N[0],N[1],C[2]).point;k===0?y.unshift([se.x,se.z]):y.push([se.x,se.z])}C.push(y)}z.push(...qc.map(Di),Di(As[2]));const b=C[0];function T(S,y,k,N){const se=[],oe=[];S.forEach((w,E)=>{const F=S[Math.max(0,E-1)],$=S[Math.min(S.length-1,E+1)],q=$[0]-F[0],ee=$[1]-F[1],xe=Math.hypot(q,ee),ge=-ee/xe*y/2,ve=q/xe*y/2;if(se.push(w[0]+ge,N,w[1]+ve,w[0]-ge,N,w[1]-ve),E){let Ee=E*2;oe.push(Ee-2,Ee,Ee-1,Ee-1,Ee,Ee+1)}});const J=new it;J.setAttribute("position",new Xe(se,3)),J.setIndex(oe),J.computeVertexNormals();const pe=new Ne(J,M(k));return n.add(pe),pe}for(const S of C)T(S,7.4,14601641,.014),T(S,5,6845816,.024);for(const S of z)T(S,2.4,14008212,.019);const H=[];for(const S of C)for(const y of[0,S.length-1]){const k=S[y],N=y===0?S.slice(5):S.slice(0,-5);N.length>1&&Ft(k[0],k[1],N).distance<2.5&&H.push({x:k[0],z:k[1]})}for(const S of C){let y=0,k=1;for(let N=1;N<S.length;N++){const se=S[N-1],oe=S[N],J=oe[0]-se[0],pe=oe[1]-se[1],w=Math.hypot(J,pe);for(;k<y+w;){const E=(k-y)/w,F=se[0]+J*E,$=se[1]+pe*E;!H.some(q=>Math.hypot(F-q.x,$-q.z)<5.5)&&!C.some(q=>q!==S&&Ft(F,$,q).distance<5.5)&&p(se[0]+J*E,.031,se[1]+pe*E,.1,.012,1.1,15984318,!1,Math.atan2(J,pe)),k+=3.5}y+=w}}const U=s.map(S=>{const y=Ct(S,-1.4,S.d/2),k=Ct(S,-1.4,S.d/2+2.5),se=(S.street?[C[{north:4,south:5,elm:6}[S.street]]]:S.route==="trail"?z:S.shop?[...C,z[4]]:S.id==="willow"||S.id==="pavilion"?z:C).map(pe=>({...Ft(k.x,k.z,pe),isRoad:C.includes(pe)})).sort((pe,w)=>pe.distance-w.distance)[0];let oe=S.approach||{bakery:{x:44,z:-34},market:{x:60,z:-34},pottery:{x:39,z:-25}}[S.id]||se.point;if(se.isRoad&&!["bakery","market","pottery"].includes(S.id)){const pe=k.x-oe.x,w=k.z-oe.z,E=Math.hypot(pe,w);E>3.3&&(oe={x:oe.x+pe/E*3.3,z:oe.z+w/E*3.3})}const J=[[y.x,y.z],[k.x,k.z],[oe.x,oe.z]];if(T(J,S.shop?2.8:2.4,12959399,.032),S.garage||S.carport){const pe=Ct(S,-S.w/2-2.1,S.d/2+.15);let w=C.map(q=>Ft(pe.x,pe.z,q)).sort((q,ee)=>q.distance-ee.distance)[0].point;const E=pe.x-w.x,F=pe.z-w.z,$=Math.hypot(E,F);$>3.3&&(w={x:w.x+E/$*3.3,z:w.z+F/$*3.3}),T([[pe.x,pe.z],[w.x,w.z]],3.6,12959399,.033)}return{entry:y,end:oe,points:J,w:S.shop?2.8:2.4}});for(const S of s){let pe=function(ie){const ae=S.w>9?2.4:1.8,ue=S.shop?2.6:S.w>9?2.2:1.5,Z=1.05,P=1.2,le=ie>0?[[-y/2,se-oe/2],[se+oe/2,ae-ue/2],[ae+ue/2,y/2]]:[[-y/2,ae-ue/2],[ae+ue/2,y/2]];for(const[de,be]of le)be>de&&J((de+be)/2,1.5,ie,be-de,3,.22,S.wall,!0);ie>0&&J(se,2.675,ie,oe,.65,.22,S.wall,!0),J(ae,Z/2,ie,ue,Z,.22,S.wall,!0),J(ae,(Z+P+3)/2,ie,ue,3-Z-P,.22,S.wall,!0),J(ae,Z+P/2,ie,ue,P,.1,L,!0);for(const de of[ae-ue/2,ae,ae+ue/2])J(de,Z+P/2,ie+.01,.065,P+.12,.29,R);for(const de of[Z,Z+P/2,Z+P])J(ae,de,ie+.01,ue+.12,.065,.29,R);J(ae,Z-.06,ie,ue+.27,.12,.42,R)};var Le=pe;const{w:y,d:k}=S,N=k/2,se=-1.4,oe=1.4,J=(ie,ae,ue,Z,P,le,de,be=!1)=>{const Re=Ct(S,ie,ue);p(Re.x,ae,Re.z,Z,P,le,de,be,S.angle)};if(c=!!S.designed,S.designed){gm({h:S,put:J,local:(ie,ae)=>Ct(S,ie,ae),scene:n,material:M,doors:d,solids:l,label:_,rooms:a}),c=!1;continue}if(J(0,.006,0,y,.012,k,14006419),pe(N),pe(-N),S.wing){const ie=-N+2.75;for(const[ae,ue]of[[-N,ie-.9],[ie+.9,N]])ue>ae&&J(-y/2,1.5,(ae+ue)/2,.22,3,ue-ae,S.wall,!0);J(-y/2,2.72,ie,.22,.56,1.8,S.wall,!0),a.push({house:S.id,name:"Side room",...Ct(S,-y/2-2.25,ie),y:0})}else J(-y/2,1.5,0,.22,3,k,S.wall,!0);if((S.d>8||S.bay)&&Ic.some(ie=>ie.id===S.id)){const ie=S.d>10?[-2.6,2.6]:[0],ae=.8;let ue=-N;for(const Z of ie){const P=Z-ae;J(y/2,1.5,(ue+P)/2,.22,3,P-ue,S.wall,!0),J(y/2,.525,Z,.22,1.05,1.6,S.wall,!0),J(y/2,2.625,Z,.22,.75,1.6,S.wall,!0),S.bay||J(y/2,1.65,Z,.1,1.2,1.6,L,!0);for(const le of[Z-ae,Z,Z+ae])J(y/2+.01,1.65,le,.29,1.32,.065,R);for(const le of[1.05,1.65,2.25])J(y/2+.01,le,Z,.29,.065,1.72,R);ue=Z+ae}J(y/2,1.5,(ue+N)/2,.22,3,N-ue,S.wall,!0)}else J(y/2,1.5,0,.22,3,k,S.wall,!0);const w=[],E=[],F=(ie,ae,ue,Z)=>{const P=w.length/3;w.push(...ie,...ae,...ue,...Z),E.push(P,P+1,P+2,P,P+2,P+3)},$=y/2+.4,q=N+.4,ee=3.06,xe=4.7;if(S.style==="gable"){F([-$,ee,q],[0,xe,q],[0,xe,-q],[-$,ee,-q]),F([0,xe,q],[$,ee,q],[$,ee,-q],[0,xe,-q]);for(const ie of[-N,N]){const ae=ee+(xe-ee)*.4/$,ue=new it;ue.setAttribute("position",new Xe([-y/2,3,ie,y/2,3,ie,y/2,ae,ie,0,xe,ie,-y/2,ae,ie],3)),ue.setIndex([0,1,2,0,2,3,0,3,4]),ue.computeVertexNormals();const Z=M(S.wall).clone();Z.side=ht;const P=new Ne(ue,Z);P.position.set(S.x,0,S.z),P.rotation.y=S.angle,n.add(P)}}else if(S.style==="gambrel"){const ie=[-$,-$*.56,0,$*.56,$],ae=[ee,4.45,5.4,4.45,ee];for(let Z=1;Z<ie.length;Z++)F([ie[Z-1],ae[Z-1],q],[ie[Z],ae[Z],q],[ie[Z],ae[Z],-q],[ie[Z-1],ae[Z-1],-q]);const ue=ee+(4.45-ee)*.4/($*.44);for(const Z of[-N,N]){const P=[[-y/2,3,Z],[y/2,3,Z],[y/2,ue,Z],[$*.56,4.45,Z],[0,5.4,Z],[-$*.56,4.45,Z],[-y/2,ue,Z]],le=new it;le.setAttribute("position",new Xe(P.flat(),3)),le.setIndex([0,1,2,0,2,3,0,3,4,0,4,5,0,5,6]),le.computeVertexNormals();const de=M(S.wall).clone();de.side=ht;const be=new Ne(le,de);be.position.set(S.x,0,S.z),be.rotation.y=S.angle,n.add(be)}}else if(S.style==="hip")F([-$,ee,q],[$,ee,q],[0,xe,1.5],[0,xe,1.5]),F([$,ee,q],[$,ee,-q],[0,xe,-1.5],[0,xe,1.5]),F([$,ee,-q],[-$,ee,-q],[0,xe,-1.5],[0,xe,-1.5]),F([-$,ee,-q],[-$,ee,q],[0,xe,1.5],[0,xe,-1.5]);else{F([-$,ee,q],[$,ee,q],[$,4.1,-q],[-$,4.1,-q]);const ie=ee+(4.1-ee)*.4/(k+.8),ae=4.1-(4.1-ee)*.4/(k+.8);J(0,(3+ae)/2,-N,y,ae-3,.22,S.wall),J(0,(3+ie)/2,N,y,ie-3,.22,S.wall);for(const ue of[-y/2,y/2]){const Z=new it;Z.setAttribute("position",new Xe([ue,3,-N,ue,ae,-N,ue,ie,N,ue,3,N],3)),Z.setIndex([0,1,2,0,2,3]),Z.computeVertexNormals();const P=M(S.wall).clone();P.side=ht;const le=new Ne(Z,P);le.position.set(S.x,0,S.z),le.rotation.y=S.angle,n.add(le)}}const ge=new it;ge.setAttribute("position",new Xe(w,3)),ge.setIndex(E),ge.computeVertexNormals();const ve=M(S.roof).clone();ve.side=ht;const Ee=new Ne(ge,ve);Ee.position.set(S.x,0,S.z),Ee.rotation.y=S.angle,n.add(Ee),J(0,3.015,0,S.style==="shed"?y:y+.8,.09,S.style==="shed"?k:k+.8,R,!0);for(const ie of[-y/2,y/2])J(ie,1.5,N+.08,.13,3,.14,R);J(se,2.62,N+.7,S.porch||2.2,.15,1.5,S.roof,!0);for(const ie of[se-(S.porch||2.2)/2+.14,se+(S.porch||2.2)/2-.14])J(ie,1.27,N+1.28,.12,2.54,.12,R,!0);const Pe=new xt,ce=Ct(S,se-oe/2+.07,N+.03),Ye=oe-.14;Pe.position.set(ce.x,0,ce.z),Pe.rotation.y=S.angle;const ke=new Ne(new Mt(Ye,2.3,.1),M(9726028));ke.position.set(Ye/2,1.15,0),Pe.add(ke);const De=new Ne(new Mt(.78,.7,.11),M(11980733));De.position.set(Ye/2,1.66,0),Pe.add(De);const Ae=new Ne(new Gr(.055,6,5),M(16768118));Ae.position.set(Ye-.18,1,.09),Pe.add(Ae),n.add(Pe);const ye=Ct(S,se,N);if(d.push({id:S.id,pivot:Pe,baseAngle:S.angle,open:!1,center:ye,hinge:ce,width:Ye,height:2.3}),S.shop){J(y/2-1,.45,-N+1,1.4,.9,1.3,v,!0),J(y/2-1,.95,-N+1,1.6,.12,1.5,R);for(let ae=0;ae<3;ae++)J(-y/2+1.2+ae*1.6,.6,-N+.7,1.2,1.2,.65,v,!0),J(-y/2+1.2+ae*1.6,1.28,-N+.7,.8,.16,.4,[15118451,12177332,14728124][ae]);J(1,2.6,N+.19,y-1,.25,.6,S.roof);for(let ae=0;ae<8;ae++)J(-y/2+.5+ae*(y-1)/8,2.7,N+.8,(y-1)/8,.12,1.4,ae%2?R:S.roof);J(0,3.28,N+.2,4.05,.82,.12,v);for(const ae of[-1.65,1.65])J(ae,2.96,N+.18,.1,.7,.12,v);const ie=Ct(S,0,N+.28);_(S.sign,ie.x,3.28,ie.z,S.angle,3.8)}else J(-y/2+1.15,.29,-N+1.6,1.7,.58,2.4,v,!0),J(-y/2+1.15,.65,-N+1.45,1.65,.16,2.1,S.id==="home"?7183771:13214055),J(-y/2+1.15,.78,-N+.65,1.4,.17,.48,R),J(y/2-.9,.45,-N+.9,1.1,.9,.7,v,!0);if(S.garage&&to({scene:n,material:M,doors:d,h:S,put:J,local:(ie,ae)=>Ct(S,ie,ae)}),S.carport){const ie=-y/2-2.1,ae=N-2.7;J(ie,2.55,ae,4.6,.18,5.8,S.roof,!0);for(const ue of[-1.9,1.9])for(const Z of[-2.35,2.35])J(ie+ue,1.22,ae+Z,.16,2.44,.16,v,!0);J(ie,.008,ae,4.2,.016,5.4,12959399)}if(S.wing){const ie=-y/2-2.25,ae=-N+2.75;J(ie,.007,ae,4.5,.014,5.5,14006419),J(ie-2.25,1.65,ae,.22,3.3,5.5,S.wall,!0);for(const ue of[ae-2.75,ae+2.75])J(ie,1.65,ue,4.5,3.3,.22,S.wall,!0);J(ie,3.4,ae,4.9,.2,5.9,S.roof,!0),J(ie,1.7,ae+2.78,2.6,1.25,.08,L);for(const ue of[ie-1.33,ie,ie+1.33])J(ue,1.7,ae+2.84,.065,1.38,.1,R);for(const ue of[1.05,2.35])J(ie,ue,ae+2.84,2.73,.065,.1,R)}if(S.bay){c=!0,J(y/2+.32,.525,0,.64,1.05,1.9,S.wall,!0),J(y/2+.64,1.65,0,.08,1.2,1.8,L,!0);for(const ie of[-.87,.87])J(y/2+.32,1.65,ie,.64,1.2,.08,L,!0);J(y/2+.34,3.015,0,.9,.09,2.15,R,!0),J(y/2+.64,2.625,0,.1,.75,1.8,S.wall,!0);for(const ie of[-.87,.87])J(y/2+.32,2.625,ie,.64,.75,.1,S.wall,!0);for(const ie of[-.9,0,.9])J(y/2+.7,1.65,ie,.1,1.35,.065,R)}if(c=!1,S.chimney&&J(y/2-1,4.2,-N*.3,.8,2.4,.8,13075044,!0),S.tower){const ie=y/2+1.8,ae=-N+1.8;J(ie,3.4,ae,3.6,6.8,3.6,S.wall,!0);for(const le of[ae-1.83,ae+1.83]){J(ie,5.1,le,1.5,1.5,.08,R),J(ie,5.3,le+(le>ae?.06:-.06),.08,.58,.1,v),J(ie+.22,5.1,le+(le>ae?.06:-.06),.48,.08,.1,v);for(const de of[ie-.58,ie+.58])J(de,5.1,le,.08,1.65,.12,R)}const ue=Ct(S,ie,ae),Z=new Gi(2.7,1.8,4),P=new Ne(Z,M(S.roof));P.position.set(ue.x,7.7,ue.z),P.rotation.y=S.angle+Math.PI/4,n.add(P)}if(S.garden){c=!!S.wing;const ie=S.garage||S.wing?y/2+2:-y/2-2;J(ie,.18,0,2.3,.36,k*.75,5933922,!0);for(let ae=0;ae<4;ae++)J(ie,.42,-k*.25+ae*k/6,.4,.2,.4,[15118451,14728124,15851437][S.garden-1]);S.garden===3&&(J(0,.3,-N-2.2,y*.7,.6,1.2,v,!0),J(0,.64,-N-2.2,y*.65,.12,1,7052647))}c=!1,J(.55,.05,N+.5,.8,.09,.6,S.roof);const Ue=Ct(S,2.15,N+2.1);p(Ue.x,.5,Ue.z,.11,1,.11,v,!0),p(Ue.x,1.05,Ue.z,.55,.34,.4,S.roof)}const Y={x:-10.8,z:-8.1};p(Y.x,.88,Y.z,1.4,.22,1.1,11368266,!0);for(const S of[-.5,.5])for(const y of[-.35,.35])p(Y.x+S,.39,Y.z+y,.14,.78,.14,v,!0);for(let S=0;S<3;S++)for(let y=0;y<3;y++)p(Y.x-.36+S*.36,1.001,Y.z-.32+y*.32,.29,.014,.26,(S+y)%2?15718563:7687734);p(-4,.004,-.5,8,.008,6,10993279);for(const S of[-8,0])for(const y of[-3.5,2.5])p(S,.16,y,.2,.32,.2,v);const D=[[-27,-18],[-23,-7],[-28,17],[-6,-22],[18,-17],[26,-7],[28,20],[2,25],[-28,28],[27,-25],[13,29],[-2,19]];function I(S,y){return C.some(k=>Ft(S,y,k).distance<4.8)||z.some(k=>Ft(S,y,k).distance<2.1)||U.some(k=>Ft(S,y,k.points).distance<2.2)||s.some(k=>{const N=Ct({...k,angle:-k.angle,x:0,z:0},S-k.x,y-k.z);return Math.abs(N.x)<k.w/2+(k.garage||k.wing?6:2.8)&&Math.abs(N.z)<k.d/2+3})||[...Tr].some(k=>Math.abs(S-k.x)<k.w/2+2&&Math.abs(y-k.z)<k.d/2+2)?!1:!i({minX:S-2,maxX:S+2,minZ:y-2,maxZ:y+2,minY:0,maxY:7})}const G=[];for(const[S,[y,k]]of D.entries()){if(!I(y,k))continue;o.push({x:y,z:k});const N=2.5+S%3*.25;p(y,N/2,k,.42,N,.42,8675908,!0),G.push({x:y,y:N+.7,z:k,scale:1.9+S%2*.3,color:S%2?7052647:5082472})}for(const S of new Set(G.map(y=>y.color))){const y=G.filter(se=>se.color===S),k=new Hi(1,1),N=new ks(k,M(S),y.length);y.forEach((se,oe)=>{g.position.set(se.x,se.y,se.z),g.scale.set(se.scale,se.scale*.85,se.scale),g.rotation.set(0,oe,.2),g.updateMatrix(),N.setMatrixAt(oe,g.matrix)}),n.add(N)}for(let S=-et.halfSize+1;S<=et.halfSize-1;S+=4){for(const y of[-et.halfSize,et.halfSize])p(S,.7,y,4,1.4,1.4,5933922);for(const y of[-et.halfSize,et.halfSize])p(y,.7,S,1.4,1.4,4,5933922)}p(1,.48,15,2,.15,.65,v,!0),p(1,.94,15.28,2,.8,.12,v,!0);for(const S of[.25,1.75])p(S,.23,15,.12,.46,.5,5992562,!0);for(const[S,y]of[[-8,-14],[-18,-14],[10,-16],[20,15],[-21,17],[0,16]])p(S,.18,y,.07,.36,.07,5474391),p(S,.4,y,.32,.16,.32,15118451);if(p(49,.006,-26,23,.012,23,14141609),p(49,.2,-26,3,.4,3,11906454,!0),p(49,.44,-26,2.6,.08,2.6,7052647),p(49,2,-26,.32,4,.32,v,!0),p(49,4.1,-26,1.4,1.4,.4,15851437),typeof document<"u"){const S=document.createElement("canvas");S.width=S.height=192;const y=S.getContext("2d");y.fillStyle="#fff5d9",y.fillRect(0,0,192,192),y.strokeStyle="#496c61",y.lineWidth=5,y.beginPath(),y.arc(96,96,84,0,Math.PI*2),y.stroke(),y.font="bold 23px sans-serif",y.textAlign="center",y.textBaseline="middle",y.fillStyle="#496c61";for(const[se,oe,J]of[["12",96,34],["3",160,98],["6",96,160],["9",34,98]])y.fillText(se,oe,J);y.lineCap="round",y.lineWidth=8,y.beginPath(),y.moveTo(96,96),y.lineTo(65,77),y.moveTo(96,96),y.lineTo(132,60),y.stroke();const k=new Oa(S);k.colorSpace=lt;const N=new Ne(new En(1.14,1.14),new pi({map:k}));N.position.set(49,4.1,-25.79),n.add(N),f.push(N)}function X(S,y,k=0){if(i({minX:S-1.4,maxX:S+1.4,minZ:y-1.4,maxZ:y+1.4,minY:0,maxY:1.5}))return;const N=(se,oe,J,pe,w,E,F,$=!0)=>{const q=Ct({x:S,z:y,angle:k},se,J);p(q.x,oe,q.z,pe,w,E,F,$,k)};N(0,.48,0,2,.15,.65,v),N(0,.94,.28,2,.8,.12,v);for(const se of[-.75,.75])N(se,.23,0,.12,.46,.5,5992562)}for(const S of[40,58])X(S,-26,Math.PI/2);const Q=[{x:-70,z:61,w:36,d:30,subtle:!0},{x:8,z:61,w:27,d:27},...$c];for(const S of Q){const y=z.map(oe=>Ft(S.x,S.z,oe)).sort((oe,J)=>oe.distance-J.distance)[0].point,k=y.x-S.x,N=y.z-S.z,se=Math.min(Math.abs(k)>1e-6?S.w/2/Math.abs(k):1/0,Math.abs(N)>1e-6?S.d/2/Math.abs(N):1/0);if(se<1){const oe=[[y.x,y.z],[S.x+k*se,S.z+N*se]];z.push(oe),T(oe,2.4,14008212,.019)}p(S.x,.004,S.z,S.w,.008,S.d,S.subtle?9878134:10993279);for(const oe of[-S.w/2,S.w/2])for(const J of[-S.d/2,S.d/2])p(S.x+oe,.18,S.z+J,.22,.36,.22,v)}for(const S of Tr){Q.push(S);const y=S.roadZ??S.z,k=S.roadX?S.z-6:S.z+(y-S.z)*.45;p(S.x,.005,S.z,S.w,.01,S.d,9878134),T(S.roadX?[[S.x+S.w/2,S.z],[S.roadX-3.3,S.z]]:[[S.x,S.z+(y>S.z?S.d/2:-S.d/2)],[S.x,y+(y>S.z?-3.3:3.3)]],2.4,12959399,.032),p(S.x-S.w/2+.4,.45,k,.12,.9,.12,v),p(S.x-S.w/2+.4,.82,k,1.2,.5,.08,4488320),_("BUILD",S.x-S.w/2+.4,.83,k+.05,0,1.1)}c=!0,xm({box:p,bench:X,material:M,scene:n,reserved:i}),c=!1;const ne={x:18,z:-101,rx:16,rz:10},te=(S,y,k,N,se,oe=.02)=>{const J=new Js(1,48);J.rotateX(-Math.PI/2),J.scale(k,1,N);const pe=new Ne(J,M(se));pe.position.set(S,oe,y),n.add(pe)};te(18,-101,18,12,14141609,.006),te(18,-101,16,10,7515836,.022);for(let S=0;S<9;S++)p(18+(S%2?.3:-.3),.035,-110+S*2.25,1.25,.018,1.45,11906454,!1);X(38,-103,Math.PI/2),X(10,-116,Math.PI);const he=[];for(let S=0;S<18;S++){const y=S*.67;he.push([81+Math.cos(y)*(7+Math.floor(S/6)*4),94+Math.sin(y)*(7+Math.floor(S/6)*4)])}X(81,100),p(81,.015,97,3,.03,2,14728124);const fe=(S,y)=>!!(Math.abs(S)<32&&Math.abs(y)<32||Ga.slice(0,16).some(k=>{const N=Math.abs(Math.cos(k.angle)),se=Math.abs(Math.sin(k.angle));return Math.abs(S-k.x)<(k.w*N+k.d*se)/2+8&&Math.abs(y-k.z)<(k.w*se+k.d*N)/2+6})||[...C.slice(0,2),...z.slice(0,6)].some(k=>Ft(S,y,k).distance<5.2)||U.slice(0,16).some(k=>Ft(S,y,k.points).distance<3)||Q.slice(0,2).some(k=>Math.abs(S-k.x)<k.w/2+3&&Math.abs(y-k.z)<k.d/2+3)||Math.abs(S-65)<18&&Math.abs(y-46)<18||Math.abs(S-49)<17&&Math.abs(y+26)<17||Math.abs(S-18)<22&&Math.abs(y+101)<16||Math.hypot(S-81,y-94)<24);let K=73419;const re=()=>(K=Math.imul(K,1664525)+1013904223>>>0,K/4294967296),me=[];for(let S=0;S<650;S++){const y=-118+re()*236,k=-118+re()*236;fe(y,k)||me.some(N=>Math.hypot(N[0]-y,N[1]-k)<5)||k>-80&&re()<.42||me.push([y,k])}for(let S=0;S<600;S++){const y=-95+re()*63,k=-121+re()*36;fe(y,k)||me.some(N=>Math.hypot(N[0]-y,N[1]-k)<3.8)||me.push([y,k])}for(let S=0;S<24;S++){const y=S*Math.PI*2/24,k=18+Math.cos(y)*16.8,N=-101+Math.sin(y)*10.8;Math.abs(k-18)<2||(p(k,.35,N,.055,.7,.055,5474391),p(k,.74,N,.12,.17,.12,9725511))}for(const[S,[y,k]]of[...me,...he].entries()){if(!I(y,k))continue;o.push({x:y,z:k});const N=S>=me.length,se=N?2.2:2.6+S%4*.35;p(y,se/2,k,.38,se,.38,v,!0);const oe=!N&&k<-80&&S%3===0,J=oe?new Gi(2.1,4.6,7):new Hi(1,1);oe||J.scale(2.2,1.9,2.2);const pe=new Ne(J,M(oe?5082472:S%2?7052647:5933922));if(pe.position.set(y,se+.7,k),n.add(pe),N)for(const w of[-1,1])p(y+w,se+.5,k+.5,.22,.22,.22,13075044)}c=!0;const we=ym({scene:n,box:p,material:M,bench:X,disk:te,roads:C,trails:z,drives:U,houses:s,treeAllowed:I,treePositions:o,clearings:Q});c=!1;for(const S of Jc.filter(y=>y.id!=="home")){c=qa.some(N=>N.id===S.id);const y=S.signX??(S.id==="pond"?39:S.x+4),k=S.signZ??(S.id==="pond"?-94:S.z+4);i({minX:y-2,maxX:y+2,minZ:k-1,maxZ:k+1,minY:0,maxY:2.2})||(p(y,.9,k,.14,1.8,.14,v,!0),p(y,1.7,k,3.8,.8,.12,4488320),_(S.name.toUpperCase(),y,1.72,k+.075,0,3.6))}c=!1;for(const[S,y]of h){const k=new ks(u,M(S),y.length);y.forEach((N,se)=>{g.position.set(N.x,N.y,N.z),g.rotation.set(0,N.angle,0),g.scale.set(N.w,N.h,N.d),g.updateMatrix(),k.setMatrixAt(se,g.matrix)}),k.computeBoundingSphere(),n.add(k)}const Se=new Ne(new En(et.halfSize*2,et.halfSize*2),new pi({visible:!1}));Se.rotation.x=-Math.PI/2,Se.updateMatrixWorld(),n.add(Se);const Fe=Uc(d),Oe=Dc(n,new Set([...d.map(S=>S.pivot),Se,...f]));return{config:et,roads:C,selfJunctions:H,trails:z,clearings:Q,pond:ne,ponds:[ne,...Er],outerScenery:we,staticRender:Oe,doorRender:Fe,treeCount:o.length,treePositions:o,rooms:a,omitted:r,solids:l,doors:d,table:Y,ground:Se,road:b,drives:U,houses:s,treeAllowed:I,batches:h}}const mn=[{id:"home-square",name:"Home & Square",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"legacy-06",name:"Legacy neighbourhood",icon:"🏡",spawn:{x:-14.4,y:0,z:-1.2,yaw:0,pitch:0}},{id:"blank",name:"Blank creative",icon:"🧱",spawn:{x:0,y:0,z:8,yaw:0,pitch:0}}];function Em(n,e,t=[]){if(e==="home-square")return _m(n);if(e==="legacy-06")return Sm(n,t);const i=new Ne(new En(500,500),new Kt({color:11127178}));return i.rotation.x=-Math.PI/2,n.add(i),i.updateMatrixWorld(),{ground:i,solids:[],doors:[],houses:[],rooms:[],roads:[],staticRender:{updateVisibility(){}}}}function Fc(n){let e=2166136261;for(let t=0;t<n.length;t++)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return(e>>>0).toString(16).padStart(8,"0")}function Hr(n){const e=n;if(!e||e.schema!==1||!mn.some(i=>i.id===e.template)||!e.world||!e.player||!e.preferences)throw Error("Unsupported world schema or template");for(const i of["x","y","z","yaw","pitch"])if(!Number.isFinite(e.player[i]))throw Error("Invalid player position");if(Math.abs(e.player.x)>=250||Math.abs(e.player.z)>=250||e.player.y<0||e.player.y>26)throw Error("Player outside supported bounds");if(Ja({version:4,world:"little-block-world-06",blocks:e.world.blocks,doors:e.world.doors,player:e.player,selected:e.preferences.selected,inventory:{flowers:999,lantern:999,bench:999}}),!["hand",...Ii.map(i=>i.id)].includes(e.preferences.selected))throw Error("Invalid selected item");if(!e.world.doors||Array.isArray(e.world.doors)||typeof e.world.doors!="object"||Object.values(e.world.doors).some(i=>typeof i!="boolean"))throw Error("Invalid doors");const t=e.world.activity;if(t!==void 0&&(!t||!t.car||![t.car.x,t.car.z,t.car.yaw].every(Number.isFinite)||Math.abs(t.car.x)>249||Math.abs(t.car.z)>249))throw Error("Invalid vehicle checkpoint");return structuredClone(e)}function mi(n){const e=JSON.stringify(Hr(n));return{json:e,checksum:Fc(e)}}function wr(n){if(!n||typeof n.json!="string"||n.json.length>8e6||Fc(n.json)!==n.checksum)throw Error("Checkpoint checksum failed");return Hr(JSON.parse(n.json))}function In(n){return Hr({schema:1,template:n.template,world:{blocks:n.blocks,doors:n.doors,...n.activity?{activity:n.activity}:{}},player:n.player,preferences:{selected:n.selected,camera:n.camera||"first",flying:!!n.flying}})}function bm(n){if(n.length>12e6)throw Error("Backup is too large");const e=JSON.parse(n);if(e.format==="blockworld2"&&e.version===1)return{snapshot:wr(e.checkpoint),...typeof e.legacySource=="string"&&e.legacySource.length<=4e6?{source:e.legacySource}:{},name:typeof e.name=="string"?e.name.slice(0,60):"Imported world"};if(n.length>4e6)throw Error("Legacy backup exceeds 4 MB");const t=Ja(e);return{snapshot:Hr({schema:1,template:"legacy-06",world:{blocks:t.blocks,doors:t.doors},player:t.player,preferences:{selected:t.selected}}),source:n,name:"Imported legacy neighbourhood"}}class Ha extends Error{constructor(){super("This world changed in another tab. Your unsaved work is still here; export or save a new copy.")}}const Mr=n=>new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error||Error("Storage request failed"))}),yr=n=>new Promise((e,t)=>{n.oncomplete=()=>e(),n.onabort=()=>t(n.error||Error("Storage transaction aborted")),n.onerror=()=>{}});class Ir{constructor(e){this.db=e}static open(e="blockworld2-development"){return new Promise((t,i)=>{const r=indexedDB.open(e,1);r.onupgradeneeded=()=>{for(const s of["worlds","meta"])r.result.objectStoreNames.contains(s)||r.result.createObjectStore(s,{keyPath:s==="worlds"?"id":"key"})},r.onsuccess=()=>{r.result.onversionchange=()=>r.result.close(),t(new Ir(r.result))},r.onerror=()=>i(r.error),r.onblocked=()=>i(Error("Close another BlockWorld tab to open saves"))})}async read(e,t){const i=this.db.transaction(e,"readonly");return Mr(i.objectStore(e).get(t))}async list(){const e=this.db.transaction("worlds","readonly");return Mr(e.objectStore("worlds").getAll())}async last(){var e;return(e=await this.read("meta","last"))==null?void 0:e.value}async select(e){const t=this.db.transaction("meta","readwrite"),i=yr(t);t.objectStore("meta").put({key:"last",value:e}),await i}async create(e,t,i){const r=mi(t),s={id:crypto.randomUUID(),name:e.trim().slice(0,60)||"My world",template:t.template,revision:0,updated:Date.now(),current:r,previous:[],...i?{importSource:i}:{}},a=this.db.transaction("worlds","readwrite"),o=yr(a);return a.objectStore("worlds").add(s),await o,s}async load(e){const t=await this.read("worlds",e);if(!t)throw Error("World was not found");try{return{record:t,snapshot:wr(t.current),recovered:!1}}catch{for(const r of t.previous||[])try{return{record:t,snapshot:wr(r),recovered:!0}}catch{}throw Error("No valid checkpoint. Original data is retained; import a backup or choose another world.")}}async save(e,t,i){const r=mi(i),s=this.db.transaction("worlds","readwrite"),a=yr(s);try{const o=s.objectStore("worlds"),c=await Mr(o.get(e));if(!c)throw Error("World no longer exists");if(c.revision!==t)throw new Ha;wr(c.current);const l={...c,revision:t+1,current:r,previous:[c.current,...c.previous].slice(0,3),updated:Date.now()};return o.put(l),await a,l}catch(o){try{s.abort()}catch{}throw await a.catch(()=>{}),o}}async rename(e,t,i){const r=this.db.transaction("worlds","readwrite"),s=yr(r);try{const a=r.objectStore("worlds"),o=await Mr(a.get(e));if(!o||o.revision!==t)throw new Ha;const c={...o,name:i.trim().slice(0,60)||o.name,revision:t+1,updated:Date.now()};return a.put(c),await s,c}catch(a){try{r.abort()}catch{}throw await s.catch(()=>{}),a}}async duplicate(e){const{record:t,snapshot:i,recovered:r}=await this.load(e);if(r)throw Error("Recover this world to a new copy before duplicating");return this.create(t.name+" copy",i,t.importSource)}async import(e){const t=bm(e);return this.create(t.name,t.snapshot,t.source)}export(e,t){return JSON.stringify({format:"blockworld2",version:1,name:e.name,...e.importSource?{legacySource:e.importSource}:{},checkpoint:t?mi(t):e.current},null,2)}}class wm{constructor(e){this.game=e,e.paused=!0,document.querySelector("#worlds").onclick=()=>void this.menu(),e.onEdit=()=>{this.ready&&this.save().catch(()=>{})},this.init()}store;current=null;blocked=!1;ready=!1;flight=null;last="";async init(){try{this.store=await Ir.open();const e=await this.store.list(),t=await this.store.last(),i=e.find(r=>r.id===t)||e[0]||await this.store.create("My neighbourhood",In(this.game.snapshot()));await this.open(i.id),this.ready=!0,setInterval(()=>{!this.game.paused&&!document.hidden&&this.save().catch(()=>{})},1500),addEventListener("blur",()=>{this.save().catch(()=>{})}),document.addEventListener("visibilitychange",()=>{document.hidden&&this.save().catch(()=>{})})}catch(e){this.ready=!1,this.game.paused=!1,this.failure(e)}}async open(e){this.flight&&await this.flight;const t=await this.store.load(e),i=t.snapshot;this.game.load(i.template,i.world.blocks,i.player,i.world.doors,i.world.activity),this.game.selected=i.preferences.selected,this.game.cameraMode=i.preferences.camera==="third"?"third":"first",this.game.flying=!!i.preferences.flying,document.querySelector("#flightControls").hidden=!this.game.flying,this.game.refreshModes(),this.current=t.record,this.last=mi(In(this.game.snapshot())).json,this.blocked=t.recovered,await this.store.select(e),this.game.paused=!1,t.recovered?this.failure(Error("An older checkpoint was recovered. The damaged original is retained. Save a new copy before continuing.")):this.game.notice("✓ World ready · saved on this device")}async save(){if(!this.current||!this.store)return;if(this.flight)return await this.flight,this.save();if(this.blocked)throw Error("Save blocked; export or save a new copy");let e,t;try{e=In(this.game.snapshot()),t=mi(e).json}catch(r){throw this.failure(r),r}if(t===this.last)return;const i=this.current;this.flight=(async()=>{try{this.current=await this.store.save(i.id,i.revision,e),this.last=t}catch(r){throw this.failure(r),r}})();try{await this.flight}finally{this.flight=null}}async newWorld(e){await this.save();const t=mn.find(s=>s.id===e),i=In({template:e,blocks:[],doors:{},player:t.spawn,selected:"hand"}),r=await this.store.create(t.name,i);return await this.open(r.id),this.close(),r}exportCurrent(){const e=this.current||{name:"Unsaved recovered world"},t=this.store?this.store.export(e,In(this.game.snapshot())):JSON.stringify({format:"blockworld2",version:1,name:e.name,checkpoint:mi(In(this.game.snapshot()))},null,2),i=URL.createObjectURL(new Blob([t],{type:"application/json"})),r=document.createElement("a");return r.href=i,r.download="BlockWorld2-backup.bw2",r.click(),setTimeout(()=>URL.revokeObjectURL(i),6e4),t}failure(e){this.blocked=!0;let t=document.querySelector("#saveAlert");t||(t=document.createElement("aside"),t.id="saveAlert",t.setAttribute("role","alert"),document.body.append(t)),t.replaceChildren();const i=document.createElement("p");i.textContent="Progress remains in memory. "+String(e),t.append(i);const r=(s,a)=>{const o=document.createElement("button");o.textContent=s,o.onclick=a,t.append(o)};r("Export unsaved work",()=>{try{this.exportCurrent()}catch(s){i.textContent=String(s)}}),r("Save as new copy",()=>{(async()=>{var s;try{this.store||(this.store=await Ir.open());const a=await this.store.create((((s=this.current)==null?void 0:s.name)||"Recovered world")+" recovered",In(this.game.snapshot()));this.current=a,await this.store.select(a.id),this.last=a.current.json,this.blocked=!1,this.ready=!0,t.remove(),this.game.notice("✓ Recovered copy saved")}catch(a){i.textContent=String(a)}})()})}close(){document.querySelector("#modal").hidden=!0,this.game.paused=!1,this.game.controls.clear()}async menu(){var e;try{await this.save(),this.game.paused=!0,this.game.controls.clear();const t=document.querySelector("#modal");t.hidden=!1,t.innerHTML='<section><h1>🌍 Your worlds</h1><div id="worldList"></div><h2>Create another</h2><div id="templates"></div><div class="backupActions"><button id="export">⇩ Backup</button><label class="fileButton">⇧ Import<input id="import" type="file" accept=".bw2,.json,application/json"></label><button id="resume">▶ Play</button></div><p id="worldError" role="alert"></p></section>';const i=r=>{r().catch(s=>{document.querySelector("#worldError").textContent=String(s)})};for(const r of await this.store.list()){const s=document.createElement("div");s.className="worldRow";const a=document.createElement("button");a.textContent=(r.id===((e=this.current)==null?void 0:e.id)?"▶ ":"")+r.name,a.dataset.world=r.id,a.onclick=()=>i(async()=>{await this.open(r.id),this.close()});const o=document.createElement("input");o.value=r.name,o.setAttribute("aria-label","World name");const c=document.createElement("button");c.textContent="✎",c.setAttribute("aria-label","Rename "+r.name),c.onclick=()=>i(async()=>{var h;const d=await this.store.rename(r.id,r.revision,o.value);((h=this.current)==null?void 0:h.id)===r.id&&(this.current=d),await this.menu()});const l=document.createElement("button");l.textContent="⧉",l.setAttribute("aria-label","Duplicate "+r.name),l.onclick=()=>i(async()=>{await this.store.duplicate(r.id),await this.menu()}),s.append(a,o,c,l),document.querySelector("#worldList").append(s)}for(const r of mn){const s=document.createElement("button");s.dataset.template=r.id,s.textContent=r.icon+" "+r.name,s.onclick=()=>i(()=>this.newWorld(r.id)),document.querySelector("#templates").append(s)}document.querySelector("#resume").onclick=()=>this.close(),document.querySelector("#export").onclick=()=>this.exportCurrent(),document.querySelector("#import").onchange=r=>i(async()=>{var o;const s=(o=r.target.files)==null?void 0:o[0];if(!s)return;if(s.size>12e6)throw Error("Backup exceeds 12 MB");const a=await this.store.import(await s.text());await this.open(a.id),this.close()})}catch(t){this.failure(t)}}}function Oc(n,e){const t=new wn,i=new O;if(e.obb){const s=e.obb,a=n.origin.x-s.cx,o=n.origin.z-s.cz,c=new zr(new O(a*s.c-o*s.s,n.origin.y,a*s.s+o*s.c),new O(n.direction.x*s.c-n.direction.z*s.s,n.direction.y,n.direction.x*s.s+n.direction.z*s.c));t.min.set(-s.halfW,e.minY,-s.halfD),t.max.set(s.halfW,e.maxY,s.halfD);const l=c.intersectBox(t,i);return l?c.origin.distanceTo(l):1/0}t.min.set(e.minX,e.minY,e.minZ),t.max.set(e.maxX,e.maxY,e.maxZ);const r=n.intersectBox(t,i);return r?n.origin.distanceTo(r):1/0}function Tm(n,e,t,i,r){const s=Math.max(1,Math.hypot(e.forward,e.right)),a=(-Math.sin(n.yaw)*e.forward+Math.cos(n.yaw)*e.right)*6/s,o=(-Math.cos(n.yaw)*e.forward-Math.sin(n.yaw)*e.right)*6/s,c=Math.max(1,Math.ceil(i/.01));for(let l=0;l<c;l++)for(const[d,h]of[["x",a],["z",o],["y",t*5]]){const u=n[d];n[d]=Math.max(d==="y"?0:-249,Math.min(d==="y"?24:249,u+h*i/c)),Bn(n,r)&&(n[d]=u)}n.vy=0,n.grounded=n.y===0}function zc(n=14987622){const e=new xt,t=new Mt(1,1,1),i=(a,o,c,l,d,h,u)=>{const m=new Ne(t,new Kt({color:u}));return m.position.set(a,o,c),m.scale.set(l,d,h),e.add(m),m};i(0,1.43,0,.4,.4,.38,15778974),i(0,1.66,.02,.43,.12,.4,7493190),i(0,.93,0,.48,.55,.3,n);const r=i(-.14,.35,0,.2,.65,.24,5602691),s=i(.14,.35,0,.2,.65,.24,5602691);return i(-.34,.92,0,.16,.5,.2,15778974),i(.34,.92,0,.16,.5,.2,15778974),{group:e,left:r,right:s}}function Am(n,e,t){const i=new O(e.x,e.y+1.3,e.z),r=new O(e.x+Math.sin(e.yaw)*4.5,e.y+3,e.z+Math.cos(e.yaw)*4.5),s=r.clone().sub(i).normalize(),a=new zr(i,s);let o=r.distanceTo(i);for(const c of t){const l={...c,minX:c.minX-.2,maxX:c.maxX+.2,minY:c.minY-.2,maxY:c.maxY+.2,minZ:c.minZ-.2,maxZ:c.maxZ+.2,...c.obb?{obb:{...c.obb,halfW:c.obb.halfW+.2,halfD:c.obb.halfD+.2}}:{}};o=Math.min(o,Oc(a,l)-.2)}return o=Math.max(.15,o),n.position.copy(i.addScaledVector(s,o)),n.lookAt(e.x,e.y+1.3,e.z),n.updateMatrixWorld(),o>.7}function no(n,e){for(let t=0;t<=12;t++)for(let i=-t;i<=t;i++)for(let r=-t;r<=t;r++){if(t&&Math.abs(i)!==t&&Math.abs(r)!==t)continue;const s={x:n.x+i,y:0,z:n.z+r,yaw:n.yaw||0,pitch:0,vy:0,grounded:!0};if(Math.abs(s.x)<249&&Math.abs(s.z)<249&&!Bn(s,e))return s}throw Error("No clear arrival space. Your current position is retained.")}function Va(n){const e=new xt,t=new Mt(1,1,1),i=(r,s,a,o,c,l,d)=>{const h=new Ne(t,new Kt({color:d}));h.position.set(r,s,a),h.scale.set(o,c,l),e.add(h)};i(0,.65,0,1.5,.65,3,n),i(0,1.2,0,1.25,.6,1.4,13165276),i(0,1.56,0,1.4,.12,1.6,n);for(const r of[-.78,.78])for(const s of[-.95,.95])i(r,.32,s,.22,.58,.58,4149581);return i(0,.65,-1.52,.9,.2,.06,16772278),e}function gn(n){const e=Math.cos(n.yaw),t=Math.sin(n.yaw),i=Math.abs(e)*.8+Math.abs(t)*1.6,r=Math.abs(t)*.8+Math.abs(e)*1.6;return{minX:n.x-i,maxX:n.x+i,minY:0,maxY:1.7,minZ:n.z-r,maxZ:n.z+r,obb:{cx:n.x,cz:n.z,c:e,s:t,halfW:.8,halfD:1.6}}}class Rm{group=new xt;car={x:-28,z:-2,yaw:0};vehicle=Va(15119462);driving=!1;time=0;agents=[];traffic=[];progress=[0,152];constructor(e){e.add(this.group),this.group.add(this.vehicle);for(let t=0;t<4;t++){const i=zc([14260858,9088931,14139254,9545917][t]);this.group.add(i.group),this.agents.push({model:i.group,phase:t*.25,animal:!1,left:i.left,right:i.right})}for(let t=0;t<2;t++){const i=new xt,r=new Mt(1,1,1),s=new Kt({color:t?16772535:13152666});for(const[a,o,c,l,d,h]of[[0,.3,0,.65,.4,.4],[0,.57,-.3,.35,.3,.3],[-.2,.1,0,.1,.3,.1],[.2,.1,0,.1,.3,.1],[0,.58,-.53,.2,.1,.2]]){const u=new Ne(r,s);u.position.set(a,o,c),u.scale.set(l,d,h),i.add(u)}this.group.add(i),this.agents.push({model:i,phase:t*.5,animal:!0})}for(let t=0;t<2;t++){const i=Va([12156781,8628132][t]);this.traffic.push(i),this.group.add(i)}this.sync()}sync(){this.vehicle.position.set(this.car.x,0,this.car.z),this.vehicle.rotation.y=this.car.yaw}load(e){if(e!=null&&e.car){const t=e.car;if(![t.x,t.z,t.yaw].every(Number.isFinite)||Math.abs(t.x)>249||Math.abs(t.z)>249)throw Error("Invalid saved car");this.car={...t}}this.driving=!1,this.sync()}snapshot(){return{car:{...this.car}}}use(e,t){if(this.driving){const r=no({x:this.car.x+Math.cos(this.car.yaw)*2,z:this.car.z-Math.sin(this.car.yaw)*2,yaw:this.car.yaw},[...t,gn(this.car)]);return Object.assign(e,r),this.driving=!1,"✓ Parked — ready to walk"}if(Math.abs(e.y)<2&&Math.hypot(e.x-this.car.x,e.z-this.car.z)<3)return this.driving=!0,e.y=0,this.sync(),"🚗 Drive with the stick · tap Use to leave";const i=this.agents.find(r=>Math.hypot(r.model.position.x-e.x,r.model.position.z-e.z)<2.5);return i?i.animal?"♡ Hello, little friend!":"👋 Hello, neighbour!":null}update(e,t,i,r){if(this.time+=e,this.driving){const s={...this.car,yaw:this.car.yaw-i.right*e*1.3*Math.sign(i.forward||1)},a=i.forward*6;s.x-=Math.sin(s.yaw)*a*e,s.z-=Math.cos(s.yaw)*a*e,Math.abs(s.x)<47&&Math.abs(s.z)<47&&!r.some(o=>vt(gn(s),o))&&(this.car=s),Object.assign(t,{x:this.car.x,y:0,z:this.car.z,yaw:this.car.yaw,vy:0,grounded:!0}),this.sync()}for(const s of this.agents){const a=s.phase*Math.PI*2+e*(s.animal?.13:.08),o=(s.animal?22:17)+Math.cos(a)*(s.animal?3:9),c=(s.animal?22:8)+Math.sin(a)*(s.animal,2),l={x:o,y:0,z:c};Math.hypot(o-t.x,c-t.z)>1&&!r.some(d=>vt(yi(l),d))&&(s.phase=a/(Math.PI*2),s.model.position.set(o,0,c),s.model.rotation.y=-a-Math.PI/2),s.left&&s.right&&(s.left.rotation.x=Math.sin(this.time*5+s.phase)*.25,s.right.rotation.x=-s.left.rotation.x)}for(let s=0;s<this.traffic.length;s++){const a=(this.progress[s]+e*2)%304,o=a<80?{x:-40+a,z:-36,yaw:-Math.PI/2}:a<152?{x:40,z:-36+a-80,yaw:Math.PI}:a<232?{x:40-(a-152),z:36,yaw:Math.PI/2}:{x:-40,z:36-(a-232),yaw:0},c=this.traffic[s];Math.hypot(o.x-t.x,o.z-t.z)>3&&!r.some(l=>vt(gn(o),l))&&(this.progress[s]=a,c.position.set(o.x,0,o.z),c.rotation.y=o.yaw)}}dispose(){const e=new Set,t=new Set;this.group.traverse(i=>{i.isMesh&&(e.add(i.geometry),t.add(i.material))}),e.forEach(i=>i.dispose()),t.forEach(i=>i.dispose()),this.group.removeFromParent()}}function Cm(n){const e=document.querySelector("#modal");n.paused=!0,n.controls.clear(),e.hidden=!1,e.innerHTML='<section><h1>🗺 Let’s explore</h1><canvas id="mapCanvas" width="560" height="420" aria-label="Drag map; choose a landmark to travel"></canvas><div id="mapPlaces"></div><div><button id="zoomIn" aria-label="Zoom in">＋</button><button id="zoomOut" aria-label="Zoom out">−</button><button id="closeMap">▶ Play</button></div><p id="mapMessage">Drag to look around. Choose a picture to travel.</p></section>';const t=document.querySelector("#mapCanvas"),i=t.getContext("2d");let r=n.template==="home-square"?4:.8,s=280,a=210,o=null;const c=()=>{if(i.fillStyle="#c4d39e",i.fillRect(0,0,560,420),i.save(),i.translate(s,a),i.scale(r,r),i.fillStyle="#859995",n.template==="home-square"){for(const h of[-36,4,36])i.fillRect(-43,h-3,86,6);for(const h of[-40,8,40])i.fillRect(h-3,-39,6,78)}for(const h of n.world.houses)i.fillStyle="#b88361",i.fillRect(h.x-h.w/2,h.z-h.d/2,h.w,h.d);i.fillStyle="#edb447",i.beginPath(),i.arc(n.player.x,n.player.z,2,0,Math.PI*2),i.fill(),i.restore()};c(),t.onpointerdown=h=>{t.setPointerCapture(h.pointerId),o={x:h.clientX,y:h.clientY}},t.onpointermove=h=>{if(!o)return;const u=t.getBoundingClientRect();s+=(h.clientX-o.x)*560/u.width,a+=(h.clientY-o.y)*420/u.height,o={x:h.clientX,y:h.clientY},c()},t.onpointerup=t.onpointercancel=()=>{o=null},document.querySelector("#zoomIn").onclick=()=>{r=Math.min(10,r*1.3),c()},document.querySelector("#zoomOut").onclick=()=>{r=Math.max(.3,r/1.3),c()};const l=()=>{e.hidden=!0,n.paused=!1,n.controls.clear()};document.querySelector("#closeMap").onclick=l;const d=n.world.landmarks||[{name:"Home",icon:"⌂",x:n.template==="blank"?0:-14.4,z:n.template==="blank"?8:-1.2}];for(const h of d){const u=document.createElement("button");u.textContent=h.icon+" "+h.name,u.dataset.place=h.name,u.onclick=()=>{try{const m=no(h,[...n.obstacles(),...n.commands.blocks.map(ct)]);Object.assign(n.player,m),n.flying=!1,n.activity&&(n.activity.driving=!1),n.vertical=0,n.refreshModes(),n.cancel(),n.onEdit(),l()}catch(m){document.querySelector("#mapMessage").textContent=String(m)}},document.querySelector("#mapPlaces").append(u)}}function Lm(n){const e=new Cc({canvas:n,antialias:!1,powerPreference:"low-power"});e.setPixelRatio(Math.min(devicePixelRatio,1.25)),e.outputColorSpace=lt;const t=new lm;t.background=new Ze("#badbdc"),t.fog=new $s("#badbdc",70,155),t.add(new um(16774620,6720624,2.2));const i=new pm(16770744,1.8);i.position.set(-30,50,20),t.add(i);const r=new Gt(67,1,.06,180);r.rotation.order="YXZ";function s(){e.setSize(innerWidth,innerHeight),r.aspect=innerWidth/innerHeight,r.updateProjectionMatrix()}return s(),addEventListener("resize",s),{renderer:e,scene:t,camera:r,dispose(){removeEventListener("resize",s),e.dispose()}}}class Pm{constructor(e=1/60,t=5){this.step=e,this.maxSteps=t}previous=0;accumulator=0;reset(e){this.previous=e,this.accumulator=0}tick(e,t){const i=Math.max(0,Math.min(.1,(e-this.previous)/1e3));this.previous=e,this.accumulator=Math.min(this.accumulator+i,this.step*this.maxSteps);let r=0;for(;this.accumulator+1e-9>=this.step&&r<this.maxSteps;)t(this.step),this.accumulator-=this.step,r++;return r}}function Dm(n,e){let t=null,i=null;const r=()=>{clearTimeout(i),i=null};function s(){var a;r(),t=null,(a=e.onIndicator)==null||a.call(e,null)}n.addEventListener("pointerdown",a=>{var o;if(t){s();return}e.canStart()&&(a.preventDefault(),n.setPointerCapture(a.pointerId),t={id:a.pointerId,x:a.clientX,y:a.clientY,lastX:a.clientX,lastY:a.clientY,drag:!1,held:!1},(o=e.onStart)==null||o.call(e,t),i=setTimeout(()=>{var c;!t||t.drag||(t.held=!0,(c=e.onIndicator)==null||c.call(e,null),e.onHold(t.x,t.y))},550))}),n.addEventListener("pointermove",a=>{var l;if(!t||a.pointerId!==t.id)return;const o=a.clientX-t.lastX,c=a.clientY-t.lastY;!t.drag&&Math.hypot(a.clientX-t.x,a.clientY-t.y)>10?(t.drag=!0,r(),(l=e.onIndicator)==null||l.call(e,null),e.onLook(a.clientX-t.x,a.clientY-t.y)):t.drag&&e.onLook(o,c),t.lastX=a.clientX,t.lastY=a.clientY}),n.addEventListener("pointerup",a=>{var c;if(!t||a.pointerId!==t.id)return;const o=t;s(),!o.drag&&!o.held&&e.onTap(o.x,o.y),(c=e.onEnd)==null||c.call(e)});for(const a of["pointercancel","lostpointercapture"])n.addEventListener(a,o=>{(t==null?void 0:t.id)===o.pointerId&&s()});return n.addEventListener("contextmenu",a=>a.preventDefault()),{cancel:s}}function Um(n=document){const e=new Map;let t=!1,i=0;n.addEventListener("pointerdown",r=>{var a,o;i=0;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button");(r.pointerType==="touch"||r.pointerType==="pen")&&s&&!s.disabled&&e.set(r.pointerId,{button:s,x:r.clientX,y:r.clientY,moved:!1})},!0),n.addEventListener("keydown",()=>{i=0},!0),n.addEventListener("pointermove",r=>{const s=e.get(r.pointerId);s&&Math.hypot(r.clientX-s.x,r.clientY-s.y)>10&&(s.moved=!0)},!0),n.addEventListener("pointercancel",r=>{e.has(r.pointerId)&&(i=performance.now()+900),e.delete(r.pointerId)},!0),n.addEventListener("pointerup",r=>{var a,o;const s=e.get(r.pointerId);if(e.delete(r.pointerId),(r.pointerType==="touch"||r.pointerType==="pen")&&((o=(a=r.target).closest)!=null&&o.call(a,"#world"))&&(i=performance.now()+900),!!s&&(i=performance.now()+900,!s.moved&&!s.button.disabled&&s.button.isConnected!==!1)){r.preventDefault(),t=!0;try{s.button.click()}finally{t=!1}}},!0),n.addEventListener("click",r=>{var a,o;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button,summary,.file-button");!t&&s&&performance.now()<i&&(r.preventDefault(),r.stopImmediatePropagation())},!0)}class Im{stick={x:0,y:0};keys=new Set;pointer=null;gestures;constructor(e,t,i){Um();let r=null;this.gestures=Dm(e,{canStart:t,onStart:()=>{r=i.pose?{...i.pose()}:null},onTap:i.tap,onHold:(o,c)=>{var d;const l=(d=i.pose)==null?void 0:d.call(i);r&&l&&(Math.hypot(l.x-r.x,l.y-r.y,l.z-r.z)>.08||Math.abs(l.yaw-r.yaw)+Math.abs(l.pitch-r.pitch)>.01)||i.hold(o,c)},onLook:i.look});const s=document.querySelector("#joystick"),a=o=>{const c=s.getBoundingClientRect(),l=o.clientX-c.left-c.width/2,d=o.clientY-c.top-c.height/2,h=Math.max(1,Math.hypot(l,d)/40);this.stick={x:l/h/40,y:d/h/40},document.querySelector("#knob").style.transform=`translate(${this.stick.x*36}px,${this.stick.y*36}px)`};s.addEventListener("pointerdown",o=>{!t()||this.pointer!==null||(o.preventDefault(),this.pointer=o.pointerId,s.setPointerCapture(o.pointerId),a(o))}),s.addEventListener("pointermove",o=>{this.pointer===o.pointerId&&a(o)});for(const o of["pointerup","pointercancel","lostpointercapture"])s.addEventListener(o,c=>{this.pointer===c.pointerId&&this.clear()});addEventListener("keydown",o=>{var c;(c=o.target)!=null&&c.matches("input,textarea,select")||!t()&&o.code!=="Escape"||(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(o.code)&&o.preventDefault(),this.keys.add(o.code),o.repeat||i.action(o.code))}),addEventListener("keyup",o=>this.keys.delete(o.code)),addEventListener("blur",()=>this.clear()),document.addEventListener("visibilitychange",()=>this.clear())}clear(){var t;this.keys.clear(),this.pointer=null,this.stick={x:0,y:0},(t=this.gestures)==null||t.cancel();const e=document.querySelector("#knob");e&&(e.style.transform="")}movement(){return{forward:+this.keys.has("KeyW")-+this.keys.has("KeyS")-this.stick.y,right:+this.keys.has("KeyD")-+this.keys.has("KeyA")+this.stick.x}}}class Nm{constructor(e,t,i){this.obstacles=e,this.player=t,this.changed=i}blocks=[];past=[];future=[];reason(e,t=!0){return tl(e,{blocks:this.blocks,inventory:{flowers:999,lantern:999,bench:999}},this.obstacles(),this.player(),t)}place(e,t=!0){const i=this.reason(e,t);if(i)return i;const r={...e};return this.blocks.push(r),this.record({kind:"place",block:r}),this.changed(r,!0),""}remove(e){const t=this.blocks.findIndex(r=>r.x===e.x&&r.y===e.y&&r.z===e.z);if(t<0)return!1;const[i]=this.blocks.splice(t,1);return this.record({kind:"remove",block:{...i}}),this.changed(i,!1),!0}record(e){this.past.push(e),this.past.length>100&&this.past.shift(),this.future=[]}apply(e,t){const i=e.kind==="place"!==t,r=e.block;if(i){if(vt(ct(r),yi(this.player()))||[...this.obstacles(),...this.blocks.map(ct)].some(s=>vt(ct(r),s)))return!1;this.blocks.push({...r})}else{const s=this.blocks.findIndex(a=>a.x===r.x&&a.y===r.y&&a.z===r.z);if(s<0)return!1;this.blocks.splice(s,1)}return!0}undo(){const e=this.past.at(-1);return!e||!this.apply(e,!0)?!1:(this.past.pop(),this.future.push(e),this.changed(e.block,e.kind==="remove"),!0)}redo(){const e=this.future.at(-1);return!e||!this.apply(e,!1)?!1:(this.future.pop(),this.past.push(e),this.changed(e.block,e.kind==="place"),!0)}reset(e){this.blocks.splice(0,this.blocks.length,...e.map(t=>({...t}))),this.past=[],this.future=[]}get canUndo(){return!!this.past.length}get canRedo(){return!!this.future.length}}const Mi=Math.PI/2,Fm=Mi/.65,Om=2.25,zm=3.1,Bm=1.2;function Bc(n){if(n.kind==="roller"){const e=Math.max(0,Math.min(1,n.angle/Mi));n.leaf.scale.y=Math.max(.001,1-e),n.leaf.position.y=e*n.height,n.pivot.rotation.y=n.baseAngle}else n.pivot.rotation.y=n.baseAngle+n.angle}function km(n,e=!1,t=-1){n.kind==="roller"&&(t=1),Object.assign(n,{open:e,targetOpen:e,swing:t,angle:e?t*Mi:0,leaveSince:null,manualHold:!1,lastAttempt:-1/0,blocked:!1}),Bc(n)}function Wa(n,e,t){return Math.abs(e.y)<2.3&&Math.hypot(e.x-n.center.x,e.z-n.center.z)<t}function Hs(n,e,t,i,r,s){const a=Math.max(1,Math.ceil(Math.abs(t-e)/.02)),o=[yi(i),...r.map(ct),...s];for(let c=0;c<=a;c++){const l=Nc(n,e+(t-e)*c/a);if(o.some(d=>vt(l,d)))return!1}return!0}function Vs(n,e,t,i,r=[],s=!1){const a=n.angle??(n.open?(n.swing??-1)*Mi:0);if(e){const o=(t.x-n.center.x)*Math.sin(n.baseAngle)+(t.z-n.center.z)*Math.cos(n.baseAngle),c=n.kind==="roller"?1:Math.abs(a)>.01?n.swing??-1:o>=0?1:-1;for(const l of Math.abs(a)>.01?[c]:[c,-c])if(Hs(n,a,l*Mi,t,i,r))return n.swing=l,n.targetOpen=n.open=!0,n.manualHold=s,n.blocked=!1,{ok:!0}}else if(Hs(n,a,0,t,i,r))return n.targetOpen=n.open=!1,n.manualHold=s,n.blocked=!1,{ok:!0};return{ok:!1,message:e?"There is something in the door’s swing. Make room beside it.":"The door stays open while someone or something is in its way."}}function Gm(n,e,t,i,r,s,a,o=null,c="normal"){const l=Om*Za(c)/3.4,d=Math.max(zm,l+.85);let h=!1;for(const u of n){let m;const M=()=>m??=(o==null?void 0:o(u))??{blocks:t,solids:i},g=Wa(u,e,d);g?u.leaveSince=null:(u.leaveSince??=s,u.manualHold=!1),r&&!u.manualHold&&s-u.lastAttempt>.3&&(Wa(u,e,l)&&!u.targetOpen?(u.lastAttempt=s,Vs(u,!0,e,M().blocks,M().solids)):!g&&u.targetOpen&&s-u.leaveSince>Bm&&(u.lastAttempt=s,Vs(u,!1,e,M().blocks,M().solids)));let f=(u.targetOpen?u.swing*Mi:0)-u.angle;const _=Math.sign(f)*Math.min(Math.abs(f),Math.max(0,a)*Fm),x=Math.max(1,Math.ceil(Math.abs(_)/.02));for(let v=0;v<x&&Math.abs(_)>1e-8;v++){const R=u.angle+_/x;if(!Hs(u,u.angle,R,e,M().blocks,M().solids)){u.blocked=!0,u.targetOpen||(u.targetOpen=u.open=!0,u.manualHold=!1,u.leaveSince=null);break}u.angle=R,u.blocked=!1,h=!0}Bc(u)}return h}const kc={flowers:[[.5,.16,.5,.6,.32,.6,11827792],[.5,.48,.5,.06,.64,.06,5671001],[.5,.78,.5,.46,.18,.46,14523267],[.5,.89,.5,.18,.06,.18,16110715]],lantern:[[.5,.06,.5,.55,.12,.55,6255726],[.5,.46,.5,.4,.7,.4,16174707],[.5,.87,.5,.6,.12,.6,6255726],...[.27,.73].flatMap(n=>[.27,.73].map(e=>[n,.46,e,.06,.75,.06,6255726]))],bench:[[.5,.47,.5,.94,.12,.64,11369552],[.5,.77,.77,.94,.4,.1,11369552],...[.12,.88].flatMap(n=>[.25,.72].map(e=>[n,.22,e,.1,.44,.1,6714986]))]};function Hm(n,e,t){const i=new xt;i.position.set(n.x+.5,n.y,n.z+.5),i.rotation.y=(n.rotation||0)*Math.PI/180;for(const[r,s,a,o,c,l,d]of kc[n.type]){const h=new Ne(e,t(d));h.position.set(r-.5,s,a-.5),h.scale.set(o,c,l),h.userData.block=n,i.add(h)}return i}const Sr=n=>`${Math.floor(n.x/et.chunkSize)},${Math.floor(n.z/et.chunkSize)}`;class Vm{constructor(e,t,i,r){Object.assign(this,{parent:e,geometry:t,materials:i,decorMat:r}),this.cells=new Map,this.groups=new Map,this.rebuilt=0}clear(){for(const e of this.groups.values())this.dispose(e);this.cells.clear(),this.groups.clear()}dispose(e){e.traverse(t=>{t.isInstancedMesh&&t.dispose(),t.userData.ownedGeometry&&t.geometry.dispose()}),e.removeFromParent()}reset(e){this.clear();for(const t of e)this.store(t);for(const t of this.cells.keys())this.rebuild(t)}store(e){const t=Sr(e);this.cells.has(t)||this.cells.set(t,new Map),this.cells.get(t).set(Ar(e),e)}update(e,t){var s;const i=Sr(e);t?this.store(e):(s=this.cells.get(i))==null||s.delete(Ar(e));const r=new Set([i]);et.chunkSize;for(const[a,o]of[[1,0],[-1,0],[0,1],[0,-1]]){const c=Sr({x:e.x+a,z:e.z+o});c!==i&&this.cells.has(c)&&r.add(c)}for(const a of r)this.rebuild(a)}opaque(e,t,i){var r,s;return Rs.includes((s=(r=this.cells.get(Sr({x:e,z:i})))==null?void 0:r.get(`${e},${t},${i}`))==null?void 0:s.type)}rebuild(e){var d;const t=this.groups.get(e);t&&this.dispose(t);const i=new xt,r=[...((d=this.cells.get(e))==null?void 0:d.values())||[]],s=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],a=this.geometry;for(const h of Rs){const u=[],m=[],M=[],g=[],p=[];for(const x of r.filter(v=>v.type===h))for(let v=0;v<6;v++){const[R,L,C]=s[v];if(this.opaque(x.x+R,x.y+L,x.z+C))continue;const z=u.length/3;for(let b=0;b<4;b++){const T=v*4+b;u.push(a.attributes.position.getX(T)+x.x+.5,a.attributes.position.getY(T)+x.y+.5,a.attributes.position.getZ(T)+x.z+.5),m.push(a.attributes.normal.getX(T),a.attributes.normal.getY(T),a.attributes.normal.getZ(T)),M.push(a.attributes.uv.getX(T),a.attributes.uv.getY(T))}for(let b=0;b<6;b++)g.push(z+a.index.array[v*6+b]-v*4);p.push(x,x)}if(!u.length)continue;const f=new it;f.setAttribute("position",new Xe(u,3)),f.setAttribute("normal",new Xe(m,3)),f.setAttribute("uv",new Xe(M,2)),f.setIndex(g),f.computeBoundingSphere(),f.computeBoundingBox();const _=new Ne(f,this.materials[h]);_.userData.faceBlocks=p,_.userData.ownedGeometry=!0,i.add(_)}const o=new Map,c=new ut,l=new ut;for(const h of r.filter(u=>zi.includes(u.type))){c.position.set(h.x+.5,h.y,h.z+.5),c.rotation.y=(h.rotation||0)*Math.PI/180,c.updateMatrix();for(const[u,m,M,g,p,f,_]of kc[h.type])l.position.set(u-.5,m,M-.5),l.scale.set(g,p,f),l.updateMatrix(),o.has(_)||o.set(_,[]),o.get(_).push({b:h,m:new Ke().multiplyMatrices(c.matrix,l.matrix)})}for(const[h,u]of o){const m=new ks(this.geometry,this.decorMat(h),u.length);u.forEach((M,g)=>m.setMatrixAt(g,M.m)),m.userData.blocks=u.map(M=>M.b),m.computeBoundingSphere(),i.add(m)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i),this.rebuilt++}rayMeshes(){const e=[];return this.parent.traverse(t=>{t.isMesh&&e.push(t)}),e}}const Wm=Gm;class Xm{activity=null;body=zc();cameraMode="first";flying=!1;vertical=0;view;world;worldGroup=new xt;buildGroup=new xt;preview=new xt;player={...mn[0].spawn,vy:0,grounded:!0};selected="hand";pending=null;automatic=!0;guard=!0;paused=!1;template="legacy-06";controls;commands;chunks;index=new Oi;clock=new Pm;ray=new mm;geometry=new Mt(1,1,1);materials={};decor=new Map;noticeTimer=0;onEdit=()=>{};constructor(){document.querySelector("#app").innerHTML='<canvas id="world" tabindex="-1" aria-label="Drag to look; tap to build; hold to remove"></canvas><div class="brand">BLOCKWORLD <b>2.0</b><small>Home & Square · Development prototype</small></div><nav id="top"><button id="home" aria-label="Return home">⌂</button><button id="doorMode" aria-label="Automatic doors" aria-pressed="true">🚪 Auto</button><button id="guard" aria-label="Edge protection" aria-pressed="true">🛡</button><button id="cameraMode" aria-label="Switch camera">👤</button><button id="flyMode" aria-label="Creative flight" aria-pressed="false">🪽</button><button id="mapButton" aria-label="World map">🗺</button><button id="catalogueButton" aria-label="Building catalogue">▦</button><button id="worlds" aria-label="Worlds">🌍</button></nav><output id="status">Starting…</output><div id="crosshair">+</div><div id="joystick" aria-label="Move joystick"><div id="knob"></div></div><div id="actions"><button id="use" aria-label="Use nearby object">🚪</button><button id="undo" aria-label="Undo">↶</button><button id="redo" aria-label="Redo">↷</button><button id="jump" aria-label="Jump">↑</button></div><div id="palette" aria-label="Building hotbar"></div><div id="flightControls" hidden><button id="flyUp" aria-label="Fly up">⇧</button><button id="flyDown" aria-label="Fly down">⇩</button></div><div id="previewControls" hidden><button id="cancel" aria-label="Cancel placement">✕</button><button id="rotate" aria-label="Rotate preview">↻</button><button id="confirm" aria-label="Confirm placement">✓</button></div><div id="modal" hidden></div>',this.view=Lm(document.querySelector("#world")),this.view.scene.add(this.worldGroup,this.buildGroup,this.preview,this.body.group);for(const e of Ii)this.materials[e.id]=new Kt({color:e.color});this.chunks=new Vm(this.buildGroup,this.geometry,this.materials,e=>(this.decor.has(e)||this.decor.set(e,new Kt({color:e})),this.decor.get(e))),this.commands=new Nm(()=>this.obstacles(),()=>this.player,(e,t)=>{this.chunks.update(e,t),this.refreshHistory(),this.onEdit()}),this.load("home-square"),this.controls=new Im(document.querySelector("#world"),()=>!this.paused,{tap:(e,t)=>this.tap(e,t),hold:(e,t)=>this.removeAt(e,t),look:(e,t)=>{this.player.yaw-=e*.004,this.player.pitch=Math.max(-1.3,Math.min(1.3,this.player.pitch-t*.0035))},action:e=>this.key(e),pose:()=>this.player}),this.ui(),this.clock.reset(performance.now()),requestAnimationFrame(e=>this.frame(e)),this.notice("Ready · choose a picture to build")}load(e,t=[],i,r={},s){var l,d;const a=new xt,o=Em(a,e,t),c=new Oi;for(const h of o.solids)c.add(h);if(t.some(h=>c.query(ct(h)).some(u=>vt(ct(h),u.ramp?{...u,ramp:null}:u))))throw this.clearGroup(a),Error("Saved objects overlap permanent structures; active progress is unchanged");if(e==="home-square"&&(s!=null&&s.car)&&[...o.solids,...t.map(ct)].some(h=>vt(gn(s.car),h)))throw this.clearGroup(a),Error("Saved vehicle overlaps structures; active world is retained");(l=this.activity)==null||l.dispose(),this.activity=null,this.flying=!1,this.vertical=0,this.clearGroup(this.worldGroup);for(const h of[...a.children])this.worldGroup.add(h);this.chunks.clear(),this.template=e,this.world=o,this.index=c,e==="home-square"&&(this.activity=new Rm(this.view.scene),this.activity.load(s));for(const h of this.world.doors)km(h,r[h.id]===!0,-1);this.player={...((d=mn.find(h=>h.id===e))==null?void 0:d.spawn)||mn[0].spawn,...i,vy:0,grounded:!0},this.commands.reset(t),this.chunks.reset(t),this.cancel(),Bn(this.player,this.nearbySolids())&&this.home(),this.refreshHistory(),this.updateCamera()}clearGroup(e){const t=new Set,i=new Set,r=new Set;e.traverse(s=>{if(s.isMesh){t.add(s.geometry);for(const a of Array.isArray(s.material)?s.material:[s.material])i.add(a),a.map&&r.add(a.map);s.isInstancedMesh&&s.dispose()}}),t.forEach(s=>s.dispose()),i.forEach(s=>s.dispose()),r.forEach(s=>s.dispose()),e.clear()}obstacles(){return[...this.world.solids,...this.world.doors.map(e=>Ui(e)),...this.activity?[gn(this.activity.car)]:[]]}nearbySolids(){return[...this.activity&&!this.activity.driving?[gn(this.activity.car)]:[],...this.index.query(Ki(this.player,3)),...this.commands.blocks.filter(e=>Math.abs(e.x-this.player.x)<4&&Math.abs(e.z-this.player.z)<4).map(ct),...this.world.doors.filter(e=>Math.hypot(e.center.x-this.player.x,e.center.z-this.player.z)<6).map(e=>Ui(e))]}update(e){var s,a;Wm(this.world.doors,this.player,this.commands.blocks,this.world.solids,this.automatic,performance.now()/1e3,e,o=>({solids:[...this.index.query(Ki({...o.center,y:0},4)),...this.activity?[gn(this.activity.car)]:[]],blocks:this.commands.blocks.filter(c=>Math.hypot(c.x-o.center.x,c.z-o.center.z)<5)}));const t=this.controls.movement(),i=this.nearbySolids(),r=[...this.world.solids,...this.world.doors.map(o=>Ui(o)),...this.commands.blocks.map(ct)];(s=this.activity)!=null&&s.driving||(this.flying?Tm(this.player,t,this.vertical+ +this.controls.keys.has("Space")-+(this.controls.keys.has("ShiftLeft")||this.controls.keys.has("ShiftRight")),e,i):el(this.player,{...t,edgeProtection:this.guard,walkSpeed:"normal"},e,i)),(a=this.activity)==null||a.update(e,this.player,t,r)}frame(e){requestAnimationFrame(t=>this.frame(t)),this.paused||document.hidden?this.clock.reset(e):this.clock.tick(e,t=>this.update(t)),this.updateCamera(),this.world.staticRender.updateVisibility(this.view.camera,155),this.view.renderer.render(this.view.scene,this.view.camera)}updateCamera(){var e;this.body.group.position.set(this.player.x,this.player.y,this.player.z),this.body.group.rotation.y=this.player.yaw,this.body.group.visible=!1,this.cameraMode==="third"?this.body.group.visible=Am(this.view.camera,this.player,[...this.index.query(Ki(this.player,8)),...this.world.doors.map(t=>Ui(t)),...this.commands.blocks.filter(t=>Math.abs(t.x-this.player.x)<8&&Math.abs(t.z-this.player.z)<8).map(ct)])&&!((e=this.activity)!=null&&e.driving):(this.view.camera.position.set(this.player.x,this.player.y+1.53,this.player.z),this.view.camera.rotation.set(this.player.pitch,this.player.yaw,0),this.view.camera.updateMatrixWorld())}hit(e=innerWidth/2,t=innerHeight/2){var o,c;this.updateCamera(),this.view.scene.updateMatrixWorld(!0),this.ray.setFromCamera(new qe(e/innerWidth*2-1,1-t/innerHeight*2),this.view.camera);const i=this.ray.intersectObjects([...this.chunks.rayMeshes(),this.world.ground],!1)[0];if(!i||i.distance>8)return null;for(const l of[...this.index.query(Ki(this.player,9)),...this.world.doors.map(d=>Ui(d))])if(Oc(this.ray.ray,l)<i.distance-.02)return null;const r=i.object.userData,s=((o=r.faceBlocks)==null?void 0:o[i.faceIndex])||((c=r.blocks)==null?void 0:c[i.instanceId])||r.block;let a;if(s){const l=i.face.normal.clone().transformDirection(i.object.matrixWorld);if(i.object.isInstancedMesh){const h=new Ke;i.object.getMatrixAt(i.instanceId,h),l.copy(i.face.normal).transformDirection(h).transformDirection(i.object.matrixWorld)}const d=i.point.clone().addScaledVector(l,.015);if(a={x:Math.floor(d.x),y:Math.floor(d.y),z:Math.floor(d.z),type:this.selected},["flowers","lantern","bench"].includes(s.type)){const h=["x","y","z"].sort((u,m)=>Math.abs(l[m])-Math.abs(l[u]))[0];a={...s,type:this.selected},a[h]+=Math.sign(l[h])}}else a={x:Math.floor(i.point.x),y:0,z:Math.floor(i.point.z),type:this.selected};return{target:s,aim:a}}tap(e,t){var s;if(this.paused)return;if((s=this.activity)!=null&&s.driving){this.notice("Park before building");return}if(this.selected==="hand"){this.use();return}const i=this.hit(e,t);if(!i){this.notice("Move closer to a clear space");return}const r=this.commands.reason(i.aim);if(r){this.notice(r);return}["flowers","lantern","bench"].includes(this.selected)?(this.pending={...i.aim,rotation:0},this.showPreview()):this.notice(this.commands.place(i.aim)||"✓ Placed")}removeAt(e,t){if(this.paused)return;const i=this.hit(e,t);i!=null&&i.target&&(this.cancel(),this.commands.remove(i.target),this.notice("↶ Removed — Undo brings it back"))}showPreview(){this.preview.traverse(e=>{e.isMesh&&e.material.dispose()}),this.preview.clear(),this.pending&&(this.preview.add(Hm(this.pending,this.geometry,e=>new Kt({color:e,transparent:!0,opacity:.6}))),document.querySelector("#previewControls").hidden=!1,document.querySelector("#confirm").disabled=!!this.commands.reason(this.pending))}cancel(){this.pending=null,this.preview.traverse(t=>{t.isMesh&&t.material.dispose()}),this.preview.clear();const e=document.querySelector("#previewControls");e&&(e.hidden=!0)}confirm(){if(!this.pending)return;const e=this.commands.place(this.pending);e?this.notice(e):(this.cancel(),this.notice("✓ Placed"))}use(){if(this.activity)try{const i=this.activity.use(this.player,[...this.obstacles(),...this.commands.blocks.map(ct)]);if(i){this.flying=!1,this.vertical=0,this.refreshModes(),this.controls.clear(),this.notice(i),this.onEdit();return}}catch(i){this.notice(String(i));return}const e=this.world.doors.filter(i=>Math.abs(this.player.y)<2.3&&Math.hypot(i.center.x-this.player.x,i.center.z-this.player.z)<3.2).sort((i,r)=>Math.hypot(i.center.x-this.player.x,i.center.z-this.player.z)-Math.hypot(r.center.x-this.player.x,r.center.z-this.player.z))[0];if(!e){this.notice("Walk closer to a door");return}const t=Vs(e,!e.targetOpen,this.player,this.commands.blocks,[...this.world.solids,...this.activity?[gn(this.activity.car)]:[]],!0);this.notice(t.ok?"🚪 Door":t.message||"Clear the doorway"),this.onEdit()}home(){var e,t;Object.assign(this.player,no(((e=mn.find(i=>i.id===this.template))==null?void 0:e.spawn)||mn[0].spawn,[...this.obstacles(),...this.commands.blocks.map(ct)])),this.flying=!1,this.activity&&(this.activity.driving=!1),this.vertical=0,this.refreshModes(),(t=this.controls)==null||t.clear(),this.cancel()}jump(){var e;!this.paused&&!this.flying&&!((e=this.activity)!=null&&e.driving)&&this.player.grounded&&(this.player.vy=6,this.player.grounded=!1)}key(e){e==="Space"&&this.jump(),e==="KeyE"&&this.use(),e==="KeyF"&&this.tap(innerWidth/2,innerHeight/2),e==="KeyR"&&(this.pending?(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview()):this.removeAt(innerWidth/2,innerHeight/2)),e==="Enter"&&this.confirm(),e==="KeyZ"&&this.commands.undo(),e==="KeyY"&&this.commands.redo(),e==="Escape"&&this.cancel()}ui(){const e=(t,i)=>document.querySelector("#"+t).onclick=i;e("cameraMode",()=>{this.cameraMode=this.cameraMode==="first"?"third":"first",this.refreshModes(),this.onEdit()}),e("flyMode",()=>{var t;if((t=this.activity)!=null&&t.driving){this.notice("Leave the car before flying");return}this.flying=!this.flying,this.player.vy=0,document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),this.onEdit()}),e("mapButton",()=>Cm(this)),e("catalogueButton",()=>this.catalogue());for(const[t,i]of[["flyUp",1],["flyDown",-1]]){const r=document.querySelector("#"+t);r.onpointerdown=s=>{s.preventDefault(),r.setPointerCapture(s.pointerId),this.vertical=i};for(const s of["pointerup","pointercancel","lostpointercapture"])r.addEventListener(s,()=>this.vertical=0)}addEventListener("blur",()=>this.vertical=0),e("home",()=>this.home()),e("jump",()=>this.jump()),e("use",()=>this.use()),e("undo",()=>this.commands.undo()),e("redo",()=>this.commands.redo()),e("cancel",()=>this.cancel()),e("rotate",()=>{this.pending&&(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview())}),e("confirm",()=>this.confirm()),e("doorMode",()=>{this.automatic=!this.automatic,document.querySelector("#doorMode").setAttribute("aria-pressed",String(this.automatic))}),e("guard",()=>{this.guard=!this.guard,document.querySelector("#guard").setAttribute("aria-pressed",String(this.guard))}),document.querySelector("#palette").innerHTML=Ii.map(t=>`<button data-item="${t.id}" aria-label="Choose ${t.label}" title="${t.label}"><span>${t.icon}</span><small>${t.label}</small></button>`).join(""),document.querySelector("#palette").addEventListener("click",t=>{const i=t.target.closest("[data-item]");i&&(this.selected=this.selected===i.dataset.item?"hand":i.dataset.item,this.cancel(),document.querySelectorAll("[data-item]").forEach(r=>r.setAttribute("aria-pressed",String(r.dataset.item===this.selected))))})}catalogue(){this.paused=!0,this.controls.clear();const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section><h1>▦ Build anything</h1><div id="categories"></div><div id="catalogueGrid"></div><button id="closeCatalogue">▶ Play</button></section>';const t=()=>{e.hidden=!0,this.paused=!1},i=r=>{const s=document.querySelector("#catalogueGrid");s.replaceChildren();for(const a of Ii.filter(o=>r==="All"||o.category===r)){const o=document.createElement("button");o.dataset.catalogue=a.id,o.textContent=a.icon+" "+a.label,o.onclick=()=>{this.selected=a.id,this.cancel(),t()},s.append(o)}};for(const r of["All",...new Set(Ii.map(s=>s.category))]){const s=document.createElement("button");s.textContent=r,s.onclick=()=>i(r),document.querySelector("#categories").append(s)}document.querySelector("#closeCatalogue").onclick=t,i("All")}refreshModes(){var e;document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),document.querySelector("#cameraMode").setAttribute("aria-pressed",String(this.cameraMode==="third")),document.querySelector("#use").textContent=(e=this.activity)!=null&&e.driving?"🚶":"✋"}refreshHistory(){const e=document.querySelector("#undo"),t=document.querySelector("#redo");e&&(e.disabled=!this.commands.canUndo),t&&(t.disabled=!this.commands.canRedo)}notice(e){const t=document.querySelector("#status");t.textContent=e,clearTimeout(this.noticeTimer),this.noticeTimer=window.setTimeout(()=>t.textContent="",5e3)}snapshot(){var e;return{camera:this.cameraMode,flying:this.flying,activity:(e=this.activity)==null?void 0:e.snapshot(),template:this.template,player:{...this.player},blocks:this.commands.blocks.map(t=>({...t})),doors:Object.fromEntries(this.world.doors.map(t=>[t.id,t.targetOpen])),selected:this.selected}}}try{const n=new Xm,e=new wm(n);new URLSearchParams(location.search).get("test")==="1"&&Object.assign(window,{bw2:{session:e,game:n,snapshot:()=>n.snapshot(),setPlayer:t=>Object.assign(n.player,t),simulate:(t,i)=>{const r=n.controls.movement;n.controls.movement=()=>t;for(let s=0;s<i;s+=1/60)n.update(1/60);n.controls.movement=r},add:t=>n.commands.place(t,!1)}}),"serviceWorker"in navigator&&navigator.serviceWorker.register("./sw.js",{scope:"./"}).catch(()=>n.notice("Offline preparation unavailable; export a backup before closing."))}catch(n){const e=document.createElement("p");e.textContent=`Could not start: ${String(n)}`,document.querySelector("#app").append(e),console.error(n)}
