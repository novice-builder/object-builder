from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import argparse, os
p=argparse.ArgumentParser();p.add_argument('--lan',action='store_true');a=p.parse_args()
os.chdir(Path(__file__).resolve().parent)
address='0.0.0.0' if a.lan else '127.0.0.1'
print('Open http://localhost:8000/adventures.html (Ctrl+C to stop)',flush=True)
ThreadingHTTPServer((address,8000),SimpleHTTPRequestHandler).serve_forever()
