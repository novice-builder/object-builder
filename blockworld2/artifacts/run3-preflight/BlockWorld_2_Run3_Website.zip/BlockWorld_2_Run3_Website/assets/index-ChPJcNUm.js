(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const $a="160",Rh=0,So=1,Ch=2,xc=1,Ph=2,xn=3,wn=0,Ot=1,bt=2,In=0,ki=1,Eo=2,To=3,Ao=4,Lh=5,Jn=100,zh=101,Dh=102,Ro=103,Co=104,Ih=200,Uh=201,Nh=202,Fh=203,Pa=204,La=205,kh=206,Oh=207,Bh=208,Gh=209,Hh=210,Vh=211,Wh=212,Xh=213,qh=214,Yh=0,jh=1,Zh=2,cs=3,Kh=4,$h=5,Jh=6,Qh=7,Ja=0,ed=1,td=2,Un=0,nd=1,id=2,rd=3,sd=4,ad=5,od=6,_c=300,Hi=301,Vi=302,za=303,Da=304,Es=306,Ia=1e3,rn=1001,Ua=1002,Lt=1003,Po=1004,Ws=1005,Kt=1006,ld=1007,xr=1008,Nn=1009,cd=1010,hd=1011,Qa=1012,yc=1013,Ln=1014,zn=1015,_r=1016,vc=1017,Mc=1018,ni=1020,dd=1021,sn=1023,ud=1024,fd=1025,ii=1026,Wi=1027,pd=1028,bc=1029,md=1030,wc=1031,Sc=1033,Xs=33776,qs=33777,Ys=33778,js=33779,Lo=35840,zo=35841,Do=35842,Io=35843,Ec=36196,Uo=37492,No=37496,Fo=37808,ko=37809,Oo=37810,Bo=37811,Go=37812,Ho=37813,Vo=37814,Wo=37815,Xo=37816,qo=37817,Yo=37818,jo=37819,Zo=37820,Ko=37821,Zs=36492,$o=36494,Jo=36495,gd=36283,Qo=36284,el=36285,tl=36286,Tc=3e3,ri=3001,xd=3200,_d=3201,Ac=0,yd=1,Jt="",vt="srgb",Sn="srgb-linear",eo="display-p3",Ts="display-p3-linear",hs="linear",dt="srgb",ds="rec709",us="p3",di=7680,nl=519,vd=512,Md=513,bd=514,Rc=515,wd=516,Sd=517,Ed=518,Td=519,Na=35044,il="300 es",Fa=1035,yn=2e3,fs=2001;class Ki{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const r=this._listeners[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const Ct=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let rl=1234567;const fr=Math.PI/180,yr=180/Math.PI;function Mn(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(Ct[n&255]+Ct[n>>8&255]+Ct[n>>16&255]+Ct[n>>24&255]+"-"+Ct[e&255]+Ct[e>>8&255]+"-"+Ct[e>>16&15|64]+Ct[e>>24&255]+"-"+Ct[t&63|128]+Ct[t>>8&255]+"-"+Ct[t>>16&255]+Ct[t>>24&255]+Ct[i&255]+Ct[i>>8&255]+Ct[i>>16&255]+Ct[i>>24&255]).toLowerCase()}function Ft(n,e,t){return Math.max(e,Math.min(t,n))}function to(n,e){return(n%e+e)%e}function Ad(n,e,t,i,r){return i+(n-e)*(r-i)/(t-e)}function Rd(n,e,t){return n!==e?(t-n)/(e-n):0}function pr(n,e,t){return(1-t)*n+t*e}function Cd(n,e,t,i){return pr(n,e,1-Math.exp(-t*i))}function Pd(n,e=1){return e-Math.abs(to(n,e*2)-e)}function Ld(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*(3-2*n))}function zd(n,e,t){return n<=e?0:n>=t?1:(n=(n-e)/(t-e),n*n*n*(n*(n*6-15)+10))}function Dd(n,e){return n+Math.floor(Math.random()*(e-n+1))}function Id(n,e){return n+Math.random()*(e-n)}function Ud(n){return n*(.5-Math.random())}function Nd(n){n!==void 0&&(rl=n);let e=rl+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Fd(n){return n*fr}function kd(n){return n*yr}function ka(n){return(n&n-1)===0&&n!==0}function Od(n){return Math.pow(2,Math.ceil(Math.log(n)/Math.LN2))}function ps(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function Bd(n,e,t,i,r){const s=Math.cos,a=Math.sin,o=s(t/2),c=a(t/2),l=s((e+i)/2),d=a((e+i)/2),u=s((e-i)/2),h=a((e-i)/2),f=s((i-e)/2),y=a((i-e)/2);switch(r){case"XYX":n.set(o*d,c*u,c*h,o*l);break;case"YZY":n.set(c*h,o*d,c*u,o*l);break;case"ZXZ":n.set(c*u,c*h,o*d,o*l);break;case"XZX":n.set(o*d,c*y,c*f,o*l);break;case"YXY":n.set(c*f,o*d,c*y,o*l);break;case"ZYZ":n.set(c*y,c*f,o*d,o*l);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)}}function cn(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function it(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}const Ks={DEG2RAD:fr,RAD2DEG:yr,generateUUID:Mn,clamp:Ft,euclideanModulo:to,mapLinear:Ad,inverseLerp:Rd,lerp:pr,damp:Cd,pingpong:Pd,smoothstep:Ld,smootherstep:zd,randInt:Dd,randFloat:Id,randFloatSpread:Ud,seededRandom:Nd,degToRad:Fd,radToDeg:kd,isPowerOfTwo:ka,ceilPowerOfTwo:Od,floorPowerOfTwo:ps,setQuaternionFromProperEuler:Bd,normalize:it,denormalize:cn};class Oe{constructor(e=0,t=0){Oe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ft(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*r+e.x,this.y=s*r+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class We{constructor(e,t,i,r,s,a,o,c,l){We.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,c,l)}set(e,t,i,r,s,a,o,c,l){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=c,d[6]=i,d[7]=a,d[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],d=i[4],u=i[7],h=i[2],f=i[5],y=i[8],x=r[0],m=r[3],p=r[6],_=r[1],g=r[4],v=r[7],A=r[2],E=r[5],C=r[8];return s[0]=a*x+o*_+c*A,s[3]=a*m+o*g+c*E,s[6]=a*p+o*v+c*C,s[1]=l*x+d*_+u*A,s[4]=l*m+d*g+u*E,s[7]=l*p+d*v+u*C,s[2]=h*x+f*_+y*A,s[5]=h*m+f*g+y*E,s[8]=h*p+f*v+y*C,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8];return t*a*d-t*o*l-i*s*d+i*o*c+r*s*l-r*a*c}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8],u=d*a-o*l,h=o*c-d*s,f=l*s-a*c,y=t*u+i*h+r*f;if(y===0)return this.set(0,0,0,0,0,0,0,0,0);const x=1/y;return e[0]=u*x,e[1]=(r*l-d*i)*x,e[2]=(o*i-r*a)*x,e[3]=h*x,e[4]=(d*t-r*c)*x,e[5]=(r*s-o*t)*x,e[6]=f*x,e[7]=(i*c-l*t)*x,e[8]=(a*t-i*s)*x,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,a,o){const c=Math.cos(s),l=Math.sin(s);return this.set(i*c,i*l,-i*(c*a+l*o)+a+e,-r*l,r*c,-r*(-l*a+c*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply($s.makeScale(e,t)),this}rotate(e){return this.premultiply($s.makeRotation(-e)),this}translate(e,t){return this.premultiply($s.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const $s=new We;function Cc(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function ms(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function Gd(){const n=ms("canvas");return n.style.display="block",n}const sl={};function mr(n){n in sl||(sl[n]=!0,console.warn(n))}const al=new We().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),ol=new We().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Rr={[Sn]:{transfer:hs,primaries:ds,toReference:n=>n,fromReference:n=>n},[vt]:{transfer:dt,primaries:ds,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[Ts]:{transfer:hs,primaries:us,toReference:n=>n.applyMatrix3(ol),fromReference:n=>n.applyMatrix3(al)},[eo]:{transfer:dt,primaries:us,toReference:n=>n.convertSRGBToLinear().applyMatrix3(ol),fromReference:n=>n.applyMatrix3(al).convertLinearToSRGB()}},Hd=new Set([Sn,Ts]),rt={enabled:!0,_workingColorSpace:Sn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!Hd.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,e,t){if(this.enabled===!1||e===t||!e||!t)return n;const i=Rr[e].toReference,r=Rr[t].fromReference;return r(i(n))},fromWorkingColorSpace:function(n,e){return this.convert(n,this._workingColorSpace,e)},toWorkingColorSpace:function(n,e){return this.convert(n,e,this._workingColorSpace)},getPrimaries:function(n){return Rr[n].primaries},getTransfer:function(n){return n===Jt?hs:Rr[n].transfer}};function Oi(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Js(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let ui;class Pc{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{ui===void 0&&(ui=ms("canvas")),ui.width=e.width,ui.height=e.height;const i=ui.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=ui}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=ms("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=Oi(s[a]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Oi(t[i]/255)*255):t[i]=Oi(t[i]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Vd=0;class Lc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Vd++}),this.uuid=Mn(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(Qs(r[a].image)):s.push(Qs(r[a]))}else s=Qs(r);i.url=s}return t||(e.images[this.uuid]=i),i}}function Qs(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?Pc.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Wd=0;class Bt extends Ki{constructor(e=Bt.DEFAULT_IMAGE,t=Bt.DEFAULT_MAPPING,i=rn,r=rn,s=Kt,a=xr,o=sn,c=Nn,l=Bt.DEFAULT_ANISOTROPY,d=Jt){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Wd++}),this.uuid=Mn(),this.name="",this.source=new Lc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new Oe(0,0),this.repeat=new Oe(1,1),this.center=new Oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new We,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof d=="string"?this.colorSpace=d:(mr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=d===ri?vt:Jt),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==_c)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Ia:e.x=e.x-Math.floor(e.x);break;case rn:e.x=e.x<0?0:1;break;case Ua:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Ia:e.y=e.y-Math.floor(e.y);break;case rn:e.y=e.y<0?0:1;break;case Ua:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return mr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===vt?ri:Tc}set encoding(e){mr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===ri?vt:Jt}}Bt.DEFAULT_IMAGE=null;Bt.DEFAULT_MAPPING=_c;Bt.DEFAULT_ANISOTROPY=1;class ft{constructor(e=0,t=0,i=0,r=1){ft.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*r+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s;const c=e.elements,l=c[0],d=c[4],u=c[8],h=c[1],f=c[5],y=c[9],x=c[2],m=c[6],p=c[10];if(Math.abs(d-h)<.01&&Math.abs(u-x)<.01&&Math.abs(y-m)<.01){if(Math.abs(d+h)<.1&&Math.abs(u+x)<.1&&Math.abs(y+m)<.1&&Math.abs(l+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const g=(l+1)/2,v=(f+1)/2,A=(p+1)/2,E=(d+h)/4,C=(u+x)/4,z=(y+m)/4;return g>v&&g>A?g<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(g),r=E/i,s=C/i):v>A?v<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(v),i=E/r,s=z/r):A<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(A),i=C/s,r=z/s),this.set(i,r,s,t),this}let _=Math.sqrt((m-y)*(m-y)+(u-x)*(u-x)+(h-d)*(h-d));return Math.abs(_)<.001&&(_=1),this.x=(m-y)/_,this.y=(u-x)/_,this.z=(h-d)/_,this.w=Math.acos((l+f+p-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Xd extends Ki{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new ft(0,0,e,t),this.scissorTest=!1,this.viewport=new ft(0,0,e,t);const r={width:e,height:t,depth:1};i.encoding!==void 0&&(mr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===ri?vt:Jt),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Kt,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Bt(r,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){(this.width!==e||this.height!==t||this.depth!==i)&&(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new Lc(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ai extends Xd{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class zc extends Bt{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Lt,this.minFilter=Lt,this.wrapR=rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class qd extends Bt{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Lt,this.minFilter=Lt,this.wrapR=rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class wr{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,a,o){let c=i[r+0],l=i[r+1],d=i[r+2],u=i[r+3];const h=s[a+0],f=s[a+1],y=s[a+2],x=s[a+3];if(o===0){e[t+0]=c,e[t+1]=l,e[t+2]=d,e[t+3]=u;return}if(o===1){e[t+0]=h,e[t+1]=f,e[t+2]=y,e[t+3]=x;return}if(u!==x||c!==h||l!==f||d!==y){let m=1-o;const p=c*h+l*f+d*y+u*x,_=p>=0?1:-1,g=1-p*p;if(g>Number.EPSILON){const A=Math.sqrt(g),E=Math.atan2(A,p*_);m=Math.sin(m*E)/A,o=Math.sin(o*E)/A}const v=o*_;if(c=c*m+h*v,l=l*m+f*v,d=d*m+y*v,u=u*m+x*v,m===1-o){const A=1/Math.sqrt(c*c+l*l+d*d+u*u);c*=A,l*=A,d*=A,u*=A}}e[t]=c,e[t+1]=l,e[t+2]=d,e[t+3]=u}static multiplyQuaternionsFlat(e,t,i,r,s,a){const o=i[r],c=i[r+1],l=i[r+2],d=i[r+3],u=s[a],h=s[a+1],f=s[a+2],y=s[a+3];return e[t]=o*y+d*u+c*f-l*h,e[t+1]=c*y+d*h+l*u-o*f,e[t+2]=l*y+d*f+o*h-c*u,e[t+3]=d*y-o*u-c*h-l*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,c=Math.sin,l=o(i/2),d=o(r/2),u=o(s/2),h=c(i/2),f=c(r/2),y=c(s/2);switch(a){case"XYZ":this._x=h*d*u+l*f*y,this._y=l*f*u-h*d*y,this._z=l*d*y+h*f*u,this._w=l*d*u-h*f*y;break;case"YXZ":this._x=h*d*u+l*f*y,this._y=l*f*u-h*d*y,this._z=l*d*y-h*f*u,this._w=l*d*u+h*f*y;break;case"ZXY":this._x=h*d*u-l*f*y,this._y=l*f*u+h*d*y,this._z=l*d*y+h*f*u,this._w=l*d*u-h*f*y;break;case"ZYX":this._x=h*d*u-l*f*y,this._y=l*f*u+h*d*y,this._z=l*d*y-h*f*u,this._w=l*d*u+h*f*y;break;case"YZX":this._x=h*d*u+l*f*y,this._y=l*f*u+h*d*y,this._z=l*d*y-h*f*u,this._w=l*d*u-h*f*y;break;case"XZY":this._x=h*d*u-l*f*y,this._y=l*f*u-h*d*y,this._z=l*d*y+h*f*u,this._w=l*d*u+h*f*y;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],r=t[4],s=t[8],a=t[1],o=t[5],c=t[9],l=t[2],d=t[6],u=t[10],h=i+o+u;if(h>0){const f=.5/Math.sqrt(h+1);this._w=.25/f,this._x=(d-c)*f,this._y=(s-l)*f,this._z=(a-r)*f}else if(i>o&&i>u){const f=2*Math.sqrt(1+i-o-u);this._w=(d-c)/f,this._x=.25*f,this._y=(r+a)/f,this._z=(s+l)/f}else if(o>u){const f=2*Math.sqrt(1+o-i-u);this._w=(s-l)/f,this._x=(r+a)/f,this._y=.25*f,this._z=(c+d)/f}else{const f=2*Math.sqrt(1+u-i-o);this._w=(a-r)/f,this._x=(s+l)/f,this._y=(c+d)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Ft(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,r=e._y,s=e._z,a=e._w,o=t._x,c=t._y,l=t._z,d=t._w;return this._x=i*d+a*o+r*l-s*c,this._y=r*d+a*c+s*o-i*l,this._z=s*d+a*l+i*c-r*o,this._w=a*d-i*o-r*c-s*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const i=this._x,r=this._y,s=this._z,a=this._w;let o=a*e._w+i*e._x+r*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=r,this._z=s,this;const c=1-o*o;if(c<=Number.EPSILON){const f=1-t;return this._w=f*a+t*this._w,this._x=f*i+t*this._x,this._y=f*r+t*this._y,this._z=f*s+t*this._z,this.normalize(),this}const l=Math.sqrt(c),d=Math.atan2(l,o),u=Math.sin((1-t)*d)/l,h=Math.sin(t*d)/l;return this._w=a*u+this._w*h,this._x=i*u+this._x*h,this._y=r*u+this._y*h,this._z=s*u+this._z*h,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),r=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(r),i*Math.sin(s),i*Math.cos(s),t*Math.sin(r))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class N{constructor(e=0,t=0,i=0){N.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(ll.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(ll.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,r=this.z,s=e.x,a=e.y,o=e.z,c=e.w,l=2*(a*r-o*i),d=2*(o*t-s*r),u=2*(s*i-a*t);return this.x=t+c*l+a*u-o*d,this.y=i+c*d+o*l-s*u,this.z=r+c*u+s*d-a*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,r=e.y,s=e.z,a=t.x,o=t.y,c=t.z;return this.x=r*c-s*o,this.y=s*a-i*c,this.z=i*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return ea.copy(this).projectOnVector(e),this.sub(ea)}reflect(e){return this.sub(ea.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(Ft(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const ea=new N,ll=new wr;class hn{constructor(e=new N(1/0,1/0,1/0),t=new N(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(en.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(en.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=en.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,en):en.fromBufferAttribute(s,a),en.applyMatrix4(e.matrixWorld),this.expandByPoint(en);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Cr.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Cr.copy(i.boundingBox)),Cr.applyMatrix4(e.matrixWorld),this.union(Cr)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,en),en.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(tr),Pr.subVectors(this.max,tr),fi.subVectors(e.a,tr),pi.subVectors(e.b,tr),mi.subVectors(e.c,tr),En.subVectors(pi,fi),Tn.subVectors(mi,pi),Hn.subVectors(fi,mi);let t=[0,-En.z,En.y,0,-Tn.z,Tn.y,0,-Hn.z,Hn.y,En.z,0,-En.x,Tn.z,0,-Tn.x,Hn.z,0,-Hn.x,-En.y,En.x,0,-Tn.y,Tn.x,0,-Hn.y,Hn.x,0];return!ta(t,fi,pi,mi,Pr)||(t=[1,0,0,0,1,0,0,0,1],!ta(t,fi,pi,mi,Pr))?!1:(Lr.crossVectors(En,Tn),t=[Lr.x,Lr.y,Lr.z],ta(t,fi,pi,mi,Pr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,en).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(en).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(un[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),un[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),un[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),un[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),un[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),un[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),un[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),un[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(un),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const un=[new N,new N,new N,new N,new N,new N,new N,new N],en=new N,Cr=new hn,fi=new N,pi=new N,mi=new N,En=new N,Tn=new N,Hn=new N,tr=new N,Pr=new N,Lr=new N,Vn=new N;function ta(n,e,t,i,r){for(let s=0,a=n.length-3;s<=a;s+=3){Vn.fromArray(n,s);const o=r.x*Math.abs(Vn.x)+r.y*Math.abs(Vn.y)+r.z*Math.abs(Vn.z),c=e.dot(Vn),l=t.dot(Vn),d=i.dot(Vn);if(Math.max(-Math.max(c,l,d),Math.min(c,l,d))>o)return!1}return!0}const Yd=new hn,nr=new N,na=new N;class Sr{constructor(e=new N,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):Yd.setFromPoints(e).getCenter(i);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;nr.subVectors(e,this.center);const t=nr.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(nr,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(na.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(nr.copy(e.center).add(na)),this.expandByPoint(nr.copy(e.center).sub(na))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const fn=new N,ia=new N,zr=new N,An=new N,ra=new N,Dr=new N,sa=new N;class Er{constructor(e=new N,t=new N(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,fn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=fn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(fn.copy(this.origin).addScaledVector(this.direction,t),fn.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){ia.copy(e).add(t).multiplyScalar(.5),zr.copy(t).sub(e).normalize(),An.copy(this.origin).sub(ia);const s=e.distanceTo(t)*.5,a=-this.direction.dot(zr),o=An.dot(this.direction),c=-An.dot(zr),l=An.lengthSq(),d=Math.abs(1-a*a);let u,h,f,y;if(d>0)if(u=a*c-o,h=a*o-c,y=s*d,u>=0)if(h>=-y)if(h<=y){const x=1/d;u*=x,h*=x,f=u*(u+a*h+2*o)+h*(a*u+h+2*c)+l}else h=s,u=Math.max(0,-(a*h+o)),f=-u*u+h*(h+2*c)+l;else h=-s,u=Math.max(0,-(a*h+o)),f=-u*u+h*(h+2*c)+l;else h<=-y?(u=Math.max(0,-(-a*s+o)),h=u>0?-s:Math.min(Math.max(-s,-c),s),f=-u*u+h*(h+2*c)+l):h<=y?(u=0,h=Math.min(Math.max(-s,-c),s),f=h*(h+2*c)+l):(u=Math.max(0,-(a*s+o)),h=u>0?s:Math.min(Math.max(-s,-c),s),f=-u*u+h*(h+2*c)+l);else h=a>0?-s:s,u=Math.max(0,-(a*h+o)),f=-u*u+h*(h+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(ia).addScaledVector(zr,h),f}intersectSphere(e,t){fn.subVectors(e.center,this.origin);const i=fn.dot(this.direction),r=fn.dot(fn)-i*i,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,a,o,c;const l=1/this.direction.x,d=1/this.direction.y,u=1/this.direction.z,h=this.origin;return l>=0?(i=(e.min.x-h.x)*l,r=(e.max.x-h.x)*l):(i=(e.max.x-h.x)*l,r=(e.min.x-h.x)*l),d>=0?(s=(e.min.y-h.y)*d,a=(e.max.y-h.y)*d):(s=(e.max.y-h.y)*d,a=(e.min.y-h.y)*d),i>a||s>r||((s>i||isNaN(i))&&(i=s),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-h.z)*u,c=(e.max.z-h.z)*u):(o=(e.max.z-h.z)*u,c=(e.min.z-h.z)*u),i>c||o>r)||((o>i||i!==i)&&(i=o),(c<r||r!==r)&&(r=c),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,fn)!==null}intersectTriangle(e,t,i,r,s){ra.subVectors(t,e),Dr.subVectors(i,e),sa.crossVectors(ra,Dr);let a=this.direction.dot(sa),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;An.subVectors(this.origin,e);const c=o*this.direction.dot(Dr.crossVectors(An,Dr));if(c<0)return null;const l=o*this.direction.dot(ra.cross(An));if(l<0||c+l>a)return null;const d=-o*An.dot(sa);return d<0?null:this.at(d/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class et{constructor(e,t,i,r,s,a,o,c,l,d,u,h,f,y,x,m){et.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,c,l,d,u,h,f,y,x,m)}set(e,t,i,r,s,a,o,c,l,d,u,h,f,y,x,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=i,p[12]=r,p[1]=s,p[5]=a,p[9]=o,p[13]=c,p[2]=l,p[6]=d,p[10]=u,p[14]=h,p[3]=f,p[7]=y,p[11]=x,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new et().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,r=1/gi.setFromMatrixColumn(e,0).length(),s=1/gi.setFromMatrixColumn(e,1).length(),a=1/gi.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,r=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(r),l=Math.sin(r),d=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const h=a*d,f=a*u,y=o*d,x=o*u;t[0]=c*d,t[4]=-c*u,t[8]=l,t[1]=f+y*l,t[5]=h-x*l,t[9]=-o*c,t[2]=x-h*l,t[6]=y+f*l,t[10]=a*c}else if(e.order==="YXZ"){const h=c*d,f=c*u,y=l*d,x=l*u;t[0]=h+x*o,t[4]=y*o-f,t[8]=a*l,t[1]=a*u,t[5]=a*d,t[9]=-o,t[2]=f*o-y,t[6]=x+h*o,t[10]=a*c}else if(e.order==="ZXY"){const h=c*d,f=c*u,y=l*d,x=l*u;t[0]=h-x*o,t[4]=-a*u,t[8]=y+f*o,t[1]=f+y*o,t[5]=a*d,t[9]=x-h*o,t[2]=-a*l,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){const h=a*d,f=a*u,y=o*d,x=o*u;t[0]=c*d,t[4]=y*l-f,t[8]=h*l+x,t[1]=c*u,t[5]=x*l+h,t[9]=f*l-y,t[2]=-l,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){const h=a*c,f=a*l,y=o*c,x=o*l;t[0]=c*d,t[4]=x-h*u,t[8]=y*u+f,t[1]=u,t[5]=a*d,t[9]=-o*d,t[2]=-l*d,t[6]=f*u+y,t[10]=h-x*u}else if(e.order==="XZY"){const h=a*c,f=a*l,y=o*c,x=o*l;t[0]=c*d,t[4]=-u,t[8]=l*d,t[1]=h*u+x,t[5]=a*d,t[9]=f*u-y,t[2]=y*u-f,t[6]=o*d,t[10]=x*u+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(jd,e,Zd)}lookAt(e,t,i){const r=this.elements;return Ht.subVectors(e,t),Ht.lengthSq()===0&&(Ht.z=1),Ht.normalize(),Rn.crossVectors(i,Ht),Rn.lengthSq()===0&&(Math.abs(i.z)===1?Ht.x+=1e-4:Ht.z+=1e-4,Ht.normalize(),Rn.crossVectors(i,Ht)),Rn.normalize(),Ir.crossVectors(Ht,Rn),r[0]=Rn.x,r[4]=Ir.x,r[8]=Ht.x,r[1]=Rn.y,r[5]=Ir.y,r[9]=Ht.y,r[2]=Rn.z,r[6]=Ir.z,r[10]=Ht.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],d=i[1],u=i[5],h=i[9],f=i[13],y=i[2],x=i[6],m=i[10],p=i[14],_=i[3],g=i[7],v=i[11],A=i[15],E=r[0],C=r[4],z=r[8],M=r[12],b=r[1],F=r[5],I=r[9],H=r[13],L=r[2],U=r[6],O=r[10],X=r[14],Z=r[3],te=r[7],ie=r[11],de=r[15];return s[0]=a*E+o*b+c*L+l*Z,s[4]=a*C+o*F+c*U+l*te,s[8]=a*z+o*I+c*O+l*ie,s[12]=a*M+o*H+c*X+l*de,s[1]=d*E+u*b+h*L+f*Z,s[5]=d*C+u*F+h*U+f*te,s[9]=d*z+u*I+h*O+f*ie,s[13]=d*M+u*H+h*X+f*de,s[2]=y*E+x*b+m*L+p*Z,s[6]=y*C+x*F+m*U+p*te,s[10]=y*z+x*I+m*O+p*ie,s[14]=y*M+x*H+m*X+p*de,s[3]=_*E+g*b+v*L+A*Z,s[7]=_*C+g*F+v*U+A*te,s[11]=_*z+g*I+v*O+A*ie,s[15]=_*M+g*H+v*X+A*de,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],a=e[1],o=e[5],c=e[9],l=e[13],d=e[2],u=e[6],h=e[10],f=e[14],y=e[3],x=e[7],m=e[11],p=e[15];return y*(+s*c*u-r*l*u-s*o*h+i*l*h+r*o*f-i*c*f)+x*(+t*c*f-t*l*h+s*a*h-r*a*f+r*l*d-s*c*d)+m*(+t*l*u-t*o*f-s*a*u+i*a*f+s*o*d-i*l*d)+p*(-r*o*d-t*c*u+t*o*h+r*a*u-i*a*h+i*c*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8],u=e[9],h=e[10],f=e[11],y=e[12],x=e[13],m=e[14],p=e[15],_=u*m*l-x*h*l+x*c*f-o*m*f-u*c*p+o*h*p,g=y*h*l-d*m*l-y*c*f+a*m*f+d*c*p-a*h*p,v=d*x*l-y*u*l+y*o*f-a*x*f-d*o*p+a*u*p,A=y*u*c-d*x*c-y*o*h+a*x*h+d*o*m-a*u*m,E=t*_+i*g+r*v+s*A;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const C=1/E;return e[0]=_*C,e[1]=(x*h*s-u*m*s-x*r*f+i*m*f+u*r*p-i*h*p)*C,e[2]=(o*m*s-x*c*s+x*r*l-i*m*l-o*r*p+i*c*p)*C,e[3]=(u*c*s-o*h*s-u*r*l+i*h*l+o*r*f-i*c*f)*C,e[4]=g*C,e[5]=(d*m*s-y*h*s+y*r*f-t*m*f-d*r*p+t*h*p)*C,e[6]=(y*c*s-a*m*s-y*r*l+t*m*l+a*r*p-t*c*p)*C,e[7]=(a*h*s-d*c*s+d*r*l-t*h*l-a*r*f+t*c*f)*C,e[8]=v*C,e[9]=(y*u*s-d*x*s-y*i*f+t*x*f+d*i*p-t*u*p)*C,e[10]=(a*x*s-y*o*s+y*i*l-t*x*l-a*i*p+t*o*p)*C,e[11]=(d*o*s-a*u*s-d*i*l+t*u*l+a*i*f-t*o*f)*C,e[12]=A*C,e[13]=(d*x*r-y*u*r+y*i*h-t*x*h-d*i*m+t*u*m)*C,e[14]=(y*o*r-a*x*r-y*i*c+t*x*c+a*i*m-t*o*m)*C,e[15]=(a*u*r-d*o*r+d*i*c-t*u*c-a*i*h+t*o*h)*C,this}scale(e){const t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),r=Math.sin(t),s=1-i,a=e.x,o=e.y,c=e.z,l=s*a,d=s*o;return this.set(l*a+i,l*o-r*c,l*c+r*o,0,l*o+r*c,d*o+i,d*c-r*a,0,l*c-r*o,d*c+r*a,s*c*c+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,a){return this.set(1,i,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){const r=this.elements,s=t._x,a=t._y,o=t._z,c=t._w,l=s+s,d=a+a,u=o+o,h=s*l,f=s*d,y=s*u,x=a*d,m=a*u,p=o*u,_=c*l,g=c*d,v=c*u,A=i.x,E=i.y,C=i.z;return r[0]=(1-(x+p))*A,r[1]=(f+v)*A,r[2]=(y-g)*A,r[3]=0,r[4]=(f-v)*E,r[5]=(1-(h+p))*E,r[6]=(m+_)*E,r[7]=0,r[8]=(y+g)*C,r[9]=(m-_)*C,r[10]=(1-(h+x))*C,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){const r=this.elements;let s=gi.set(r[0],r[1],r[2]).length();const a=gi.set(r[4],r[5],r[6]).length(),o=gi.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],tn.copy(this);const l=1/s,d=1/a,u=1/o;return tn.elements[0]*=l,tn.elements[1]*=l,tn.elements[2]*=l,tn.elements[4]*=d,tn.elements[5]*=d,tn.elements[6]*=d,tn.elements[8]*=u,tn.elements[9]*=u,tn.elements[10]*=u,t.setFromRotationMatrix(tn),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,r,s,a,o=yn){const c=this.elements,l=2*s/(t-e),d=2*s/(i-r),u=(t+e)/(t-e),h=(i+r)/(i-r);let f,y;if(o===yn)f=-(a+s)/(a-s),y=-2*a*s/(a-s);else if(o===fs)f=-a/(a-s),y=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=u,c[12]=0,c[1]=0,c[5]=d,c[9]=h,c[13]=0,c[2]=0,c[6]=0,c[10]=f,c[14]=y,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,i,r,s,a,o=yn){const c=this.elements,l=1/(t-e),d=1/(i-r),u=1/(a-s),h=(t+e)*l,f=(i+r)*d;let y,x;if(o===yn)y=(a+s)*u,x=-2*u;else if(o===fs)y=s*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-h,c[1]=0,c[5]=2*d,c[9]=0,c[13]=-f,c[2]=0,c[6]=0,c[10]=x,c[14]=-y,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const gi=new N,tn=new et,jd=new N(0,0,0),Zd=new N(1,1,1),Rn=new N,Ir=new N,Ht=new N,cl=new et,hl=new wr;class As{constructor(e=0,t=0,i=0,r=As.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],c=r[1],l=r[5],d=r[9],u=r[2],h=r[6],f=r[10];switch(t){case"XYZ":this._y=Math.asin(Ft(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,f),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(h,l),this._z=0);break;case"YXZ":this._x=Math.asin(-Ft(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(Ft(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-Ft(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(h,f),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(Ft(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-d,l),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,f));break;case"XZY":this._z=Math.asin(-Ft(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,l),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return cl.makeRotationFromQuaternion(e),this.setFromRotationMatrix(cl,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return hl.setFromEuler(this),this.setFromQuaternion(hl,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}As.DEFAULT_ORDER="XYZ";class no{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Kd=0;const dl=new N,xi=new wr,pn=new et,Ur=new N,ir=new N,$d=new N,Jd=new wr,ul=new N(1,0,0),fl=new N(0,1,0),pl=new N(0,0,1),Qd={type:"added"},eu={type:"removed"};class mt extends Ki{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Kd++}),this.uuid=Mn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=mt.DEFAULT_UP.clone();const e=new N,t=new As,i=new wr,r=new N(1,1,1);function s(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new et},normalMatrix:{value:new We}}),this.matrix=new et,this.matrixWorld=new et,this.matrixAutoUpdate=mt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new no,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return xi.setFromAxisAngle(e,t),this.quaternion.multiply(xi),this}rotateOnWorldAxis(e,t){return xi.setFromAxisAngle(e,t),this.quaternion.premultiply(xi),this}rotateX(e){return this.rotateOnAxis(ul,e)}rotateY(e){return this.rotateOnAxis(fl,e)}rotateZ(e){return this.rotateOnAxis(pl,e)}translateOnAxis(e,t){return dl.copy(e).applyQuaternion(this.quaternion),this.position.add(dl.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(ul,e)}translateY(e){return this.translateOnAxis(fl,e)}translateZ(e){return this.translateOnAxis(pl,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(pn.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Ur.copy(e):Ur.set(e,t,i);const r=this.parent;this.updateWorldMatrix(!0,!1),ir.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?pn.lookAt(ir,Ur,this.up):pn.lookAt(Ur,ir,this.up),this.quaternion.setFromRotationMatrix(pn),r&&(pn.extractRotation(r.matrixWorld),xi.setFromRotationMatrix(pn),this.quaternion.premultiply(xi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(Qd)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(eu)),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),pn.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),pn.multiply(e.parent.matrixWorld)),e.applyMatrix4(pn),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ir,e,$d),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ir,Jd,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,r=t.length;i<r;i++){const s=t[i];(s.matrixWorldAutoUpdate===!0||e===!0)&&s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){const r=this.children;for(let s=0,a=r.length;s<a;s++){const o=r[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.visibility=this._visibility,r.active=this._active,r.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),r.maxGeometryCount=this._maxGeometryCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.geometryCount=this._geometryCount,r.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(r.boundingSphere={center:r.boundingSphere.center.toArray(),radius:r.boundingSphere.radius}),this.boundingBox!==null&&(r.boundingBox={min:r.boundingBox.min.toArray(),max:r.boundingBox.max.toArray()}));function s(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const c=o.shapes;if(Array.isArray(c))for(let l=0,d=c.length;l<d;l++){const u=c[l];s(e.shapes,u)}else s(e.shapes,c)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(s(e.materials,this.material[c]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const c=this.animations[o];r.animations.push(s(e.animations,c))}}if(t){const o=a(e.geometries),c=a(e.materials),l=a(e.textures),d=a(e.images),u=a(e.shapes),h=a(e.skeletons),f=a(e.animations),y=a(e.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),d.length>0&&(i.images=d),u.length>0&&(i.shapes=u),h.length>0&&(i.skeletons=h),f.length>0&&(i.animations=f),y.length>0&&(i.nodes=y)}return i.object=r,i;function a(o){const c=[];for(const l in o){const d=o[l];delete d.metadata,c.push(d)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}}mt.DEFAULT_UP=new N(0,1,0);mt.DEFAULT_MATRIX_AUTO_UPDATE=!0;mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const nn=new N,mn=new N,aa=new N,gn=new N,_i=new N,yi=new N,ml=new N,oa=new N,la=new N,ca=new N;let Nr=!1;class $t{constructor(e=new N,t=new N,i=new N){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),nn.subVectors(e,t),r.cross(nn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){nn.subVectors(r,t),mn.subVectors(i,t),aa.subVectors(e,t);const a=nn.dot(nn),o=nn.dot(mn),c=nn.dot(aa),l=mn.dot(mn),d=mn.dot(aa),u=a*l-o*o;if(u===0)return s.set(0,0,0),null;const h=1/u,f=(l*c-o*d)*h,y=(a*d-o*c)*h;return s.set(1-f-y,y,f)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,gn)===null?!1:gn.x>=0&&gn.y>=0&&gn.x+gn.y<=1}static getUV(e,t,i,r,s,a,o,c){return Nr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Nr=!0),this.getInterpolation(e,t,i,r,s,a,o,c)}static getInterpolation(e,t,i,r,s,a,o,c){return this.getBarycoord(e,t,i,r,gn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,gn.x),c.addScaledVector(a,gn.y),c.addScaledVector(o,gn.z),c)}static isFrontFacing(e,t,i,r){return nn.subVectors(i,t),mn.subVectors(e,t),nn.cross(mn).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return nn.subVectors(this.c,this.b),mn.subVectors(this.a,this.b),nn.cross(mn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return $t.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return $t.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,r,s){return Nr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Nr=!0),$t.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}getInterpolation(e,t,i,r,s){return $t.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return $t.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return $t.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,r=this.b,s=this.c;let a,o;_i.subVectors(r,i),yi.subVectors(s,i),oa.subVectors(e,i);const c=_i.dot(oa),l=yi.dot(oa);if(c<=0&&l<=0)return t.copy(i);la.subVectors(e,r);const d=_i.dot(la),u=yi.dot(la);if(d>=0&&u<=d)return t.copy(r);const h=c*u-d*l;if(h<=0&&c>=0&&d<=0)return a=c/(c-d),t.copy(i).addScaledVector(_i,a);ca.subVectors(e,s);const f=_i.dot(ca),y=yi.dot(ca);if(y>=0&&f<=y)return t.copy(s);const x=f*l-c*y;if(x<=0&&l>=0&&y<=0)return o=l/(l-y),t.copy(i).addScaledVector(yi,o);const m=d*y-f*u;if(m<=0&&u-d>=0&&f-y>=0)return ml.subVectors(s,r),o=(u-d)/(u-d+(f-y)),t.copy(r).addScaledVector(ml,o);const p=1/(m+x+h);return a=x*p,o=h*p,t.copy(i).addScaledVector(_i,a).addScaledVector(yi,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Dc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Cn={h:0,s:0,l:0},Fr={h:0,s:0,l:0};function ha(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class Ke{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=vt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,rt.toWorkingColorSpace(this,t),this}setRGB(e,t,i,r=rt.workingColorSpace){return this.r=e,this.g=t,this.b=i,rt.toWorkingColorSpace(this,r),this}setHSL(e,t,i,r=rt.workingColorSpace){if(e=to(e,1),t=Ft(t,0,1),i=Ft(i,0,1),t===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=ha(a,s,e+1/3),this.g=ha(a,s,e),this.b=ha(a,s,e-1/3)}return rt.toWorkingColorSpace(this,r),this}setStyle(e,t=vt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=vt){const i=Dc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Oi(e.r),this.g=Oi(e.g),this.b=Oi(e.b),this}copyLinearToSRGB(e){return this.r=Js(e.r),this.g=Js(e.g),this.b=Js(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=vt){return rt.fromWorkingColorSpace(Pt.copy(this),e),Math.round(Ft(Pt.r*255,0,255))*65536+Math.round(Ft(Pt.g*255,0,255))*256+Math.round(Ft(Pt.b*255,0,255))}getHexString(e=vt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=rt.workingColorSpace){rt.fromWorkingColorSpace(Pt.copy(this),t);const i=Pt.r,r=Pt.g,s=Pt.b,a=Math.max(i,r,s),o=Math.min(i,r,s);let c,l;const d=(o+a)/2;if(o===a)c=0,l=0;else{const u=a-o;switch(l=d<=.5?u/(a+o):u/(2-a-o),a){case i:c=(r-s)/u+(r<s?6:0);break;case r:c=(s-i)/u+2;break;case s:c=(i-r)/u+4;break}c/=6}return e.h=c,e.s=l,e.l=d,e}getRGB(e,t=rt.workingColorSpace){return rt.fromWorkingColorSpace(Pt.copy(this),t),e.r=Pt.r,e.g=Pt.g,e.b=Pt.b,e}getStyle(e=vt){rt.fromWorkingColorSpace(Pt.copy(this),e);const t=Pt.r,i=Pt.g,r=Pt.b;return e!==vt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL(Cn),this.setHSL(Cn.h+e,Cn.s+t,Cn.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(Cn),e.getHSL(Fr);const i=pr(Cn.h,Fr.h,t),r=pr(Cn.s,Fr.s,t),s=pr(Cn.l,Fr.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Pt=new Ke;Ke.NAMES=Dc;let tu=0;class $i extends Ki{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:tu++}),this.uuid=Mn(),this.name="",this.type="Material",this.blending=ki,this.side=wn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Pa,this.blendDst=La,this.blendEquation=Jn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ke(0,0,0),this.blendAlpha=0,this.depthFunc=cs,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=nl,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=di,this.stencilZFail=di,this.stencilZPass=di,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==ki&&(i.blending=this.blending),this.side!==wn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==Pa&&(i.blendSrc=this.blendSrc),this.blendDst!==La&&(i.blendDst=this.blendDst),this.blendEquation!==Jn&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==cs&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==nl&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==di&&(i.stencilFail=this.stencilFail),this.stencilZFail!==di&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==di&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){const a=[];for(const o in s){const c=s[o];delete c.metadata,a.push(c)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Bi extends $i{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ke(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Ja,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Mt=new N,kr=new Oe;class Qt{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Na,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=zn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)kr.fromBufferAttribute(this,t),kr.applyMatrix3(e),this.setXY(t,kr.x,kr.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)Mt.fromBufferAttribute(this,t),Mt.applyMatrix3(e),this.setXYZ(t,Mt.x,Mt.y,Mt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)Mt.fromBufferAttribute(this,t),Mt.applyMatrix4(e),this.setXYZ(t,Mt.x,Mt.y,Mt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Mt.fromBufferAttribute(this,t),Mt.applyNormalMatrix(e),this.setXYZ(t,Mt.x,Mt.y,Mt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Mt.fromBufferAttribute(this,t),Mt.transformDirection(e),this.setXYZ(t,Mt.x,Mt.y,Mt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=cn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=it(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=cn(t,this.array)),t}setX(e,t){return this.normalized&&(t=it(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=cn(t,this.array)),t}setY(e,t){return this.normalized&&(t=it(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=cn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=it(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=cn(t,this.array)),t}setW(e,t){return this.normalized&&(t=it(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=it(t,this.array),i=it(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=it(t,this.array),i=it(i,this.array),r=it(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=it(t,this.array),i=it(i,this.array),r=it(r,this.array),s=it(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Na&&(e.usage=this.usage),e}}class Ic extends Qt{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class Uc extends Qt{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class De extends Qt{constructor(e,t,i){super(new Float32Array(e),t,i)}}let nu=0;const Yt=new et,da=new mt,vi=new N,Vt=new hn,rr=new hn,At=new N;class tt extends Ki{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:nu++}),this.uuid=Mn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Cc(e)?Uc:Ic)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new We().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Yt.makeRotationFromQuaternion(e),this.applyMatrix4(Yt),this}rotateX(e){return Yt.makeRotationX(e),this.applyMatrix4(Yt),this}rotateY(e){return Yt.makeRotationY(e),this.applyMatrix4(Yt),this}rotateZ(e){return Yt.makeRotationZ(e),this.applyMatrix4(Yt),this}translate(e,t,i){return Yt.makeTranslation(e,t,i),this.applyMatrix4(Yt),this}scale(e,t,i){return Yt.makeScale(e,t,i),this.applyMatrix4(Yt),this}lookAt(e){return da.lookAt(e),da.updateMatrix(),this.applyMatrix4(da.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(vi).negate(),this.translate(vi.x,vi.y,vi.z),this}setFromPoints(e){const t=[];for(let i=0,r=e.length;i<r;i++){const s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new De(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new hn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new N(-1/0,-1/0,-1/0),new N(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){const s=t[i];Vt.setFromBufferAttribute(s),this.morphTargetsRelative?(At.addVectors(this.boundingBox.min,Vt.min),this.boundingBox.expandByPoint(At),At.addVectors(this.boundingBox.max,Vt.max),this.boundingBox.expandByPoint(At)):(this.boundingBox.expandByPoint(Vt.min),this.boundingBox.expandByPoint(Vt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Sr);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new N,1/0);return}if(e){const i=this.boundingSphere.center;if(Vt.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];rr.setFromBufferAttribute(o),this.morphTargetsRelative?(At.addVectors(Vt.min,rr.min),Vt.expandByPoint(At),At.addVectors(Vt.max,rr.max),Vt.expandByPoint(At)):(Vt.expandByPoint(rr.min),Vt.expandByPoint(rr.max))}Vt.getCenter(i);let r=0;for(let s=0,a=e.count;s<a;s++)At.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(At));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],c=this.morphTargetsRelative;for(let l=0,d=o.count;l<d;l++)At.fromBufferAttribute(o,l),c&&(vi.fromBufferAttribute(e,l),At.add(vi)),r=Math.max(r,i.distanceToSquared(At))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=e.array,r=t.position.array,s=t.normal.array,a=t.uv.array,o=r.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Qt(new Float32Array(4*o),4));const c=this.getAttribute("tangent").array,l=[],d=[];for(let b=0;b<o;b++)l[b]=new N,d[b]=new N;const u=new N,h=new N,f=new N,y=new Oe,x=new Oe,m=new Oe,p=new N,_=new N;function g(b,F,I){u.fromArray(r,b*3),h.fromArray(r,F*3),f.fromArray(r,I*3),y.fromArray(a,b*2),x.fromArray(a,F*2),m.fromArray(a,I*2),h.sub(u),f.sub(u),x.sub(y),m.sub(y);const H=1/(x.x*m.y-m.x*x.y);isFinite(H)&&(p.copy(h).multiplyScalar(m.y).addScaledVector(f,-x.y).multiplyScalar(H),_.copy(f).multiplyScalar(x.x).addScaledVector(h,-m.x).multiplyScalar(H),l[b].add(p),l[F].add(p),l[I].add(p),d[b].add(_),d[F].add(_),d[I].add(_))}let v=this.groups;v.length===0&&(v=[{start:0,count:i.length}]);for(let b=0,F=v.length;b<F;++b){const I=v[b],H=I.start,L=I.count;for(let U=H,O=H+L;U<O;U+=3)g(i[U+0],i[U+1],i[U+2])}const A=new N,E=new N,C=new N,z=new N;function M(b){C.fromArray(s,b*3),z.copy(C);const F=l[b];A.copy(F),A.sub(C.multiplyScalar(C.dot(F))).normalize(),E.crossVectors(z,F);const H=E.dot(d[b])<0?-1:1;c[b*4]=A.x,c[b*4+1]=A.y,c[b*4+2]=A.z,c[b*4+3]=H}for(let b=0,F=v.length;b<F;++b){const I=v[b],H=I.start,L=I.count;for(let U=H,O=H+L;U<O;U+=3)M(i[U+0]),M(i[U+1]),M(i[U+2])}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Qt(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let h=0,f=i.count;h<f;h++)i.setXYZ(h,0,0,0);const r=new N,s=new N,a=new N,o=new N,c=new N,l=new N,d=new N,u=new N;if(e)for(let h=0,f=e.count;h<f;h+=3){const y=e.getX(h+0),x=e.getX(h+1),m=e.getX(h+2);r.fromBufferAttribute(t,y),s.fromBufferAttribute(t,x),a.fromBufferAttribute(t,m),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),o.fromBufferAttribute(i,y),c.fromBufferAttribute(i,x),l.fromBufferAttribute(i,m),o.add(d),c.add(d),l.add(d),i.setXYZ(y,o.x,o.y,o.z),i.setXYZ(x,c.x,c.y,c.z),i.setXYZ(m,l.x,l.y,l.z)}else for(let h=0,f=t.count;h<f;h+=3)r.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),a.fromBufferAttribute(t,h+2),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),i.setXYZ(h+0,d.x,d.y,d.z),i.setXYZ(h+1,d.x,d.y,d.z),i.setXYZ(h+2,d.x,d.y,d.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)At.fromBufferAttribute(e,t),At.normalize(),e.setXYZ(t,At.x,At.y,At.z)}toNonIndexed(){function e(o,c){const l=o.array,d=o.itemSize,u=o.normalized,h=new l.constructor(c.length*d);let f=0,y=0;for(let x=0,m=c.length;x<m;x++){o.isInterleavedBufferAttribute?f=c[x]*o.data.stride+o.offset:f=c[x]*d;for(let p=0;p<d;p++)h[y++]=l[f++]}return new Qt(h,d,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new tt,i=this.index.array,r=this.attributes;for(const o in r){const c=r[o],l=e(c,i);t.setAttribute(o,l)}const s=this.morphAttributes;for(const o in s){const c=[],l=s[o];for(let d=0,u=l.length;d<u;d++){const h=l[d],f=e(h,i);c.push(f)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,c=a.length;o<c;o++){const l=a[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const c in i){const l=i[c];e.data.attributes[c]=l.toJSON(e.data)}const r={};let s=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],d=[];for(let u=0,h=l.length;u<h;u++){const f=l[u];d.push(f.toJSON(e.data))}d.length>0&&(r[c]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(t));const r=e.attributes;for(const l in r){const d=r[l];this.setAttribute(l,d.clone(t))}const s=e.morphAttributes;for(const l in s){const d=[],u=s[l];for(let h=0,f=u.length;h<f;h++)d.push(u[h].clone(t));this.morphAttributes[l]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let l=0,d=a.length;l<d;l++){const u=a[l];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const gl=new et,Wn=new Er,Or=new Sr,xl=new N,Mi=new N,bi=new N,wi=new N,ua=new N,Br=new N,Gr=new Oe,Hr=new Oe,Vr=new Oe,_l=new N,yl=new N,vl=new N,Wr=new N,Xr=new N;class we extends mt{constructor(e=new tt,t=new Bi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){Br.set(0,0,0);for(let c=0,l=s.length;c<l;c++){const d=o[c],u=s[c];d!==0&&(ua.fromBufferAttribute(u,e),a?Br.addScaledVector(ua,d):Br.addScaledVector(ua.sub(t),d))}t.add(Br)}return t}raycast(e,t){const i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Or.copy(i.boundingSphere),Or.applyMatrix4(s),Wn.copy(e.ray).recast(e.near),!(Or.containsPoint(Wn.origin)===!1&&(Wn.intersectSphere(Or,xl)===null||Wn.origin.distanceToSquared(xl)>(e.far-e.near)**2))&&(gl.copy(s).invert(),Wn.copy(e.ray).applyMatrix4(gl),!(i.boundingBox!==null&&Wn.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,Wn)))}_computeIntersections(e,t,i){let r;const s=this.geometry,a=this.material,o=s.index,c=s.attributes.position,l=s.attributes.uv,d=s.attributes.uv1,u=s.attributes.normal,h=s.groups,f=s.drawRange;if(o!==null)if(Array.isArray(a))for(let y=0,x=h.length;y<x;y++){const m=h[y],p=a[m.materialIndex],_=Math.max(m.start,f.start),g=Math.min(o.count,Math.min(m.start+m.count,f.start+f.count));for(let v=_,A=g;v<A;v+=3){const E=o.getX(v),C=o.getX(v+1),z=o.getX(v+2);r=qr(this,p,e,i,l,d,u,E,C,z),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const y=Math.max(0,f.start),x=Math.min(o.count,f.start+f.count);for(let m=y,p=x;m<p;m+=3){const _=o.getX(m),g=o.getX(m+1),v=o.getX(m+2);r=qr(this,a,e,i,l,d,u,_,g,v),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}else if(c!==void 0)if(Array.isArray(a))for(let y=0,x=h.length;y<x;y++){const m=h[y],p=a[m.materialIndex],_=Math.max(m.start,f.start),g=Math.min(c.count,Math.min(m.start+m.count,f.start+f.count));for(let v=_,A=g;v<A;v+=3){const E=v,C=v+1,z=v+2;r=qr(this,p,e,i,l,d,u,E,C,z),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=m.materialIndex,t.push(r))}}else{const y=Math.max(0,f.start),x=Math.min(c.count,f.start+f.count);for(let m=y,p=x;m<p;m+=3){const _=m,g=m+1,v=m+2;r=qr(this,a,e,i,l,d,u,_,g,v),r&&(r.faceIndex=Math.floor(m/3),t.push(r))}}}}function iu(n,e,t,i,r,s,a,o){let c;if(e.side===Ot?c=i.intersectTriangle(a,s,r,!0,o):c=i.intersectTriangle(r,s,a,e.side===wn,o),c===null)return null;Xr.copy(o),Xr.applyMatrix4(n.matrixWorld);const l=t.ray.origin.distanceTo(Xr);return l<t.near||l>t.far?null:{distance:l,point:Xr.clone(),object:n}}function qr(n,e,t,i,r,s,a,o,c,l){n.getVertexPosition(o,Mi),n.getVertexPosition(c,bi),n.getVertexPosition(l,wi);const d=iu(n,e,t,i,Mi,bi,wi,Wr);if(d){r&&(Gr.fromBufferAttribute(r,o),Hr.fromBufferAttribute(r,c),Vr.fromBufferAttribute(r,l),d.uv=$t.getInterpolation(Wr,Mi,bi,wi,Gr,Hr,Vr,new Oe)),s&&(Gr.fromBufferAttribute(s,o),Hr.fromBufferAttribute(s,c),Vr.fromBufferAttribute(s,l),d.uv1=$t.getInterpolation(Wr,Mi,bi,wi,Gr,Hr,Vr,new Oe),d.uv2=d.uv1),a&&(_l.fromBufferAttribute(a,o),yl.fromBufferAttribute(a,c),vl.fromBufferAttribute(a,l),d.normal=$t.getInterpolation(Wr,Mi,bi,wi,_l,yl,vl,new N),d.normal.dot(i.direction)>0&&d.normal.multiplyScalar(-1));const u={a:o,b:c,c:l,normal:new N,materialIndex:0};$t.getNormal(Mi,bi,wi,u.normal),d.face=u}return d}class ht extends tt{constructor(e=1,t=1,i=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const c=[],l=[],d=[],u=[];let h=0,f=0;y("z","y","x",-1,-1,i,t,e,a,s,0),y("z","y","x",1,-1,i,t,-e,a,s,1),y("x","z","y",1,1,e,i,t,r,a,2),y("x","z","y",1,-1,e,i,-t,r,a,3),y("x","y","z",1,-1,e,t,i,r,s,4),y("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(c),this.setAttribute("position",new De(l,3)),this.setAttribute("normal",new De(d,3)),this.setAttribute("uv",new De(u,2));function y(x,m,p,_,g,v,A,E,C,z,M){const b=v/C,F=A/z,I=v/2,H=A/2,L=E/2,U=C+1,O=z+1;let X=0,Z=0;const te=new N;for(let ie=0;ie<O;ie++){const de=ie*F-H;for(let ue=0;ue<U;ue++){const J=ue*b-I;te[x]=J*_,te[m]=de*g,te[p]=L,l.push(te.x,te.y,te.z),te[x]=0,te[m]=0,te[p]=E>0?1:-1,d.push(te.x,te.y,te.z),u.push(ue/C),u.push(1-ie/z),X+=1}}for(let ie=0;ie<z;ie++)for(let de=0;de<C;de++){const ue=h+de+U*ie,J=h+de+U*(ie+1),se=h+(de+1)+U*(ie+1),ge=h+(de+1)+U*ie;c.push(ue,J,ge),c.push(J,se,ge),Z+=6}o.addGroup(f,Z,M),f+=Z,h+=X}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ht(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Xi(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const r=n[t][i];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone():Array.isArray(r)?e[t][i]=r.slice():e[t][i]=r}}return e}function Nt(n){const e={};for(let t=0;t<n.length;t++){const i=Xi(n[t]);for(const r in i)e[r]=i[r]}return e}function ru(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function Nc(n){return n.getRenderTarget()===null?n.outputColorSpace:rt.workingColorSpace}const su={clone:Xi,merge:Nt};var au=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,ou=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class oi extends $i{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=au,this.fragmentShader=ou,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Xi(e.uniforms),this.uniformsGroups=ru(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class Fc extends mt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new et,this.projectionMatrix=new et,this.projectionMatrixInverse=new et,this.coordinateSystem=yn}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class Xt extends Fc{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=yr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(fr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return yr*2*Math.atan(Math.tan(fr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(fr*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*r/c,t-=a.offsetY*i/l,r*=a.width/c,i*=a.height/l}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Si=-90,Ei=1;class lu extends mt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Xt(Si,Ei,e,t);r.layers=this.layers,this.add(r);const s=new Xt(Si,Ei,e,t);s.layers=this.layers,this.add(s);const a=new Xt(Si,Ei,e,t);a.layers=this.layers,this.add(a);const o=new Xt(Si,Ei,e,t);o.layers=this.layers,this.add(o);const c=new Xt(Si,Ei,e,t);c.layers=this.layers,this.add(c);const l=new Xt(Si,Ei,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,r,s,a,o,c]=t;for(const l of t)this.remove(l);if(e===yn)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===fs)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,c,l,d]=this.children,u=e.getRenderTarget(),h=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),y=e.xr.enabled;e.xr.enabled=!1;const x=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,r),e.render(t,s),e.setRenderTarget(i,1,r),e.render(t,a),e.setRenderTarget(i,2,r),e.render(t,o),e.setRenderTarget(i,3,r),e.render(t,c),e.setRenderTarget(i,4,r),e.render(t,l),i.texture.generateMipmaps=x,e.setRenderTarget(i,5,r),e.render(t,d),e.setRenderTarget(u,h,f),e.xr.enabled=y,i.texture.needsPMREMUpdate=!0}}class kc extends Bt{constructor(e,t,i,r,s,a,o,c,l,d){e=e!==void 0?e:[],t=t!==void 0?t:Hi,super(e,t,i,r,s,a,o,c,l,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class cu extends ai{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];t.encoding!==void 0&&(mr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===ri?vt:Jt),this.texture=new kc(r,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Kt}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new ht(5,5,5),s=new oi({name:"CubemapFromEquirect",uniforms:Xi(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Ot,blending:In});s.uniforms.tEquirect.value=t;const a=new we(r,s),o=t.minFilter;return t.minFilter===xr&&(t.minFilter=Kt),new lu(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,r){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,r);e.setRenderTarget(s)}}const fa=new N,hu=new N,du=new We;class Zn{constructor(e=new N(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const r=fa.subVectors(i,t).cross(hu.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(fa),r=this.normal.dot(i);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||du.getNormalMatrix(e),r=this.coplanarPoint(fa).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Xn=new Sr,Yr=new N;class io{constructor(e=new Zn,t=new Zn,i=new Zn,r=new Zn,s=new Zn,a=new Zn){this.planes=[e,t,i,r,s,a]}set(e,t,i,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=yn){const i=this.planes,r=e.elements,s=r[0],a=r[1],o=r[2],c=r[3],l=r[4],d=r[5],u=r[6],h=r[7],f=r[8],y=r[9],x=r[10],m=r[11],p=r[12],_=r[13],g=r[14],v=r[15];if(i[0].setComponents(c-s,h-l,m-f,v-p).normalize(),i[1].setComponents(c+s,h+l,m+f,v+p).normalize(),i[2].setComponents(c+a,h+d,m+y,v+_).normalize(),i[3].setComponents(c-a,h-d,m-y,v-_).normalize(),i[4].setComponents(c-o,h-u,m-x,v-g).normalize(),t===yn)i[5].setComponents(c+o,h+u,m+x,v+g).normalize();else if(t===fs)i[5].setComponents(o,u,x,g).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Xn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Xn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Xn)}intersectsSprite(e){return Xn.center.set(0,0,0),Xn.radius=.7071067811865476,Xn.applyMatrix4(e.matrixWorld),this.intersectsSphere(Xn)}intersectsSphere(e){const t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const r=t[i];if(Yr.x=r.normal.x>0?e.max.x:e.min.x,Yr.y=r.normal.y>0?e.max.y:e.min.y,Yr.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Yr)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Oc(){let n=null,e=!1,t=null,i=null;function r(s,a){t(s,a),i=n.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function uu(n,e){const t=e.isWebGL2,i=new WeakMap;function r(l,d){const u=l.array,h=l.usage,f=u.byteLength,y=n.createBuffer();n.bindBuffer(d,y),n.bufferData(d,u,h),l.onUploadCallback();let x;if(u instanceof Float32Array)x=n.FLOAT;else if(u instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(t)x=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else x=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)x=n.SHORT;else if(u instanceof Uint32Array)x=n.UNSIGNED_INT;else if(u instanceof Int32Array)x=n.INT;else if(u instanceof Int8Array)x=n.BYTE;else if(u instanceof Uint8Array)x=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)x=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:y,type:x,bytesPerElement:u.BYTES_PER_ELEMENT,version:l.version,size:f}}function s(l,d,u){const h=d.array,f=d._updateRange,y=d.updateRanges;if(n.bindBuffer(u,l),f.count===-1&&y.length===0&&n.bufferSubData(u,0,h),y.length!==0){for(let x=0,m=y.length;x<m;x++){const p=y[x];t?n.bufferSubData(u,p.start*h.BYTES_PER_ELEMENT,h,p.start,p.count):n.bufferSubData(u,p.start*h.BYTES_PER_ELEMENT,h.subarray(p.start,p.start+p.count))}d.clearUpdateRanges()}f.count!==-1&&(t?n.bufferSubData(u,f.offset*h.BYTES_PER_ELEMENT,h,f.offset,f.count):n.bufferSubData(u,f.offset*h.BYTES_PER_ELEMENT,h.subarray(f.offset,f.offset+f.count)),f.count=-1),d.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);const d=i.get(l);d&&(n.deleteBuffer(d.buffer),i.delete(l))}function c(l,d){if(l.isGLBufferAttribute){const h=i.get(l);(!h||h.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);const u=i.get(l);if(u===void 0)i.set(l,r(l,d));else if(u.version<l.version){if(u.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(u.buffer,l,d),u.version=l.version}}return{get:a,remove:o,update:c}}class Fn extends tt{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(i),c=Math.floor(r),l=o+1,d=c+1,u=e/o,h=t/c,f=[],y=[],x=[],m=[];for(let p=0;p<d;p++){const _=p*h-a;for(let g=0;g<l;g++){const v=g*u-s;y.push(v,-_,0),x.push(0,0,1),m.push(g/o),m.push(1-p/c)}}for(let p=0;p<c;p++)for(let _=0;_<o;_++){const g=_+l*p,v=_+l*(p+1),A=_+1+l*(p+1),E=_+1+l*p;f.push(g,v,E),f.push(v,A,E)}this.setIndex(f),this.setAttribute("position",new De(y,3)),this.setAttribute("normal",new De(x,3)),this.setAttribute("uv",new De(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fn(e.width,e.height,e.widthSegments,e.heightSegments)}}var fu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,pu=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,mu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,gu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,xu=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,_u=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,yu=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,vu=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Mu=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,bu=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,wu=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Su=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Eu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Tu=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Au=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Ru=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Cu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Pu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Lu=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,zu=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Du=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Iu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Uu=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Nu=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Fu=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,ku=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Ou=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Bu=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Gu=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Hu=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Vu="gl_FragColor = linearToOutputTexel( gl_FragColor );",Wu=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Xu=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,qu=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Yu=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,ju=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Zu=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Ku=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,$u=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Ju=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Qu=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,ef=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,tf=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,nf=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,rf=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,sf=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,af=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,of=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,lf=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,cf=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,hf=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,df=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,uf=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,ff=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,pf=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,mf=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,gf=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,xf=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_f=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,yf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,vf=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Mf=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,bf=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,wf=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Sf=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ef=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Tf=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Af=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Rf=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,Cf=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Pf=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Lf=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,zf=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Df=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,If=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Uf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Nf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Ff=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,kf=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Of=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Bf=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Gf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Hf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Vf=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Wf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Xf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,qf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Yf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,jf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Zf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Kf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,$f=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Jf=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Qf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,e0=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,t0=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,n0=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,i0=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,r0=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,s0=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,a0=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,o0=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,l0=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,c0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,h0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,d0=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,u0=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const f0=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,p0=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,m0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,g0=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,x0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,_0=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,y0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,v0=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,M0=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,b0=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,w0=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,S0=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,E0=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,T0=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,A0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,R0=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,C0=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,P0=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,L0=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,z0=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,D0=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,I0=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,U0=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,N0=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,F0=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,k0=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,O0=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,B0=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,G0=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,H0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,V0=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,W0=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,X0=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,q0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ye={alphahash_fragment:fu,alphahash_pars_fragment:pu,alphamap_fragment:mu,alphamap_pars_fragment:gu,alphatest_fragment:xu,alphatest_pars_fragment:_u,aomap_fragment:yu,aomap_pars_fragment:vu,batching_pars_vertex:Mu,batching_vertex:bu,begin_vertex:wu,beginnormal_vertex:Su,bsdfs:Eu,iridescence_fragment:Tu,bumpmap_pars_fragment:Au,clipping_planes_fragment:Ru,clipping_planes_pars_fragment:Cu,clipping_planes_pars_vertex:Pu,clipping_planes_vertex:Lu,color_fragment:zu,color_pars_fragment:Du,color_pars_vertex:Iu,color_vertex:Uu,common:Nu,cube_uv_reflection_fragment:Fu,defaultnormal_vertex:ku,displacementmap_pars_vertex:Ou,displacementmap_vertex:Bu,emissivemap_fragment:Gu,emissivemap_pars_fragment:Hu,colorspace_fragment:Vu,colorspace_pars_fragment:Wu,envmap_fragment:Xu,envmap_common_pars_fragment:qu,envmap_pars_fragment:Yu,envmap_pars_vertex:ju,envmap_physical_pars_fragment:of,envmap_vertex:Zu,fog_vertex:Ku,fog_pars_vertex:$u,fog_fragment:Ju,fog_pars_fragment:Qu,gradientmap_pars_fragment:ef,lightmap_fragment:tf,lightmap_pars_fragment:nf,lights_lambert_fragment:rf,lights_lambert_pars_fragment:sf,lights_pars_begin:af,lights_toon_fragment:lf,lights_toon_pars_fragment:cf,lights_phong_fragment:hf,lights_phong_pars_fragment:df,lights_physical_fragment:uf,lights_physical_pars_fragment:ff,lights_fragment_begin:pf,lights_fragment_maps:mf,lights_fragment_end:gf,logdepthbuf_fragment:xf,logdepthbuf_pars_fragment:_f,logdepthbuf_pars_vertex:yf,logdepthbuf_vertex:vf,map_fragment:Mf,map_pars_fragment:bf,map_particle_fragment:wf,map_particle_pars_fragment:Sf,metalnessmap_fragment:Ef,metalnessmap_pars_fragment:Tf,morphcolor_vertex:Af,morphnormal_vertex:Rf,morphtarget_pars_vertex:Cf,morphtarget_vertex:Pf,normal_fragment_begin:Lf,normal_fragment_maps:zf,normal_pars_fragment:Df,normal_pars_vertex:If,normal_vertex:Uf,normalmap_pars_fragment:Nf,clearcoat_normal_fragment_begin:Ff,clearcoat_normal_fragment_maps:kf,clearcoat_pars_fragment:Of,iridescence_pars_fragment:Bf,opaque_fragment:Gf,packing:Hf,premultiplied_alpha_fragment:Vf,project_vertex:Wf,dithering_fragment:Xf,dithering_pars_fragment:qf,roughnessmap_fragment:Yf,roughnessmap_pars_fragment:jf,shadowmap_pars_fragment:Zf,shadowmap_pars_vertex:Kf,shadowmap_vertex:$f,shadowmask_pars_fragment:Jf,skinbase_vertex:Qf,skinning_pars_vertex:e0,skinning_vertex:t0,skinnormal_vertex:n0,specularmap_fragment:i0,specularmap_pars_fragment:r0,tonemapping_fragment:s0,tonemapping_pars_fragment:a0,transmission_fragment:o0,transmission_pars_fragment:l0,uv_pars_fragment:c0,uv_pars_vertex:h0,uv_vertex:d0,worldpos_vertex:u0,background_vert:f0,background_frag:p0,backgroundCube_vert:m0,backgroundCube_frag:g0,cube_vert:x0,cube_frag:_0,depth_vert:y0,depth_frag:v0,distanceRGBA_vert:M0,distanceRGBA_frag:b0,equirect_vert:w0,equirect_frag:S0,linedashed_vert:E0,linedashed_frag:T0,meshbasic_vert:A0,meshbasic_frag:R0,meshlambert_vert:C0,meshlambert_frag:P0,meshmatcap_vert:L0,meshmatcap_frag:z0,meshnormal_vert:D0,meshnormal_frag:I0,meshphong_vert:U0,meshphong_frag:N0,meshphysical_vert:F0,meshphysical_frag:k0,meshtoon_vert:O0,meshtoon_frag:B0,points_vert:G0,points_frag:H0,shadow_vert:V0,shadow_frag:W0,sprite_vert:X0,sprite_frag:q0},_e={common:{diffuse:{value:new Ke(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new We}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new We}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new We}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new We},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new We},normalScale:{value:new Oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new We},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new We}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new We}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new We}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ke(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ke(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0},uvTransform:{value:new We}},sprite:{diffuse:{value:new Ke(16777215)},opacity:{value:1},center:{value:new Oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new We},alphaMap:{value:null},alphaMapTransform:{value:new We},alphaTest:{value:0}}},on={basic:{uniforms:Nt([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.fog]),vertexShader:Ye.meshbasic_vert,fragmentShader:Ye.meshbasic_frag},lambert:{uniforms:Nt([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,_e.lights,{emissive:{value:new Ke(0)}}]),vertexShader:Ye.meshlambert_vert,fragmentShader:Ye.meshlambert_frag},phong:{uniforms:Nt([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,_e.lights,{emissive:{value:new Ke(0)},specular:{value:new Ke(1118481)},shininess:{value:30}}]),vertexShader:Ye.meshphong_vert,fragmentShader:Ye.meshphong_frag},standard:{uniforms:Nt([_e.common,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.roughnessmap,_e.metalnessmap,_e.fog,_e.lights,{emissive:{value:new Ke(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ye.meshphysical_vert,fragmentShader:Ye.meshphysical_frag},toon:{uniforms:Nt([_e.common,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.gradientmap,_e.fog,_e.lights,{emissive:{value:new Ke(0)}}]),vertexShader:Ye.meshtoon_vert,fragmentShader:Ye.meshtoon_frag},matcap:{uniforms:Nt([_e.common,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,{matcap:{value:null}}]),vertexShader:Ye.meshmatcap_vert,fragmentShader:Ye.meshmatcap_frag},points:{uniforms:Nt([_e.points,_e.fog]),vertexShader:Ye.points_vert,fragmentShader:Ye.points_frag},dashed:{uniforms:Nt([_e.common,_e.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ye.linedashed_vert,fragmentShader:Ye.linedashed_frag},depth:{uniforms:Nt([_e.common,_e.displacementmap]),vertexShader:Ye.depth_vert,fragmentShader:Ye.depth_frag},normal:{uniforms:Nt([_e.common,_e.bumpmap,_e.normalmap,_e.displacementmap,{opacity:{value:1}}]),vertexShader:Ye.meshnormal_vert,fragmentShader:Ye.meshnormal_frag},sprite:{uniforms:Nt([_e.sprite,_e.fog]),vertexShader:Ye.sprite_vert,fragmentShader:Ye.sprite_frag},background:{uniforms:{uvTransform:{value:new We},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ye.background_vert,fragmentShader:Ye.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ye.backgroundCube_vert,fragmentShader:Ye.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ye.cube_vert,fragmentShader:Ye.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ye.equirect_vert,fragmentShader:Ye.equirect_frag},distanceRGBA:{uniforms:Nt([_e.common,_e.displacementmap,{referencePosition:{value:new N},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ye.distanceRGBA_vert,fragmentShader:Ye.distanceRGBA_frag},shadow:{uniforms:Nt([_e.lights,_e.fog,{color:{value:new Ke(0)},opacity:{value:1}}]),vertexShader:Ye.shadow_vert,fragmentShader:Ye.shadow_frag}};on.physical={uniforms:Nt([on.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new We},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new We},clearcoatNormalScale:{value:new Oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new We},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new We},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new We},sheen:{value:0},sheenColor:{value:new Ke(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new We},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new We},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new We},transmissionSamplerSize:{value:new Oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new We},attenuationDistance:{value:0},attenuationColor:{value:new Ke(0)},specularColor:{value:new Ke(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new We},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new We},anisotropyVector:{value:new Oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new We}}]),vertexShader:Ye.meshphysical_vert,fragmentShader:Ye.meshphysical_frag};const jr={r:0,b:0,g:0};function Y0(n,e,t,i,r,s,a){const o=new Ke(0);let c=s===!0?0:1,l,d,u=null,h=0,f=null;function y(m,p){let _=!1,g=p.isScene===!0?p.background:null;g&&g.isTexture&&(g=(p.backgroundBlurriness>0?t:e).get(g)),g===null?x(o,c):g&&g.isColor&&(x(g,1),_=!0);const v=n.xr.getEnvironmentBlendMode();v==="additive"?i.buffers.color.setClear(0,0,0,1,a):v==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||_)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),g&&(g.isCubeTexture||g.mapping===Es)?(d===void 0&&(d=new we(new ht(1,1,1),new oi({name:"BackgroundCubeMaterial",uniforms:Xi(on.backgroundCube.uniforms),vertexShader:on.backgroundCube.vertexShader,fragmentShader:on.backgroundCube.fragmentShader,side:Ot,depthTest:!1,depthWrite:!1,fog:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(A,E,C){this.matrixWorld.copyPosition(C.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(d)),d.material.uniforms.envMap.value=g,d.material.uniforms.flipEnvMap.value=g.isCubeTexture&&g.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=p.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,d.material.toneMapped=rt.getTransfer(g.colorSpace)!==dt,(u!==g||h!==g.version||f!==n.toneMapping)&&(d.material.needsUpdate=!0,u=g,h=g.version,f=n.toneMapping),d.layers.enableAll(),m.unshift(d,d.geometry,d.material,0,0,null)):g&&g.isTexture&&(l===void 0&&(l=new we(new Fn(2,2),new oi({name:"BackgroundMaterial",uniforms:Xi(on.background.uniforms),vertexShader:on.background.vertexShader,fragmentShader:on.background.fragmentShader,side:wn,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(l)),l.material.uniforms.t2D.value=g,l.material.uniforms.backgroundIntensity.value=p.backgroundIntensity,l.material.toneMapped=rt.getTransfer(g.colorSpace)!==dt,g.matrixAutoUpdate===!0&&g.updateMatrix(),l.material.uniforms.uvTransform.value.copy(g.matrix),(u!==g||h!==g.version||f!==n.toneMapping)&&(l.material.needsUpdate=!0,u=g,h=g.version,f=n.toneMapping),l.layers.enableAll(),m.unshift(l,l.geometry,l.material,0,0,null))}function x(m,p){m.getRGB(jr,Nc(n)),i.buffers.color.setClear(jr.r,jr.g,jr.b,p,a)}return{getClearColor:function(){return o},setClearColor:function(m,p=1){o.set(m),c=p,x(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(m){c=m,x(o,c)},render:y}}function j0(n,e,t,i){const r=n.getParameter(n.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},c=m(null);let l=c,d=!1;function u(L,U,O,X,Z){let te=!1;if(a){const ie=x(X,O,U);l!==ie&&(l=ie,f(l.object)),te=p(L,X,O,Z),te&&_(L,X,O,Z)}else{const ie=U.wireframe===!0;(l.geometry!==X.id||l.program!==O.id||l.wireframe!==ie)&&(l.geometry=X.id,l.program=O.id,l.wireframe=ie,te=!0)}Z!==null&&t.update(Z,n.ELEMENT_ARRAY_BUFFER),(te||d)&&(d=!1,z(L,U,O,X),Z!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,t.get(Z).buffer))}function h(){return i.isWebGL2?n.createVertexArray():s.createVertexArrayOES()}function f(L){return i.isWebGL2?n.bindVertexArray(L):s.bindVertexArrayOES(L)}function y(L){return i.isWebGL2?n.deleteVertexArray(L):s.deleteVertexArrayOES(L)}function x(L,U,O){const X=O.wireframe===!0;let Z=o[L.id];Z===void 0&&(Z={},o[L.id]=Z);let te=Z[U.id];te===void 0&&(te={},Z[U.id]=te);let ie=te[X];return ie===void 0&&(ie=m(h()),te[X]=ie),ie}function m(L){const U=[],O=[],X=[];for(let Z=0;Z<r;Z++)U[Z]=0,O[Z]=0,X[Z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:U,enabledAttributes:O,attributeDivisors:X,object:L,attributes:{},index:null}}function p(L,U,O,X){const Z=l.attributes,te=U.attributes;let ie=0;const de=O.getAttributes();for(const ue in de)if(de[ue].location>=0){const se=Z[ue];let ge=te[ue];if(ge===void 0&&(ue==="instanceMatrix"&&L.instanceMatrix&&(ge=L.instanceMatrix),ue==="instanceColor"&&L.instanceColor&&(ge=L.instanceColor)),se===void 0||se.attribute!==ge||ge&&se.data!==ge.data)return!0;ie++}return l.attributesNum!==ie||l.index!==X}function _(L,U,O,X){const Z={},te=U.attributes;let ie=0;const de=O.getAttributes();for(const ue in de)if(de[ue].location>=0){let se=te[ue];se===void 0&&(ue==="instanceMatrix"&&L.instanceMatrix&&(se=L.instanceMatrix),ue==="instanceColor"&&L.instanceColor&&(se=L.instanceColor));const ge={};ge.attribute=se,se&&se.data&&(ge.data=se.data),Z[ue]=ge,ie++}l.attributes=Z,l.attributesNum=ie,l.index=X}function g(){const L=l.newAttributes;for(let U=0,O=L.length;U<O;U++)L[U]=0}function v(L){A(L,0)}function A(L,U){const O=l.newAttributes,X=l.enabledAttributes,Z=l.attributeDivisors;O[L]=1,X[L]===0&&(n.enableVertexAttribArray(L),X[L]=1),Z[L]!==U&&((i.isWebGL2?n:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,U),Z[L]=U)}function E(){const L=l.newAttributes,U=l.enabledAttributes;for(let O=0,X=U.length;O<X;O++)U[O]!==L[O]&&(n.disableVertexAttribArray(O),U[O]=0)}function C(L,U,O,X,Z,te,ie){ie===!0?n.vertexAttribIPointer(L,U,O,Z,te):n.vertexAttribPointer(L,U,O,X,Z,te)}function z(L,U,O,X){if(i.isWebGL2===!1&&(L.isInstancedMesh||X.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;g();const Z=X.attributes,te=O.getAttributes(),ie=U.defaultAttributeValues;for(const de in te){const ue=te[de];if(ue.location>=0){let J=Z[de];if(J===void 0&&(de==="instanceMatrix"&&L.instanceMatrix&&(J=L.instanceMatrix),de==="instanceColor"&&L.instanceColor&&(J=L.instanceColor)),J!==void 0){const se=J.normalized,ge=J.itemSize,Re=t.get(J);if(Re===void 0)continue;const Ee=Re.buffer,Be=Re.type,He=Re.bytesPerElement,Ie=i.isWebGL2===!0&&(Be===n.INT||Be===n.UNSIGNED_INT||J.gpuType===yc);if(J.isInterleavedBufferAttribute){const S=J.data,w=S.stride,V=J.offset;if(S.isInstancedInterleavedBuffer){for(let k=0;k<ue.locationSize;k++)A(ue.location+k,S.meshPerAttribute);L.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=S.meshPerAttribute*S.count)}else for(let k=0;k<ue.locationSize;k++)v(ue.location+k);n.bindBuffer(n.ARRAY_BUFFER,Ee);for(let k=0;k<ue.locationSize;k++)C(ue.location+k,ge/ue.locationSize,Be,se,w*He,(V+ge/ue.locationSize*k)*He,Ie)}else{if(J.isInstancedBufferAttribute){for(let S=0;S<ue.locationSize;S++)A(ue.location+S,J.meshPerAttribute);L.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let S=0;S<ue.locationSize;S++)v(ue.location+S);n.bindBuffer(n.ARRAY_BUFFER,Ee);for(let S=0;S<ue.locationSize;S++)C(ue.location+S,ge/ue.locationSize,Be,se,ge*He,ge/ue.locationSize*S*He,Ie)}}else if(ie!==void 0){const se=ie[de];if(se!==void 0)switch(se.length){case 2:n.vertexAttrib2fv(ue.location,se);break;case 3:n.vertexAttrib3fv(ue.location,se);break;case 4:n.vertexAttrib4fv(ue.location,se);break;default:n.vertexAttrib1fv(ue.location,se)}}}}E()}function M(){I();for(const L in o){const U=o[L];for(const O in U){const X=U[O];for(const Z in X)y(X[Z].object),delete X[Z];delete U[O]}delete o[L]}}function b(L){if(o[L.id]===void 0)return;const U=o[L.id];for(const O in U){const X=U[O];for(const Z in X)y(X[Z].object),delete X[Z];delete U[O]}delete o[L.id]}function F(L){for(const U in o){const O=o[U];if(O[L.id]===void 0)continue;const X=O[L.id];for(const Z in X)y(X[Z].object),delete X[Z];delete O[L.id]}}function I(){H(),d=!0,l!==c&&(l=c,f(l.object))}function H(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:u,reset:I,resetDefaultState:H,dispose:M,releaseStatesOfGeometry:b,releaseStatesOfProgram:F,initAttributes:g,enableAttribute:v,disableUnusedAttributes:E}}function Z0(n,e,t,i){const r=i.isWebGL2;let s;function a(d){s=d}function o(d,u){n.drawArrays(s,d,u),t.update(u,s,1)}function c(d,u,h){if(h===0)return;let f,y;if(r)f=n,y="drawArraysInstanced";else if(f=e.get("ANGLE_instanced_arrays"),y="drawArraysInstancedANGLE",f===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}f[y](s,d,u,h),t.update(u,s,h)}function l(d,u,h){if(h===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let y=0;y<h;y++)this.render(d[y],u[y]);else{f.multiDrawArraysWEBGL(s,d,0,u,0,h);let y=0;for(let x=0;x<h;x++)y+=u[x];t.update(y,s,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function K0(n,e,t){let i;function r(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const C=e.get("EXT_texture_filter_anisotropic");i=n.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function s(C){if(C==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext";let o=t.precision!==void 0?t.precision:"highp";const c=s(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);const l=a||e.has("WEBGL_draw_buffers"),d=t.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),h=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),f=n.getParameter(n.MAX_TEXTURE_SIZE),y=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),x=n.getParameter(n.MAX_VERTEX_ATTRIBS),m=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),p=n.getParameter(n.MAX_VARYING_VECTORS),_=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),g=h>0,v=a||e.has("OES_texture_float"),A=g&&v,E=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:r,getMaxPrecision:s,precision:o,logarithmicDepthBuffer:d,maxTextures:u,maxVertexTextures:h,maxTextureSize:f,maxCubemapSize:y,maxAttributes:x,maxVertexUniforms:m,maxVaryings:p,maxFragmentUniforms:_,vertexTextures:g,floatFragmentTextures:v,floatVertexTextures:A,maxSamples:E}}function $0(n){const e=this;let t=null,i=0,r=!1,s=!1;const a=new Zn,o=new We,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(u,h){const f=u.length!==0||h||i!==0||r;return r=h,i=u.length,f},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,h){t=d(u,h,0)},this.setState=function(u,h,f){const y=u.clippingPlanes,x=u.clipIntersection,m=u.clipShadows,p=n.get(u);if(!r||y===null||y.length===0||s&&!m)s?d(null):l();else{const _=s?0:i,g=_*4;let v=p.clippingState||null;c.value=v,v=d(y,h,g,f);for(let A=0;A!==g;++A)v[A]=t[A];p.clippingState=v,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=_}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function d(u,h,f,y){const x=u!==null?u.length:0;let m=null;if(x!==0){if(m=c.value,y!==!0||m===null){const p=f+x*4,_=h.matrixWorldInverse;o.getNormalMatrix(_),(m===null||m.length<p)&&(m=new Float32Array(p));for(let g=0,v=f;g!==x;++g,v+=4)a.copy(u[g]).applyMatrix4(_,o),a.normal.toArray(m,v),m[v+3]=a.constant}c.value=m,c.needsUpdate=!0}return e.numPlanes=x,e.numIntersection=0,m}}function J0(n){let e=new WeakMap;function t(a,o){return o===za?a.mapping=Hi:o===Da&&(a.mapping=Vi),a}function i(a){if(a&&a.isTexture){const o=a.mapping;if(o===za||o===Da)if(e.has(a)){const c=e.get(a).texture;return t(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new cu(c.height/2);return l.fromEquirectangularTexture(n,a),e.set(a,l),a.addEventListener("dispose",r),t(l.texture,a.mapping)}else return null}}return a}function r(a){const o=a.target;o.removeEventListener("dispose",r);const c=e.get(o);c!==void 0&&(e.delete(o),c.dispose())}function s(){e=new WeakMap}return{get:i,dispose:s}}class ro extends Fc{constructor(e=-1,t=1,i=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=i-e,a=i+e,o=r+t,c=r-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,o-=d*this.view.offsetY,c=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const Ui=4,Ml=[.125,.215,.35,.446,.526,.582],Qn=20,pa=new ro,bl=new Ke;let ma=null,ga=0,xa=0;const Kn=(1+Math.sqrt(5))/2,Ti=1/Kn,wl=[new N(1,1,1),new N(-1,1,1),new N(1,1,-1),new N(-1,1,-1),new N(0,Kn,Ti),new N(0,Kn,-Ti),new N(Ti,0,Kn),new N(-Ti,0,Kn),new N(Kn,Ti,0),new N(-Kn,Ti,0)];class Sl{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,r=100){ma=this._renderer.getRenderTarget(),ga=this._renderer.getActiveCubeFace(),xa=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,r,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Al(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Tl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(ma,ga,xa),e.scissorTest=!1,Zr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Hi||e.mapping===Vi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ma=this._renderer.getRenderTarget(),ga=this._renderer.getActiveCubeFace(),xa=this._renderer.getActiveMipmapLevel();const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Kt,minFilter:Kt,generateMipmaps:!1,type:_r,format:sn,colorSpace:Sn,depthBuffer:!1},r=El(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=El(e,t,i);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=Q0(s)),this._blurMaterial=ep(s,e,t)}return r}_compileMaterial(e){const t=new we(this._lodPlanes[0],e);this._renderer.compile(t,pa)}_sceneToCubeUV(e,t,i,r){const o=new Xt(90,1,t,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],d=this._renderer,u=d.autoClear,h=d.toneMapping;d.getClearColor(bl),d.toneMapping=Un,d.autoClear=!1;const f=new Bi({name:"PMREM.Background",side:Ot,depthWrite:!1,depthTest:!1}),y=new we(new ht,f);let x=!1;const m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,x=!0):(f.color.copy(bl),x=!0);for(let p=0;p<6;p++){const _=p%3;_===0?(o.up.set(0,c[p],0),o.lookAt(l[p],0,0)):_===1?(o.up.set(0,0,c[p]),o.lookAt(0,l[p],0)):(o.up.set(0,c[p],0),o.lookAt(0,0,l[p]));const g=this._cubeSize;Zr(r,_*g,p>2?g:0,g,g),d.setRenderTarget(r),x&&d.render(y,o),d.render(e,o)}y.geometry.dispose(),y.material.dispose(),d.toneMapping=h,d.autoClear=u,e.background=m}_textureToCubeUV(e,t){const i=this._renderer,r=e.mapping===Hi||e.mapping===Vi;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Al()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Tl());const s=r?this._cubemapMaterial:this._equirectMaterial,a=new we(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;const c=this._cubeSize;Zr(t,0,0,3*c,2*c),i.setRenderTarget(t),i.render(a,pa)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let r=1;r<this._lodPlanes.length;r++){const s=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=wl[(r-1)%wl.length];this._blur(e,r-1,r,s,a)}t.autoClear=i}_blur(e,t,i,r,s){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,r,"latitudinal",s),this._halfBlur(a,e,i,i,r,"longitudinal",s)}_halfBlur(e,t,i,r,s,a,o){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,u=new we(this._lodPlanes[r],l),h=l.uniforms,f=this._sizeLods[i]-1,y=isFinite(s)?Math.PI/(2*f):2*Math.PI/(2*Qn-1),x=s/y,m=isFinite(s)?1+Math.floor(d*x):Qn;m>Qn&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${Qn}`);const p=[];let _=0;for(let C=0;C<Qn;++C){const z=C/x,M=Math.exp(-z*z/2);p.push(M),C===0?_+=M:C<m&&(_+=2*M)}for(let C=0;C<p.length;C++)p[C]=p[C]/_;h.envMap.value=e.texture,h.samples.value=m,h.weights.value=p,h.latitudinal.value=a==="latitudinal",o&&(h.poleAxis.value=o);const{_lodMax:g}=this;h.dTheta.value=y,h.mipInt.value=g-i;const v=this._sizeLods[r],A=3*v*(r>g-Ui?r-g+Ui:0),E=4*(this._cubeSize-v);Zr(t,A,E,3*v,2*v),c.setRenderTarget(t),c.render(u,pa)}}function Q0(n){const e=[],t=[],i=[];let r=n;const s=n-Ui+1+Ml.length;for(let a=0;a<s;a++){const o=Math.pow(2,r);t.push(o);let c=1/o;a>n-Ui?c=Ml[a-n+Ui-1]:a===0&&(c=0),i.push(c);const l=1/(o-2),d=-l,u=1+l,h=[d,d,u,d,u,u,d,d,u,u,d,u],f=6,y=6,x=3,m=2,p=1,_=new Float32Array(x*y*f),g=new Float32Array(m*y*f),v=new Float32Array(p*y*f);for(let E=0;E<f;E++){const C=E%3*2/3-1,z=E>2?0:-1,M=[C,z,0,C+2/3,z,0,C+2/3,z+1,0,C,z,0,C+2/3,z+1,0,C,z+1,0];_.set(M,x*y*E),g.set(h,m*y*E);const b=[E,E,E,E,E,E];v.set(b,p*y*E)}const A=new tt;A.setAttribute("position",new Qt(_,x)),A.setAttribute("uv",new Qt(g,m)),A.setAttribute("faceIndex",new Qt(v,p)),e.push(A),r>Ui&&r--}return{lodPlanes:e,sizeLods:t,sigmas:i}}function El(n,e,t){const i=new ai(n,e,t);return i.texture.mapping=Es,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Zr(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function ep(n,e,t){const i=new Float32Array(Qn),r=new N(0,1,0);return new oi({name:"SphericalGaussianBlur",defines:{n:Qn,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:so(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:In,depthTest:!1,depthWrite:!1})}function Tl(){return new oi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:so(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:In,depthTest:!1,depthWrite:!1})}function Al(){return new oi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:so(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:In,depthTest:!1,depthWrite:!1})}function so(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function tp(n){let e=new WeakMap,t=null;function i(o){if(o&&o.isTexture){const c=o.mapping,l=c===za||c===Da,d=c===Hi||c===Vi;if(l||d)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=e.get(o);return t===null&&(t=new Sl(n)),u=l?t.fromEquirectangular(o,u):t.fromCubemap(o,u),e.set(o,u),u.texture}else{if(e.has(o))return e.get(o).texture;{const u=o.image;if(l&&u&&u.height>0||d&&u&&r(u)){t===null&&(t=new Sl(n));const h=l?t.fromEquirectangular(o):t.fromCubemap(o);return e.set(o,h),o.addEventListener("dispose",s),h.texture}else return null}}}return o}function r(o){let c=0;const l=6;for(let d=0;d<l;d++)o[d]!==void 0&&c++;return c===l}function s(o){const c=o.target;c.removeEventListener("dispose",s);const l=e.get(c);l!==void 0&&(e.delete(c),l.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:a}}function np(n){const e={};function t(i){if(e[i]!==void 0)return e[i];let r;switch(i){case"WEBGL_depth_texture":r=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=n.getExtension(i)}return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){const r=t(i);return r===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),r}}}function ip(n,e,t,i){const r={},s=new WeakMap;function a(u){const h=u.target;h.index!==null&&e.remove(h.index);for(const y in h.attributes)e.remove(h.attributes[y]);for(const y in h.morphAttributes){const x=h.morphAttributes[y];for(let m=0,p=x.length;m<p;m++)e.remove(x[m])}h.removeEventListener("dispose",a),delete r[h.id];const f=s.get(h);f&&(e.remove(f),s.delete(h)),i.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function o(u,h){return r[h.id]===!0||(h.addEventListener("dispose",a),r[h.id]=!0,t.memory.geometries++),h}function c(u){const h=u.attributes;for(const y in h)e.update(h[y],n.ARRAY_BUFFER);const f=u.morphAttributes;for(const y in f){const x=f[y];for(let m=0,p=x.length;m<p;m++)e.update(x[m],n.ARRAY_BUFFER)}}function l(u){const h=[],f=u.index,y=u.attributes.position;let x=0;if(f!==null){const _=f.array;x=f.version;for(let g=0,v=_.length;g<v;g+=3){const A=_[g+0],E=_[g+1],C=_[g+2];h.push(A,E,E,C,C,A)}}else if(y!==void 0){const _=y.array;x=y.version;for(let g=0,v=_.length/3-1;g<v;g+=3){const A=g+0,E=g+1,C=g+2;h.push(A,E,E,C,C,A)}}else return;const m=new(Cc(h)?Uc:Ic)(h,1);m.version=x;const p=s.get(u);p&&e.remove(p),s.set(u,m)}function d(u){const h=s.get(u);if(h){const f=u.index;f!==null&&h.version<f.version&&l(u)}else l(u);return s.get(u)}return{get:o,update:c,getWireframeAttribute:d}}function rp(n,e,t,i){const r=i.isWebGL2;let s;function a(f){s=f}let o,c;function l(f){o=f.type,c=f.bytesPerElement}function d(f,y){n.drawElements(s,y,o,f*c),t.update(y,s,1)}function u(f,y,x){if(x===0)return;let m,p;if(r)m=n,p="drawElementsInstanced";else if(m=e.get("ANGLE_instanced_arrays"),p="drawElementsInstancedANGLE",m===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[p](s,y,o,f*c,x),t.update(y,s,x)}function h(f,y,x){if(x===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<x;p++)this.render(f[p]/c,y[p]);else{m.multiDrawElementsWEBGL(s,y,0,o,f,0,x);let p=0;for(let _=0;_<x;_++)p+=y[_];t.update(p,s,1)}}this.setMode=a,this.setIndex=l,this.render=d,this.renderInstances=u,this.renderMultiDraw=h}function sp(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,a,o){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=o*(s/3);break;case n.LINES:t.lines+=o*(s/2);break;case n.LINE_STRIP:t.lines+=o*(s-1);break;case n.LINE_LOOP:t.lines+=o*s;break;case n.POINTS:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function ap(n,e){return n[0]-e[0]}function op(n,e){return Math.abs(e[1])-Math.abs(n[1])}function lp(n,e,t){const i={},r=new Float32Array(8),s=new WeakMap,a=new ft,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,d,u){const h=l.morphTargetInfluences;if(e.isWebGL2===!0){const y=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,x=y!==void 0?y.length:0;let m=s.get(d);if(m===void 0||m.count!==x){let U=function(){H.dispose(),s.delete(d),d.removeEventListener("dispose",U)};var f=U;m!==void 0&&m.texture.dispose();const g=d.morphAttributes.position!==void 0,v=d.morphAttributes.normal!==void 0,A=d.morphAttributes.color!==void 0,E=d.morphAttributes.position||[],C=d.morphAttributes.normal||[],z=d.morphAttributes.color||[];let M=0;g===!0&&(M=1),v===!0&&(M=2),A===!0&&(M=3);let b=d.attributes.position.count*M,F=1;b>e.maxTextureSize&&(F=Math.ceil(b/e.maxTextureSize),b=e.maxTextureSize);const I=new Float32Array(b*F*4*x),H=new zc(I,b,F,x);H.type=zn,H.needsUpdate=!0;const L=M*4;for(let O=0;O<x;O++){const X=E[O],Z=C[O],te=z[O],ie=b*F*4*O;for(let de=0;de<X.count;de++){const ue=de*L;g===!0&&(a.fromBufferAttribute(X,de),I[ie+ue+0]=a.x,I[ie+ue+1]=a.y,I[ie+ue+2]=a.z,I[ie+ue+3]=0),v===!0&&(a.fromBufferAttribute(Z,de),I[ie+ue+4]=a.x,I[ie+ue+5]=a.y,I[ie+ue+6]=a.z,I[ie+ue+7]=0),A===!0&&(a.fromBufferAttribute(te,de),I[ie+ue+8]=a.x,I[ie+ue+9]=a.y,I[ie+ue+10]=a.z,I[ie+ue+11]=te.itemSize===4?a.w:1)}}m={count:x,texture:H,size:new Oe(b,F)},s.set(d,m),d.addEventListener("dispose",U)}let p=0;for(let g=0;g<h.length;g++)p+=h[g];const _=d.morphTargetsRelative?1:1-p;u.getUniforms().setValue(n,"morphTargetBaseInfluence",_),u.getUniforms().setValue(n,"morphTargetInfluences",h),u.getUniforms().setValue(n,"morphTargetsTexture",m.texture,t),u.getUniforms().setValue(n,"morphTargetsTextureSize",m.size)}else{const y=h===void 0?0:h.length;let x=i[d.id];if(x===void 0||x.length!==y){x=[];for(let v=0;v<y;v++)x[v]=[v,0];i[d.id]=x}for(let v=0;v<y;v++){const A=x[v];A[0]=v,A[1]=h[v]}x.sort(op);for(let v=0;v<8;v++)v<y&&x[v][1]?(o[v][0]=x[v][0],o[v][1]=x[v][1]):(o[v][0]=Number.MAX_SAFE_INTEGER,o[v][1]=0);o.sort(ap);const m=d.morphAttributes.position,p=d.morphAttributes.normal;let _=0;for(let v=0;v<8;v++){const A=o[v],E=A[0],C=A[1];E!==Number.MAX_SAFE_INTEGER&&C?(m&&d.getAttribute("morphTarget"+v)!==m[E]&&d.setAttribute("morphTarget"+v,m[E]),p&&d.getAttribute("morphNormal"+v)!==p[E]&&d.setAttribute("morphNormal"+v,p[E]),r[v]=C,_+=C):(m&&d.hasAttribute("morphTarget"+v)===!0&&d.deleteAttribute("morphTarget"+v),p&&d.hasAttribute("morphNormal"+v)===!0&&d.deleteAttribute("morphNormal"+v),r[v]=0)}const g=d.morphTargetsRelative?1:1-_;u.getUniforms().setValue(n,"morphTargetBaseInfluence",g),u.getUniforms().setValue(n,"morphTargetInfluences",r)}}return{update:c}}function cp(n,e,t,i){let r=new WeakMap;function s(c){const l=i.render.frame,d=c.geometry,u=e.get(c,d);if(r.get(u)!==l&&(e.update(u),r.set(u,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),r.get(c)!==l&&(t.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,n.ARRAY_BUFFER),r.set(c,l))),c.isSkinnedMesh){const h=c.skeleton;r.get(h)!==l&&(h.update(),r.set(h,l))}return u}function a(){r=new WeakMap}function o(c){const l=c.target;l.removeEventListener("dispose",o),t.remove(l.instanceMatrix),l.instanceColor!==null&&t.remove(l.instanceColor)}return{update:s,dispose:a}}class Bc extends Bt{constructor(e,t,i,r,s,a,o,c,l,d){if(d=d!==void 0?d:ii,d!==ii&&d!==Wi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&d===ii&&(i=Ln),i===void 0&&d===Wi&&(i=ni),super(null,r,s,a,o,c,d,i,l),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:Lt,this.minFilter=c!==void 0?c:Lt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const Gc=new Bt,Hc=new Bc(1,1);Hc.compareFunction=Rc;const Vc=new zc,Wc=new qd,Xc=new kc,Rl=[],Cl=[],Pl=new Float32Array(16),Ll=new Float32Array(9),zl=new Float32Array(4);function Ji(n,e,t){const i=n[0];if(i<=0||i>0)return n;const r=e*t;let s=Rl[r];if(s===void 0&&(s=new Float32Array(r),Rl[r]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,n[a].toArray(s,o)}return s}function wt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function St(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function Rs(n,e){let t=Cl[e];t===void 0&&(t=new Int32Array(e),Cl[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function hp(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function dp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;n.uniform2fv(this.addr,e),St(t,e)}}function up(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(wt(t,e))return;n.uniform3fv(this.addr,e),St(t,e)}}function fp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;n.uniform4fv(this.addr,e),St(t,e)}}function pp(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(wt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),St(t,e)}else{if(wt(t,i))return;zl.set(i),n.uniformMatrix2fv(this.addr,!1,zl),St(t,i)}}function mp(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(wt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),St(t,e)}else{if(wt(t,i))return;Ll.set(i),n.uniformMatrix3fv(this.addr,!1,Ll),St(t,i)}}function gp(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(wt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),St(t,e)}else{if(wt(t,i))return;Pl.set(i),n.uniformMatrix4fv(this.addr,!1,Pl),St(t,i)}}function xp(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function _p(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;n.uniform2iv(this.addr,e),St(t,e)}}function yp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wt(t,e))return;n.uniform3iv(this.addr,e),St(t,e)}}function vp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;n.uniform4iv(this.addr,e),St(t,e)}}function Mp(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function bp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(wt(t,e))return;n.uniform2uiv(this.addr,e),St(t,e)}}function wp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(wt(t,e))return;n.uniform3uiv(this.addr,e),St(t,e)}}function Sp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(wt(t,e))return;n.uniform4uiv(this.addr,e),St(t,e)}}function Ep(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);const s=this.type===n.SAMPLER_2D_SHADOW?Hc:Gc;t.setTexture2D(e||s,r)}function Tp(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||Wc,r)}function Ap(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||Xc,r)}function Rp(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||Vc,r)}function Cp(n){switch(n){case 5126:return hp;case 35664:return dp;case 35665:return up;case 35666:return fp;case 35674:return pp;case 35675:return mp;case 35676:return gp;case 5124:case 35670:return xp;case 35667:case 35671:return _p;case 35668:case 35672:return yp;case 35669:case 35673:return vp;case 5125:return Mp;case 36294:return bp;case 36295:return wp;case 36296:return Sp;case 35678:case 36198:case 36298:case 36306:case 35682:return Ep;case 35679:case 36299:case 36307:return Tp;case 35680:case 36300:case 36308:case 36293:return Ap;case 36289:case 36303:case 36311:case 36292:return Rp}}function Pp(n,e){n.uniform1fv(this.addr,e)}function Lp(n,e){const t=Ji(e,this.size,2);n.uniform2fv(this.addr,t)}function zp(n,e){const t=Ji(e,this.size,3);n.uniform3fv(this.addr,t)}function Dp(n,e){const t=Ji(e,this.size,4);n.uniform4fv(this.addr,t)}function Ip(n,e){const t=Ji(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function Up(n,e){const t=Ji(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function Np(n,e){const t=Ji(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function Fp(n,e){n.uniform1iv(this.addr,e)}function kp(n,e){n.uniform2iv(this.addr,e)}function Op(n,e){n.uniform3iv(this.addr,e)}function Bp(n,e){n.uniform4iv(this.addr,e)}function Gp(n,e){n.uniform1uiv(this.addr,e)}function Hp(n,e){n.uniform2uiv(this.addr,e)}function Vp(n,e){n.uniform3uiv(this.addr,e)}function Wp(n,e){n.uniform4uiv(this.addr,e)}function Xp(n,e,t){const i=this.cache,r=e.length,s=Rs(t,r);wt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTexture2D(e[a]||Gc,s[a])}function qp(n,e,t){const i=this.cache,r=e.length,s=Rs(t,r);wt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||Wc,s[a])}function Yp(n,e,t){const i=this.cache,r=e.length,s=Rs(t,r);wt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||Xc,s[a])}function jp(n,e,t){const i=this.cache,r=e.length,s=Rs(t,r);wt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||Vc,s[a])}function Zp(n){switch(n){case 5126:return Pp;case 35664:return Lp;case 35665:return zp;case 35666:return Dp;case 35674:return Ip;case 35675:return Up;case 35676:return Np;case 5124:case 35670:return Fp;case 35667:case 35671:return kp;case 35668:case 35672:return Op;case 35669:case 35673:return Bp;case 5125:return Gp;case 36294:return Hp;case 36295:return Vp;case 36296:return Wp;case 35678:case 36198:case 36298:case 36306:case 35682:return Xp;case 35679:case 36299:case 36307:return qp;case 35680:case 36300:case 36308:case 36293:return Yp;case 36289:case 36303:case 36311:case 36292:return jp}}class Kp{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=Cp(t.type)}}class $p{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Zp(t.type)}}class Jp{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],i)}}}const _a=/(\w+)(\])?(\[|\.)?/g;function Dl(n,e){n.seq.push(e),n.map[e.id]=e}function Qp(n,e,t){const i=n.name,r=i.length;for(_a.lastIndex=0;;){const s=_a.exec(i),a=_a.lastIndex;let o=s[1];const c=s[2]==="]",l=s[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===r){Dl(t,l===void 0?new Kp(o,n,e):new $p(o,n,e));break}else{let u=t.map[o];u===void 0&&(u=new Jp(o),Dl(t,u)),t=u}}}class rs{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<i;++r){const s=e.getActiveUniform(t,r),a=e.getUniformLocation(t,s.name);Qp(s,a,this)}}setValue(e,t,i,r){const s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){const r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],c=i[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,r)}}static seqWithValue(e,t){const i=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&i.push(a)}return i}}function Il(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const em=37297;let tm=0;function nm(n,e){const t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;i.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return i.join(`
`)}function im(n){const e=rt.getPrimaries(rt.workingColorSpace),t=rt.getPrimaries(n);let i;switch(e===t?i="":e===us&&t===ds?i="LinearDisplayP3ToLinearSRGB":e===ds&&t===us&&(i="LinearSRGBToLinearDisplayP3"),n){case Sn:case Ts:return[i,"LinearTransferOETF"];case vt:case eo:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function Ul(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=n.getShaderInfoLog(e).trim();if(i&&r==="")return"";const s=/ERROR: 0:(\d+)/.exec(r);if(s){const a=parseInt(s[1]);return t.toUpperCase()+`

`+r+`

`+nm(n.getShaderSource(e),a)}else return r}function rm(n,e){const t=im(e);return`vec4 ${n}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function sm(n,e){let t;switch(e){case nd:t="Linear";break;case id:t="Reinhard";break;case rd:t="OptimizedCineon";break;case sd:t="ACESFilmic";break;case od:t="AgX";break;case ad:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function am(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ni).join(`
`)}function om(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ni).join(`
`)}function lm(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function cm(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const s=n.getActiveAttrib(e,r),a=s.name;let o=1;s.type===n.FLOAT_MAT2&&(o=2),s.type===n.FLOAT_MAT3&&(o=3),s.type===n.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:n.getAttribLocation(e,a),locationSize:o}}return t}function Ni(n){return n!==""}function Nl(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Fl(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const hm=/^[ \t]*#include +<([\w\d./]+)>/gm;function Oa(n){return n.replace(hm,um)}const dm=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function um(n,e){let t=Ye[e];if(t===void 0){const i=dm.get(e);if(i!==void 0)t=Ye[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return Oa(t)}const fm=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function kl(n){return n.replace(fm,pm)}function pm(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function Ol(n){let e="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function mm(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===xc?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===Ph?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===xn&&(e="SHADOWMAP_TYPE_VSM"),e}function gm(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Hi:case Vi:e="ENVMAP_TYPE_CUBE";break;case Es:e="ENVMAP_TYPE_CUBE_UV";break}return e}function xm(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Vi:e="ENVMAP_MODE_REFRACTION";break}return e}function _m(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Ja:e="ENVMAP_BLENDING_MULTIPLY";break;case ed:e="ENVMAP_BLENDING_MIX";break;case td:e="ENVMAP_BLENDING_ADD";break}return e}function ym(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function vm(n,e,t,i){const r=n.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const c=mm(t),l=gm(t),d=xm(t),u=_m(t),h=ym(t),f=t.isWebGL2?"":am(t),y=om(t),x=lm(s),m=r.createProgram();let p,_,g=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x].filter(Ni).join(`
`),p.length>0&&(p+=`
`),_=[f,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x].filter(Ni).join(`
`),_.length>0&&(_+=`
`)):(p=[Ol(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ni).join(`
`),_=[f,Ol(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+d:"",t.envMap?"#define "+u:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Un?"#define TONE_MAPPING":"",t.toneMapping!==Un?Ye.tonemapping_pars_fragment:"",t.toneMapping!==Un?sm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ye.colorspace_pars_fragment,rm("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ni).join(`
`)),a=Oa(a),a=Nl(a,t),a=Fl(a,t),o=Oa(o),o=Nl(o,t),o=Fl(o,t),a=kl(a),o=kl(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,p=[y,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+p,_=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===il?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===il?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+_);const v=g+p+a,A=g+_+o,E=Il(r,r.VERTEX_SHADER,v),C=Il(r,r.FRAGMENT_SHADER,A);r.attachShader(m,E),r.attachShader(m,C),t.index0AttributeName!==void 0?r.bindAttribLocation(m,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(m,0,"position"),r.linkProgram(m);function z(I){if(n.debug.checkShaderErrors){const H=r.getProgramInfoLog(m).trim(),L=r.getShaderInfoLog(E).trim(),U=r.getShaderInfoLog(C).trim();let O=!0,X=!0;if(r.getProgramParameter(m,r.LINK_STATUS)===!1)if(O=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,m,E,C);else{const Z=Ul(r,E,"vertex"),te=Ul(r,C,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(m,r.VALIDATE_STATUS)+`

Program Info Log: `+H+`
`+Z+`
`+te)}else H!==""?console.warn("THREE.WebGLProgram: Program Info Log:",H):(L===""||U==="")&&(X=!1);X&&(I.diagnostics={runnable:O,programLog:H,vertexShader:{log:L,prefix:p},fragmentShader:{log:U,prefix:_}})}r.deleteShader(E),r.deleteShader(C),M=new rs(r,m),b=cm(r,m)}let M;this.getUniforms=function(){return M===void 0&&z(this),M};let b;this.getAttributes=function(){return b===void 0&&z(this),b};let F=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return F===!1&&(F=r.getProgramParameter(m,em)),F},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(m),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=tm++,this.cacheKey=e,this.usedTimes=1,this.program=m,this.vertexShader=E,this.fragmentShader=C,this}let Mm=0;class bm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(r)===!1&&(a.add(r),r.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new wm(e),t.set(e,i)),i}}class wm{constructor(e){this.id=Mm++,this.code=e,this.usedTimes=0}}function Sm(n,e,t,i,r,s,a){const o=new no,c=new bm,l=[],d=r.isWebGL2,u=r.logarithmicDepthBuffer,h=r.vertexTextures;let f=r.precision;const y={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(M){return M===0?"uv":`uv${M}`}function m(M,b,F,I,H){const L=I.fog,U=H.geometry,O=M.isMeshStandardMaterial?I.environment:null,X=(M.isMeshStandardMaterial?t:e).get(M.envMap||O),Z=X&&X.mapping===Es?X.image.height:null,te=y[M.type];M.precision!==null&&(f=r.getMaxPrecision(M.precision),f!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",f,"instead."));const ie=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,de=ie!==void 0?ie.length:0;let ue=0;U.morphAttributes.position!==void 0&&(ue=1),U.morphAttributes.normal!==void 0&&(ue=2),U.morphAttributes.color!==void 0&&(ue=3);let J,se,ge,Re;if(te){const Dt=on[te];J=Dt.vertexShader,se=Dt.fragmentShader}else J=M.vertexShader,se=M.fragmentShader,c.update(M),ge=c.getVertexShaderID(M),Re=c.getFragmentShaderID(M);const Ee=n.getRenderTarget(),Be=H.isInstancedMesh===!0,He=H.isBatchedMesh===!0,Ie=!!M.map,S=!!M.matcap,w=!!X,V=!!M.aoMap,k=!!M.lightMap,ae=!!M.bumpMap,oe=!!M.normalMap,ee=!!M.displacementMap,me=!!M.emissiveMap,R=!!M.metalnessMap,T=!!M.roughnessMap,B=M.anisotropy>0,Q=M.clearcoat>0,j=M.iridescence>0,ne=M.sheen>0,ye=M.transmission>0,xe=B&&!!M.anisotropyMap,ve=Q&&!!M.clearcoatMap,Te=Q&&!!M.clearcoatNormalMap,Ue=Q&&!!M.clearcoatRoughnessMap,ce=j&&!!M.iridescenceMap,$e=j&&!!M.iridescenceThicknessMap,qe=ne&&!!M.sheenColorMap,Ne=ne&&!!M.sheenRoughnessMap,Pe=!!M.specularMap,be=!!M.specularColorMap,Fe=!!M.specularIntensityMap,re=ye&&!!M.transmissionMap,le=ye&&!!M.thicknessMap,fe=!!M.gradientMap,K=!!M.alphaMap,D=M.alphaTest>0,he=!!M.alphaHash,pe=!!M.extensions,Ae=!!U.attributes.uv1,Le=!!U.attributes.uv2,at=!!U.attributes.uv3;let ot=Un;return M.toneMapped&&(Ee===null||Ee.isXRRenderTarget===!0)&&(ot=n.toneMapping),{isWebGL2:d,shaderID:te,shaderType:M.type,shaderName:M.name,vertexShader:J,fragmentShader:se,defines:M.defines,customVertexShaderID:ge,customFragmentShaderID:Re,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:f,batching:He,instancing:Be,instancingColor:Be&&H.instanceColor!==null,supportsVertexTextures:h,outputColorSpace:Ee===null?n.outputColorSpace:Ee.isXRRenderTarget===!0?Ee.texture.colorSpace:Sn,map:Ie,matcap:S,envMap:w,envMapMode:w&&X.mapping,envMapCubeUVHeight:Z,aoMap:V,lightMap:k,bumpMap:ae,normalMap:oe,displacementMap:h&&ee,emissiveMap:me,normalMapObjectSpace:oe&&M.normalMapType===yd,normalMapTangentSpace:oe&&M.normalMapType===Ac,metalnessMap:R,roughnessMap:T,anisotropy:B,anisotropyMap:xe,clearcoat:Q,clearcoatMap:ve,clearcoatNormalMap:Te,clearcoatRoughnessMap:Ue,iridescence:j,iridescenceMap:ce,iridescenceThicknessMap:$e,sheen:ne,sheenColorMap:qe,sheenRoughnessMap:Ne,specularMap:Pe,specularColorMap:be,specularIntensityMap:Fe,transmission:ye,transmissionMap:re,thicknessMap:le,gradientMap:fe,opaque:M.transparent===!1&&M.blending===ki,alphaMap:K,alphaTest:D,alphaHash:he,combine:M.combine,mapUv:Ie&&x(M.map.channel),aoMapUv:V&&x(M.aoMap.channel),lightMapUv:k&&x(M.lightMap.channel),bumpMapUv:ae&&x(M.bumpMap.channel),normalMapUv:oe&&x(M.normalMap.channel),displacementMapUv:ee&&x(M.displacementMap.channel),emissiveMapUv:me&&x(M.emissiveMap.channel),metalnessMapUv:R&&x(M.metalnessMap.channel),roughnessMapUv:T&&x(M.roughnessMap.channel),anisotropyMapUv:xe&&x(M.anisotropyMap.channel),clearcoatMapUv:ve&&x(M.clearcoatMap.channel),clearcoatNormalMapUv:Te&&x(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&x(M.clearcoatRoughnessMap.channel),iridescenceMapUv:ce&&x(M.iridescenceMap.channel),iridescenceThicknessMapUv:$e&&x(M.iridescenceThicknessMap.channel),sheenColorMapUv:qe&&x(M.sheenColorMap.channel),sheenRoughnessMapUv:Ne&&x(M.sheenRoughnessMap.channel),specularMapUv:Pe&&x(M.specularMap.channel),specularColorMapUv:be&&x(M.specularColorMap.channel),specularIntensityMapUv:Fe&&x(M.specularIntensityMap.channel),transmissionMapUv:re&&x(M.transmissionMap.channel),thicknessMapUv:le&&x(M.thicknessMap.channel),alphaMapUv:K&&x(M.alphaMap.channel),vertexTangents:!!U.attributes.tangent&&(oe||B),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,vertexUv1s:Ae,vertexUv2s:Le,vertexUv3s:at,pointsUvs:H.isPoints===!0&&!!U.attributes.uv&&(Ie||K),fog:!!L,useFog:M.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:M.flatShading===!0,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:H.isSkinnedMesh===!0,morphTargets:U.morphAttributes.position!==void 0,morphNormals:U.morphAttributes.normal!==void 0,morphColors:U.morphAttributes.color!==void 0,morphTargetsCount:de,morphTextureStride:ue,numDirLights:b.directional.length,numPointLights:b.point.length,numSpotLights:b.spot.length,numSpotLightMaps:b.spotLightMap.length,numRectAreaLights:b.rectArea.length,numHemiLights:b.hemi.length,numDirLightShadows:b.directionalShadowMap.length,numPointLightShadows:b.pointShadowMap.length,numSpotLightShadows:b.spotShadowMap.length,numSpotLightShadowsWithMaps:b.numSpotLightShadowsWithMaps,numLightProbes:b.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:M.dithering,shadowMapEnabled:n.shadowMap.enabled&&F.length>0,shadowMapType:n.shadowMap.type,toneMapping:ot,useLegacyLights:n._useLegacyLights,decodeVideoTexture:Ie&&M.map.isVideoTexture===!0&&rt.getTransfer(M.map.colorSpace)===dt,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===bt,flipSided:M.side===Ot,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionDerivatives:pe&&M.extensions.derivatives===!0,extensionFragDepth:pe&&M.extensions.fragDepth===!0,extensionDrawBuffers:pe&&M.extensions.drawBuffers===!0,extensionShaderTextureLOD:pe&&M.extensions.shaderTextureLOD===!0,extensionClipCullDistance:pe&&M.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:d||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:d||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:d||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()}}function p(M){const b=[];if(M.shaderID?b.push(M.shaderID):(b.push(M.customVertexShaderID),b.push(M.customFragmentShaderID)),M.defines!==void 0)for(const F in M.defines)b.push(F),b.push(M.defines[F]);return M.isRawShaderMaterial===!1&&(_(b,M),g(b,M),b.push(n.outputColorSpace)),b.push(M.customProgramCacheKey),b.join()}function _(M,b){M.push(b.precision),M.push(b.outputColorSpace),M.push(b.envMapMode),M.push(b.envMapCubeUVHeight),M.push(b.mapUv),M.push(b.alphaMapUv),M.push(b.lightMapUv),M.push(b.aoMapUv),M.push(b.bumpMapUv),M.push(b.normalMapUv),M.push(b.displacementMapUv),M.push(b.emissiveMapUv),M.push(b.metalnessMapUv),M.push(b.roughnessMapUv),M.push(b.anisotropyMapUv),M.push(b.clearcoatMapUv),M.push(b.clearcoatNormalMapUv),M.push(b.clearcoatRoughnessMapUv),M.push(b.iridescenceMapUv),M.push(b.iridescenceThicknessMapUv),M.push(b.sheenColorMapUv),M.push(b.sheenRoughnessMapUv),M.push(b.specularMapUv),M.push(b.specularColorMapUv),M.push(b.specularIntensityMapUv),M.push(b.transmissionMapUv),M.push(b.thicknessMapUv),M.push(b.combine),M.push(b.fogExp2),M.push(b.sizeAttenuation),M.push(b.morphTargetsCount),M.push(b.morphAttributeCount),M.push(b.numDirLights),M.push(b.numPointLights),M.push(b.numSpotLights),M.push(b.numSpotLightMaps),M.push(b.numHemiLights),M.push(b.numRectAreaLights),M.push(b.numDirLightShadows),M.push(b.numPointLightShadows),M.push(b.numSpotLightShadows),M.push(b.numSpotLightShadowsWithMaps),M.push(b.numLightProbes),M.push(b.shadowMapType),M.push(b.toneMapping),M.push(b.numClippingPlanes),M.push(b.numClipIntersection),M.push(b.depthPacking)}function g(M,b){o.disableAll(),b.isWebGL2&&o.enable(0),b.supportsVertexTextures&&o.enable(1),b.instancing&&o.enable(2),b.instancingColor&&o.enable(3),b.matcap&&o.enable(4),b.envMap&&o.enable(5),b.normalMapObjectSpace&&o.enable(6),b.normalMapTangentSpace&&o.enable(7),b.clearcoat&&o.enable(8),b.iridescence&&o.enable(9),b.alphaTest&&o.enable(10),b.vertexColors&&o.enable(11),b.vertexAlphas&&o.enable(12),b.vertexUv1s&&o.enable(13),b.vertexUv2s&&o.enable(14),b.vertexUv3s&&o.enable(15),b.vertexTangents&&o.enable(16),b.anisotropy&&o.enable(17),b.alphaHash&&o.enable(18),b.batching&&o.enable(19),M.push(o.mask),o.disableAll(),b.fog&&o.enable(0),b.useFog&&o.enable(1),b.flatShading&&o.enable(2),b.logarithmicDepthBuffer&&o.enable(3),b.skinning&&o.enable(4),b.morphTargets&&o.enable(5),b.morphNormals&&o.enable(6),b.morphColors&&o.enable(7),b.premultipliedAlpha&&o.enable(8),b.shadowMapEnabled&&o.enable(9),b.useLegacyLights&&o.enable(10),b.doubleSided&&o.enable(11),b.flipSided&&o.enable(12),b.useDepthPacking&&o.enable(13),b.dithering&&o.enable(14),b.transmission&&o.enable(15),b.sheen&&o.enable(16),b.opaque&&o.enable(17),b.pointsUvs&&o.enable(18),b.decodeVideoTexture&&o.enable(19),M.push(o.mask)}function v(M){const b=y[M.type];let F;if(b){const I=on[b];F=su.clone(I.uniforms)}else F=M.uniforms;return F}function A(M,b){let F;for(let I=0,H=l.length;I<H;I++){const L=l[I];if(L.cacheKey===b){F=L,++F.usedTimes;break}}return F===void 0&&(F=new vm(n,b,M,s),l.push(F)),F}function E(M){if(--M.usedTimes===0){const b=l.indexOf(M);l[b]=l[l.length-1],l.pop(),M.destroy()}}function C(M){c.remove(M)}function z(){c.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:v,acquireProgram:A,releaseProgram:E,releaseShaderCache:C,programs:l,dispose:z}}function Em(){let n=new WeakMap;function e(s){let a=n.get(s);return a===void 0&&(a={},n.set(s,a)),a}function t(s){n.delete(s)}function i(s,a,o){n.get(s)[a]=o}function r(){n=new WeakMap}return{get:e,remove:t,update:i,dispose:r}}function Tm(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function Bl(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function Gl(){const n=[];let e=0;const t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function a(u,h,f,y,x,m){let p=n[e];return p===void 0?(p={id:u.id,object:u,geometry:h,material:f,groupOrder:y,renderOrder:u.renderOrder,z:x,group:m},n[e]=p):(p.id=u.id,p.object=u,p.geometry=h,p.material=f,p.groupOrder=y,p.renderOrder=u.renderOrder,p.z=x,p.group=m),e++,p}function o(u,h,f,y,x,m){const p=a(u,h,f,y,x,m);f.transmission>0?i.push(p):f.transparent===!0?r.push(p):t.push(p)}function c(u,h,f,y,x,m){const p=a(u,h,f,y,x,m);f.transmission>0?i.unshift(p):f.transparent===!0?r.unshift(p):t.unshift(p)}function l(u,h){t.length>1&&t.sort(u||Tm),i.length>1&&i.sort(h||Bl),r.length>1&&r.sort(h||Bl)}function d(){for(let u=e,h=n.length;u<h;u++){const f=n[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:o,unshift:c,finish:d,sort:l}}function Am(){let n=new WeakMap;function e(i,r){const s=n.get(i);let a;return s===void 0?(a=new Gl,n.set(i,[a])):r>=s.length?(a=new Gl,s.push(a)):a=s[r],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function Rm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new N,color:new Ke};break;case"SpotLight":t={position:new N,direction:new N,color:new Ke,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new N,color:new Ke,distance:0,decay:0};break;case"HemisphereLight":t={direction:new N,skyColor:new Ke,groundColor:new Ke};break;case"RectAreaLight":t={color:new Ke,position:new N,halfWidth:new N,halfHeight:new N};break}return n[e.id]=t,t}}}function Cm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let Pm=0;function Lm(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function zm(n,e){const t=new Rm,i=Cm(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)r.probe.push(new N);const s=new N,a=new et,o=new et;function c(d,u){let h=0,f=0,y=0;for(let I=0;I<9;I++)r.probe[I].set(0,0,0);let x=0,m=0,p=0,_=0,g=0,v=0,A=0,E=0,C=0,z=0,M=0;d.sort(Lm);const b=u===!0?Math.PI:1;for(let I=0,H=d.length;I<H;I++){const L=d[I],U=L.color,O=L.intensity,X=L.distance,Z=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)h+=U.r*O*b,f+=U.g*O*b,y+=U.b*O*b;else if(L.isLightProbe){for(let te=0;te<9;te++)r.probe[te].addScaledVector(L.sh.coefficients[te],O);M++}else if(L.isDirectionalLight){const te=t.get(L);if(te.color.copy(L.color).multiplyScalar(L.intensity*b),L.castShadow){const ie=L.shadow,de=i.get(L);de.shadowBias=ie.bias,de.shadowNormalBias=ie.normalBias,de.shadowRadius=ie.radius,de.shadowMapSize=ie.mapSize,r.directionalShadow[x]=de,r.directionalShadowMap[x]=Z,r.directionalShadowMatrix[x]=L.shadow.matrix,v++}r.directional[x]=te,x++}else if(L.isSpotLight){const te=t.get(L);te.position.setFromMatrixPosition(L.matrixWorld),te.color.copy(U).multiplyScalar(O*b),te.distance=X,te.coneCos=Math.cos(L.angle),te.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),te.decay=L.decay,r.spot[p]=te;const ie=L.shadow;if(L.map&&(r.spotLightMap[C]=L.map,C++,ie.updateMatrices(L),L.castShadow&&z++),r.spotLightMatrix[p]=ie.matrix,L.castShadow){const de=i.get(L);de.shadowBias=ie.bias,de.shadowNormalBias=ie.normalBias,de.shadowRadius=ie.radius,de.shadowMapSize=ie.mapSize,r.spotShadow[p]=de,r.spotShadowMap[p]=Z,E++}p++}else if(L.isRectAreaLight){const te=t.get(L);te.color.copy(U).multiplyScalar(O),te.halfWidth.set(L.width*.5,0,0),te.halfHeight.set(0,L.height*.5,0),r.rectArea[_]=te,_++}else if(L.isPointLight){const te=t.get(L);if(te.color.copy(L.color).multiplyScalar(L.intensity*b),te.distance=L.distance,te.decay=L.decay,L.castShadow){const ie=L.shadow,de=i.get(L);de.shadowBias=ie.bias,de.shadowNormalBias=ie.normalBias,de.shadowRadius=ie.radius,de.shadowMapSize=ie.mapSize,de.shadowCameraNear=ie.camera.near,de.shadowCameraFar=ie.camera.far,r.pointShadow[m]=de,r.pointShadowMap[m]=Z,r.pointShadowMatrix[m]=L.shadow.matrix,A++}r.point[m]=te,m++}else if(L.isHemisphereLight){const te=t.get(L);te.skyColor.copy(L.color).multiplyScalar(O*b),te.groundColor.copy(L.groundColor).multiplyScalar(O*b),r.hemi[g]=te,g++}}_>0&&(e.isWebGL2?n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_FLOAT_1,r.rectAreaLTC2=_e.LTC_FLOAT_2):(r.rectAreaLTC1=_e.LTC_HALF_1,r.rectAreaLTC2=_e.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_FLOAT_1,r.rectAreaLTC2=_e.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_HALF_1,r.rectAreaLTC2=_e.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),r.ambient[0]=h,r.ambient[1]=f,r.ambient[2]=y;const F=r.hash;(F.directionalLength!==x||F.pointLength!==m||F.spotLength!==p||F.rectAreaLength!==_||F.hemiLength!==g||F.numDirectionalShadows!==v||F.numPointShadows!==A||F.numSpotShadows!==E||F.numSpotMaps!==C||F.numLightProbes!==M)&&(r.directional.length=x,r.spot.length=p,r.rectArea.length=_,r.point.length=m,r.hemi.length=g,r.directionalShadow.length=v,r.directionalShadowMap.length=v,r.pointShadow.length=A,r.pointShadowMap.length=A,r.spotShadow.length=E,r.spotShadowMap.length=E,r.directionalShadowMatrix.length=v,r.pointShadowMatrix.length=A,r.spotLightMatrix.length=E+C-z,r.spotLightMap.length=C,r.numSpotLightShadowsWithMaps=z,r.numLightProbes=M,F.directionalLength=x,F.pointLength=m,F.spotLength=p,F.rectAreaLength=_,F.hemiLength=g,F.numDirectionalShadows=v,F.numPointShadows=A,F.numSpotShadows=E,F.numSpotMaps=C,F.numLightProbes=M,r.version=Pm++)}function l(d,u){let h=0,f=0,y=0,x=0,m=0;const p=u.matrixWorldInverse;for(let _=0,g=d.length;_<g;_++){const v=d[_];if(v.isDirectionalLight){const A=r.directional[h];A.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(p),h++}else if(v.isSpotLight){const A=r.spot[y];A.position.setFromMatrixPosition(v.matrixWorld),A.position.applyMatrix4(p),A.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),A.direction.sub(s),A.direction.transformDirection(p),y++}else if(v.isRectAreaLight){const A=r.rectArea[x];A.position.setFromMatrixPosition(v.matrixWorld),A.position.applyMatrix4(p),o.identity(),a.copy(v.matrixWorld),a.premultiply(p),o.extractRotation(a),A.halfWidth.set(v.width*.5,0,0),A.halfHeight.set(0,v.height*.5,0),A.halfWidth.applyMatrix4(o),A.halfHeight.applyMatrix4(o),x++}else if(v.isPointLight){const A=r.point[f];A.position.setFromMatrixPosition(v.matrixWorld),A.position.applyMatrix4(p),f++}else if(v.isHemisphereLight){const A=r.hemi[m];A.direction.setFromMatrixPosition(v.matrixWorld),A.direction.transformDirection(p),m++}}}return{setup:c,setupView:l,state:r}}function Hl(n,e){const t=new zm(n,e),i=[],r=[];function s(){i.length=0,r.length=0}function a(u){i.push(u)}function o(u){r.push(u)}function c(u){t.setup(i,u)}function l(u){t.setupView(i,u)}return{init:s,state:{lightsArray:i,shadowsArray:r,lights:t},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function Dm(n,e){let t=new WeakMap;function i(s,a=0){const o=t.get(s);let c;return o===void 0?(c=new Hl(n,e),t.set(s,[c])):a>=o.length?(c=new Hl(n,e),o.push(c)):c=o[a],c}function r(){t=new WeakMap}return{get:i,dispose:r}}class Im extends $i{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=xd,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Um extends $i{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Nm=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Fm=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function km(n,e,t){let i=new io;const r=new Oe,s=new Oe,a=new ft,o=new Im({depthPacking:_d}),c=new Um,l={},d=t.maxTextureSize,u={[wn]:Ot,[Ot]:wn,[bt]:bt},h=new oi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Oe},radius:{value:4}},vertexShader:Nm,fragmentShader:Fm}),f=h.clone();f.defines.HORIZONTAL_PASS=1;const y=new tt;y.setAttribute("position",new Qt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const x=new we(y,h),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=xc;let p=this.type;this.render=function(E,C,z){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||E.length===0)return;const M=n.getRenderTarget(),b=n.getActiveCubeFace(),F=n.getActiveMipmapLevel(),I=n.state;I.setBlending(In),I.buffers.color.setClear(1,1,1,1),I.buffers.depth.setTest(!0),I.setScissorTest(!1);const H=p!==xn&&this.type===xn,L=p===xn&&this.type!==xn;for(let U=0,O=E.length;U<O;U++){const X=E[U],Z=X.shadow;if(Z===void 0){console.warn("THREE.WebGLShadowMap:",X,"has no shadow.");continue}if(Z.autoUpdate===!1&&Z.needsUpdate===!1)continue;r.copy(Z.mapSize);const te=Z.getFrameExtents();if(r.multiply(te),s.copy(Z.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/te.x),r.x=s.x*te.x,Z.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/te.y),r.y=s.y*te.y,Z.mapSize.y=s.y)),Z.map===null||H===!0||L===!0){const de=this.type!==xn?{minFilter:Lt,magFilter:Lt}:{};Z.map!==null&&Z.map.dispose(),Z.map=new ai(r.x,r.y,de),Z.map.texture.name=X.name+".shadowMap",Z.camera.updateProjectionMatrix()}n.setRenderTarget(Z.map),n.clear();const ie=Z.getViewportCount();for(let de=0;de<ie;de++){const ue=Z.getViewport(de);a.set(s.x*ue.x,s.y*ue.y,s.x*ue.z,s.y*ue.w),I.viewport(a),Z.updateMatrices(X,de),i=Z.getFrustum(),v(C,z,Z.camera,X,this.type)}Z.isPointLightShadow!==!0&&this.type===xn&&_(Z,z),Z.needsUpdate=!1}p=this.type,m.needsUpdate=!1,n.setRenderTarget(M,b,F)};function _(E,C){const z=e.update(x);h.defines.VSM_SAMPLES!==E.blurSamples&&(h.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,h.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new ai(r.x,r.y)),h.uniforms.shadow_pass.value=E.map.texture,h.uniforms.resolution.value=E.mapSize,h.uniforms.radius.value=E.radius,n.setRenderTarget(E.mapPass),n.clear(),n.renderBufferDirect(C,null,z,h,x,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,n.setRenderTarget(E.map),n.clear(),n.renderBufferDirect(C,null,z,f,x,null)}function g(E,C,z,M){let b=null;const F=z.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(F!==void 0)b=F;else if(b=z.isPointLight===!0?c:o,n.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0){const I=b.uuid,H=C.uuid;let L=l[I];L===void 0&&(L={},l[I]=L);let U=L[H];U===void 0&&(U=b.clone(),L[H]=U,C.addEventListener("dispose",A)),b=U}if(b.visible=C.visible,b.wireframe=C.wireframe,M===xn?b.side=C.shadowSide!==null?C.shadowSide:C.side:b.side=C.shadowSide!==null?C.shadowSide:u[C.side],b.alphaMap=C.alphaMap,b.alphaTest=C.alphaTest,b.map=C.map,b.clipShadows=C.clipShadows,b.clippingPlanes=C.clippingPlanes,b.clipIntersection=C.clipIntersection,b.displacementMap=C.displacementMap,b.displacementScale=C.displacementScale,b.displacementBias=C.displacementBias,b.wireframeLinewidth=C.wireframeLinewidth,b.linewidth=C.linewidth,z.isPointLight===!0&&b.isMeshDistanceMaterial===!0){const I=n.properties.get(b);I.light=z}return b}function v(E,C,z,M,b){if(E.visible===!1)return;if(E.layers.test(C.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&b===xn)&&(!E.frustumCulled||i.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(z.matrixWorldInverse,E.matrixWorld);const H=e.update(E),L=E.material;if(Array.isArray(L)){const U=H.groups;for(let O=0,X=U.length;O<X;O++){const Z=U[O],te=L[Z.materialIndex];if(te&&te.visible){const ie=g(E,te,M,b);E.onBeforeShadow(n,E,C,z,H,ie,Z),n.renderBufferDirect(z,null,H,ie,E,Z),E.onAfterShadow(n,E,C,z,H,ie,Z)}}}else if(L.visible){const U=g(E,L,M,b);E.onBeforeShadow(n,E,C,z,H,U,null),n.renderBufferDirect(z,null,H,U,E,null),E.onAfterShadow(n,E,C,z,H,U,null)}}const I=E.children;for(let H=0,L=I.length;H<L;H++)v(I[H],C,z,M,b)}function A(E){E.target.removeEventListener("dispose",A);for(const z in l){const M=l[z],b=E.target.uuid;b in M&&(M[b].dispose(),delete M[b])}}}function Om(n,e,t){const i=t.isWebGL2;function r(){let D=!1;const he=new ft;let pe=null;const Ae=new ft(0,0,0,0);return{setMask:function(Le){pe!==Le&&!D&&(n.colorMask(Le,Le,Le,Le),pe=Le)},setLocked:function(Le){D=Le},setClear:function(Le,at,ot,Et,Dt){Dt===!0&&(Le*=Et,at*=Et,ot*=Et),he.set(Le,at,ot,Et),Ae.equals(he)===!1&&(n.clearColor(Le,at,ot,Et),Ae.copy(he))},reset:function(){D=!1,pe=null,Ae.set(-1,0,0,0)}}}function s(){let D=!1,he=null,pe=null,Ae=null;return{setTest:function(Le){Le?He(n.DEPTH_TEST):Ie(n.DEPTH_TEST)},setMask:function(Le){he!==Le&&!D&&(n.depthMask(Le),he=Le)},setFunc:function(Le){if(pe!==Le){switch(Le){case Yh:n.depthFunc(n.NEVER);break;case jh:n.depthFunc(n.ALWAYS);break;case Zh:n.depthFunc(n.LESS);break;case cs:n.depthFunc(n.LEQUAL);break;case Kh:n.depthFunc(n.EQUAL);break;case $h:n.depthFunc(n.GEQUAL);break;case Jh:n.depthFunc(n.GREATER);break;case Qh:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}pe=Le}},setLocked:function(Le){D=Le},setClear:function(Le){Ae!==Le&&(n.clearDepth(Le),Ae=Le)},reset:function(){D=!1,he=null,pe=null,Ae=null}}}function a(){let D=!1,he=null,pe=null,Ae=null,Le=null,at=null,ot=null,Et=null,Dt=null;return{setTest:function(lt){D||(lt?He(n.STENCIL_TEST):Ie(n.STENCIL_TEST))},setMask:function(lt){he!==lt&&!D&&(n.stencilMask(lt),he=lt)},setFunc:function(lt,It,an){(pe!==lt||Ae!==It||Le!==an)&&(n.stencilFunc(lt,It,an),pe=lt,Ae=It,Le=an)},setOp:function(lt,It,an){(at!==lt||ot!==It||Et!==an)&&(n.stencilOp(lt,It,an),at=lt,ot=It,Et=an)},setLocked:function(lt){D=lt},setClear:function(lt){Dt!==lt&&(n.clearStencil(lt),Dt=lt)},reset:function(){D=!1,he=null,pe=null,Ae=null,Le=null,at=null,ot=null,Et=null,Dt=null}}}const o=new r,c=new s,l=new a,d=new WeakMap,u=new WeakMap;let h={},f={},y=new WeakMap,x=[],m=null,p=!1,_=null,g=null,v=null,A=null,E=null,C=null,z=null,M=new Ke(0,0,0),b=0,F=!1,I=null,H=null,L=null,U=null,O=null;const X=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let Z=!1,te=0;const ie=n.getParameter(n.VERSION);ie.indexOf("WebGL")!==-1?(te=parseFloat(/^WebGL (\d)/.exec(ie)[1]),Z=te>=1):ie.indexOf("OpenGL ES")!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(ie)[1]),Z=te>=2);let de=null,ue={};const J=n.getParameter(n.SCISSOR_BOX),se=n.getParameter(n.VIEWPORT),ge=new ft().fromArray(J),Re=new ft().fromArray(se);function Ee(D,he,pe,Ae){const Le=new Uint8Array(4),at=n.createTexture();n.bindTexture(D,at),n.texParameteri(D,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(D,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let ot=0;ot<pe;ot++)i&&(D===n.TEXTURE_3D||D===n.TEXTURE_2D_ARRAY)?n.texImage3D(he,0,n.RGBA,1,1,Ae,0,n.RGBA,n.UNSIGNED_BYTE,Le):n.texImage2D(he+ot,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Le);return at}const Be={};Be[n.TEXTURE_2D]=Ee(n.TEXTURE_2D,n.TEXTURE_2D,1),Be[n.TEXTURE_CUBE_MAP]=Ee(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(Be[n.TEXTURE_2D_ARRAY]=Ee(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Be[n.TEXTURE_3D]=Ee(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),He(n.DEPTH_TEST),c.setFunc(cs),me(!1),R(So),He(n.CULL_FACE),oe(In);function He(D){h[D]!==!0&&(n.enable(D),h[D]=!0)}function Ie(D){h[D]!==!1&&(n.disable(D),h[D]=!1)}function S(D,he){return f[D]!==he?(n.bindFramebuffer(D,he),f[D]=he,i&&(D===n.DRAW_FRAMEBUFFER&&(f[n.FRAMEBUFFER]=he),D===n.FRAMEBUFFER&&(f[n.DRAW_FRAMEBUFFER]=he)),!0):!1}function w(D,he){let pe=x,Ae=!1;if(D)if(pe=y.get(he),pe===void 0&&(pe=[],y.set(he,pe)),D.isWebGLMultipleRenderTargets){const Le=D.texture;if(pe.length!==Le.length||pe[0]!==n.COLOR_ATTACHMENT0){for(let at=0,ot=Le.length;at<ot;at++)pe[at]=n.COLOR_ATTACHMENT0+at;pe.length=Le.length,Ae=!0}}else pe[0]!==n.COLOR_ATTACHMENT0&&(pe[0]=n.COLOR_ATTACHMENT0,Ae=!0);else pe[0]!==n.BACK&&(pe[0]=n.BACK,Ae=!0);Ae&&(t.isWebGL2?n.drawBuffers(pe):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(pe))}function V(D){return m!==D?(n.useProgram(D),m=D,!0):!1}const k={[Jn]:n.FUNC_ADD,[zh]:n.FUNC_SUBTRACT,[Dh]:n.FUNC_REVERSE_SUBTRACT};if(i)k[Ro]=n.MIN,k[Co]=n.MAX;else{const D=e.get("EXT_blend_minmax");D!==null&&(k[Ro]=D.MIN_EXT,k[Co]=D.MAX_EXT)}const ae={[Ih]:n.ZERO,[Uh]:n.ONE,[Nh]:n.SRC_COLOR,[Pa]:n.SRC_ALPHA,[Hh]:n.SRC_ALPHA_SATURATE,[Bh]:n.DST_COLOR,[kh]:n.DST_ALPHA,[Fh]:n.ONE_MINUS_SRC_COLOR,[La]:n.ONE_MINUS_SRC_ALPHA,[Gh]:n.ONE_MINUS_DST_COLOR,[Oh]:n.ONE_MINUS_DST_ALPHA,[Vh]:n.CONSTANT_COLOR,[Wh]:n.ONE_MINUS_CONSTANT_COLOR,[Xh]:n.CONSTANT_ALPHA,[qh]:n.ONE_MINUS_CONSTANT_ALPHA};function oe(D,he,pe,Ae,Le,at,ot,Et,Dt,lt){if(D===In){p===!0&&(Ie(n.BLEND),p=!1);return}if(p===!1&&(He(n.BLEND),p=!0),D!==Lh){if(D!==_||lt!==F){if((g!==Jn||E!==Jn)&&(n.blendEquation(n.FUNC_ADD),g=Jn,E=Jn),lt)switch(D){case ki:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Eo:n.blendFunc(n.ONE,n.ONE);break;case To:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Ao:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case ki:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case Eo:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case To:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case Ao:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}v=null,A=null,C=null,z=null,M.set(0,0,0),b=0,_=D,F=lt}return}Le=Le||he,at=at||pe,ot=ot||Ae,(he!==g||Le!==E)&&(n.blendEquationSeparate(k[he],k[Le]),g=he,E=Le),(pe!==v||Ae!==A||at!==C||ot!==z)&&(n.blendFuncSeparate(ae[pe],ae[Ae],ae[at],ae[ot]),v=pe,A=Ae,C=at,z=ot),(Et.equals(M)===!1||Dt!==b)&&(n.blendColor(Et.r,Et.g,Et.b,Dt),M.copy(Et),b=Dt),_=D,F=!1}function ee(D,he){D.side===bt?Ie(n.CULL_FACE):He(n.CULL_FACE);let pe=D.side===Ot;he&&(pe=!pe),me(pe),D.blending===ki&&D.transparent===!1?oe(In):oe(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),c.setFunc(D.depthFunc),c.setTest(D.depthTest),c.setMask(D.depthWrite),o.setMask(D.colorWrite);const Ae=D.stencilWrite;l.setTest(Ae),Ae&&(l.setMask(D.stencilWriteMask),l.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),l.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),B(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?He(n.SAMPLE_ALPHA_TO_COVERAGE):Ie(n.SAMPLE_ALPHA_TO_COVERAGE)}function me(D){I!==D&&(D?n.frontFace(n.CW):n.frontFace(n.CCW),I=D)}function R(D){D!==Rh?(He(n.CULL_FACE),D!==H&&(D===So?n.cullFace(n.BACK):D===Ch?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):Ie(n.CULL_FACE),H=D}function T(D){D!==L&&(Z&&n.lineWidth(D),L=D)}function B(D,he,pe){D?(He(n.POLYGON_OFFSET_FILL),(U!==he||O!==pe)&&(n.polygonOffset(he,pe),U=he,O=pe)):Ie(n.POLYGON_OFFSET_FILL)}function Q(D){D?He(n.SCISSOR_TEST):Ie(n.SCISSOR_TEST)}function j(D){D===void 0&&(D=n.TEXTURE0+X-1),de!==D&&(n.activeTexture(D),de=D)}function ne(D,he,pe){pe===void 0&&(de===null?pe=n.TEXTURE0+X-1:pe=de);let Ae=ue[pe];Ae===void 0&&(Ae={type:void 0,texture:void 0},ue[pe]=Ae),(Ae.type!==D||Ae.texture!==he)&&(de!==pe&&(n.activeTexture(pe),de=pe),n.bindTexture(D,he||Be[D]),Ae.type=D,Ae.texture=he)}function ye(){const D=ue[de];D!==void 0&&D.type!==void 0&&(n.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function xe(){try{n.compressedTexImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ve(){try{n.compressedTexImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Te(){try{n.texSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ue(){try{n.texSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ce(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function $e(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function qe(){try{n.texStorage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ne(){try{n.texStorage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Pe(){try{n.texImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function be(){try{n.texImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Fe(D){ge.equals(D)===!1&&(n.scissor(D.x,D.y,D.z,D.w),ge.copy(D))}function re(D){Re.equals(D)===!1&&(n.viewport(D.x,D.y,D.z,D.w),Re.copy(D))}function le(D,he){let pe=u.get(he);pe===void 0&&(pe=new WeakMap,u.set(he,pe));let Ae=pe.get(D);Ae===void 0&&(Ae=n.getUniformBlockIndex(he,D.name),pe.set(D,Ae))}function fe(D,he){const Ae=u.get(he).get(D);d.get(he)!==Ae&&(n.uniformBlockBinding(he,Ae,D.__bindingPointIndex),d.set(he,Ae))}function K(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),h={},de=null,ue={},f={},y=new WeakMap,x=[],m=null,p=!1,_=null,g=null,v=null,A=null,E=null,C=null,z=null,M=new Ke(0,0,0),b=0,F=!1,I=null,H=null,L=null,U=null,O=null,ge.set(0,0,n.canvas.width,n.canvas.height),Re.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:He,disable:Ie,bindFramebuffer:S,drawBuffers:w,useProgram:V,setBlending:oe,setMaterial:ee,setFlipSided:me,setCullFace:R,setLineWidth:T,setPolygonOffset:B,setScissorTest:Q,activeTexture:j,bindTexture:ne,unbindTexture:ye,compressedTexImage2D:xe,compressedTexImage3D:ve,texImage2D:Pe,texImage3D:be,updateUBOMapping:le,uniformBlockBinding:fe,texStorage2D:qe,texStorage3D:Ne,texSubImage2D:Te,texSubImage3D:Ue,compressedTexSubImage2D:ce,compressedTexSubImage3D:$e,scissor:Fe,viewport:re,reset:K}}function Bm(n,e,t,i,r,s,a){const o=r.isWebGL2,c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new WeakMap;let u;const h=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function y(R,T){return f?new OffscreenCanvas(R,T):ms("canvas")}function x(R,T,B,Q){let j=1;if((R.width>Q||R.height>Q)&&(j=Q/Math.max(R.width,R.height)),j<1||T===!0)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap){const ne=T?ps:Math.floor,ye=ne(j*R.width),xe=ne(j*R.height);u===void 0&&(u=y(ye,xe));const ve=B?y(ye,xe):u;return ve.width=ye,ve.height=xe,ve.getContext("2d").drawImage(R,0,0,ye,xe),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+R.width+"x"+R.height+") to ("+ye+"x"+xe+")."),ve}else return"data"in R&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+R.width+"x"+R.height+")."),R;return R}function m(R){return ka(R.width)&&ka(R.height)}function p(R){return o?!1:R.wrapS!==rn||R.wrapT!==rn||R.minFilter!==Lt&&R.minFilter!==Kt}function _(R,T){return R.generateMipmaps&&T&&R.minFilter!==Lt&&R.minFilter!==Kt}function g(R){n.generateMipmap(R)}function v(R,T,B,Q,j=!1){if(o===!1)return T;if(R!==null){if(n[R]!==void 0)return n[R];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let ne=T;if(T===n.RED&&(B===n.FLOAT&&(ne=n.R32F),B===n.HALF_FLOAT&&(ne=n.R16F),B===n.UNSIGNED_BYTE&&(ne=n.R8)),T===n.RED_INTEGER&&(B===n.UNSIGNED_BYTE&&(ne=n.R8UI),B===n.UNSIGNED_SHORT&&(ne=n.R16UI),B===n.UNSIGNED_INT&&(ne=n.R32UI),B===n.BYTE&&(ne=n.R8I),B===n.SHORT&&(ne=n.R16I),B===n.INT&&(ne=n.R32I)),T===n.RG&&(B===n.FLOAT&&(ne=n.RG32F),B===n.HALF_FLOAT&&(ne=n.RG16F),B===n.UNSIGNED_BYTE&&(ne=n.RG8)),T===n.RGBA){const ye=j?hs:rt.getTransfer(Q);B===n.FLOAT&&(ne=n.RGBA32F),B===n.HALF_FLOAT&&(ne=n.RGBA16F),B===n.UNSIGNED_BYTE&&(ne=ye===dt?n.SRGB8_ALPHA8:n.RGBA8),B===n.UNSIGNED_SHORT_4_4_4_4&&(ne=n.RGBA4),B===n.UNSIGNED_SHORT_5_5_5_1&&(ne=n.RGB5_A1)}return(ne===n.R16F||ne===n.R32F||ne===n.RG16F||ne===n.RG32F||ne===n.RGBA16F||ne===n.RGBA32F)&&e.get("EXT_color_buffer_float"),ne}function A(R,T,B){return _(R,B)===!0||R.isFramebufferTexture&&R.minFilter!==Lt&&R.minFilter!==Kt?Math.log2(Math.max(T.width,T.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?T.mipmaps.length:1}function E(R){return R===Lt||R===Po||R===Ws?n.NEAREST:n.LINEAR}function C(R){const T=R.target;T.removeEventListener("dispose",C),M(T),T.isVideoTexture&&d.delete(T)}function z(R){const T=R.target;T.removeEventListener("dispose",z),F(T)}function M(R){const T=i.get(R);if(T.__webglInit===void 0)return;const B=R.source,Q=h.get(B);if(Q){const j=Q[T.__cacheKey];j.usedTimes--,j.usedTimes===0&&b(R),Object.keys(Q).length===0&&h.delete(B)}i.remove(R)}function b(R){const T=i.get(R);n.deleteTexture(T.__webglTexture);const B=R.source,Q=h.get(B);delete Q[T.__cacheKey],a.memory.textures--}function F(R){const T=R.texture,B=i.get(R),Q=i.get(T);if(Q.__webglTexture!==void 0&&(n.deleteTexture(Q.__webglTexture),a.memory.textures--),R.depthTexture&&R.depthTexture.dispose(),R.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(B.__webglFramebuffer[j]))for(let ne=0;ne<B.__webglFramebuffer[j].length;ne++)n.deleteFramebuffer(B.__webglFramebuffer[j][ne]);else n.deleteFramebuffer(B.__webglFramebuffer[j]);B.__webglDepthbuffer&&n.deleteRenderbuffer(B.__webglDepthbuffer[j])}else{if(Array.isArray(B.__webglFramebuffer))for(let j=0;j<B.__webglFramebuffer.length;j++)n.deleteFramebuffer(B.__webglFramebuffer[j]);else n.deleteFramebuffer(B.__webglFramebuffer);if(B.__webglDepthbuffer&&n.deleteRenderbuffer(B.__webglDepthbuffer),B.__webglMultisampledFramebuffer&&n.deleteFramebuffer(B.__webglMultisampledFramebuffer),B.__webglColorRenderbuffer)for(let j=0;j<B.__webglColorRenderbuffer.length;j++)B.__webglColorRenderbuffer[j]&&n.deleteRenderbuffer(B.__webglColorRenderbuffer[j]);B.__webglDepthRenderbuffer&&n.deleteRenderbuffer(B.__webglDepthRenderbuffer)}if(R.isWebGLMultipleRenderTargets)for(let j=0,ne=T.length;j<ne;j++){const ye=i.get(T[j]);ye.__webglTexture&&(n.deleteTexture(ye.__webglTexture),a.memory.textures--),i.remove(T[j])}i.remove(T),i.remove(R)}let I=0;function H(){I=0}function L(){const R=I;return R>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+r.maxTextures),I+=1,R}function U(R){const T=[];return T.push(R.wrapS),T.push(R.wrapT),T.push(R.wrapR||0),T.push(R.magFilter),T.push(R.minFilter),T.push(R.anisotropy),T.push(R.internalFormat),T.push(R.format),T.push(R.type),T.push(R.generateMipmaps),T.push(R.premultiplyAlpha),T.push(R.flipY),T.push(R.unpackAlignment),T.push(R.colorSpace),T.join()}function O(R,T){const B=i.get(R);if(R.isVideoTexture&&ee(R),R.isRenderTargetTexture===!1&&R.version>0&&B.__version!==R.version){const Q=R.image;if(Q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ge(B,R,T);return}}t.bindTexture(n.TEXTURE_2D,B.__webglTexture,n.TEXTURE0+T)}function X(R,T){const B=i.get(R);if(R.version>0&&B.__version!==R.version){ge(B,R,T);return}t.bindTexture(n.TEXTURE_2D_ARRAY,B.__webglTexture,n.TEXTURE0+T)}function Z(R,T){const B=i.get(R);if(R.version>0&&B.__version!==R.version){ge(B,R,T);return}t.bindTexture(n.TEXTURE_3D,B.__webglTexture,n.TEXTURE0+T)}function te(R,T){const B=i.get(R);if(R.version>0&&B.__version!==R.version){Re(B,R,T);return}t.bindTexture(n.TEXTURE_CUBE_MAP,B.__webglTexture,n.TEXTURE0+T)}const ie={[Ia]:n.REPEAT,[rn]:n.CLAMP_TO_EDGE,[Ua]:n.MIRRORED_REPEAT},de={[Lt]:n.NEAREST,[Po]:n.NEAREST_MIPMAP_NEAREST,[Ws]:n.NEAREST_MIPMAP_LINEAR,[Kt]:n.LINEAR,[ld]:n.LINEAR_MIPMAP_NEAREST,[xr]:n.LINEAR_MIPMAP_LINEAR},ue={[vd]:n.NEVER,[Td]:n.ALWAYS,[Md]:n.LESS,[Rc]:n.LEQUAL,[bd]:n.EQUAL,[Ed]:n.GEQUAL,[wd]:n.GREATER,[Sd]:n.NOTEQUAL};function J(R,T,B){if(B?(n.texParameteri(R,n.TEXTURE_WRAP_S,ie[T.wrapS]),n.texParameteri(R,n.TEXTURE_WRAP_T,ie[T.wrapT]),(R===n.TEXTURE_3D||R===n.TEXTURE_2D_ARRAY)&&n.texParameteri(R,n.TEXTURE_WRAP_R,ie[T.wrapR]),n.texParameteri(R,n.TEXTURE_MAG_FILTER,de[T.magFilter]),n.texParameteri(R,n.TEXTURE_MIN_FILTER,de[T.minFilter])):(n.texParameteri(R,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(R,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(R===n.TEXTURE_3D||R===n.TEXTURE_2D_ARRAY)&&n.texParameteri(R,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(T.wrapS!==rn||T.wrapT!==rn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(R,n.TEXTURE_MAG_FILTER,E(T.magFilter)),n.texParameteri(R,n.TEXTURE_MIN_FILTER,E(T.minFilter)),T.minFilter!==Lt&&T.minFilter!==Kt&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),T.compareFunction&&(n.texParameteri(R,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(R,n.TEXTURE_COMPARE_FUNC,ue[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){const Q=e.get("EXT_texture_filter_anisotropic");if(T.magFilter===Lt||T.minFilter!==Ws&&T.minFilter!==xr||T.type===zn&&e.has("OES_texture_float_linear")===!1||o===!1&&T.type===_r&&e.has("OES_texture_half_float_linear")===!1)return;(T.anisotropy>1||i.get(T).__currentAnisotropy)&&(n.texParameterf(R,Q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,r.getMaxAnisotropy())),i.get(T).__currentAnisotropy=T.anisotropy)}}function se(R,T){let B=!1;R.__webglInit===void 0&&(R.__webglInit=!0,T.addEventListener("dispose",C));const Q=T.source;let j=h.get(Q);j===void 0&&(j={},h.set(Q,j));const ne=U(T);if(ne!==R.__cacheKey){j[ne]===void 0&&(j[ne]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,B=!0),j[ne].usedTimes++;const ye=j[R.__cacheKey];ye!==void 0&&(j[R.__cacheKey].usedTimes--,ye.usedTimes===0&&b(T)),R.__cacheKey=ne,R.__webglTexture=j[ne].texture}return B}function ge(R,T,B){let Q=n.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(Q=n.TEXTURE_2D_ARRAY),T.isData3DTexture&&(Q=n.TEXTURE_3D);const j=se(R,T),ne=T.source;t.bindTexture(Q,R.__webglTexture,n.TEXTURE0+B);const ye=i.get(ne);if(ne.version!==ye.__version||j===!0){t.activeTexture(n.TEXTURE0+B);const xe=rt.getPrimaries(rt.workingColorSpace),ve=T.colorSpace===Jt?null:rt.getPrimaries(T.colorSpace),Te=T.colorSpace===Jt||xe===ve?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,T.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,T.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Te);const Ue=p(T)&&m(T.image)===!1;let ce=x(T.image,Ue,!1,r.maxTextureSize);ce=me(T,ce);const $e=m(ce)||o,qe=s.convert(T.format,T.colorSpace);let Ne=s.convert(T.type),Pe=v(T.internalFormat,qe,Ne,T.colorSpace,T.isVideoTexture);J(Q,T,$e);let be;const Fe=T.mipmaps,re=o&&T.isVideoTexture!==!0&&Pe!==Ec,le=ye.__version===void 0||j===!0,fe=A(T,ce,$e);if(T.isDepthTexture)Pe=n.DEPTH_COMPONENT,o?T.type===zn?Pe=n.DEPTH_COMPONENT32F:T.type===Ln?Pe=n.DEPTH_COMPONENT24:T.type===ni?Pe=n.DEPTH24_STENCIL8:Pe=n.DEPTH_COMPONENT16:T.type===zn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),T.format===ii&&Pe===n.DEPTH_COMPONENT&&T.type!==Qa&&T.type!==Ln&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),T.type=Ln,Ne=s.convert(T.type)),T.format===Wi&&Pe===n.DEPTH_COMPONENT&&(Pe=n.DEPTH_STENCIL,T.type!==ni&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),T.type=ni,Ne=s.convert(T.type))),le&&(re?t.texStorage2D(n.TEXTURE_2D,1,Pe,ce.width,ce.height):t.texImage2D(n.TEXTURE_2D,0,Pe,ce.width,ce.height,0,qe,Ne,null));else if(T.isDataTexture)if(Fe.length>0&&$e){re&&le&&t.texStorage2D(n.TEXTURE_2D,fe,Pe,Fe[0].width,Fe[0].height);for(let K=0,D=Fe.length;K<D;K++)be=Fe[K],re?t.texSubImage2D(n.TEXTURE_2D,K,0,0,be.width,be.height,qe,Ne,be.data):t.texImage2D(n.TEXTURE_2D,K,Pe,be.width,be.height,0,qe,Ne,be.data);T.generateMipmaps=!1}else re?(le&&t.texStorage2D(n.TEXTURE_2D,fe,Pe,ce.width,ce.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,ce.width,ce.height,qe,Ne,ce.data)):t.texImage2D(n.TEXTURE_2D,0,Pe,ce.width,ce.height,0,qe,Ne,ce.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){re&&le&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Pe,Fe[0].width,Fe[0].height,ce.depth);for(let K=0,D=Fe.length;K<D;K++)be=Fe[K],T.format!==sn?qe!==null?re?t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,K,0,0,0,be.width,be.height,ce.depth,qe,be.data,0,0):t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,K,Pe,be.width,be.height,ce.depth,0,be.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?t.texSubImage3D(n.TEXTURE_2D_ARRAY,K,0,0,0,be.width,be.height,ce.depth,qe,Ne,be.data):t.texImage3D(n.TEXTURE_2D_ARRAY,K,Pe,be.width,be.height,ce.depth,0,qe,Ne,be.data)}else{re&&le&&t.texStorage2D(n.TEXTURE_2D,fe,Pe,Fe[0].width,Fe[0].height);for(let K=0,D=Fe.length;K<D;K++)be=Fe[K],T.format!==sn?qe!==null?re?t.compressedTexSubImage2D(n.TEXTURE_2D,K,0,0,be.width,be.height,qe,be.data):t.compressedTexImage2D(n.TEXTURE_2D,K,Pe,be.width,be.height,0,be.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?t.texSubImage2D(n.TEXTURE_2D,K,0,0,be.width,be.height,qe,Ne,be.data):t.texImage2D(n.TEXTURE_2D,K,Pe,be.width,be.height,0,qe,Ne,be.data)}else if(T.isDataArrayTexture)re?(le&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Pe,ce.width,ce.height,ce.depth),t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,ce.width,ce.height,ce.depth,qe,Ne,ce.data)):t.texImage3D(n.TEXTURE_2D_ARRAY,0,Pe,ce.width,ce.height,ce.depth,0,qe,Ne,ce.data);else if(T.isData3DTexture)re?(le&&t.texStorage3D(n.TEXTURE_3D,fe,Pe,ce.width,ce.height,ce.depth),t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,ce.width,ce.height,ce.depth,qe,Ne,ce.data)):t.texImage3D(n.TEXTURE_3D,0,Pe,ce.width,ce.height,ce.depth,0,qe,Ne,ce.data);else if(T.isFramebufferTexture){if(le)if(re)t.texStorage2D(n.TEXTURE_2D,fe,Pe,ce.width,ce.height);else{let K=ce.width,D=ce.height;for(let he=0;he<fe;he++)t.texImage2D(n.TEXTURE_2D,he,Pe,K,D,0,qe,Ne,null),K>>=1,D>>=1}}else if(Fe.length>0&&$e){re&&le&&t.texStorage2D(n.TEXTURE_2D,fe,Pe,Fe[0].width,Fe[0].height);for(let K=0,D=Fe.length;K<D;K++)be=Fe[K],re?t.texSubImage2D(n.TEXTURE_2D,K,0,0,qe,Ne,be):t.texImage2D(n.TEXTURE_2D,K,Pe,qe,Ne,be);T.generateMipmaps=!1}else re?(le&&t.texStorage2D(n.TEXTURE_2D,fe,Pe,ce.width,ce.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,qe,Ne,ce)):t.texImage2D(n.TEXTURE_2D,0,Pe,qe,Ne,ce);_(T,$e)&&g(Q),ye.__version=ne.version,T.onUpdate&&T.onUpdate(T)}R.__version=T.version}function Re(R,T,B){if(T.image.length!==6)return;const Q=se(R,T),j=T.source;t.bindTexture(n.TEXTURE_CUBE_MAP,R.__webglTexture,n.TEXTURE0+B);const ne=i.get(j);if(j.version!==ne.__version||Q===!0){t.activeTexture(n.TEXTURE0+B);const ye=rt.getPrimaries(rt.workingColorSpace),xe=T.colorSpace===Jt?null:rt.getPrimaries(T.colorSpace),ve=T.colorSpace===Jt||ye===xe?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,T.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,T.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,ve);const Te=T.isCompressedTexture||T.image[0].isCompressedTexture,Ue=T.image[0]&&T.image[0].isDataTexture,ce=[];for(let K=0;K<6;K++)!Te&&!Ue?ce[K]=x(T.image[K],!1,!0,r.maxCubemapSize):ce[K]=Ue?T.image[K].image:T.image[K],ce[K]=me(T,ce[K]);const $e=ce[0],qe=m($e)||o,Ne=s.convert(T.format,T.colorSpace),Pe=s.convert(T.type),be=v(T.internalFormat,Ne,Pe,T.colorSpace),Fe=o&&T.isVideoTexture!==!0,re=ne.__version===void 0||Q===!0;let le=A(T,$e,qe);J(n.TEXTURE_CUBE_MAP,T,qe);let fe;if(Te){Fe&&re&&t.texStorage2D(n.TEXTURE_CUBE_MAP,le,be,$e.width,$e.height);for(let K=0;K<6;K++){fe=ce[K].mipmaps;for(let D=0;D<fe.length;D++){const he=fe[D];T.format!==sn?Ne!==null?Fe?t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D,0,0,he.width,he.height,Ne,he.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D,be,he.width,he.height,0,he.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Fe?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D,0,0,he.width,he.height,Ne,Pe,he.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D,be,he.width,he.height,0,Ne,Pe,he.data)}}}else{fe=T.mipmaps,Fe&&re&&(fe.length>0&&le++,t.texStorage2D(n.TEXTURE_CUBE_MAP,le,be,ce[0].width,ce[0].height));for(let K=0;K<6;K++)if(Ue){Fe?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,0,0,ce[K].width,ce[K].height,Ne,Pe,ce[K].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,be,ce[K].width,ce[K].height,0,Ne,Pe,ce[K].data);for(let D=0;D<fe.length;D++){const pe=fe[D].image[K].image;Fe?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D+1,0,0,pe.width,pe.height,Ne,Pe,pe.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D+1,be,pe.width,pe.height,0,Ne,Pe,pe.data)}}else{Fe?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,0,0,Ne,Pe,ce[K]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,0,be,Ne,Pe,ce[K]);for(let D=0;D<fe.length;D++){const he=fe[D];Fe?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D+1,0,0,Ne,Pe,he.image[K]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+K,D+1,be,Ne,Pe,he.image[K])}}}_(T,qe)&&g(n.TEXTURE_CUBE_MAP),ne.__version=j.version,T.onUpdate&&T.onUpdate(T)}R.__version=T.version}function Ee(R,T,B,Q,j,ne){const ye=s.convert(B.format,B.colorSpace),xe=s.convert(B.type),ve=v(B.internalFormat,ye,xe,B.colorSpace);if(!i.get(T).__hasExternalTextures){const Ue=Math.max(1,T.width>>ne),ce=Math.max(1,T.height>>ne);j===n.TEXTURE_3D||j===n.TEXTURE_2D_ARRAY?t.texImage3D(j,ne,ve,Ue,ce,T.depth,0,ye,xe,null):t.texImage2D(j,ne,ve,Ue,ce,0,ye,xe,null)}t.bindFramebuffer(n.FRAMEBUFFER,R),oe(T)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,Q,j,i.get(B).__webglTexture,0,ae(T)):(j===n.TEXTURE_2D||j>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&j<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,Q,j,i.get(B).__webglTexture,ne),t.bindFramebuffer(n.FRAMEBUFFER,null)}function Be(R,T,B){if(n.bindRenderbuffer(n.RENDERBUFFER,R),T.depthBuffer&&!T.stencilBuffer){let Q=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(B||oe(T)){const j=T.depthTexture;j&&j.isDepthTexture&&(j.type===zn?Q=n.DEPTH_COMPONENT32F:j.type===Ln&&(Q=n.DEPTH_COMPONENT24));const ne=ae(T);oe(T)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,ne,Q,T.width,T.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,ne,Q,T.width,T.height)}else n.renderbufferStorage(n.RENDERBUFFER,Q,T.width,T.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,R)}else if(T.depthBuffer&&T.stencilBuffer){const Q=ae(T);B&&oe(T)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Q,n.DEPTH24_STENCIL8,T.width,T.height):oe(T)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Q,n.DEPTH24_STENCIL8,T.width,T.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,T.width,T.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,R)}else{const Q=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let j=0;j<Q.length;j++){const ne=Q[j],ye=s.convert(ne.format,ne.colorSpace),xe=s.convert(ne.type),ve=v(ne.internalFormat,ye,xe,ne.colorSpace),Te=ae(T);B&&oe(T)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Te,ve,T.width,T.height):oe(T)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Te,ve,T.width,T.height):n.renderbufferStorage(n.RENDERBUFFER,ve,T.width,T.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function He(R,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,R),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(T.depthTexture).__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),O(T.depthTexture,0);const Q=i.get(T.depthTexture).__webglTexture,j=ae(T);if(T.depthTexture.format===ii)oe(T)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Q,0,j):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Q,0);else if(T.depthTexture.format===Wi)oe(T)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Q,0,j):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Q,0);else throw new Error("Unknown depthTexture format")}function Ie(R){const T=i.get(R),B=R.isWebGLCubeRenderTarget===!0;if(R.depthTexture&&!T.__autoAllocateDepthBuffer){if(B)throw new Error("target.depthTexture not supported in Cube render targets");He(T.__webglFramebuffer,R)}else if(B){T.__webglDepthbuffer=[];for(let Q=0;Q<6;Q++)t.bindFramebuffer(n.FRAMEBUFFER,T.__webglFramebuffer[Q]),T.__webglDepthbuffer[Q]=n.createRenderbuffer(),Be(T.__webglDepthbuffer[Q],R,!1)}else t.bindFramebuffer(n.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer=n.createRenderbuffer(),Be(T.__webglDepthbuffer,R,!1);t.bindFramebuffer(n.FRAMEBUFFER,null)}function S(R,T,B){const Q=i.get(R);T!==void 0&&Ee(Q.__webglFramebuffer,R,R.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),B!==void 0&&Ie(R)}function w(R){const T=R.texture,B=i.get(R),Q=i.get(T);R.addEventListener("dispose",z),R.isWebGLMultipleRenderTargets!==!0&&(Q.__webglTexture===void 0&&(Q.__webglTexture=n.createTexture()),Q.__version=T.version,a.memory.textures++);const j=R.isWebGLCubeRenderTarget===!0,ne=R.isWebGLMultipleRenderTargets===!0,ye=m(R)||o;if(j){B.__webglFramebuffer=[];for(let xe=0;xe<6;xe++)if(o&&T.mipmaps&&T.mipmaps.length>0){B.__webglFramebuffer[xe]=[];for(let ve=0;ve<T.mipmaps.length;ve++)B.__webglFramebuffer[xe][ve]=n.createFramebuffer()}else B.__webglFramebuffer[xe]=n.createFramebuffer()}else{if(o&&T.mipmaps&&T.mipmaps.length>0){B.__webglFramebuffer=[];for(let xe=0;xe<T.mipmaps.length;xe++)B.__webglFramebuffer[xe]=n.createFramebuffer()}else B.__webglFramebuffer=n.createFramebuffer();if(ne)if(r.drawBuffers){const xe=R.texture;for(let ve=0,Te=xe.length;ve<Te;ve++){const Ue=i.get(xe[ve]);Ue.__webglTexture===void 0&&(Ue.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&R.samples>0&&oe(R)===!1){const xe=ne?T:[T];B.__webglMultisampledFramebuffer=n.createFramebuffer(),B.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,B.__webglMultisampledFramebuffer);for(let ve=0;ve<xe.length;ve++){const Te=xe[ve];B.__webglColorRenderbuffer[ve]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,B.__webglColorRenderbuffer[ve]);const Ue=s.convert(Te.format,Te.colorSpace),ce=s.convert(Te.type),$e=v(Te.internalFormat,Ue,ce,Te.colorSpace,R.isXRRenderTarget===!0),qe=ae(R);n.renderbufferStorageMultisample(n.RENDERBUFFER,qe,$e,R.width,R.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ve,n.RENDERBUFFER,B.__webglColorRenderbuffer[ve])}n.bindRenderbuffer(n.RENDERBUFFER,null),R.depthBuffer&&(B.__webglDepthRenderbuffer=n.createRenderbuffer(),Be(B.__webglDepthRenderbuffer,R,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(j){t.bindTexture(n.TEXTURE_CUBE_MAP,Q.__webglTexture),J(n.TEXTURE_CUBE_MAP,T,ye);for(let xe=0;xe<6;xe++)if(o&&T.mipmaps&&T.mipmaps.length>0)for(let ve=0;ve<T.mipmaps.length;ve++)Ee(B.__webglFramebuffer[xe][ve],R,T,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,ve);else Ee(B.__webglFramebuffer[xe],R,T,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0);_(T,ye)&&g(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ne){const xe=R.texture;for(let ve=0,Te=xe.length;ve<Te;ve++){const Ue=xe[ve],ce=i.get(Ue);t.bindTexture(n.TEXTURE_2D,ce.__webglTexture),J(n.TEXTURE_2D,Ue,ye),Ee(B.__webglFramebuffer,R,Ue,n.COLOR_ATTACHMENT0+ve,n.TEXTURE_2D,0),_(Ue,ye)&&g(n.TEXTURE_2D)}t.unbindTexture()}else{let xe=n.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(o?xe=R.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(xe,Q.__webglTexture),J(xe,T,ye),o&&T.mipmaps&&T.mipmaps.length>0)for(let ve=0;ve<T.mipmaps.length;ve++)Ee(B.__webglFramebuffer[ve],R,T,n.COLOR_ATTACHMENT0,xe,ve);else Ee(B.__webglFramebuffer,R,T,n.COLOR_ATTACHMENT0,xe,0);_(T,ye)&&g(xe),t.unbindTexture()}R.depthBuffer&&Ie(R)}function V(R){const T=m(R)||o,B=R.isWebGLMultipleRenderTargets===!0?R.texture:[R.texture];for(let Q=0,j=B.length;Q<j;Q++){const ne=B[Q];if(_(ne,T)){const ye=R.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,xe=i.get(ne).__webglTexture;t.bindTexture(ye,xe),g(ye),t.unbindTexture()}}}function k(R){if(o&&R.samples>0&&oe(R)===!1){const T=R.isWebGLMultipleRenderTargets?R.texture:[R.texture],B=R.width,Q=R.height;let j=n.COLOR_BUFFER_BIT;const ne=[],ye=R.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,xe=i.get(R),ve=R.isWebGLMultipleRenderTargets===!0;if(ve)for(let Te=0;Te<T.length;Te++)t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Te,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Te,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,xe.__webglMultisampledFramebuffer),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,xe.__webglFramebuffer);for(let Te=0;Te<T.length;Te++){ne.push(n.COLOR_ATTACHMENT0+Te),R.depthBuffer&&ne.push(ye);const Ue=xe.__ignoreDepthValues!==void 0?xe.__ignoreDepthValues:!1;if(Ue===!1&&(R.depthBuffer&&(j|=n.DEPTH_BUFFER_BIT),R.stencilBuffer&&(j|=n.STENCIL_BUFFER_BIT)),ve&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,xe.__webglColorRenderbuffer[Te]),Ue===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[ye]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[ye])),ve){const ce=i.get(T[Te]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,ce,0)}n.blitFramebuffer(0,0,B,Q,0,0,B,Q,j,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,ne)}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),ve)for(let Te=0;Te<T.length;Te++){t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Te,n.RENDERBUFFER,xe.__webglColorRenderbuffer[Te]);const Ue=i.get(T[Te]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Te,n.TEXTURE_2D,Ue,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,xe.__webglMultisampledFramebuffer)}}function ae(R){return Math.min(r.maxSamples,R.samples)}function oe(R){const T=i.get(R);return o&&R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function ee(R){const T=a.render.frame;d.get(R)!==T&&(d.set(R,T),R.update())}function me(R,T){const B=R.colorSpace,Q=R.format,j=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||R.format===Fa||B!==Sn&&B!==Jt&&(rt.getTransfer(B)===dt?o===!1?e.has("EXT_sRGB")===!0&&Q===sn?(R.format=Fa,R.minFilter=Kt,R.generateMipmaps=!1):T=Pc.sRGBToLinear(T):(Q!==sn||j!==Nn)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",B)),T}this.allocateTextureUnit=L,this.resetTextureUnits=H,this.setTexture2D=O,this.setTexture2DArray=X,this.setTexture3D=Z,this.setTextureCube=te,this.rebindTextures=S,this.setupRenderTarget=w,this.updateRenderTargetMipmap=V,this.updateMultisampleRenderTarget=k,this.setupDepthRenderbuffer=Ie,this.setupFrameBufferTexture=Ee,this.useMultisampledRTT=oe}function Gm(n,e,t){const i=t.isWebGL2;function r(s,a=Jt){let o;const c=rt.getTransfer(a);if(s===Nn)return n.UNSIGNED_BYTE;if(s===vc)return n.UNSIGNED_SHORT_4_4_4_4;if(s===Mc)return n.UNSIGNED_SHORT_5_5_5_1;if(s===cd)return n.BYTE;if(s===hd)return n.SHORT;if(s===Qa)return n.UNSIGNED_SHORT;if(s===yc)return n.INT;if(s===Ln)return n.UNSIGNED_INT;if(s===zn)return n.FLOAT;if(s===_r)return i?n.HALF_FLOAT:(o=e.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(s===dd)return n.ALPHA;if(s===sn)return n.RGBA;if(s===ud)return n.LUMINANCE;if(s===fd)return n.LUMINANCE_ALPHA;if(s===ii)return n.DEPTH_COMPONENT;if(s===Wi)return n.DEPTH_STENCIL;if(s===Fa)return o=e.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(s===pd)return n.RED;if(s===bc)return n.RED_INTEGER;if(s===md)return n.RG;if(s===wc)return n.RG_INTEGER;if(s===Sc)return n.RGBA_INTEGER;if(s===Xs||s===qs||s===Ys||s===js)if(c===dt)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(s===Xs)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===qs)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===Ys)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===js)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(s===Xs)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===qs)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===Ys)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===js)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Lo||s===zo||s===Do||s===Io)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(s===Lo)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===zo)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Do)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===Io)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===Ec)return o=e.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===Uo||s===No)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(s===Uo)return c===dt?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(s===No)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Fo||s===ko||s===Oo||s===Bo||s===Go||s===Ho||s===Vo||s===Wo||s===Xo||s===qo||s===Yo||s===jo||s===Zo||s===Ko)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(s===Fo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===ko)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Oo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Bo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Go)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Ho)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Vo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Wo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===Xo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===qo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Yo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===jo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Zo)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Ko)return c===dt?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Zs||s===$o||s===Jo)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(s===Zs)return c===dt?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===$o)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Jo)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===gd||s===Qo||s===el||s===tl)if(o=e.get("EXT_texture_compression_rgtc"),o!==null){if(s===Zs)return o.COMPRESSED_RED_RGTC1_EXT;if(s===Qo)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===el)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===tl)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===ni?i?n.UNSIGNED_INT_24_8:(o=e.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[s]!==void 0?n[s]:null}return{convert:r}}class Hm extends Xt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class nt extends mt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Vm={type:"move"};class ya{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new nt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new nt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new N,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new N),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new nt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new N,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new N),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,a=null;const o=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){a=!0;for(const x of e.hand.values()){const m=t.getJointPose(x,i),p=this._getHandJoint(l,x);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const d=l.joints["index-finger-tip"],u=l.joints["thumb-tip"],h=d.position.distanceTo(u.position),f=.02,y=.005;l.inputState.pinching&&h>f+y?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&h<=f-y&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Vm)))}return o!==null&&(o.visible=r!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new nt;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class Wm extends Ki{constructor(e,t){super();const i=this;let r=null,s=1,a=null,o="local-floor",c=1,l=null,d=null,u=null,h=null,f=null,y=null;const x=t.getContextAttributes();let m=null,p=null;const _=[],g=[],v=new Oe;let A=null;const E=new Xt;E.layers.enable(1),E.viewport=new ft;const C=new Xt;C.layers.enable(2),C.viewport=new ft;const z=[E,C],M=new Hm;M.layers.enable(1),M.layers.enable(2);let b=null,F=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let se=_[J];return se===void 0&&(se=new ya,_[J]=se),se.getTargetRaySpace()},this.getControllerGrip=function(J){let se=_[J];return se===void 0&&(se=new ya,_[J]=se),se.getGripSpace()},this.getHand=function(J){let se=_[J];return se===void 0&&(se=new ya,_[J]=se),se.getHandSpace()};function I(J){const se=g.indexOf(J.inputSource);if(se===-1)return;const ge=_[se];ge!==void 0&&(ge.update(J.inputSource,J.frame,l||a),ge.dispatchEvent({type:J.type,data:J.inputSource}))}function H(){r.removeEventListener("select",I),r.removeEventListener("selectstart",I),r.removeEventListener("selectend",I),r.removeEventListener("squeeze",I),r.removeEventListener("squeezestart",I),r.removeEventListener("squeezeend",I),r.removeEventListener("end",H),r.removeEventListener("inputsourceschange",L);for(let J=0;J<_.length;J++){const se=g[J];se!==null&&(g[J]=null,_[J].disconnect(se))}b=null,F=null,e.setRenderTarget(m),f=null,h=null,u=null,r=null,p=null,ue.stop(),i.isPresenting=!1,e.setPixelRatio(A),e.setSize(v.width,v.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){s=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){o=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(J){l=J},this.getBaseLayer=function(){return h!==null?h:f},this.getBinding=function(){return u},this.getFrame=function(){return y},this.getSession=function(){return r},this.setSession=async function(J){if(r=J,r!==null){if(m=e.getRenderTarget(),r.addEventListener("select",I),r.addEventListener("selectstart",I),r.addEventListener("selectend",I),r.addEventListener("squeeze",I),r.addEventListener("squeezestart",I),r.addEventListener("squeezeend",I),r.addEventListener("end",H),r.addEventListener("inputsourceschange",L),x.xrCompatible!==!0&&await t.makeXRCompatible(),A=e.getPixelRatio(),e.getSize(v),r.renderState.layers===void 0||e.capabilities.isWebGL2===!1){const se={antialias:r.renderState.layers===void 0?x.antialias:!0,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(r,t,se),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),p=new ai(f.framebufferWidth,f.framebufferHeight,{format:sn,type:Nn,colorSpace:e.outputColorSpace,stencilBuffer:x.stencil})}else{let se=null,ge=null,Re=null;x.depth&&(Re=x.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,se=x.stencil?Wi:ii,ge=x.stencil?ni:Ln);const Ee={colorFormat:t.RGBA8,depthFormat:Re,scaleFactor:s};u=new XRWebGLBinding(r,t),h=u.createProjectionLayer(Ee),r.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),p=new ai(h.textureWidth,h.textureHeight,{format:sn,type:Nn,depthTexture:new Bc(h.textureWidth,h.textureHeight,ge,void 0,void 0,void 0,void 0,void 0,void 0,se),stencilBuffer:x.stencil,colorSpace:e.outputColorSpace,samples:x.antialias?4:0});const Be=e.properties.get(p);Be.__ignoreDepthValues=h.ignoreDepthValues}p.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await r.requestReferenceSpace(o),ue.setContext(r),ue.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode};function L(J){for(let se=0;se<J.removed.length;se++){const ge=J.removed[se],Re=g.indexOf(ge);Re>=0&&(g[Re]=null,_[Re].disconnect(ge))}for(let se=0;se<J.added.length;se++){const ge=J.added[se];let Re=g.indexOf(ge);if(Re===-1){for(let Be=0;Be<_.length;Be++)if(Be>=g.length){g.push(ge),Re=Be;break}else if(g[Be]===null){g[Be]=ge,Re=Be;break}if(Re===-1)break}const Ee=_[Re];Ee&&Ee.connect(ge)}}const U=new N,O=new N;function X(J,se,ge){U.setFromMatrixPosition(se.matrixWorld),O.setFromMatrixPosition(ge.matrixWorld);const Re=U.distanceTo(O),Ee=se.projectionMatrix.elements,Be=ge.projectionMatrix.elements,He=Ee[14]/(Ee[10]-1),Ie=Ee[14]/(Ee[10]+1),S=(Ee[9]+1)/Ee[5],w=(Ee[9]-1)/Ee[5],V=(Ee[8]-1)/Ee[0],k=(Be[8]+1)/Be[0],ae=He*V,oe=He*k,ee=Re/(-V+k),me=ee*-V;se.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(me),J.translateZ(ee),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert();const R=He+ee,T=Ie+ee,B=ae-me,Q=oe+(Re-me),j=S*Ie/T*R,ne=w*Ie/T*R;J.projectionMatrix.makePerspective(B,Q,j,ne,R,T),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}function Z(J,se){se===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(se.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(r===null)return;M.near=C.near=E.near=J.near,M.far=C.far=E.far=J.far,(b!==M.near||F!==M.far)&&(r.updateRenderState({depthNear:M.near,depthFar:M.far}),b=M.near,F=M.far);const se=J.parent,ge=M.cameras;Z(M,se);for(let Re=0;Re<ge.length;Re++)Z(ge[Re],se);ge.length===2?X(M,E,C):M.projectionMatrix.copy(E.projectionMatrix),te(J,M,se)};function te(J,se,ge){ge===null?J.matrix.copy(se.matrixWorld):(J.matrix.copy(ge.matrixWorld),J.matrix.invert(),J.matrix.multiply(se.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(se.projectionMatrix),J.projectionMatrixInverse.copy(se.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=yr*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(h===null&&f===null))return c},this.setFoveation=function(J){c=J,h!==null&&(h.fixedFoveation=J),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=J)};let ie=null;function de(J,se){if(d=se.getViewerPose(l||a),y=se,d!==null){const ge=d.views;f!==null&&(e.setRenderTargetFramebuffer(p,f.framebuffer),e.setRenderTarget(p));let Re=!1;ge.length!==M.cameras.length&&(M.cameras.length=0,Re=!0);for(let Ee=0;Ee<ge.length;Ee++){const Be=ge[Ee];let He=null;if(f!==null)He=f.getViewport(Be);else{const S=u.getViewSubImage(h,Be);He=S.viewport,Ee===0&&(e.setRenderTargetTextures(p,S.colorTexture,h.ignoreDepthValues?void 0:S.depthStencilTexture),e.setRenderTarget(p))}let Ie=z[Ee];Ie===void 0&&(Ie=new Xt,Ie.layers.enable(Ee),Ie.viewport=new ft,z[Ee]=Ie),Ie.matrix.fromArray(Be.transform.matrix),Ie.matrix.decompose(Ie.position,Ie.quaternion,Ie.scale),Ie.projectionMatrix.fromArray(Be.projectionMatrix),Ie.projectionMatrixInverse.copy(Ie.projectionMatrix).invert(),Ie.viewport.set(He.x,He.y,He.width,He.height),Ee===0&&(M.matrix.copy(Ie.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),Re===!0&&M.cameras.push(Ie)}}for(let ge=0;ge<_.length;ge++){const Re=g[ge],Ee=_[ge];Re!==null&&Ee!==void 0&&Ee.update(Re,se,l||a)}ie&&ie(J,se),se.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:se}),y=null}const ue=new Oc;ue.setAnimationLoop(de),this.setAnimationLoop=function(J){ie=J},this.dispose=function(){}}}function Xm(n,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function i(m,p){p.color.getRGB(m.fogColor.value,Nc(n)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function r(m,p,_,g,v){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(m,p):p.isMeshToonMaterial?(s(m,p),u(m,p)):p.isMeshPhongMaterial?(s(m,p),d(m,p)):p.isMeshStandardMaterial?(s(m,p),h(m,p),p.isMeshPhysicalMaterial&&f(m,p,v)):p.isMeshMatcapMaterial?(s(m,p),y(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),x(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(a(m,p),p.isLineDashedMaterial&&o(m,p)):p.isPointsMaterial?c(m,p,_,g):p.isSpriteMaterial?l(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Ot&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Ot&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const _=e.get(p).envMap;if(_&&(m.envMap.value=_,m.flipEnvMap.value=_.isCubeTexture&&_.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap){m.lightMap.value=p.lightMap;const g=n._useLegacyLights===!0?Math.PI:1;m.lightMapIntensity.value=p.lightMapIntensity*g,t(p.lightMap,m.lightMapTransform)}p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function a(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function o(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function c(m,p,_,g){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*_,m.scale.value=g*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function l(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function d(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function h(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),e.get(p).envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,_){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Ot&&m.clearcoatNormalScale.value.negate())),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=_.texture,m.transmissionSamplerSize.value.set(_.width,_.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function y(m,p){p.matcap&&(m.matcap.value=p.matcap)}function x(m,p){const _=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(_.matrixWorld),m.nearDistance.value=_.shadow.camera.near,m.farDistance.value=_.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function qm(n,e,t,i){let r={},s={},a=[];const o=t.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(_,g){const v=g.program;i.uniformBlockBinding(_,v)}function l(_,g){let v=r[_.id];v===void 0&&(y(_),v=d(_),r[_.id]=v,_.addEventListener("dispose",m));const A=g.program;i.updateUBOMapping(_,A);const E=e.render.frame;s[_.id]!==E&&(h(_),s[_.id]=E)}function d(_){const g=u();_.__bindingPointIndex=g;const v=n.createBuffer(),A=_.__size,E=_.usage;return n.bindBuffer(n.UNIFORM_BUFFER,v),n.bufferData(n.UNIFORM_BUFFER,A,E),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,g,v),v}function u(){for(let _=0;_<o;_++)if(a.indexOf(_)===-1)return a.push(_),_;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(_){const g=r[_.id],v=_.uniforms,A=_.__cache;n.bindBuffer(n.UNIFORM_BUFFER,g);for(let E=0,C=v.length;E<C;E++){const z=Array.isArray(v[E])?v[E]:[v[E]];for(let M=0,b=z.length;M<b;M++){const F=z[M];if(f(F,E,M,A)===!0){const I=F.__offset,H=Array.isArray(F.value)?F.value:[F.value];let L=0;for(let U=0;U<H.length;U++){const O=H[U],X=x(O);typeof O=="number"||typeof O=="boolean"?(F.__data[0]=O,n.bufferSubData(n.UNIFORM_BUFFER,I+L,F.__data)):O.isMatrix3?(F.__data[0]=O.elements[0],F.__data[1]=O.elements[1],F.__data[2]=O.elements[2],F.__data[3]=0,F.__data[4]=O.elements[3],F.__data[5]=O.elements[4],F.__data[6]=O.elements[5],F.__data[7]=0,F.__data[8]=O.elements[6],F.__data[9]=O.elements[7],F.__data[10]=O.elements[8],F.__data[11]=0):(O.toArray(F.__data,L),L+=X.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,I,F.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function f(_,g,v,A){const E=_.value,C=g+"_"+v;if(A[C]===void 0)return typeof E=="number"||typeof E=="boolean"?A[C]=E:A[C]=E.clone(),!0;{const z=A[C];if(typeof E=="number"||typeof E=="boolean"){if(z!==E)return A[C]=E,!0}else if(z.equals(E)===!1)return z.copy(E),!0}return!1}function y(_){const g=_.uniforms;let v=0;const A=16;for(let C=0,z=g.length;C<z;C++){const M=Array.isArray(g[C])?g[C]:[g[C]];for(let b=0,F=M.length;b<F;b++){const I=M[b],H=Array.isArray(I.value)?I.value:[I.value];for(let L=0,U=H.length;L<U;L++){const O=H[L],X=x(O),Z=v%A;Z!==0&&A-Z<X.boundary&&(v+=A-Z),I.__data=new Float32Array(X.storage/Float32Array.BYTES_PER_ELEMENT),I.__offset=v,v+=X.storage}}}const E=v%A;return E>0&&(v+=A-E),_.__size=v,_.__cache={},this}function x(_){const g={boundary:0,storage:0};return typeof _=="number"||typeof _=="boolean"?(g.boundary=4,g.storage=4):_.isVector2?(g.boundary=8,g.storage=8):_.isVector3||_.isColor?(g.boundary=16,g.storage=12):_.isVector4?(g.boundary=16,g.storage=16):_.isMatrix3?(g.boundary=48,g.storage=48):_.isMatrix4?(g.boundary=64,g.storage=64):_.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",_),g}function m(_){const g=_.target;g.removeEventListener("dispose",m);const v=a.indexOf(g.__bindingPointIndex);a.splice(v,1),n.deleteBuffer(r[g.id]),delete r[g.id],delete s[g.id]}function p(){for(const _ in r)n.deleteBuffer(r[_]);a=[],r={},s={}}return{bind:c,update:l,dispose:p}}class ao{constructor(e={}){const{canvas:t=Gd(),context:i=null,depth:r=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:u=!1}=e;this.isWebGLRenderer=!0;let h;i!==null?h=i.getContextAttributes().alpha:h=a;const f=new Uint32Array(4),y=new Int32Array(4);let x=null,m=null;const p=[],_=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=vt,this._useLegacyLights=!1,this.toneMapping=Un,this.toneMappingExposure=1;const g=this;let v=!1,A=0,E=0,C=null,z=-1,M=null;const b=new ft,F=new ft;let I=null;const H=new Ke(0);let L=0,U=t.width,O=t.height,X=1,Z=null,te=null;const ie=new ft(0,0,U,O),de=new ft(0,0,U,O);let ue=!1;const J=new io;let se=!1,ge=!1,Re=null;const Ee=new et,Be=new Oe,He=new N,Ie={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function S(){return C===null?X:1}let w=i;function V(P,G){for(let Y=0;Y<P.length;Y++){const $=P[Y],q=t.getContext($,G);if(q!==null)return q}return null}try{const P={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:d,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${$a}`),t.addEventListener("webglcontextlost",K,!1),t.addEventListener("webglcontextrestored",D,!1),t.addEventListener("webglcontextcreationerror",he,!1),w===null){const G=["webgl2","webgl","experimental-webgl"];if(g.isWebGL1Renderer===!0&&G.shift(),w=V(G,P),w===null)throw V(G)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&w instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),w.getShaderPrecisionFormat===void 0&&(w.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(P){throw console.error("THREE.WebGLRenderer: "+P.message),P}let k,ae,oe,ee,me,R,T,B,Q,j,ne,ye,xe,ve,Te,Ue,ce,$e,qe,Ne,Pe,be,Fe,re;function le(){k=new np(w),ae=new K0(w,k,e),k.init(ae),be=new Gm(w,k,ae),oe=new Om(w,k,ae),ee=new sp(w),me=new Em,R=new Bm(w,k,oe,me,ae,be,ee),T=new J0(g),B=new tp(g),Q=new uu(w,ae),Fe=new j0(w,k,Q,ae),j=new ip(w,Q,ee,Fe),ne=new cp(w,j,Q,ee),qe=new lp(w,ae,R),Ue=new $0(me),ye=new Sm(g,T,B,k,ae,Fe,Ue),xe=new Xm(g,me),ve=new Am,Te=new Dm(k,ae),$e=new Y0(g,T,B,oe,ne,h,c),ce=new km(g,ne,ae),re=new qm(w,ee,ae,oe),Ne=new Z0(w,k,ee,ae),Pe=new rp(w,k,ee,ae),ee.programs=ye.programs,g.capabilities=ae,g.extensions=k,g.properties=me,g.renderLists=ve,g.shadowMap=ce,g.state=oe,g.info=ee}le();const fe=new Wm(g,w);this.xr=fe,this.getContext=function(){return w},this.getContextAttributes=function(){return w.getContextAttributes()},this.forceContextLoss=function(){const P=k.get("WEBGL_lose_context");P&&P.loseContext()},this.forceContextRestore=function(){const P=k.get("WEBGL_lose_context");P&&P.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(P){P!==void 0&&(X=P,this.setSize(U,O,!1))},this.getSize=function(P){return P.set(U,O)},this.setSize=function(P,G,Y=!0){if(fe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}U=P,O=G,t.width=Math.floor(P*X),t.height=Math.floor(G*X),Y===!0&&(t.style.width=P+"px",t.style.height=G+"px"),this.setViewport(0,0,P,G)},this.getDrawingBufferSize=function(P){return P.set(U*X,O*X).floor()},this.setDrawingBufferSize=function(P,G,Y){U=P,O=G,X=Y,t.width=Math.floor(P*Y),t.height=Math.floor(G*Y),this.setViewport(0,0,P,G)},this.getCurrentViewport=function(P){return P.copy(b)},this.getViewport=function(P){return P.copy(ie)},this.setViewport=function(P,G,Y,$){P.isVector4?ie.set(P.x,P.y,P.z,P.w):ie.set(P,G,Y,$),oe.viewport(b.copy(ie).multiplyScalar(X).floor())},this.getScissor=function(P){return P.copy(de)},this.setScissor=function(P,G,Y,$){P.isVector4?de.set(P.x,P.y,P.z,P.w):de.set(P,G,Y,$),oe.scissor(F.copy(de).multiplyScalar(X).floor())},this.getScissorTest=function(){return ue},this.setScissorTest=function(P){oe.setScissorTest(ue=P)},this.setOpaqueSort=function(P){Z=P},this.setTransparentSort=function(P){te=P},this.getClearColor=function(P){return P.copy($e.getClearColor())},this.setClearColor=function(){$e.setClearColor.apply($e,arguments)},this.getClearAlpha=function(){return $e.getClearAlpha()},this.setClearAlpha=function(){$e.setClearAlpha.apply($e,arguments)},this.clear=function(P=!0,G=!0,Y=!0){let $=0;if(P){let q=!1;if(C!==null){const Me=C.texture.format;q=Me===Sc||Me===wc||Me===bc}if(q){const Me=C.texture.type,Ce=Me===Nn||Me===Ln||Me===Qa||Me===ni||Me===vc||Me===Mc,ze=$e.getClearColor(),ke=$e.getClearAlpha(),je=ze.r,Ve=ze.g,Xe=ze.b;Ce?(f[0]=je,f[1]=Ve,f[2]=Xe,f[3]=ke,w.clearBufferuiv(w.COLOR,0,f)):(y[0]=je,y[1]=Ve,y[2]=Xe,y[3]=ke,w.clearBufferiv(w.COLOR,0,y))}else $|=w.COLOR_BUFFER_BIT}G&&($|=w.DEPTH_BUFFER_BIT),Y&&($|=w.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),w.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",K,!1),t.removeEventListener("webglcontextrestored",D,!1),t.removeEventListener("webglcontextcreationerror",he,!1),ve.dispose(),Te.dispose(),me.dispose(),T.dispose(),B.dispose(),ne.dispose(),Fe.dispose(),re.dispose(),ye.dispose(),fe.dispose(),fe.removeEventListener("sessionstart",Dt),fe.removeEventListener("sessionend",lt),Re&&(Re.dispose(),Re=null),It.stop()};function K(P){P.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),v=!0}function D(){console.log("THREE.WebGLRenderer: Context Restored."),v=!1;const P=ee.autoReset,G=ce.enabled,Y=ce.autoUpdate,$=ce.needsUpdate,q=ce.type;le(),ee.autoReset=P,ce.enabled=G,ce.autoUpdate=Y,ce.needsUpdate=$,ce.type=q}function he(P){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",P.statusMessage)}function pe(P){const G=P.target;G.removeEventListener("dispose",pe),Ae(G)}function Ae(P){Le(P),me.remove(P)}function Le(P){const G=me.get(P).programs;G!==void 0&&(G.forEach(function(Y){ye.releaseProgram(Y)}),P.isShaderMaterial&&ye.releaseShaderCache(P))}this.renderBufferDirect=function(P,G,Y,$,q,Me){G===null&&(G=Ie);const Ce=q.isMesh&&q.matrixWorld.determinant()<0,ze=Sh(P,G,Y,$,q);oe.setMaterial($,Ce);let ke=Y.index,je=1;if($.wireframe===!0){if(ke=j.getWireframeAttribute(Y),ke===void 0)return;je=2}const Ve=Y.drawRange,Xe=Y.attributes.position;let yt=Ve.start*je,Gt=(Ve.start+Ve.count)*je;Me!==null&&(yt=Math.max(yt,Me.start*je),Gt=Math.min(Gt,(Me.start+Me.count)*je)),ke!==null?(yt=Math.max(yt,0),Gt=Math.min(Gt,ke.count)):Xe!=null&&(yt=Math.max(yt,0),Gt=Math.min(Gt,Xe.count));const Tt=Gt-yt;if(Tt<0||Tt===1/0)return;Fe.setup(q,$,ze,Y,ke);let dn,pt=Ne;if(ke!==null&&(dn=Q.get(ke),pt=Pe,pt.setIndex(dn)),q.isMesh)$.wireframe===!0?(oe.setLineWidth($.wireframeLinewidth*S()),pt.setMode(w.LINES)):pt.setMode(w.TRIANGLES);else if(q.isLine){let Ze=$.linewidth;Ze===void 0&&(Ze=1),oe.setLineWidth(Ze*S()),q.isLineSegments?pt.setMode(w.LINES):q.isLineLoop?pt.setMode(w.LINE_LOOP):pt.setMode(w.LINE_STRIP)}else q.isPoints?pt.setMode(w.POINTS):q.isSprite&&pt.setMode(w.TRIANGLES);if(q.isBatchedMesh)pt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else if(q.isInstancedMesh)pt.renderInstances(yt,Tt,q.count);else if(Y.isInstancedBufferGeometry){const Ze=Y._maxInstanceCount!==void 0?Y._maxInstanceCount:1/0,Bs=Math.min(Y.instanceCount,Ze);pt.renderInstances(yt,Tt,Bs)}else pt.render(yt,Tt)};function at(P,G,Y){P.transparent===!0&&P.side===bt&&P.forceSinglePass===!1?(P.side=Ot,P.needsUpdate=!0,Ar(P,G,Y),P.side=wn,P.needsUpdate=!0,Ar(P,G,Y),P.side=bt):Ar(P,G,Y)}this.compile=function(P,G,Y=null){Y===null&&(Y=P),m=Te.get(Y),m.init(),_.push(m),Y.traverseVisible(function(q){q.isLight&&q.layers.test(G.layers)&&(m.pushLight(q),q.castShadow&&m.pushShadow(q))}),P!==Y&&P.traverseVisible(function(q){q.isLight&&q.layers.test(G.layers)&&(m.pushLight(q),q.castShadow&&m.pushShadow(q))}),m.setupLights(g._useLegacyLights);const $=new Set;return P.traverse(function(q){const Me=q.material;if(Me)if(Array.isArray(Me))for(let Ce=0;Ce<Me.length;Ce++){const ze=Me[Ce];at(ze,Y,q),$.add(ze)}else at(Me,Y,q),$.add(Me)}),_.pop(),m=null,$},this.compileAsync=function(P,G,Y=null){const $=this.compile(P,G,Y);return new Promise(q=>{function Me(){if($.forEach(function(Ce){me.get(Ce).currentProgram.isReady()&&$.delete(Ce)}),$.size===0){q(P);return}setTimeout(Me,10)}k.get("KHR_parallel_shader_compile")!==null?Me():setTimeout(Me,10)})};let ot=null;function Et(P){ot&&ot(P)}function Dt(){It.stop()}function lt(){It.start()}const It=new Oc;It.setAnimationLoop(Et),typeof self<"u"&&It.setContext(self),this.setAnimationLoop=function(P){ot=P,fe.setAnimationLoop(P),P===null?It.stop():It.start()},fe.addEventListener("sessionstart",Dt),fe.addEventListener("sessionend",lt),this.render=function(P,G){if(G!==void 0&&G.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(v===!0)return;P.matrixWorldAutoUpdate===!0&&P.updateMatrixWorld(),G.parent===null&&G.matrixWorldAutoUpdate===!0&&G.updateMatrixWorld(),fe.enabled===!0&&fe.isPresenting===!0&&(fe.cameraAutoUpdate===!0&&fe.updateCamera(G),G=fe.getCamera()),P.isScene===!0&&P.onBeforeRender(g,P,G,C),m=Te.get(P,_.length),m.init(),_.push(m),Ee.multiplyMatrices(G.projectionMatrix,G.matrixWorldInverse),J.setFromProjectionMatrix(Ee),ge=this.localClippingEnabled,se=Ue.init(this.clippingPlanes,ge),x=ve.get(P,p.length),x.init(),p.push(x),an(P,G,0,g.sortObjects),x.finish(),g.sortObjects===!0&&x.sort(Z,te),this.info.render.frame++,se===!0&&Ue.beginShadows();const Y=m.state.shadowsArray;if(ce.render(Y,P,G),se===!0&&Ue.endShadows(),this.info.autoReset===!0&&this.info.reset(),$e.render(x,P),m.setupLights(g._useLegacyLights),G.isArrayCamera){const $=G.cameras;for(let q=0,Me=$.length;q<Me;q++){const Ce=$[q];_o(x,P,Ce,Ce.viewport)}}else _o(x,P,G);C!==null&&(R.updateMultisampleRenderTarget(C),R.updateRenderTargetMipmap(C)),P.isScene===!0&&P.onAfterRender(g,P,G),Fe.resetDefaultState(),z=-1,M=null,_.pop(),_.length>0?m=_[_.length-1]:m=null,p.pop(),p.length>0?x=p[p.length-1]:x=null};function an(P,G,Y,$){if(P.visible===!1)return;if(P.layers.test(G.layers)){if(P.isGroup)Y=P.renderOrder;else if(P.isLOD)P.autoUpdate===!0&&P.update(G);else if(P.isLight)m.pushLight(P),P.castShadow&&m.pushShadow(P);else if(P.isSprite){if(!P.frustumCulled||J.intersectsSprite(P)){$&&He.setFromMatrixPosition(P.matrixWorld).applyMatrix4(Ee);const Ce=ne.update(P),ze=P.material;ze.visible&&x.push(P,Ce,ze,Y,He.z,null)}}else if((P.isMesh||P.isLine||P.isPoints)&&(!P.frustumCulled||J.intersectsObject(P))){const Ce=ne.update(P),ze=P.material;if($&&(P.boundingSphere!==void 0?(P.boundingSphere===null&&P.computeBoundingSphere(),He.copy(P.boundingSphere.center)):(Ce.boundingSphere===null&&Ce.computeBoundingSphere(),He.copy(Ce.boundingSphere.center)),He.applyMatrix4(P.matrixWorld).applyMatrix4(Ee)),Array.isArray(ze)){const ke=Ce.groups;for(let je=0,Ve=ke.length;je<Ve;je++){const Xe=ke[je],yt=ze[Xe.materialIndex];yt&&yt.visible&&x.push(P,Ce,yt,Y,He.z,Xe)}}else ze.visible&&x.push(P,Ce,ze,Y,He.z,null)}}const Me=P.children;for(let Ce=0,ze=Me.length;Ce<ze;Ce++)an(Me[Ce],G,Y,$)}function _o(P,G,Y,$){const q=P.opaque,Me=P.transmissive,Ce=P.transparent;m.setupLightsView(Y),se===!0&&Ue.setGlobalState(g.clippingPlanes,Y),Me.length>0&&wh(q,Me,G,Y),$&&oe.viewport(b.copy($)),q.length>0&&Tr(q,G,Y),Me.length>0&&Tr(Me,G,Y),Ce.length>0&&Tr(Ce,G,Y),oe.buffers.depth.setTest(!0),oe.buffers.depth.setMask(!0),oe.buffers.color.setMask(!0),oe.setPolygonOffset(!1)}function wh(P,G,Y,$){if((Y.isScene===!0?Y.overrideMaterial:null)!==null)return;const Me=ae.isWebGL2;Re===null&&(Re=new ai(1,1,{generateMipmaps:!0,type:k.has("EXT_color_buffer_half_float")?_r:Nn,minFilter:xr,samples:Me?4:0})),g.getDrawingBufferSize(Be),Me?Re.setSize(Be.x,Be.y):Re.setSize(ps(Be.x),ps(Be.y));const Ce=g.getRenderTarget();g.setRenderTarget(Re),g.getClearColor(H),L=g.getClearAlpha(),L<1&&g.setClearColor(16777215,.5),g.clear();const ze=g.toneMapping;g.toneMapping=Un,Tr(P,Y,$),R.updateMultisampleRenderTarget(Re),R.updateRenderTargetMipmap(Re);let ke=!1;for(let je=0,Ve=G.length;je<Ve;je++){const Xe=G[je],yt=Xe.object,Gt=Xe.geometry,Tt=Xe.material,dn=Xe.group;if(Tt.side===bt&&yt.layers.test($.layers)){const pt=Tt.side;Tt.side=Ot,Tt.needsUpdate=!0,yo(yt,Y,$,Gt,Tt,dn),Tt.side=pt,Tt.needsUpdate=!0,ke=!0}}ke===!0&&(R.updateMultisampleRenderTarget(Re),R.updateRenderTargetMipmap(Re)),g.setRenderTarget(Ce),g.setClearColor(H,L),g.toneMapping=ze}function Tr(P,G,Y){const $=G.isScene===!0?G.overrideMaterial:null;for(let q=0,Me=P.length;q<Me;q++){const Ce=P[q],ze=Ce.object,ke=Ce.geometry,je=$===null?Ce.material:$,Ve=Ce.group;ze.layers.test(Y.layers)&&yo(ze,G,Y,ke,je,Ve)}}function yo(P,G,Y,$,q,Me){P.onBeforeRender(g,G,Y,$,q,Me),P.modelViewMatrix.multiplyMatrices(Y.matrixWorldInverse,P.matrixWorld),P.normalMatrix.getNormalMatrix(P.modelViewMatrix),q.onBeforeRender(g,G,Y,$,P,Me),q.transparent===!0&&q.side===bt&&q.forceSinglePass===!1?(q.side=Ot,q.needsUpdate=!0,g.renderBufferDirect(Y,G,$,q,P,Me),q.side=wn,q.needsUpdate=!0,g.renderBufferDirect(Y,G,$,q,P,Me),q.side=bt):g.renderBufferDirect(Y,G,$,q,P,Me),P.onAfterRender(g,G,Y,$,q,Me)}function Ar(P,G,Y){G.isScene!==!0&&(G=Ie);const $=me.get(P),q=m.state.lights,Me=m.state.shadowsArray,Ce=q.state.version,ze=ye.getParameters(P,q.state,Me,G,Y),ke=ye.getProgramCacheKey(ze);let je=$.programs;$.environment=P.isMeshStandardMaterial?G.environment:null,$.fog=G.fog,$.envMap=(P.isMeshStandardMaterial?B:T).get(P.envMap||$.environment),je===void 0&&(P.addEventListener("dispose",pe),je=new Map,$.programs=je);let Ve=je.get(ke);if(Ve!==void 0){if($.currentProgram===Ve&&$.lightsStateVersion===Ce)return Mo(P,ze),Ve}else ze.uniforms=ye.getUniforms(P),P.onBuild(Y,ze,g),P.onBeforeCompile(ze,g),Ve=ye.acquireProgram(ze,ke),je.set(ke,Ve),$.uniforms=ze.uniforms;const Xe=$.uniforms;return(!P.isShaderMaterial&&!P.isRawShaderMaterial||P.clipping===!0)&&(Xe.clippingPlanes=Ue.uniform),Mo(P,ze),$.needsLights=Th(P),$.lightsStateVersion=Ce,$.needsLights&&(Xe.ambientLightColor.value=q.state.ambient,Xe.lightProbe.value=q.state.probe,Xe.directionalLights.value=q.state.directional,Xe.directionalLightShadows.value=q.state.directionalShadow,Xe.spotLights.value=q.state.spot,Xe.spotLightShadows.value=q.state.spotShadow,Xe.rectAreaLights.value=q.state.rectArea,Xe.ltc_1.value=q.state.rectAreaLTC1,Xe.ltc_2.value=q.state.rectAreaLTC2,Xe.pointLights.value=q.state.point,Xe.pointLightShadows.value=q.state.pointShadow,Xe.hemisphereLights.value=q.state.hemi,Xe.directionalShadowMap.value=q.state.directionalShadowMap,Xe.directionalShadowMatrix.value=q.state.directionalShadowMatrix,Xe.spotShadowMap.value=q.state.spotShadowMap,Xe.spotLightMatrix.value=q.state.spotLightMatrix,Xe.spotLightMap.value=q.state.spotLightMap,Xe.pointShadowMap.value=q.state.pointShadowMap,Xe.pointShadowMatrix.value=q.state.pointShadowMatrix),$.currentProgram=Ve,$.uniformsList=null,Ve}function vo(P){if(P.uniformsList===null){const G=P.currentProgram.getUniforms();P.uniformsList=rs.seqWithValue(G.seq,P.uniforms)}return P.uniformsList}function Mo(P,G){const Y=me.get(P);Y.outputColorSpace=G.outputColorSpace,Y.batching=G.batching,Y.instancing=G.instancing,Y.instancingColor=G.instancingColor,Y.skinning=G.skinning,Y.morphTargets=G.morphTargets,Y.morphNormals=G.morphNormals,Y.morphColors=G.morphColors,Y.morphTargetsCount=G.morphTargetsCount,Y.numClippingPlanes=G.numClippingPlanes,Y.numIntersection=G.numClipIntersection,Y.vertexAlphas=G.vertexAlphas,Y.vertexTangents=G.vertexTangents,Y.toneMapping=G.toneMapping}function Sh(P,G,Y,$,q){G.isScene!==!0&&(G=Ie),R.resetTextureUnits();const Me=G.fog,Ce=$.isMeshStandardMaterial?G.environment:null,ze=C===null?g.outputColorSpace:C.isXRRenderTarget===!0?C.texture.colorSpace:Sn,ke=($.isMeshStandardMaterial?B:T).get($.envMap||Ce),je=$.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,Ve=!!Y.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),Xe=!!Y.morphAttributes.position,yt=!!Y.morphAttributes.normal,Gt=!!Y.morphAttributes.color;let Tt=Un;$.toneMapped&&(C===null||C.isXRRenderTarget===!0)&&(Tt=g.toneMapping);const dn=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,pt=dn!==void 0?dn.length:0,Ze=me.get($),Bs=m.state.lights;if(se===!0&&(ge===!0||P!==M)){const qt=P===M&&$.id===z;Ue.setState($,P,qt)}let gt=!1;$.version===Ze.__version?(Ze.needsLights&&Ze.lightsStateVersion!==Bs.state.version||Ze.outputColorSpace!==ze||q.isBatchedMesh&&Ze.batching===!1||!q.isBatchedMesh&&Ze.batching===!0||q.isInstancedMesh&&Ze.instancing===!1||!q.isInstancedMesh&&Ze.instancing===!0||q.isSkinnedMesh&&Ze.skinning===!1||!q.isSkinnedMesh&&Ze.skinning===!0||q.isInstancedMesh&&Ze.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ze.instancingColor===!1&&q.instanceColor!==null||Ze.envMap!==ke||$.fog===!0&&Ze.fog!==Me||Ze.numClippingPlanes!==void 0&&(Ze.numClippingPlanes!==Ue.numPlanes||Ze.numIntersection!==Ue.numIntersection)||Ze.vertexAlphas!==je||Ze.vertexTangents!==Ve||Ze.morphTargets!==Xe||Ze.morphNormals!==yt||Ze.morphColors!==Gt||Ze.toneMapping!==Tt||ae.isWebGL2===!0&&Ze.morphTargetsCount!==pt)&&(gt=!0):(gt=!0,Ze.__version=$.version);let Bn=Ze.currentProgram;gt===!0&&(Bn=Ar($,G,q));let bo=!1,er=!1,Gs=!1;const Rt=Bn.getUniforms(),Gn=Ze.uniforms;if(oe.useProgram(Bn.program)&&(bo=!0,er=!0,Gs=!0),$.id!==z&&(z=$.id,er=!0),bo||M!==P){Rt.setValue(w,"projectionMatrix",P.projectionMatrix),Rt.setValue(w,"viewMatrix",P.matrixWorldInverse);const qt=Rt.map.cameraPosition;qt!==void 0&&qt.setValue(w,He.setFromMatrixPosition(P.matrixWorld)),ae.logarithmicDepthBuffer&&Rt.setValue(w,"logDepthBufFC",2/(Math.log(P.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&Rt.setValue(w,"isOrthographic",P.isOrthographicCamera===!0),M!==P&&(M=P,er=!0,Gs=!0)}if(q.isSkinnedMesh){Rt.setOptional(w,q,"bindMatrix"),Rt.setOptional(w,q,"bindMatrixInverse");const qt=q.skeleton;qt&&(ae.floatVertexTextures?(qt.boneTexture===null&&qt.computeBoneTexture(),Rt.setValue(w,"boneTexture",qt.boneTexture,R)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}q.isBatchedMesh&&(Rt.setOptional(w,q,"batchingTexture"),Rt.setValue(w,"batchingTexture",q._matricesTexture,R));const Hs=Y.morphAttributes;if((Hs.position!==void 0||Hs.normal!==void 0||Hs.color!==void 0&&ae.isWebGL2===!0)&&qe.update(q,Y,Bn),(er||Ze.receiveShadow!==q.receiveShadow)&&(Ze.receiveShadow=q.receiveShadow,Rt.setValue(w,"receiveShadow",q.receiveShadow)),$.isMeshGouraudMaterial&&$.envMap!==null&&(Gn.envMap.value=ke,Gn.flipEnvMap.value=ke.isCubeTexture&&ke.isRenderTargetTexture===!1?-1:1),er&&(Rt.setValue(w,"toneMappingExposure",g.toneMappingExposure),Ze.needsLights&&Eh(Gn,Gs),Me&&$.fog===!0&&xe.refreshFogUniforms(Gn,Me),xe.refreshMaterialUniforms(Gn,$,X,O,Re),rs.upload(w,vo(Ze),Gn,R)),$.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(rs.upload(w,vo(Ze),Gn,R),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&Rt.setValue(w,"center",q.center),Rt.setValue(w,"modelViewMatrix",q.modelViewMatrix),Rt.setValue(w,"normalMatrix",q.normalMatrix),Rt.setValue(w,"modelMatrix",q.matrixWorld),$.isShaderMaterial||$.isRawShaderMaterial){const qt=$.uniformsGroups;for(let Vs=0,Ah=qt.length;Vs<Ah;Vs++)if(ae.isWebGL2){const wo=qt[Vs];re.update(wo,Bn),re.bind(wo,Bn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Bn}function Eh(P,G){P.ambientLightColor.needsUpdate=G,P.lightProbe.needsUpdate=G,P.directionalLights.needsUpdate=G,P.directionalLightShadows.needsUpdate=G,P.pointLights.needsUpdate=G,P.pointLightShadows.needsUpdate=G,P.spotLights.needsUpdate=G,P.spotLightShadows.needsUpdate=G,P.rectAreaLights.needsUpdate=G,P.hemisphereLights.needsUpdate=G}function Th(P){return P.isMeshLambertMaterial||P.isMeshToonMaterial||P.isMeshPhongMaterial||P.isMeshStandardMaterial||P.isShadowMaterial||P.isShaderMaterial&&P.lights===!0}this.getActiveCubeFace=function(){return A},this.getActiveMipmapLevel=function(){return E},this.getRenderTarget=function(){return C},this.setRenderTargetTextures=function(P,G,Y){me.get(P.texture).__webglTexture=G,me.get(P.depthTexture).__webglTexture=Y;const $=me.get(P);$.__hasExternalTextures=!0,$.__hasExternalTextures&&($.__autoAllocateDepthBuffer=Y===void 0,$.__autoAllocateDepthBuffer||k.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),$.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(P,G){const Y=me.get(P);Y.__webglFramebuffer=G,Y.__useDefaultFramebuffer=G===void 0},this.setRenderTarget=function(P,G=0,Y=0){C=P,A=G,E=Y;let $=!0,q=null,Me=!1,Ce=!1;if(P){const ke=me.get(P);ke.__useDefaultFramebuffer!==void 0?(oe.bindFramebuffer(w.FRAMEBUFFER,null),$=!1):ke.__webglFramebuffer===void 0?R.setupRenderTarget(P):ke.__hasExternalTextures&&R.rebindTextures(P,me.get(P.texture).__webglTexture,me.get(P.depthTexture).__webglTexture);const je=P.texture;(je.isData3DTexture||je.isDataArrayTexture||je.isCompressedArrayTexture)&&(Ce=!0);const Ve=me.get(P).__webglFramebuffer;P.isWebGLCubeRenderTarget?(Array.isArray(Ve[G])?q=Ve[G][Y]:q=Ve[G],Me=!0):ae.isWebGL2&&P.samples>0&&R.useMultisampledRTT(P)===!1?q=me.get(P).__webglMultisampledFramebuffer:Array.isArray(Ve)?q=Ve[Y]:q=Ve,b.copy(P.viewport),F.copy(P.scissor),I=P.scissorTest}else b.copy(ie).multiplyScalar(X).floor(),F.copy(de).multiplyScalar(X).floor(),I=ue;if(oe.bindFramebuffer(w.FRAMEBUFFER,q)&&ae.drawBuffers&&$&&oe.drawBuffers(P,q),oe.viewport(b),oe.scissor(F),oe.setScissorTest(I),Me){const ke=me.get(P.texture);w.framebufferTexture2D(w.FRAMEBUFFER,w.COLOR_ATTACHMENT0,w.TEXTURE_CUBE_MAP_POSITIVE_X+G,ke.__webglTexture,Y)}else if(Ce){const ke=me.get(P.texture),je=G||0;w.framebufferTextureLayer(w.FRAMEBUFFER,w.COLOR_ATTACHMENT0,ke.__webglTexture,Y||0,je)}z=-1},this.readRenderTargetPixels=function(P,G,Y,$,q,Me,Ce){if(!(P&&P.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let ze=me.get(P).__webglFramebuffer;if(P.isWebGLCubeRenderTarget&&Ce!==void 0&&(ze=ze[Ce]),ze){oe.bindFramebuffer(w.FRAMEBUFFER,ze);try{const ke=P.texture,je=ke.format,Ve=ke.type;if(je!==sn&&be.convert(je)!==w.getParameter(w.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const Xe=Ve===_r&&(k.has("EXT_color_buffer_half_float")||ae.isWebGL2&&k.has("EXT_color_buffer_float"));if(Ve!==Nn&&be.convert(Ve)!==w.getParameter(w.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Ve===zn&&(ae.isWebGL2||k.has("OES_texture_float")||k.has("WEBGL_color_buffer_float")))&&!Xe){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}G>=0&&G<=P.width-$&&Y>=0&&Y<=P.height-q&&w.readPixels(G,Y,$,q,be.convert(je),be.convert(Ve),Me)}finally{const ke=C!==null?me.get(C).__webglFramebuffer:null;oe.bindFramebuffer(w.FRAMEBUFFER,ke)}}},this.copyFramebufferToTexture=function(P,G,Y=0){const $=Math.pow(2,-Y),q=Math.floor(G.image.width*$),Me=Math.floor(G.image.height*$);R.setTexture2D(G,0),w.copyTexSubImage2D(w.TEXTURE_2D,Y,0,0,P.x,P.y,q,Me),oe.unbindTexture()},this.copyTextureToTexture=function(P,G,Y,$=0){const q=G.image.width,Me=G.image.height,Ce=be.convert(Y.format),ze=be.convert(Y.type);R.setTexture2D(Y,0),w.pixelStorei(w.UNPACK_FLIP_Y_WEBGL,Y.flipY),w.pixelStorei(w.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),w.pixelStorei(w.UNPACK_ALIGNMENT,Y.unpackAlignment),G.isDataTexture?w.texSubImage2D(w.TEXTURE_2D,$,P.x,P.y,q,Me,Ce,ze,G.image.data):G.isCompressedTexture?w.compressedTexSubImage2D(w.TEXTURE_2D,$,P.x,P.y,G.mipmaps[0].width,G.mipmaps[0].height,Ce,G.mipmaps[0].data):w.texSubImage2D(w.TEXTURE_2D,$,P.x,P.y,Ce,ze,G.image),$===0&&Y.generateMipmaps&&w.generateMipmap(w.TEXTURE_2D),oe.unbindTexture()},this.copyTextureToTexture3D=function(P,G,Y,$,q=0){if(g.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const Me=P.max.x-P.min.x+1,Ce=P.max.y-P.min.y+1,ze=P.max.z-P.min.z+1,ke=be.convert($.format),je=be.convert($.type);let Ve;if($.isData3DTexture)R.setTexture3D($,0),Ve=w.TEXTURE_3D;else if($.isDataArrayTexture||$.isCompressedArrayTexture)R.setTexture2DArray($,0),Ve=w.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}w.pixelStorei(w.UNPACK_FLIP_Y_WEBGL,$.flipY),w.pixelStorei(w.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),w.pixelStorei(w.UNPACK_ALIGNMENT,$.unpackAlignment);const Xe=w.getParameter(w.UNPACK_ROW_LENGTH),yt=w.getParameter(w.UNPACK_IMAGE_HEIGHT),Gt=w.getParameter(w.UNPACK_SKIP_PIXELS),Tt=w.getParameter(w.UNPACK_SKIP_ROWS),dn=w.getParameter(w.UNPACK_SKIP_IMAGES),pt=Y.isCompressedTexture?Y.mipmaps[q]:Y.image;w.pixelStorei(w.UNPACK_ROW_LENGTH,pt.width),w.pixelStorei(w.UNPACK_IMAGE_HEIGHT,pt.height),w.pixelStorei(w.UNPACK_SKIP_PIXELS,P.min.x),w.pixelStorei(w.UNPACK_SKIP_ROWS,P.min.y),w.pixelStorei(w.UNPACK_SKIP_IMAGES,P.min.z),Y.isDataTexture||Y.isData3DTexture?w.texSubImage3D(Ve,q,G.x,G.y,G.z,Me,Ce,ze,ke,je,pt.data):Y.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),w.compressedTexSubImage3D(Ve,q,G.x,G.y,G.z,Me,Ce,ze,ke,pt.data)):w.texSubImage3D(Ve,q,G.x,G.y,G.z,Me,Ce,ze,ke,je,pt),w.pixelStorei(w.UNPACK_ROW_LENGTH,Xe),w.pixelStorei(w.UNPACK_IMAGE_HEIGHT,yt),w.pixelStorei(w.UNPACK_SKIP_PIXELS,Gt),w.pixelStorei(w.UNPACK_SKIP_ROWS,Tt),w.pixelStorei(w.UNPACK_SKIP_IMAGES,dn),q===0&&$.generateMipmaps&&w.generateMipmap(Ve),oe.unbindTexture()},this.initTexture=function(P){P.isCubeTexture?R.setTextureCube(P,0):P.isData3DTexture?R.setTexture3D(P,0):P.isDataArrayTexture||P.isCompressedArrayTexture?R.setTexture2DArray(P,0):R.setTexture2D(P,0),oe.unbindTexture()},this.resetState=function(){A=0,E=0,C=null,oe.reset(),Fe.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return yn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=e===eo?"display-p3":"srgb",t.unpackColorSpace=rt.workingColorSpace===Ts?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===vt?ri:Tc}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===ri?vt:Sn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}}class Ym extends ao{}Ym.prototype.isWebGL1Renderer=!0;class oo{constructor(e,t=1,i=1e3){this.isFog=!0,this.name="",this.color=new Ke(e),this.near=t,this.far=i}clone(){return new oo(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class qc extends mt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}}class jm{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Na,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=Mn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[i+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Mn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Mn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Ut=new N;class gs{constructor(e,t,i,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)Ut.fromBufferAttribute(this,t),Ut.applyMatrix4(e),this.setXYZ(t,Ut.x,Ut.y,Ut.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Ut.fromBufferAttribute(this,t),Ut.applyNormalMatrix(e),this.setXYZ(t,Ut.x,Ut.y,Ut.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Ut.fromBufferAttribute(this,t),Ut.transformDirection(e),this.setXYZ(t,Ut.x,Ut.y,Ut.z);return this}setX(e,t){return this.normalized&&(t=it(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=it(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=it(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=it(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=cn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=cn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=cn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=cn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=it(t,this.array),i=it(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=it(t,this.array),i=it(i,this.array),r=it(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=it(t,this.array),i=it(i,this.array),r=it(r,this.array),s=it(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new Qt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new gs(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class lo extends $i{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new Ke(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let Ai;const sr=new N,Ri=new N,Ci=new N,Pi=new Oe,ar=new Oe,Yc=new et,Kr=new N,or=new N,$r=new N,Vl=new Oe,va=new Oe,Wl=new Oe;class jc extends mt{constructor(e=new lo){if(super(),this.isSprite=!0,this.type="Sprite",Ai===void 0){Ai=new tt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new jm(t,5);Ai.setIndex([0,1,2,0,2,3]),Ai.setAttribute("position",new gs(i,3,0,!1)),Ai.setAttribute("uv",new gs(i,2,3,!1))}this.geometry=Ai,this.material=e,this.center=new Oe(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ri.setFromMatrixScale(this.matrixWorld),Yc.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Ci.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ri.multiplyScalar(-Ci.z);const i=this.material.rotation;let r,s;i!==0&&(s=Math.cos(i),r=Math.sin(i));const a=this.center;Jr(Kr.set(-.5,-.5,0),Ci,a,Ri,r,s),Jr(or.set(.5,-.5,0),Ci,a,Ri,r,s),Jr($r.set(.5,.5,0),Ci,a,Ri,r,s),Vl.set(0,0),va.set(1,0),Wl.set(1,1);let o=e.ray.intersectTriangle(Kr,or,$r,!1,sr);if(o===null&&(Jr(or.set(-.5,.5,0),Ci,a,Ri,r,s),va.set(0,1),o=e.ray.intersectTriangle(Kr,$r,or,!1,sr),o===null))return;const c=e.ray.origin.distanceTo(sr);c<e.near||c>e.far||t.push({distance:c,point:sr.clone(),uv:$t.getInterpolation(sr,Kr,or,$r,Vl,va,Wl,new Oe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function Jr(n,e,t,i,r,s){Pi.subVectors(n,t).addScalar(.5).multiply(i),r!==void 0?(ar.x=s*Pi.x-r*Pi.y,ar.y=r*Pi.x+s*Pi.y):ar.copy(Pi),n.copy(e),n.x+=ar.x,n.y+=ar.y,n.applyMatrix4(Yc)}class Xl extends Qt{constructor(e,t,i,r=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Li=new et,ql=new et,Qr=[],Yl=new hn,Zm=new et,lr=new we,cr=new Sr;class xs extends we{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Xl(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<i;r++)this.setMatrixAt(r,Zm)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new hn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Li),Yl.copy(e.boundingBox).applyMatrix4(Li),this.boundingBox.union(Yl)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new Sr),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Li),cr.copy(e.boundingSphere).applyMatrix4(Li),this.boundingSphere.union(cr)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){const i=this.matrixWorld,r=this.count;if(lr.geometry=this.geometry,lr.material=this.material,lr.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),cr.copy(this.boundingSphere),cr.applyMatrix4(i),e.ray.intersectsSphere(cr)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,Li),ql.multiplyMatrices(i,Li),lr.matrixWorld=ql,lr.raycast(e,Qr);for(let a=0,o=Qr.length;a<o;a++){const c=Qr[a];c.instanceId=s,c.object=this,t.push(c)}Qr.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Xl(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}}class vr extends Bt{constructor(e,t,i,r,s,a,o,c,l){super(e,t,i,r,s,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class co extends tt{constructor(e=1,t=32,i=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:r},t=Math.max(3,t);const s=[],a=[],o=[],c=[],l=new N,d=new Oe;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let u=0,h=3;u<=t;u++,h+=3){const f=i+u/t*r;l.x=e*Math.cos(f),l.y=e*Math.sin(f),a.push(l.x,l.y,l.z),o.push(0,0,1),d.x=(a[h]/e+1)/2,d.y=(a[h+1]/e+1)/2,c.push(d.x,d.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new De(a,3)),this.setAttribute("normal",new De(o,3)),this.setAttribute("uv",new De(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new co(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class ho extends tt{constructor(e=1,t=1,i=1,r=32,s=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:c};const l=this;r=Math.floor(r),s=Math.floor(s);const d=[],u=[],h=[],f=[];let y=0;const x=[],m=i/2;let p=0;_(),a===!1&&(e>0&&g(!0),t>0&&g(!1)),this.setIndex(d),this.setAttribute("position",new De(u,3)),this.setAttribute("normal",new De(h,3)),this.setAttribute("uv",new De(f,2));function _(){const v=new N,A=new N;let E=0;const C=(t-e)/i;for(let z=0;z<=s;z++){const M=[],b=z/s,F=b*(t-e)+e;for(let I=0;I<=r;I++){const H=I/r,L=H*c+o,U=Math.sin(L),O=Math.cos(L);A.x=F*U,A.y=-b*i+m,A.z=F*O,u.push(A.x,A.y,A.z),v.set(U,C,O).normalize(),h.push(v.x,v.y,v.z),f.push(H,1-b),M.push(y++)}x.push(M)}for(let z=0;z<r;z++)for(let M=0;M<s;M++){const b=x[M][z],F=x[M+1][z],I=x[M+1][z+1],H=x[M][z+1];d.push(b,F,H),d.push(F,I,H),E+=6}l.addGroup(p,E,0),p+=E}function g(v){const A=y,E=new Oe,C=new N;let z=0;const M=v===!0?e:t,b=v===!0?1:-1;for(let I=1;I<=r;I++)u.push(0,m*b,0),h.push(0,b,0),f.push(.5,.5),y++;const F=y;for(let I=0;I<=r;I++){const L=I/r*c+o,U=Math.cos(L),O=Math.sin(L);C.x=M*O,C.y=m*b,C.z=M*U,u.push(C.x,C.y,C.z),h.push(0,b,0),E.x=U*.5+.5,E.y=O*.5*b+.5,f.push(E.x,E.y),y++}for(let I=0;I<r;I++){const H=A+I,L=F+I;v===!0?d.push(L,L+1,H):d.push(L+1,L,H),z+=3}l.addGroup(p,z,v===!0?1:2),p+=z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ho(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Mr extends ho{constructor(e=1,t=1,i=32,r=1,s=!1,a=0,o=Math.PI*2){super(0,e,t,i,r,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:r,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new Mr(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class uo extends tt{constructor(e=[],t=[],i=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:r};const s=[],a=[];o(r),l(i),d(),this.setAttribute("position",new De(s,3)),this.setAttribute("normal",new De(s.slice(),3)),this.setAttribute("uv",new De(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(_){const g=new N,v=new N,A=new N;for(let E=0;E<t.length;E+=3)f(t[E+0],g),f(t[E+1],v),f(t[E+2],A),c(g,v,A,_)}function c(_,g,v,A){const E=A+1,C=[];for(let z=0;z<=E;z++){C[z]=[];const M=_.clone().lerp(v,z/E),b=g.clone().lerp(v,z/E),F=E-z;for(let I=0;I<=F;I++)I===0&&z===E?C[z][I]=M:C[z][I]=M.clone().lerp(b,I/F)}for(let z=0;z<E;z++)for(let M=0;M<2*(E-z)-1;M++){const b=Math.floor(M/2);M%2===0?(h(C[z][b+1]),h(C[z+1][b]),h(C[z][b])):(h(C[z][b+1]),h(C[z+1][b+1]),h(C[z+1][b]))}}function l(_){const g=new N;for(let v=0;v<s.length;v+=3)g.x=s[v+0],g.y=s[v+1],g.z=s[v+2],g.normalize().multiplyScalar(_),s[v+0]=g.x,s[v+1]=g.y,s[v+2]=g.z}function d(){const _=new N;for(let g=0;g<s.length;g+=3){_.x=s[g+0],_.y=s[g+1],_.z=s[g+2];const v=m(_)/2/Math.PI+.5,A=p(_)/Math.PI+.5;a.push(v,1-A)}y(),u()}function u(){for(let _=0;_<a.length;_+=6){const g=a[_+0],v=a[_+2],A=a[_+4],E=Math.max(g,v,A),C=Math.min(g,v,A);E>.9&&C<.1&&(g<.2&&(a[_+0]+=1),v<.2&&(a[_+2]+=1),A<.2&&(a[_+4]+=1))}}function h(_){s.push(_.x,_.y,_.z)}function f(_,g){const v=_*3;g.x=e[v+0],g.y=e[v+1],g.z=e[v+2]}function y(){const _=new N,g=new N,v=new N,A=new N,E=new Oe,C=new Oe,z=new Oe;for(let M=0,b=0;M<s.length;M+=9,b+=6){_.set(s[M+0],s[M+1],s[M+2]),g.set(s[M+3],s[M+4],s[M+5]),v.set(s[M+6],s[M+7],s[M+8]),E.set(a[b+0],a[b+1]),C.set(a[b+2],a[b+3]),z.set(a[b+4],a[b+5]),A.copy(_).add(g).add(v).divideScalar(3);const F=m(A);x(E,b+0,_,F),x(C,b+2,g,F),x(z,b+4,v,F)}}function x(_,g,v,A){A<0&&_.x===1&&(a[g]=_.x-1),v.x===0&&v.z===0&&(a[g]=A/2/Math.PI+.5)}function m(_){return Math.atan2(_.z,-_.x)}function p(_){return Math.atan2(-_.y,Math.sqrt(_.x*_.x+_.z*_.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new uo(e.vertices,e.indices,e.radius,e.details)}}class br extends uo{constructor(e=1,t=0){const i=(1+Math.sqrt(5))/2,r=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new br(e.radius,e.detail)}}class Cs extends tt{constructor(e=1,t=32,i=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const c=Math.min(a+o,Math.PI);let l=0;const d=[],u=new N,h=new N,f=[],y=[],x=[],m=[];for(let p=0;p<=i;p++){const _=[],g=p/i;let v=0;p===0&&a===0?v=.5/t:p===i&&c===Math.PI&&(v=-.5/t);for(let A=0;A<=t;A++){const E=A/t;u.x=-e*Math.cos(r+E*s)*Math.sin(a+g*o),u.y=e*Math.cos(a+g*o),u.z=e*Math.sin(r+E*s)*Math.sin(a+g*o),y.push(u.x,u.y,u.z),h.copy(u).normalize(),x.push(h.x,h.y,h.z),m.push(E+v,1-g),_.push(l++)}d.push(_)}for(let p=0;p<i;p++)for(let _=0;_<t;_++){const g=d[p][_+1],v=d[p][_],A=d[p+1][_],E=d[p+1][_+1];(p!==0||a>0)&&f.push(g,v,E),(p!==i-1||c<Math.PI)&&f.push(v,A,E)}this.setIndex(f),this.setAttribute("position",new De(y,3)),this.setAttribute("normal",new De(x,3)),this.setAttribute("uv",new De(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Cs(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class fo extends tt{constructor(e=1,t=.4,i=12,r=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:r,arc:s},i=Math.floor(i),r=Math.floor(r);const a=[],o=[],c=[],l=[],d=new N,u=new N,h=new N;for(let f=0;f<=i;f++)for(let y=0;y<=r;y++){const x=y/r*s,m=f/i*Math.PI*2;u.x=(e+t*Math.cos(m))*Math.cos(x),u.y=(e+t*Math.cos(m))*Math.sin(x),u.z=t*Math.sin(m),o.push(u.x,u.y,u.z),d.x=e*Math.cos(x),d.y=e*Math.sin(x),h.subVectors(u,d).normalize(),c.push(h.x,h.y,h.z),l.push(y/r),l.push(f/i)}for(let f=1;f<=i;f++)for(let y=1;y<=r;y++){const x=(r+1)*f+y-1,m=(r+1)*(f-1)+y-1,p=(r+1)*(f-1)+y,_=(r+1)*f+y;a.push(x,m,_),a.push(m,p,_)}this.setIndex(a),this.setAttribute("position",new De(o,3)),this.setAttribute("normal",new De(c,3)),this.setAttribute("uv",new De(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new fo(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class _t extends $i{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Ke(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ke(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Ac,this.normalScale=new Oe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Ja,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class po extends mt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ke(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}}class Zc extends po{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(mt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ke(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const Ma=new et,jl=new N,Zl=new N;class Kc{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Oe(512,512),this.map=null,this.mapPass=null,this.matrix=new et,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new io,this._frameExtents=new Oe(1,1),this._viewportCount=1,this._viewports=[new ft(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,i=this.matrix;jl.setFromMatrixPosition(e.matrixWorld),t.position.copy(jl),Zl.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Zl),t.updateMatrixWorld(),Ma.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Ma),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(Ma)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Kl=new et,hr=new N,ba=new N;class Km extends Kc{constructor(){super(new Xt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Oe(4,2),this._viewportCount=6,this._viewports=[new ft(2,1,1,1),new ft(0,1,1,1),new ft(3,1,1,1),new ft(1,1,1,1),new ft(3,0,1,1),new ft(1,0,1,1)],this._cubeDirections=[new N(1,0,0),new N(-1,0,0),new N(0,0,1),new N(0,0,-1),new N(0,1,0),new N(0,-1,0)],this._cubeUps=[new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,0,1),new N(0,0,-1)]}updateMatrices(e,t=0){const i=this.camera,r=this.matrix,s=e.distance||i.far;s!==i.far&&(i.far=s,i.updateProjectionMatrix()),hr.setFromMatrixPosition(e.matrixWorld),i.position.copy(hr),ba.copy(i.position),ba.add(this._cubeDirections[t]),i.up.copy(this._cubeUps[t]),i.lookAt(ba),i.updateMatrixWorld(),r.makeTranslation(-hr.x,-hr.y,-hr.z),Kl.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Kl)}}class $m extends po{constructor(e,t,i=0,r=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=r,this.shadow=new Km}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Jm extends Kc{constructor(){super(new ro(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class $c extends po{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(mt.DEFAULT_UP),this.updateMatrix(),this.target=new mt,this.shadow=new Jm}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Qm{constructor(e,t,i=0,r=1/0){this.ray=new Er(e,t),this.near=i,this.far=r,this.camera=null,this.layers=new no,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return Ba(e,this,i,t),i.sort($l),i}intersectObjects(e,t=!0,i=[]){for(let r=0,s=e.length;r<s;r++)Ba(e[r],this,i,t);return i.sort($l),i}}function $l(n,e){return n.distance-e.distance}function Ba(n,e,t,i){if(n.layers.test(e.layers)&&n.raycast(e,t),i===!0){const r=n.children;for(let s=0,a=r.length;s<a;s++)Ba(r[s],e,t,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:$a}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=$a);const Jc={flowers:[[.5,.16,.5,.6,.32,.6,11827792],[.5,.48,.5,.06,.64,.06,5671001],[.5,.78,.5,.46,.18,.46,14523267],[.5,.89,.5,.18,.06,.18,16110715]],lantern:[[.5,.06,.5,.55,.12,.55,6255726],[.5,.46,.5,.4,.7,.4,16174707],[.5,.87,.5,.6,.12,.6,6255726],...[.27,.73].flatMap(n=>[.27,.73].map(e=>[n,.46,e,.06,.75,.06,6255726]))],bench:[[.5,.47,.5,.94,.12,.64,11369552],[.5,.77,.77,.94,.4,.1,11369552],...[.12,.88].flatMap(n=>[.25,.72].map(e=>[n,.22,e,.1,.44,.1,6714986]))]},On=[],_s=[],Ga=[15851437,15185051,12177332,14728124,14268559,11914194],Qc=[4488320,11365457,7042704,7108992];function Ps(n,e,t,i,r){e.forEach((s,a)=>{const o=t+i*16,c=i<0?0:Math.PI;if(r.includes(a))_s.push({id:`${n}-lot-${a}`,x:s,z:o,w:17,d:16,angle:c,street:n,roadZ:t,subtle:!0});else{const l=n==="north"?[1,5].includes(a)&&i<0:[2,5].includes(a)&&i>0;On.push({id:`${n}-${i<0?"n":"s"}-${a}`,name:`${n==="north"?"Linden":"Willow"} ${l?"family home":"cottage"} ${a+1}`,x:s,z:o,w:l?12:8+a%3,d:l?12:8+a%2*2,angle:c,wall:Ga[(a+(i+1)*2)%Ga.length],roof:Qc[(a+(i+1))%4],style:l?"gable":["hip","gable","shed"][a%3],storeys:l?2:1,rooms:l||a%3===0,designed:!0,garden:0,garage:a%4===0,street:n})}})}Ps("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,-1,[2,6]);Ps("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,1,[1,5,8]);Ps("south",[-90,-66,-42,-18,6,30,54,78],128,-1,[0,3,6]);Ps("south",[-90,-66,-42,-18,6,30,54,78],128,1,[1,4]);On.push({id:"linden-library",name:"Linden library",x:60,z:-195,w:12,d:12,angle:Math.PI,route:"trail",wall:15851437,roof:4488320,style:"hip",shop:!0,sign:"LIBRARY",rooms:!0,designed:!0},{id:"willow-workshop",name:"Willow motor workshop",x:-109,z:110,w:12,d:12,angle:0,street:"south",wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,designed:!0},{id:"manor",name:"Magnolia manor",x:103,z:16,w:22,d:18,angle:-Math.PI/2,route:"trail",wall:15851437,roof:7042704,style:"hip",storeys:2,rooms:!0,designed:!0,porch:5},{id:"garden-cafe",name:"Garden cafe",x:112,z:-26,w:10,d:9,angle:Math.PI,wall:14728124,roof:11365457,style:"gable",shop:!0,sign:"GARDEN CAFE",designed:!0});const Ha=[[[-108,-143],[-64,-143],[-8,-143],[54,-143],[118,-143]],[[-112,128],[-66,128],[-6,128],[60,128],[119,128]],[[72,-28],[81,-16],[83,14],[83,39],[104,42]]];for(const[n,e]of[-28,-52,-76,-100,-122].entries())On.push({id:`elm-${n}`,name:`Elm lane ${n===2?"family house":"cottage"}`,x:-121,z:e,w:n===2?12:9,d:n===2?12:9,angle:-Math.PI/2,wall:Ga[n%6],roof:Qc[n%4],style:n%2?"hip":"gable",storeys:n===2?2:1,rooms:!0,designed:!0,street:"elm"});_s.push({id:"elm-lot",x:-150,z:-98,w:12,d:14,angle:Math.PI/2,street:"elm",roadX:-137,subtle:!0});Ha.push([[-137,-132],[-137,-90],[-137,-45],[-137,-9],[-146,10]]);const eg=[[[73,62],[80,66]],[[80,52],[84,52]],[[53,25],[53,36],[53,56],[65,62],[73,56],[80,52]],[[53,36],[61,34],[76,34],[80,41],[80,52]],[[65,62],[65,45]],[[197,98],[185,96],[181,82],[185,69],[197,65],[208,72],[210,86],[206,96],[197,98]],[[185,96],[197,84],[208,72]]],eh=[{id:"linden",name:"Linden street",icon:"⌂",x:-30,z:-143,color:"#b7a48a",signX:-113,signZ:-150},{id:"willow-street",name:"Willow street",icon:"⌂",x:-18,z:128,color:"#aebf90",signX:-118,signZ:136},{id:"manor",name:"Magnolia manor",icon:"♜",x:103,z:16,color:"#cfbc97",signX:88,signZ:29}],tg=On.findIndex(n=>n.id==="north-n-0");On.splice(tg,1);for(const n of["north-n-1","north-n-8"])On.find(e=>e.id===n).z=-154;On.find(n=>n.id==="south-s-0").x=-86;const ut=(n,e,t,i,r,s,a,o,c,l,d={})=>({id:n,name:e,x:t,z:i,w:r,d:s,angle:a,style:o,wall:c,roof:l,...d}),zi=0,qn=Math.PI,es=Math.PI/2,Yn=-Math.PI/2,ng=[ut("juniper","Juniper veranda",-160,-45,12,10,Yn,"hip",12177332,11365457,{porch:4.4,carport:!0,garden:2,bay:!0}),ut("birch","Birch twin cottage",-212,-40,8,11,es,"gable",15851437,7042704,{wing:!0,garden:3,chimney:!0}),ut("copper","Copper longhouse",-161,-80,7,12,Yn,"shed",14268559,4488320,{porch:4,garden:1,bay:!0}),ut("lavender","Lavender bungalow",-215,5,10,8,es,"hip",14728124,7108992,{garage:!0,garden:2}),ut("acacia","Acacia courtyard",-213,47,14,9,es,"gable",15185051,4488320,{wing:!0,porch:4.6,garden:3}),ut("riverside","Riverside home",-151,45,9,9,Yn,"hip",11914194,11365457,{carport:!0,garden:1,bay:!0}),ut("north-house","North garden house",-42,-214,12,10,zi,"hip",14728124,7042704,{wing:!0,garden:3}),ut("north-bakery","Sunbeam bakery",-18,-214,9,8,zi,"gable",15851437,11365457,{shop:!0,sign:"SUNBEAM",approach:{x:-18,z:-202},chimney:!0}),ut("north-hall","North village hall",7,-214,14,10,zi,"gable",12177332,4488320,{shop:!0,sign:"VILLAGE HALL",approach:{x:7,z:-202},porch:4.2}),ut("north-clock","Clockmaker house",35,-214,8,8,zi,"hip",14268559,7108992,{tower:!0,porch:3.2,garden:2}),ut("weavers","Weavers studio",202,-132,9,10,Yn,"shed",14728124,7042704,{shop:!0,sign:"WEAVERS",bay:!0}),ut("clay-yard","Clay courtyard",206,-103,12,8,Yn,"hip",15185051,4488320,{shop:!0,sign:"CLAY YARD",wing:!0}),ut("makers","Makers long workshop",205,-75,8,14,Yn,"gable",14268559,11365457,{shop:!0,sign:"MAKERS",carport:!0,chimney:!0}),ut("greenhouse","Garden potting house",207,-45,7,7,Yn,"gable",12177332,4488320,{porch:3.4,garden:3,bay:!0}),ut("lake-house","Lakeview veranda",213,4,10,9,zi,"shed",11914194,7108992,{route:"trail",porch:4.6,garden:2,bay:!0}),ut("east-house","Eastern carport house",212,109,14,8,qn,"hip",15851437,11365457,{route:"trail",carport:!0,garden:1}),ut("beacon-house","Beacon lodge",214,145,8,9,qn,"gable",14728124,4488320,{route:"trail",tower:!0,garden:2}),ut("farm-home","Farmhouse porch",43,215,12,10,qn,"gable",15851437,7042704,{route:"trail",porch:5,chimney:!0,garden:1}),ut("farm-shop","Farmyard store",12,216,10,8,qn,"hip",12177332,11365457,{route:"trail",shop:!0,sign:"FARM STORE",approach:{x:12,z:204},carport:!0}),ut("red-barn","Red barn workshop",-18,214,14,12,qn,"gambrel",13075044,7108992,{route:"trail",shop:!0,sign:"RED BARN",approach:{x:-18,z:202},chimney:!0}),ut("farm-cottage","Farm garden cottage",-47,213,8,9,qn,"hip",15185051,4488320,{route:"trail",wing:!0,garden:3}),ut("orchard-barn","Orchard long barn",-96,211,14,12,qn,"gambrel",14268559,11365457,{route:"trail",carport:!0,garden:1}),ut("pond-cabin","Reed pond cabin",-201,192,7,8,es,"gable",12177332,7042704,{route:"trail",porch:3.5,garden:2}),ut("trail-hut","North trail cabin",152,-218,6,7,zi,"shed",14728124,4488320,{route:"trail",porch:3,garden:2})],ig=[[[-124,6],[-146,10],[-169,1],[-186,-22],[-193,-61],[-177,-100],[-147,-127],[-112,-151],[-68,-171],[-15,-183],[40,-182],[89,-166],[133,-136],[160,-100],[175,-55],[174,-12],[176,20],[157,57],[139,92],[122,129],[91,162],[50,184],[3,190],[-47,181],[-91,157],[-124,126],[-156,91],[-181,55],[-196,18],[-174,7],[-146,10]],[[115,-53],[139,-56],[175,-55]]],rg=[[[-65,-103],[-108,-120],[-123,-150],[-128,-182],[-127,-209],[-99,-225],[-60,-221],[-66,-202],[-42,-202],[-8,-197],[-8,-182]],[[89,-166],[117,-185],[152,-198],[184,-210],[215,-208],[234,-183],[222,-151],[202,-147],[160,-100]],[[108,62],[142,48],[166,45],[184,44],[193,24],[220,20],[239,45],[236,70],[216,95],[185,116],[144,148],[122,129]],[[50,184],[33,202],[-10,198],[-57,193],[-95,193],[-131,174],[-157,173],[-184,174],[-213,181],[-216,205],[-193,222],[-162,224],[-137,212],[-131,192],[-131,174],[-139,147],[-124,126]],[[91,162],[128,181],[151,209],[181,226],[217,212],[232,174],[234,148],[222,127],[185,116]],[[-193,-61],[-218,-88],[-214,-123],[-192,-145],[-157,-151],[-147,-127]],[[-8,-197],[17,-197],[43,-202],[72,-215],[111,-229],[152,-198]],[[-184,174],[-190,183],[-192,194],[-190,206],[-193,222]],[[216,95],[208,99],[197,98],[197,84]]],sg=[{x:-161,z:-218,w:36,d:28,subtle:!0},{x:214,z:-232,w:36,d:20,subtle:!0},{x:-234,z:-111,w:22,d:24,subtle:!0},{x:151,z:234,w:36,d:20,subtle:!0}],ss=[{x:-167,z:197,rx:23,rz:14},{x:215,z:45,rx:18,rz:12}],th=[{id:"north-square",name:"Sunbeam village",icon:"☀",x:-8,z:-197,color:"#d7ae71"},{id:"artists",name:"Makers village",icon:"▤",x:190,z:-102,color:"#bd9583"},{id:"east-park",name:"Lake park",icon:"⚑",x:197,z:84,color:"#7aa276"},{id:"farm",name:"Red barn farm",icon:"♧",x:-18,z:197,color:"#bd7967"},{id:"reed-pond",name:"Reed pond",icon:"≈",x:-167,z:197,color:"#72aebc",signX:-141,signZ:216},{id:"beacon",name:"Beacon walk",icon:"♜",x:214,z:145,color:"#8eaaa1",signX:225,signZ:143},{id:"north-meadow",name:"North meadow",icon:"▦",x:-161,z:-218,color:"#a9b774",signX:-182,signZ:-218},{id:"east-meadow",name:"East meadow",icon:"▦",x:151,z:234,color:"#a9b774",signX:173,signZ:234}],st=Object.freeze({id:"little-block-world-06",saveVersion:4,halfSize:250,buildHeight:24,maxBlocks:12e3,maxSaveBytes:4e6,chunkSize:24,fogNear:75,fogFar:155,cameraFar:190,saveKey:"blockworld.neighborhood.06",preferencesKey:"blockworld.neighborhood.controls.v6"}),wa=Object.freeze({normal:3.4,quick:5.1,fast:6.8}),nh=n=>typeof wa[n]=="number"?wa[n]:wa.normal,ag=[{id:"home",name:"Home",icon:"⌂",x:-14.4,z:-1.2,color:"#cc9168"},{id:"village",name:"Village square",icon:"▥",x:49,z:-26,color:"#d9ac68"},{id:"park",name:"Play park",icon:"⚑",x:65,z:45,color:"#7aa276"},{id:"pond",name:"Willow pond",icon:"≈",x:18,z:-101,color:"#72aebc"},{id:"woods",name:"Woodland walk",icon:"♠",x:-65,z:-103,color:"#528969"},{id:"meadow",name:"Building meadow",icon:"▦",x:-59,z:61,color:"#a9b774"},{id:"orchard",name:"Orchard picnic",icon:"●",x:81,z:94,color:"#b89c78"},...th,...eh];class bn{constructor(e=12){this.size=e,this.cells=new Map,this.global=new Set,this.entries=new Map}keys(e){const t=[];for(let i=Math.floor(e.minX/this.size);i<=Math.floor(e.maxX/this.size);i++)for(let r=Math.floor(e.minZ/this.size);r<=Math.floor(e.maxZ/this.size);r++)t.push(`${i},${r}`);return t}add(e){const t=this.keys(e);if(this.entries.set(e,t),t.length>64){this.global.add(e);return}for(const i of t)this.cells.has(i)||this.cells.set(i,new Set),this.cells.get(i).add(e)}remove(e){for(const t of this.entries.get(e)||[]){const i=this.cells.get(t);i==null||i.delete(e),i!=null&&i.size||this.cells.delete(t)}this.global.delete(e),this.entries.delete(e)}query(e){const t=new Set(this.global);for(const i of this.keys(e))for(const r of this.cells.get(i)||[])t.add(r);return[...t].filter(i=>i.minX<=e.maxX&&i.maxX>=e.minX&&i.minZ<=e.maxZ&&i.maxZ>=e.minZ&&i.minY<=e.maxY&&i.maxY>=e.minY)}}const $n=(n,e=2)=>({minX:n.x-e,maxX:n.x+e,minZ:n.z-e,maxZ:n.z+e,minY:-1,maxY:(n.y||0)+30}),Di=st.halfSize,og=st.maxBlocks,ts=.28,lg=1.65,Va=["wood","brick","stone","glass"],ys=["flowers","lantern","bench"],Jl=[...Va,...ys],ih=(n,e,t)=>Math.max(e,Math.min(t,n)),vs=n=>`${n.x},${n.y},${n.z}`,ei=n=>{const e=(n.rotation||0)*Math.PI/180,t=Math.abs(Math.cos(e)),i=Math.abs(Math.sin(e)),r=n.type==="bench"?Math.max(0,(.94*t+.64*i-1)/2):0,s=n.type==="bench"?Math.max(0,(.94*i+.64*t-1)/2):0;return{minX:n.x-r,minY:n.y,minZ:n.z-s,maxX:n.x+1+r,maxY:n.y+1,maxZ:n.z+1+s}},rh=n=>({minX:n.x-ts,minY:n.y+.001,minZ:n.z-ts,maxX:n.x+ts,maxY:n.y+lg,maxZ:n.z+ts});function Ql(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function cg(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:ih((i.length/2-o)/i.length,0,1)*i.rise}function qi(n,e){if(e.ramp){const a=cg(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return qi(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=Ql(n),i=Ql(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const c=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),l=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=c+l-1e-5)return!1}return!0}const hg=(n,e)=>e.some(t=>qi(rh(n),t)),sh={x:-14.4,y:0,z:-1.2,yaw:0,pitch:0};function dg(){return{version:st.saveVersion,world:st.id,blocks:[],inventory:{flowers:0,lantern:0,bench:0},selected:"hand",player:{...sh},doors:{},doorSwings:{}}}function ug(n,e=[]){var l,d,u;if(!n||![1,2,3,st.saveVersion].includes(n.version)||n.version===st.saveVersion&&n.world!==st.id||n.version===2&&n.world!=="little-block-world-04"||n.version===3&&n.world!=="little-block-world-05"||!Array.isArray(n.blocks)||n.blocks.length>og)throw Error("This is not a supported BlockWorld save");const t=n.version===1,i=n.version===2;if(t&&n.blocks.length>800)throw Error("Older saves support up to 800 pieces");const r=dg(),s=new Set,a=new bn(4),o=new bn;for(const h of e)o.add(h);for(const h of n.blocks){if(!h||!Jl.includes(h.type)||![h.x,h.y,h.z].every(Number.isInteger)||h.y<0||h.y>=st.buildHeight||h.x<-Di||h.x>=Di||h.z<-Di||h.z>=Di||t&&(Math.abs(h.x)>31||h.x===31||Math.abs(h.z)>31||h.z===31||h.y>9)||i&&(h.x<-125||h.x>=125||h.z<-125||h.z>=125)||s.has(vs(h)))throw Error("The save contains an invalid piece");if(o.query(ei(h)).some(x=>qi(ei(h),x.ramp?{...x,ramp:null}:x)))throw Error("A saved piece overlaps the neighborhood");const f=ei(h);if(a.query(f).some(x=>qi(f,x)))throw Error("Saved pieces overlap");a.add(f),s.add(vs(h));const y=h.rotation??0;if(!Number.isFinite(y)||Math.abs(y)>36e3)throw Error("The piece rotation is invalid");r.blocks.push({x:h.x,y:h.y,z:h.z,type:h.type,...ys.includes(h.type)?{rotation:(y%360+360)%360}:{}})}for(const h of ys){const f=((l=n.inventory)==null?void 0:l[h])??0;if(!Number.isInteger(f)||f<0||f>999)throw Error("The inventory is invalid");r.inventory[h]=f}const c=n.player;c&&["x","y","z","yaw","pitch"].every(h=>Number.isFinite(c[h]))&&Math.abs(c.x)<Di&&Math.abs(c.z)<Di&&c.y>=0&&c.y<=st.buildHeight+2&&(r.player={x:c.x,y:c.y,z:c.z,yaw:c.yaw%(Math.PI*2),pitch:ih(c.pitch,-1.3,1.3)}),(n.selected==="hand"||Jl.includes(n.selected))&&(r.selected=n.selected);for(const h of Object.keys(n.doors||{}).filter(f=>/^[a-z][a-z0-9-]{0,39}$/.test(f)&&!["constructor","prototype"].includes(f)))r.doors[h]=((d=n.doors)==null?void 0:d[h])===!0,r.doorSwings[h]=((u=n.doorSwings)==null?void 0:u[h])===1?1:-1;return hg(r.player,[...e,...r.blocks.map(ei)])&&(r.player={...sh}),r}function fg(n,e){const c=(h,f,y=.7)=>[-h/2+.1,h/2-.1].flatMap(x=>[-f/2+.1,f/2-.1].map(m=>e(x,y/2,m,.1,y,.1,11963744))),l=(h,f,y=.2)=>[e(-h/2,f/2,0,.2,f,y,15655365),e(h/2,f/2,0,.2,f,y,15655365),e(0,f,0,h+.2,.2,y,15655365)],d=(h,f,y,x)=>[e(-h/2,f/2,0,.12,f,y,11963744),e(h/2,f/2,0,.12,f,y,11963744),...Array.from({length:x},(m,p)=>e(0,.08+p*(f-.16)/(x-1),0,h,.12,y,11963744))],u=[e(0,.45,0,.8,.15,.8,7838867),e(0,.85,.35,.8,.7,.12,7838867),...c(.7,.7,.4)];for(const[h,f,y,x]of[["parquet","Parquet flooring",12622701,"parquet"],["herringbone-brick","Herringbone paving",12748393,"herringbone"],["river-stone","River stone",9873565,"river"],["corrugated-metal","Corrugated sheet",10663094,"corrugated"],["woven-bamboo","Woven bamboo",13022593,"woven"],["shingles","Roof shingles",9143927,"shingles"]])n(h,f,"Materials",[e(0,.5,0,1,1,1,y)],{cube:!0,surface:x});n("window-wall","Wall with window opening","Shapes",[e(-.8,1.25,0,.4,2.5,.2,15655365),e(.8,1.25,0,.4,2.5,.2,15655365),e(0,.4,0,1.2,.8,.2,15655365),e(0,2.25,0,1.2,.5,.2,15655365)]),n("doorway-wall","Wall with clear doorway","Shapes",l(1.5,2.5)),n("wide-floor","Four-metre floor","Shapes",[e(0,.075,0,4,.15,4,11963744)]),n("long-slab","Long half slab","Shapes",[e(0,.25,0,3,.5,1,13143410)]),n("half-block","Half-width block","Shapes",[e(0,.5,0,.5,1,1,15655365)]),n("corner-pillar","L-shaped pillar","Shapes",[e(-.25,1.25,0,.25,2.5,.8,13143410),e(0,1.25,-.25,.8,2.5,.25,13143410)]),n("fluted-column","Fluted column","Shapes",[e(0,.12,0,.9,.24,.9,15655365),e(0,1.4,0,.4,2.6,.7,15655365),e(0,1.4,0,.7,2.6,.4,15655365),e(0,2.8,0,.9,.2,.9,15655365)]),n("roof-ridge","Roof ridge cap","Shapes",[e(0,.15,0,1,.3,2,13143410),e(0,.36,0,.45,.18,2,13143410)]),n("roof-corner","Roof corner","Shapes",[e(0,.5,0,1,1,1,13143410,"wedge"),{...e(.5,.5,.5,1,1,1,13143410,"wedge"),yaw:Math.PI/2}]),n("brick-stairs","Wide masonry stairs","Shapes",Array.from({length:6},(h,f)=>e(0,(f+1)/6,1.25-f*.5,2,(f+1)/3,.5,13143410)),{ramp:!0,rampLength:3}),n("long-ramp","Long accessible ramp","Shapes",[e(0,1,0,2,2,4,11963744,"wedge")],{ramp:!0,rampLength:4}),n("balcony","Balcony platform","Shapes",[e(0,.1,0,2,.2,2,11963744),...[-.95,.95].map(h=>e(h,.7,0,.1,1.2,2,6782077)),e(0,.7,-.95,2,1.2,.1,6782077)]),n("casement-window","Opening casement window","Openings",[...l(1.2,1.2,.12),e(0,.05,0,1.2,.1,.12,15655365),e(0,.6,0,1.04,1.05,.08,10536654)],{interaction:"door"}),n("stable-door","Stable half door","Openings",[...l(1.4,1.2),e(0,.6,0,1.2,1.05,.12,11963744)],{interaction:"door"}),n("field-gate","Wide field gate","Openings",[...l(2.5,1.25),e(0,.65,0,2.3,1,.1,7838867)],{interaction:"door"}),n("lattice-fence","Lattice fence","Openings",[e(-.65,.65,0,.1,1.3,.12,11963744),e(.65,.65,0,.1,1.3,.12,11963744),...[-.4,0,.4].flatMap(h=>[e(h,.45,0,.1,.8,.12,11963744),e(0,.3+h,0,1.3,.08,.12,11963744)])]),n("garage-frame","Wide garage opening frame","Openings",l(4.5,3,.35)),n("round-table","Octagonal dining table","Furniture",[e(0,.76,0,1.4,.14,1,11963744),e(0,.76,0,1,.14,1.4,11963744),e(0,.38,0,.25,.76,.25,6782077),e(0,.08,0,.9,.16,.9,6782077)]),n("rocking-chair","Rocking chair","Furniture",[...u,e(-.3,.08,0,.12,.16,1.1,11963744),e(.3,.08,0,.12,.16,1.1,11963744)]),n("beanbag","Beanbag seat","Furniture",[e(0,.25,0,.9,.5,.9,13143410),e(0,.5,.2,.8,.35,.55,13143410),e(0,.18,-.25,1,.25,.7,13143410)],{interaction:"seat"}),n("loft-bed","Loft bed with desk","Furniture",[e(0,1.6,0,1.2,.25,2,7838867),...c(1.2,2,1.6),e(0,.75,-.5,1,.12,.7,11963744),e(0,1.85,-.95,1.2,.4,.1,11963744)]),n("chaise","Chaise lounge","Furniture",[e(0,.4,0,.85,.35,1.8,7838867),e(0,.75,.7,.85,.7,.25,7838867),...c(.8,1.7,.25)],{interaction:"seat"}),n("wall-clock","Wall clock","Furniture",[e(0,.45,0,.8,.9,.1,11963744),e(0,.45,.07,.64,.72,.04,15655365),e(0,.58,.1,.04,.27,.03,6782077),e(.15,.45,.1,.3,.04,.03,6782077)]),n("picture-frame","Landscape picture","Furniture",[e(0,.45,0,1.1,.9,.1,11963744),e(0,.46,.07,.95,.7,.04,10536654),e(0,.23,.1,.95,.25,.02,7838867),e(.25,.65,.1,.15,.15,.02,15980422)]),n("coat-rack","Coat stand","Furniture",[e(0,.9,0,.12,1.8,.12,11963744),e(0,1.5,0,.8,.1,.15,11963744),e(0,1.25,0,.15,.1,.7,11963744),e(0,.06,0,.7,.12,.7,6782077)]),n("shoe-rack","Open shoe rack","Furniture",d(1,.65,.4,3)),n("folding-screen","Folding room screen","Furniture",[-1,0,1].map(h=>({...e(h*.6,1,Math.abs(h)*.18,.6,2,.08,7838867),yaw:h*.35}))),n("corner-counter","Corner kitchen counter","Kitchen",[e(-.35,.5,0,.6,1,1.3,7838867),e(.3,.5,-.35,.7,1,.6,7838867),e(-.35,1.05,0,.68,.1,1.4,15655365),e(.3,1.05,-.35,.7,.1,.68,15655365)]),n("dishwasher","Dishwasher","Kitchen",[e(0,.5,0,.8,1,.7,15655365),e(0,.5,.37,.65,.65,.04,6782077),e(0,.9,.38,.5,.06,.04,7838867)]),n("washing-machine","Washing machine","Kitchen",[e(0,.5,0,.85,1,.75,15655365),e(0,.45,.39,.55,.55,.06,6782077),e(0,.45,.43,.35,.35,.02,10536654),e(.25,.9,.4,.1,.1,.04,7838867)]),n("microwave","Microwave","Kitchen",[e(0,.22,0,.65,.44,.45,15655365),e(-.08,.22,.24,.4,.3,.03,6782077),e(.23,.3,.25,.07,.08,.03,7838867)]),n("kettle","Electric kettle","Kitchen",[e(0,.18,0,.28,.36,.28,7838867),e(.18,.2,0,.12,.08,.12,7838867),e(-.18,.22,0,.1,.22,.12,6782077),e(0,.03,0,.35,.06,.35,6782077)]),n("toaster","Toaster","Kitchen",[e(0,.15,0,.42,.3,.28,13143410),e(-.1,.31,0,.06,.02,.2,6782077),e(.1,.31,0,.06,.02,.2,6782077),e(.23,.2,0,.04,.06,.08,6782077)]),n("cup-rack","Cup rack","Kitchen",[e(0,.06,0,.5,.12,.4,11963744),e(0,.4,0,.08,.7,.08,11963744),e(0,.55,0,.55,.06,.08,11963744),...[-.2,.2].map(h=>e(h,.42,0,.15,.2,.16,15655365))]),n("dining-hutch","Dining hutch","Kitchen",[e(0,.45,0,1.5,.9,.6,11963744),...d(1.4,1,.35,3).map(h=>({...h,y:h.y+.9,z:h.z-.1})),e(0,1.4,-.3,1.5,1,.08,11963744)]),n("corner-bath","Corner bath","Bathroom",[e(-.2,.3,0,.9,.6,1.4,15655365),e(.35,.3,-.3,.8,.6,.8,15655365),e(-.2,.62,0,.65,.03,1.1,10536654)]),n("laundry-basket","Laundry basket","Bathroom",[e(0,.05,0,.65,.1,.55,11963744),...[-.3,.3].map(h=>e(h,.35,0,.07,.7,.55,11963744)),...[-.25,.25].map(h=>e(0,.35,h,.6,.7,.06,11963744)),e(0,.67,0,.5,.08,.4,15655365)]),n("bath-mat","Bath mat","Bathroom",[e(0,.02,0,1.1,.04,.65,7838867),...[-.4,-.2,0,.2,.4].map(h=>e(h,.045,0,.06,.01,.6,15655365))]),n("soap-dispenser","Soap dispenser","Bathroom",[e(0,.15,0,.18,.3,.18,13143410),e(0,.34,0,.06,.08,.06,6782077),e(.06,.39,0,.18,.03,.05,6782077)]),n("shower-stool","Shower stool","Bathroom",[e(0,.45,0,.6,.1,.5,15655365),...c(.5,.4,.4)],{interaction:"seat"}),n("car-lift","Garage service lift","Workshop",[e(-1.4,1.4,0,.3,2.8,.5,7838867),e(1.4,1.4,0,.3,2.8,.5,7838867),e(-.8,.18,0,.45,.2,4,6782077),e(.8,.18,0,.45,.2,4,6782077)]),n("air-compressor","Air compressor","Workshop",[e(0,.4,0,1.1,.5,.5,13143410),e(0,.78,0,.45,.25,.35,6782077),...[-.4,.4].map(h=>e(h,.15,0,.2,.3,.65,6782077)),e(.55,.9,0,.1,.5,.1,6782077)]),n("tool-board","Tool pegboard","Workshop",[e(0,.65,0,1.6,1.3,.1,11963744),...[-.55,0,.55].flatMap((h,f)=>[e(h,.6,.1,.08,.65,.07,6782077),e(h,.9,.1,f===1?.3:.16,.1,.07,6782077)])]),n("wheelbarrow","Wheelbarrow","Workshop",[e(0,.55,0,.8,.25,1,7838867),e(-.35,.65,.7,.08,.1,1,11963744),e(.35,.65,.7,.08,.1,1,11963744),e(0,.2,-.5,.2,.4,.4,6782077),e(-.3,.25,.3,.06,.5,.06,6782077),e(.3,.25,.3,.06,.5,.06,6782077)]),n("sawhorse","Folding sawhorse","Workshop",[e(0,.8,0,1.4,.15,.2,11963744),...[-.55,.55].flatMap(h=>[-.3,.3].map(f=>e(h,.4,f,.1,.8,.1,11963744)))]),n("bench-vice","Bench vice","Workshop",[e(0,.08,0,.6,.16,.4,6782077),e(-.18,.27,0,.15,.3,.4,7838867),e(.18,.27,0,.15,.3,.4,7838867),e(.35,.2,0,.4,.06,.06,6782077)]),n("bicycle-rack","Bicycle parking rack","Workshop",[e(0,.08,0,2,.16,.65,6782077),...[-.7,0,.7].map(h=>e(h,.4,0,.08,.8,.65,6782077))]),n("willow","Weeping willow","Garden",[e(0,1.3,0,.35,2.6,.35,11963744),e(0,3,0,2.8,1.4,2.8,7838867),...[-1.2,1.2].flatMap(h=>[-1.2,1.2].map(f=>e(h,1.9,f,.35,2,.35,7838867)))]),n("birch","Birch tree","Garden",[e(0,1.6,0,.25,3.2,.25,15655365),e(0,3.1,0,1.3,1.8,1.4,10007682),e(.5,2.7,0,.9,1.1,1,10007682),...Array.from({length:6},(h,f)=>e(0,.3+f*.4,.13,.25,.06,.02,6782077))]),n("fern","Fern","Garden",[-1,0,1].flatMap(h=>[e(h*.23,.25,0,.18,.5,.8,7838867),e(0,.2,h*.23,.8,.4,.18,7838867)])),n("flower-arch","Flowered garden arch","Garden",[...l(2.4,2.8,.3),...[-1.15,1.15].flatMap(h=>[e(h,1.4,0,.4,1.8,.4,7838867),e(h,2.3,0,.5,.4,.5,13143410)]),e(0,2.9,0,2.3,.25,.5,7838867)]),n("raised-bed","Raised vegetable bed","Garden",[e(0,.2,0,2,.4,1.3,11963744),e(0,.42,0,1.8,.04,1.1,9205339),...[-.6,0,.6].flatMap(h=>[-.3,.3].map(f=>e(h,.58,f,.3,.3,.3,7838867)))]),n("stone-path","Stepping stone path","Garden",[-.65,0,.65].map((h,f)=>e(f%2?.1:-.1,.03,h,.85,.06,.5,11318688))),n("pond-bridge","Garden footbridge","Garden",[e(0,.18,0,1.6,.2,3,11963744),...[-.85,.85].flatMap(h=>[e(h,.65,0,.1,.1,3,11963744),...[-1.3,0,1.3].map(f=>e(h,.35,f,.1,.7,.1,11963744))])].map(h=>({...h,color:h.color||11963744}))),n("watering-can","Watering can","Garden",[e(0,.22,0,.4,.44,.35,7838867),{...e(.35,.24,0,.5,.12,.12,7838867),yaw:0},e(-.25,.3,0,.12,.35,.12,6782077),e(0,.5,0,.35,.08,.12,6782077)]),n("wall-sconce","Wall sconce","Lighting",[e(0,.35,-.1,.3,.7,.1,6782077),e(0,.45,.12,.35,.4,.35,16768917)],{interaction:"light"}),n("desk-lamp","Articulated desk lamp","Lighting",[e(0,.04,0,.5,.08,.4,6782077),e(-.15,.3,0,.06,.55,.06,7838867),e(0,.55,0,.4,.08,.08,7838867),e(.18,.5,0,.3,.2,.25,16768917)],{interaction:"light"}),n("string-lights","Garden string lights","Lighting",[e(-1.5,1.1,0,.1,2.2,.1,11963744),e(1.5,1.1,0,.1,2.2,.1,11963744),e(0,2.15,0,3,.04,.04,6782077),...[-1,-.33,.33,1].map(h=>e(h,2,0,.15,.25,.15,16768917))],{interaction:"light"}),n("camp-lantern","Camping lantern","Lighting",[e(0,.07,0,.4,.14,.4,6782077),e(0,.3,0,.28,.35,.28,16768917),e(0,.5,0,.4,.08,.4,7838867),e(0,.65,0,.25,.2,.05,6782077)],{interaction:"light"}),n("swing","Playground swing","Play",[e(-1,1.3,0,.15,2.6,.8,7838867),e(1,1.3,0,.15,2.6,.8,7838867),e(0,2.5,0,2.2,.15,.15,11963744),e(-.35,1.55,0,.04,1.8,.04,6782077),e(.35,1.55,0,.04,1.8,.04,6782077),e(0,.65,0,.8,.12,.45,13143410)]),n("seesaw","Seesaw","Play",[e(0,.3,0,.4,.6,.7,7838867),e(0,.65,0,3,.15,.4,11963744),e(-1.2,.8,0,.5,.15,.55,13143410),e(1.2,.8,0,.5,.15,.55,13143410)]),n("spring-rider","Spring pony","Play",[e(0,.25,0,.25,.5,.25,6782077),e(0,.65,0,.45,.5,.9,13143410),e(0,1,-.4,.3,.5,.25,13143410),e(0,.9,0,.6,.1,.1,7838867)]),n("trampoline","Garden trampoline","Play",[e(0,.4,0,2,.15,2,7838867),e(0,.49,0,1.7,.04,1.7,6782077),...c(1.9,1.9,.35)]),n("teddy","Teddy bear","Play",[e(0,.25,0,.3,.4,.25,11963744),e(0,.55,0,.35,.3,.28,11963744),...[-.18,.18].flatMap(h=>[e(h,.7,0,.12,.14,.12,11963744),e(h,.1,.1,.15,.15,.2,11963744)]),e(0,.54,.16,.12,.07,.04,6782077)]),n("toy-train","Toy train","Play",[e(0,.18,0,.4,.2,1,13143410),e(0,.4,.2,.4,.4,.35,7838867),e(0,.4,-.25,.25,.25,.35,6782077),...[-.23,.23].flatMap(h=>[-.32,.32].map(f=>e(h,.12,f,.12,.22,.2,6782077)))]),n("toy-blocks","Wooden toy blocks","Play",[e(-.2,.12,0,.25,.24,.3,13143410),e(.15,.17,0,.3,.34,.3,7838867),e(.1,.42,0,.6,.16,.3,15655365)]),n("chalkboard","Standing chalkboard","Play",[e(0,.95,0,1.4,1,.12,11963744),e(0,.95,.08,1.2,.8,.03,3693394),...[-.55,.55].map(h=>e(h,.5,0,.12,1,.5,11963744)),e(0,.9,.11,.6,.04,.02,15655365)]),n("post-box","Post box","Street",[e(0,.5,0,.5,1,.5,13143410),e(0,1.05,0,.6,.15,.6,13143410),e(0,.85,.26,.35,.06,.02,6782077)]),n("bus-shelter","Bus shelter","Street",[e(0,2.3,0,3,.2,1.8,7838867),...[-1.3,1.3].map(h=>e(h,1.1,-.6,.12,2.2,.12,6782077)),e(0,1.2,-.7,2.8,1.8,.08,10536654),e(0,.5,-.3,2,.15,.45,11963744),e(-.8,.25,-.3,.1,.5,.1,6782077),e(.8,.25,-.3,.1,.5,.1,6782077)]),n("street-sign","Direction signpost","Street",[e(0,1.1,0,.12,2.2,.12,11963744),e(.25,1.9,0,1,.3,.1,7838867),e(-.25,1.5,0,1,.3,.1,13143410)]),n("park-bin","Park recycling bin","Street",[e(0,.5,0,.65,1,.65,7838867),e(0,1.05,0,.75,.12,.75,6782077),e(0,.85,.34,.4,.16,.03,6782077)]),n("hydrant","Street hydrant","Street",[e(0,.4,0,.3,.8,.3,13143410),e(0,.85,0,.4,.12,.4,13143410),e(0,.6,0,.7,.18,.18,6782077)]),n("bollard","Path bollard","Street",[e(0,.45,0,.2,.9,.2,6782077),e(0,.75,0,.23,.15,.23,15655365)]),n("feeding-trough","Animal feeding trough","Farm",[e(0,.2,0,1.5,.4,.6,11963744),e(0,.42,0,1.3,.04,.4,7838867),e(-.55,.12,0,.12,.24,.75,6782077),e(.55,.12,0,.12,.24,.75,6782077)]),n("hay-bale","Hay bale","Farm",[e(0,.35,0,1.2,.7,.75,14007677),e(-.35,.35,0,.06,.72,.78,11963744),e(.35,.35,0,.06,.72,.78,11963744)]),n("chicken-coop","Chicken coop","Farm",[...c(1.4,1,.4),e(0,.5,0,1.4,.2,1,11963744),e(-.6,.9,0,.2,.8,1,15655365),e(.6,.9,0,.2,.8,1,15655365),e(0,.9,-.45,1.2,.8,.1,15655365),e(0,1.35,0,1.6,.25,1.2,13143410,"wedge")]),n("kennel","Dog kennel","Farm",[e(-.4,.35,0,.15,.7,1,11963744),e(.4,.35,0,.15,.7,1,11963744),e(0,.35,-.45,.8,.7,.1,11963744),e(0,.8,0,1,.25,1.1,7838867,"wedge")]),n("hitching-post","Hitching rail","Farm",[e(-.8,.6,0,.15,1.2,.15,11963744),e(.8,.6,0,.15,1.2,.15,11963744),e(0,1,0,1.8,.15,.15,11963744)]),n("beehive","Garden beehive","Farm",[e(0,.1,0,.85,.2,.75,11963744),...[0,1,2].map(h=>e(0,.3+h*.24,0,.65,.22,.6,14204024)),e(0,.92,0,.8,.12,.75,7838867)])}const as=new Set(["wood","brick","stone","glass","flowers","lantern","bench"]),W=(n,e,t,i,r,s,a,o="box")=>({x:n,y:e,z:t,w:i,h:r,d:s,color:a,shape:o}),Ge=11239513,ct=15852744,Je=5796718,Yi=10340302,hi=[];function Se(n,e,t,i,r={}){var s;hi.push({id:n,label:e,category:t,parts:i,icon:t==="Garden"?"🌿":t==="Lighting"?"💡":t==="Openings"?"🚪":t==="Furniture"?"🪑":"▦",color:((s=i[0])==null?void 0:s.color)||Ge,...r})}for(const[n,e,t]of[["wood","Wood",12424551],["brick","Brick",13075044],["stone","Stone",10267045],["glass","Glass",Yi]])Se(n,e,"Materials",[W(0,.5,0,1,1,1,t)],{cube:!0,icon:n==="wood"?"▥":n==="brick"?"▦":n==="stone"?"▧":"◈"});for(const[n,e,t]of[["flowers","Flowers","🌷"],["lantern","Lantern","🏮"],["bench","Bench","🪑"]])Se(n,e,n==="flowers"?"Garden":"Furniture",Jc[n].map(([i,r,s,a,o,c,l])=>W(i-.5,r,s-.5,a,o,c,l)),{icon:t});for(const[n,e,t,i]of[["oak-planks","Oak planks",12423520,"wood"],["bamboo","Bamboo",12763001,"bamboo"],["log-end","Timber logs",10912340,"log"],["white-brick","White brick",14407359,"brick"],["cobble","Cobblestone",9607822,"cobble"],["sandstone","Sandstone",14468245,"stone"],["marble","Marble",14867920,"marble"],["slate","Slate",6912896,"stone"],["concrete","Concrete",11710880,"concrete"],["terracotta","Terracotta",12419166,"tile"],["mosaic","Mosaic tiles",8563103,"mosaic"],["checker-tile","Checker tiles",14274995,"checker"],["copper","Copper panels",12157540,"metal"],["steel","Steel plate",11123392,"metal"],["grass","Turf",8957292,"grass"],["sand","Sand",14930847,"sand"]])Se(n,e,"Materials",[W(0,.5,0,1,1,1,t)],{cube:!0,surface:i});for(const[n,e,t,i,r,s]of[["slab","Half slab",1,.5,1,"box"],["floor-panel","Floor panel",1,.15,1,"box"],["wall-panel","Wall panel",1,2,.15,"box"],["half-wall","Half wall",1,1,.15,"box"],["pillar","Square pillar",.35,2.5,.35,"box"],["beam","Long beam",3,.25,.25,"box"],["post","Fence post",.18,1.2,.18,"box"],["roof-slope","Roof slope",1,1,1,"wedge"],["roof-slab","Roof sheet",2,.15,2,"box"],["ramp","Walking ramp",1,1,2,"wedge"],["wide-ramp","Wide ramp",2,1,2,"wedge"],["step","Low step",1,.25,.5,"box"],["foundation","Foundation plinth",2,.4,2,"box"]])Se(n,e,"Shapes",[W(0,i/2,0,t,i,r,n.includes("roof")?9665388:Ge,s)],{ramp:s==="wedge"});Se("stairs","Timber stairs","Shapes",Array.from({length:4},(n,e)=>W(0,(e+1)*.125,.75-e*.5,1,(e+1)*.25,.5,Ge)),{ramp:!0});Se("arch","Wide arch","Shapes",[W(-.8,1,0,.3,2,.4,12627596),W(.8,1,0,.3,2,.4,12627596),W(0,2,0,1.9,.35,.4,12627596)]);Se("corner-wall","Corner wall","Shapes",[W(-.42,1,0,.16,2,1,ct),W(0,1,-.42,1,2,.16,ct)]);for(const[n,e,t,i,r]of[["door","Timber door",1,2.2,Ge],["glass-door","Glass door",1,2.2,Yi],["double-door","Double-width door",2,2.2,Ge],["garden-gate","Garden gate",1.4,1.2,10268294]])Se(n,e,"Openings",[W(-t/2,i/2,0,.1,i,.18,Je),W(t/2,i/2,0,.1,i,.18,Je),W(0,i,0,t+.1,.1,.18,Je),W(0,i/2,0,t-.16,i-.1,.1,r)],{interaction:"door"});for(const[n,e,t,i]of[["window","Window",1.2,1.2],["wide-window","Wide window",2,1.2],["tall-window","Tall window",.8,2],["skylight","Skylight",1.2,.35]])Se(n,e,"Openings",[W(0,i/2,0,t,i,.09,Yi),W(-t/2,i/2,0,.08,i,.15,ct),W(t/2,i/2,0,.08,i,.15,ct),W(0,i,0,t+.08,.08,.15,ct),W(0,.04,0,t+.08,.08,.15,ct),W(0,i/2,0,.06,i,.16,ct)]);for(const[n,e,t]of[["picket-fence","Picket fence",ct],["rail-fence","Timber rail fence",Ge],["metal-rail","Metal railing",Je]])Se(n,e,"Openings",[...[-.48,.48].map(i=>W(i,.6,0,.1,1.2,.1,t)),W(0,.9,0,1,.1,.1,t),W(0,.4,0,1,.1,.1,t),...n==="picket-fence"?[-.25,0,.25].map(i=>W(i,.55,0,.09,1.1,.1,t)):[]]);const Ls=(n=1.5,e=1,t=.75,i=Ge)=>[W(0,t,0,n,.12,e,i),...[-n*.38,n*.38].flatMap(r=>[-e*.35,e*.35].map(s=>W(r,t/2,s,.1,t,.1,Je)))],zs=(n=1,e=9942176)=>[W(0,.4,0,n,.25,.8,e),W(0,.8,.34,n,.6,.16,e),...[-n*.36,n*.36].map(t=>W(t,.15,0,.1,.3,.6,Ge))];Se("chair","Dining chair","Furniture",zs(.6),{interaction:"seat"});Se("armchair","Armchair","Furniture",[...zs(1),W(-.48,.55,0,.18,.4,.8,9942176),W(.48,.55,0,.18,.4,.8,9942176)],{interaction:"seat"});Se("sofa","Two-seat sofa","Furniture",zs(1.9,9152434),{interaction:"seat"});Se("corner-sofa","Corner sofa","Furniture",[...zs(1.8,11772084),W(-.6,.4,-.7,.6,.25,1.2,11772084)],{interaction:"seat"});Se("stool","Stool","Furniture",[W(0,.55,0,.55,.12,.55,14003573),...[-.2,.2].flatMap(n=>[-.2,.2].map(e=>W(n,.25,e,.08,.5,.08,Ge)))],{interaction:"seat"});Se("dining-table","Dining table","Furniture",Ls(1.8,1));Se("coffee-table","Coffee table","Furniture",Ls(1.2,.7,.4));Se("desk","Writing desk","Furniture",[...Ls(1.5,.8),W(.5,.5,0,.4,.5,.65,14272417)]);for(const[n,e,t,i]of[["single-bed","Single bed",.95,2],["double-bed","Double bed",1.75,2.1]])Se(n,e,"Furniture",[W(0,.25,0,t,.5,i,Ge),W(0,.55,0,t,.15,i,15186816),W(0,.68,-i*.33,t*.8,.18,.45,ct),W(0,.65,-i/2,t,.8,.12,Ge)]);Se("bunk-bed","Bunk beds","Furniture",[W(0,.5,0,1,.2,2,14663563),W(0,1.7,0,1,.2,2,14663563),...[-.47,.47].flatMap(n=>[-.95,.95].map(e=>W(n,1,e,.1,2,.1,Ge))),...Array.from({length:5},(n,e)=>W(-.58,.2+e*.33,.6,.25,.08,.18,Ge))]);Se("crib","Crib","Furniture",[W(0,.4,0,.9,.15,1.5,ct),...[-.45,.45].flatMap(n=>[-.65,-.3,0,.3,.65].map(e=>W(n,.75,e,.06,.8,.06,Ge)))]);Se("wardrobe","Wardrobe","Furniture",[W(0,1,0,1.2,2,.6,Ge),W(0,1,.32,.04,1.8,.05,ct)]);Se("dresser","Dresser","Furniture",[W(0,.6,0,1.4,1.2,.65,Ge),...Array.from({length:3},(n,e)=>W(0,.25+e*.35,.34,1.25,.04,.04,ct))]);Se("nightstand","Nightstand","Furniture",[W(0,.3,0,.55,.6,.5,Ge),W(0,.4,.27,.1,.06,.05,Je)]);Se("bookcase","Bookcase","Furniture",[W(0,1,0,1.4,2,.35,Ge),...Array.from({length:6},(n,e)=>W(-.55+e*.22,1.35,.2,.16,.55,.08,[13208431,8562842,13876601][e%3]))]);Se("shelf","Wall shelf","Furniture",[W(0,.2,0,1.5,.12,.35,Ge),W(-.55,.1,.08,.1,.2,.1,Je),W(.55,.1,.08,.1,.2,.1,Je)]);Se("tv-cabinet","TV cabinet","Furniture",[W(0,.35,0,1.5,.7,.5,Ge),W(0,1,.05,1.2,.65,.12,Je),W(0,.95,.13,1.05,.5,.03,10930105)]);Se("rug","Woven rug","Furniture",[W(0,.025,0,1.8,.05,1.3,13216390),W(0,.055,0,1.5,.01,1,14994589)]);const Ds=(n=12897715)=>[W(0,.5,0,.98,1,.6,n),W(0,1.04,0,1,.08,.68,ct),W(0,.75,.32,.25,.05,.06,Je)];Se("kitchen-counter","Kitchen counter","Kitchen",Ds());Se("sink","Kitchen sink","Kitchen",[...Ds(),W(0,1.09,0,.6,.04,.4,9218473),W(.28,1.3,-.2,.06,.45,.06,Je)]);Se("stove","Cooker","Kitchen",[...Ds(13949132),...[-.25,.25].flatMap(n=>[-.18,.18].map(e=>W(n,1.1,e,.25,.02,.22,Je))),W(0,.55,.32,.7,.45,.04,Je)]);Se("fridge","Fridge","Kitchen",[W(0,1,0,.85,2,.8,14476243),W(.28,1,.42,.06,.6,.06,Je)]);Se("oven","Oven","Kitchen",[...Ds(11713718),W(0,.5,.32,.7,.5,.05,Je)]);Se("kitchen-island","Kitchen island","Kitchen",[W(0,.5,0,2,1,.8,10860973),W(0,1.05,0,2.2,.12,1,ct)]);Se("wall-cupboard","Wall cupboard","Kitchen",[W(0,.4,0,1,.8,.35,14081476),W(0,.4,.2,.04,.7,.03,Je)]);Se("bin","Kitchen bin","Kitchen",[W(0,.4,0,.5,.8,.5,Je),W(0,.82,0,.55,.08,.55,11779249)]);Se("toilet","Toilet","Bathroom",[W(0,.22,0,.4,.44,.5,ct),W(0,.48,-.05,.6,.15,.7,ct),W(0,.72,-.3,.6,.6,.18,ct)]);Se("bath","Bath","Bathroom",[W(0,.25,0,.9,.5,1.8,ct),W(0,.52,0,.7,.03,1.5,10077642),W(.32,.7,-.55,.05,.35,.05,Je)]);Se("shower","Shower","Bathroom",[W(0,.04,0,1,.08,1,ct),W(0,1,-.46,.9,2,.06,Yi),W(.44,1,0,.06,2,1,Yi),W(-.3,1.4,-.4,.05,1,.05,Je),W(-.3,1.95,-.2,.3,.07,.3,Je)]);Se("washbasin","Washbasin","Bathroom",[W(0,.5,0,.7,1,.5,12306876),W(0,1.05,0,.8,.12,.6,ct),W(.2,1.2,-.2,.05,.3,.05,Je)]);Se("mirror","Mirror","Bathroom",[W(0,.65,0,.8,1.3,.1,Ge),W(0,.65,.06,.68,1.15,.04,Yi)]);Se("towel-rail","Towel rail","Bathroom",[W(0,.6,0,.9,.08,.08,Je),W(0,.4,.04,.6,.45,.04,13939875)]);Se("workbench","Workbench","Workshop",[...Ls(2,.9,.9),W(0,1.4,-.35,2,.8,.1,Ge)]);Se("tool-cabinet","Tool cabinet","Workshop",[W(0,.7,0,1.1,1.4,.55,9153185),...Array.from({length:4},(n,e)=>W(0,.25+e*.3,.29,.8,.04,.05,Je))]);Se("garage-shelf","Garage shelving","Workshop",[...[-.7,.7].flatMap(n=>[-.3,.3].map(e=>W(n,1,e,.08,2,.08,Je))),...Array.from({length:4},(n,e)=>W(0,.2+e*.55,0,1.5,.08,.7,Ge))]);Se("storage-crate","Storage crate","Workshop",[W(0,.4,0,.8,.8,.8,Ge),W(0,.42,.41,.7,.1,.04,ct)]);Se("traffic-cone","Traffic cone","Workshop",[W(0,.06,0,.6,.12,.6,6255729),W(0,.3,0,.35,.5,.35,13998948),W(0,.6,0,.2,.2,.2,16050123)]);Se("tyre-stack","Tyre stack","Workshop",[W(0,.18,0,.7,.3,.7,Je),W(0,.52,0,.7,.3,.7,Je)]);for(const[n,e,t,i,r]of[["oak-tree","Oak tree",2.4,3.5,7444841],["pine-tree","Pine tree",1.6,4,6132863],["palm-tree","Palm tree",2.5,3.2,8890990],["fruit-tree","Fruit tree",2,2.8,9876856]])Se(n,e,"Garden",[W(0,i*.35,0,.25,i*.7,.25,Ge),...n==="pine-tree"?[0,1,2].map(s=>W(0,i*.48+s*.75,0,t*(1-s*.23),1,t*(1-s*.23),r)):n==="palm-tree"?[W(0,i*.86,0,t,.3,.45,r),W(0,i*.88,0,.45,.3,t,r),W(0,i*.95,0,.8,.5,.8,r)]:[W(0,i*.75,0,t*.75,i*.5,t*.75,r),...[-1,1].map(s=>W(s*t*.3,i*.71,0,t*.4,i*.33,t*.65,r))],...n==="fruit-tree"?[-.65,0,.65].map(s=>W(s,i*.75,.8,.2,.2,.2,14724205)):[]]);Se("hedge","Hedge","Garden",[W(0,.5,0,1.5,1,.7,7840116)]);Se("flower-bed","Flower bed","Garden",[W(0,.12,0,1.5,.24,.8,Ge),...[-.5,0,.5].map(n=>W(n,.45,0,.3,.5,.3,14069921))]);Se("planter","Square planter","Garden",[W(0,.25,0,.7,.5,.7,12555371),W(0,.65,0,.5,.5,.5,8956533)]);Se("vegetable-patch","Vegetable patch","Garden",[W(0,.06,0,1.8,.12,1.5,10847589),...[-.5,0,.5].flatMap(n=>[-.45,0,.45].map(e=>W(n,.22,e,.2,.3,.2,9021805)))]);Se("boulder","Boulder","Garden",[W(0,.35,0,1.3,.7,1.1,10398366),W(.2,.8,0,.8,.3,.8,10398366)]);Se("birdhouse","Birdhouse","Garden",[W(0,.8,0,.1,1.6,.1,Ge),W(0,1.65,0,.5,.5,.45,13939070),W(0,1.95,0,.65,.12,.6,9217434)]);Se("pergola","Pergola","Garden",[...[-1,1].flatMap(n=>[-1,1].map(e=>W(n,1.25,e,.15,2.5,.15,Ge))),...[-1,-.5,0,.5,1].map(n=>W(n,2.55,0,.15,.15,2.3,Ge))]);for(const[n,e,t,i]of[["table-lamp","Table lamp",.65,.4],["floor-lamp","Floor lamp",1.8,.6],["street-lamp","Street lamp",3,.7],["garden-light","Garden light",.7,.35],["ceiling-light","Ceiling lamp",.3,.7],["wall-light","Wall light",.5,.3]])Se(n,e,"Lighting",[W(0,t*.4,0,.08,t*.8,.08,Je),W(0,t*.85,0,i,t*.3,i,16768917),W(0,.04,0,i*.7,.08,i*.7,Je)],{interaction:"light"});Se("toy-box","Toy box","Play",[W(0,.3,0,1.1,.6,.7,13874817),W(0,.65,0,1.15,.1,.75,9154209)]);Se("dollhouse","Doll house","Play",[W(0,.25,0,.8,.5,.55,14529701),W(0,.6,0,.9,.25,.65,9348764,"wedge")]);Se("sandpit","Sandpit","Play",[W(0,.08,0,2,.16,2,Ge),W(0,.18,0,1.7,.08,1.7,14930335)]);Se("play-slide","Play slide","Play",[W(0,.5,0,.6,1,1.7,14202233,"wedge"),W(-.4,1,.7,.12,2,.12,Je),W(.4,1,.7,.12,2,.12,Je)]);Se("goal","Play goal","Play",[W(-1,.7,0,.1,1.4,.1,ct),W(1,.7,0,.1,1.4,.1,ct),W(0,1.4,0,2.1,.1,.1,ct)]);fg(Se,W);for(const[n,e]of[["swing","swing"],["seesaw","seesaw"],["spring-rider","rock"],["rocking-chair","rock"],["trampoline","bounce"],["play-slide","slide"],["bench","seat"],["lantern","light"]])hi.find(t=>t.id===n).interaction=e;const Wa=hi.find(n=>n.id==="dining-hutch");Wa.interaction="cabinet";Wa.parts=[W(-.7,.45,0,.1,.9,.6,Ge),W(.7,.45,0,.1,.9,.6,Ge),W(0,.45,-.25,1.4,.9,.1,Ge),W(0,.05,0,1.4,.1,.6,Ge),W(0,.87,0,1.5,.12,.6,Ge),...Wa.parts.slice(1),W(0,.45,.32,1.3,.72,.08,10860706)];const zt=new Map(hi.map(n=>[n.id,n]));function mo(n,e){const t=zt.get(n.type);if(!t)throw Error("Unknown catalogue item");const i=t.parts.filter((r,s)=>!(["garden-gate","stable-door","field-gate"].includes(n.type)&&s===2)).map(r=>({...r}));if(["door","cabinet"].includes(t.interaction||"")&&(n.open||e!==void 0)){const r=i.at(-1),s=(e??(n.open?1:0))*Math.PI/2*(t.interaction==="cabinet"?-1:1);r.x+=-r.w/2+Math.cos(s)*r.w/2,r.z+=-Math.sin(s)*r.w/2,r.yaw=s}if(t.interaction==="light"&&n.on===!1)for(const r of i)r.color===16768917&&(r.color=12960431);return i}function ah(n,e){if(as.has(n.type))return[ei(n)];const t=(n.rotation||0)*Math.PI/180,i=Math.cos(t),r=Math.sin(t),s=zt.get(n.type);if(s.ramp){const a=Math.max(...s.parts.map(l=>l.w)),o=s.rampLength||(n.type==="stairs"?2:s.parts[0].d),c=Math.max(...s.parts.map(l=>l.y+l.h/2));return[{minX:n.x+.5-(Math.abs(i)*a+Math.abs(r)*o)/2,maxX:n.x+.5+(Math.abs(i)*a+Math.abs(r)*o)/2,minZ:n.z+.5-(Math.abs(r)*a+Math.abs(i)*o)/2,maxZ:n.z+.5+(Math.abs(r)*a+Math.abs(i)*o)/2,minY:n.y,maxY:n.y+c,ramp:{cx:n.x+.5,cz:n.z+.5,c:i,s:r,width:a,length:o,rise:c,baseY:n.y}}]}return mo(n,e).map(a=>{const o=t+(a.yaw||0),c=Math.cos(o),l=Math.sin(o),d=n.x+.5+a.x*i+a.z*r,u=n.z+.5-a.x*r+a.z*i,h=(Math.abs(c)*a.w+Math.abs(l)*a.d)/2,f=(Math.abs(l)*a.w+Math.abs(c)*a.d)/2;return{minX:d-h,maxX:d+h,minZ:u-f,maxZ:u+f,minY:n.y+a.y-a.h/2,maxY:n.y+a.y+a.h/2,obb:{cx:d,cz:u,c,s:l,halfW:a.w/2,halfD:a.d/2}}})}function Qe(n){return ah(n)}function pg(n,e){return ah(n,e)}function Ms(n){const e=Qe(n);return{minX:Math.min(...e.map(t=>t.minX)),maxX:Math.max(...e.map(t=>t.maxX)),minY:Math.min(...e.map(t=>t.minY)),maxY:Math.max(...e.map(t=>t.maxY)),minZ:Math.min(...e.map(t=>t.minZ)),maxZ:Math.max(...e.map(t=>t.maxZ))}}const Is=[{id:"set-bedroom",label:"Bedroom set",category:"Presets",icon:"🛏",color:Ge,blocks:[{x:0,y:0,z:0,type:"single-bed"},{x:2,y:0,z:0,type:"nightstand"},{x:2,y:0,z:2,type:"floor-lamp"}]},{id:"set-kitchen",label:"Kitchen run",category:"Presets",icon:"🍳",color:ct,blocks:[{x:0,y:0,z:0,type:"kitchen-counter"},{x:1,y:0,z:0,type:"sink"},{x:2,y:0,z:0,type:"stove"}]},{id:"set-garden",label:"Garden seating",category:"Presets",icon:"🌷",color:Ge,blocks:[{x:0,y:0,z:0,type:"bench"},{x:-2,y:0,z:0,type:"planter"},{x:2,y:0,z:0,type:"planter"}]},{id:"set-workshop",label:"Workshop set",category:"Presets",icon:"🛠",color:Je,blocks:[{x:0,y:0,z:0,type:"workbench"},{x:3,y:0,z:0,type:"tool-cabinet"},{x:0,y:0,z:2,type:"storage-crate"}]}];Is.push({id:"set-dining",label:"Family dining",category:"Presets",icon:"🍽",color:Ge,blocks:[{x:0,y:0,z:0,type:"round-table"},{x:-2,y:0,z:0,type:"chair",rotation:270},{x:2,y:0,z:0,type:"chair",rotation:90},{x:0,y:0,z:2,type:"chair"}]},{id:"set-bathroom",label:"Bathroom suite",category:"Presets",icon:"🛁",color:ct,blocks:[{x:0,y:0,z:0,type:"washbasin"},{x:2,y:0,z:0,type:"toilet"},{x:4,y:0,z:0,type:"bath"}]},{id:"set-study",label:"Reading and study",category:"Presets",icon:"📚",color:Ge,blocks:[{x:0,y:0,z:0,type:"desk"},{x:0,y:.81,z:0,type:"desk-lamp"},{x:0,y:0,z:2,type:"chair"},{x:3,y:0,z:0,type:"bookcase"}]},{id:"set-playground",label:"Little playground",category:"Presets",icon:"🛝",color:Ge,blocks:[{x:0,y:0,z:0,type:"swing"},{x:4,y:0,z:0,type:"play-slide"},{x:0,y:0,z:4,type:"sandpit"}]},{id:"set-farm",label:"Animal care corner",category:"Presets",icon:"🐾",color:Ge,blocks:[{x:0,y:0,z:0,type:"feeding-trough"},{x:3,y:0,z:0,type:"kennel"},{x:-3,y:0,z:0,type:"hay-bale"}]},{id:"set-bus-stop",label:"Neighbourhood bus stop",category:"Presets",icon:"🚏",color:Je,blocks:[{x:0,y:0,z:0,type:"bus-shelter"},{x:3,y:0,z:0,type:"street-sign"},{x:-3,y:0,z:0,type:"park-bin"}]},{id:"set-picnic",label:"Picnic corner",category:"Presets",icon:"☀",color:Ge,blocks:[{x:0,y:0,z:0,type:"round-table"},{x:0,y:0,z:2,type:"bench"},{x:0,y:0,z:-2,type:"bench",rotation:180},{x:3,y:0,z:0,type:"planter"}]},{id:"set-pavilion",label:"Open garden pavilion",category:"Presets",icon:"⌂",color:Ge,blocks:[{x:0,y:0,z:0,type:"wide-floor"},...[-1,1].flatMap(n=>[-1,1].map(e=>({x:n,y:.15,z:e,type:"pillar"}))),{x:0,y:2.65,z:0,type:"wide-floor"}]});const si=[...hi,...Is];function oh(n){const e=Is.find(s=>s.id===n.type);if(!e)return[n];const t=(n.rotation||0)*Math.PI/180,i=Math.round(Math.cos(t)),r=Math.round(Math.sin(t));return e.blocks.map(s=>({x:n.x+s.x*i+s.z*r,y:n.y+s.y,z:n.z-s.x*r+s.z*i,type:s.type,rotation:((n.rotation||0)+(s.rotation||0))%360}))}const Fi=n=>`${Math.floor(n.x/st.chunkSize)},${Math.floor(n.z/st.chunkSize)}`;class mg{constructor(e,t,i,r){Object.assign(this,{parent:e,geometry:t,materials:i,decorMat:r}),this.cells=new Map,this.groups=new Map,this.rebuilt=0}clear(){for(const e of this.groups.values())this.dispose(e);this.cells.clear(),this.groups.clear()}dispose(e){e.traverse(t=>{t.isInstancedMesh&&t.dispose(),t.userData.ownedGeometry&&t.geometry.dispose()}),e.removeFromParent()}reset(e){this.clear();for(const t of e)this.store(t);for(const t of this.cells.keys())this.rebuild(t)}store(e){const t=Fi(e);this.cells.has(t)||this.cells.set(t,new Map),this.cells.get(t).set(vs(e),e)}update(e,t){var s;const i=Fi(e);t?this.store(e):(s=this.cells.get(i))==null||s.delete(vs(e));const r=new Set([i]);st.chunkSize;for(const[a,o]of[[1,0],[-1,0],[0,1],[0,-1]]){const c=Fi({x:e.x+a,z:e.z+o});c!==i&&this.cells.has(c)&&r.add(c)}for(const a of r)this.rebuild(a)}opaque(e,t,i){var r,s;return Va.includes((s=(r=this.cells.get(Fi({x:e,z:i})))==null?void 0:r.get(`${e},${t},${i}`))==null?void 0:s.type)}rebuild(e){var d;const t=this.groups.get(e);t&&this.dispose(t);const i=new nt,r=[...((d=this.cells.get(e))==null?void 0:d.values())||[]],s=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],a=this.geometry;for(const u of Va){const h=[],f=[],y=[],x=[],m=[];for(const g of r.filter(v=>v.type===u))for(let v=0;v<6;v++){const[A,E,C]=s[v];if(this.opaque(g.x+A,g.y+E,g.z+C))continue;const z=h.length/3;for(let M=0;M<4;M++){const b=v*4+M;h.push(a.attributes.position.getX(b)+g.x+.5,a.attributes.position.getY(b)+g.y+.5,a.attributes.position.getZ(b)+g.z+.5),f.push(a.attributes.normal.getX(b),a.attributes.normal.getY(b),a.attributes.normal.getZ(b)),y.push(a.attributes.uv.getX(b),a.attributes.uv.getY(b))}for(let M=0;M<6;M++)x.push(z+a.index.array[v*6+M]-v*4);m.push(g,g)}if(!h.length)continue;const p=new tt;p.setAttribute("position",new De(h,3)),p.setAttribute("normal",new De(f,3)),p.setAttribute("uv",new De(y,2)),p.setIndex(x),p.computeBoundingSphere(),p.computeBoundingBox();const _=new we(p,this.materials[u]);_.userData.faceBlocks=m,_.userData.ownedGeometry=!0,i.add(_)}const o=new Map,c=new mt,l=new mt;for(const u of r.filter(h=>ys.includes(h.type))){c.position.set(u.x+.5,u.y,u.z+.5),c.rotation.y=(u.rotation||0)*Math.PI/180,c.updateMatrix();for(const[h,f,y,x,m,p,_]of Jc[u.type])l.position.set(h-.5,f,y-.5),l.scale.set(x,m,p),l.updateMatrix(),o.has(_)||o.set(_,[]),o.get(_).push({b:u,m:new et().multiplyMatrices(c.matrix,l.matrix)})}for(const[u,h]of o){const f=new xs(this.geometry,this.decorMat(u),h.length);h.forEach((y,x)=>f.setMatrixAt(x,y.m)),f.userData.blocks=h.map(y=>y.b),f.computeBoundingSphere(),i.add(f)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i),this.rebuilt++}rayMeshes(){const e=[];return this.parent.traverse(t=>{t.isMesh&&e.push(t)}),e}}const gg=new ht(1,1,1),Us=new tt;Us.setAttribute("position",new De([-.5,-.5,-.5,.5,-.5,-.5,-.5,-.5,.5,.5,-.5,.5,-.5,.5,-.5,.5,.5,-.5],3));Us.setIndex([0,2,1,1,2,3,0,1,4,1,5,4,0,4,2,1,3,5,2,4,3,3,4,5]);Us.computeVertexNormals();const Sa=new Map;function lh(n,e){if(Sa.has(n))return Sa.get(n);if(typeof document>"u")return;const t=document.createElement("canvas");t.width=t.height=128;const i=t.getContext("2d");if(i.fillStyle="#ffffff",i.fillRect(0,0,128,128),i.strokeStyle="#c7c7c7",i.lineWidth=3,["parquet","herringbone","woven","shingles","corrugated","river"].includes(e))if(e==="corrugated")for(let s=0;s<128;s+=16)i.fillStyle="#b2b2b2",i.fillRect(s,0,4,128),i.fillStyle="#eeeeee",i.fillRect(s+4,0,5,128);else if(e==="river")for(let s=0;s<24;s++)i.fillStyle=s%2?"#cccccc":"#eeeeee",i.beginPath(),i.ellipse(s*43%128,s*67%128,13,9,s,0,Math.PI*2),i.fill(),i.stroke();else{const s=e==="woven"?12:32;for(let a=0;a<128;a+=s)for(let o=0;o<128;o+=s){if(i.save(),i.translate(o+s/2,a+s/2),["parquet","herringbone"].includes(e)&&i.rotate((o+a)/s%2?Math.PI/2:0),i.strokeRect(-s/2,-s/2,s,s),e==="shingles")i.beginPath(),i.arc(0,-s/2,s/2,0,Math.PI),i.stroke();else for(let c=-s/2;c<s/2;c+=s/4)i.beginPath(),i.moveTo(c,-s/2),i.lineTo(c,s/2),i.stroke();i.restore()}}else if(["brick","tile","checker","mosaic","metal"].includes(e)){const s=e==="mosaic"?16:e==="metal"?64:32;for(let a=0;a<128;a+=s)for(let o=0;o<128;o+=s){const c=o-(e==="brick"&&a/s%2?s/2:0);e==="checker"&&(o+a)/s%2===0&&(i.fillStyle="#aaaaaa",i.fillRect(c,a,s,s)),i.strokeRect(c,a,s,s)}}else if(["wood","bamboo","log"].includes(e)){for(let s=0;s<8;s++)i.beginPath(),i.moveTo(s*18,0),i.lineTo(s*18,128),i.stroke();if(e==="log")for(let s=12;s<64;s+=12)i.beginPath(),i.arc(64,64,s,0,Math.PI*2),i.stroke()}else for(let s=0;s<110;s++){const a=s*37%128,o=s*67%128;i.fillStyle=s%3?"#e1e1e1":"#bdbdbd",i.fillRect(a,o,e==="cobble"?15:e==="marble"?22:3,e==="cobble"?12:2)}const r=new vr(t);return r.userData.shared=!0,r.colorSpace=vt,r.magFilter=Lt,Sa.set(n,r),r}const ch=n=>n.shape==="wedge"?Us:gg;function li(n,e=!1){const t=new nt;t.position.set(n.x+.5,n.y,n.z+.5),t.rotation.y=(n.rotation||0)*Math.PI/180;const i=zt.get(n.type);if(!i){for(const r of oh(n))t.add(li({...r,x:r.x-n.x-.5,y:r.y-n.y,z:r.z-n.z-.5},e));return t.rotation.y=0,t.position.set(n.x+.5,n.y,n.z+.5),t}for(const r of mo(n)){const s=new we(ch(r),new _t({color:r.color,map:i.surface&&lh(i.id,i.surface)||null,transparent:e,opacity:e?.55:1}));s.position.set(r.x,r.y,r.z),s.scale.set(r.w,r.h,r.d),s.rotation.y=r.yaw||0,s.userData.block=n,s.userData.sharedGeometry=!0,t.add(s)}return t}class xg{constructor(e,t,i,r){this.parent=e,e.add(this.legacyGroup),this.legacy=new mg(this.legacyGroup,t,i,r)}legacy;legacyGroup=new nt;cells=new Map;groups=new Map;materials=new Map;rebuilt=0;key(e){return`${Math.floor(e.x/16)},${Math.floor(e.z/16)}`}anchor(e){return`${e.x},${e.y},${e.z}`}clear(){this.legacy.clear();for(const e of this.groups.values())e.traverse(t=>{t.isInstancedMesh&&t.dispose()}),e.removeFromParent();this.groups.clear(),this.cells.clear()}reset(e){this.clear(),this.legacy.reset(e.filter(t=>as.has(t.type)));for(const t of e.filter(i=>!as.has(i.type))){const i=this.key(t);this.cells.has(i)||this.cells.set(i,new Map),this.cells.get(i).set(this.anchor(t),t)}for(const t of this.cells.keys())this.rebuild(t)}update(e,t){this.updateMany([{block:e,present:t}])}updateMany(e){var r;const t=new Set,i=new Set;for(const{block:s,present:a}of e)if(as.has(s.type)){const o=Fi(s);a?this.legacy.store(s):(r=this.legacy.cells.get(o))==null||r.delete(this.anchor(s)),t.add(o);for(const[c,l]of[[1,0],[-1,0],[0,1],[0,-1]]){const d=Fi({x:s.x+c,z:s.z+l});d!==o&&this.legacy.cells.has(d)&&t.add(d)}}else{const o=this.key(s);this.cells.has(o)||this.cells.set(o,new Map),a?this.cells.get(o).set(this.anchor(s),s):this.cells.get(o).delete(this.anchor(s)),i.add(o)}for(const s of t)this.legacy.rebuild(s);for(const s of i)this.rebuild(s)}rebuild(e){var o;this.rebuilt++;const t=this.groups.get(e);t&&(t.traverse(c=>{c.isInstancedMesh&&c.dispose()}),t.removeFromParent());const i=new nt,r=new Map,s=new mt,a=new mt;for(const c of((o=this.cells.get(e))==null?void 0:o.values())||[]){s.position.set(c.x+.5,c.y,c.z+.5),s.rotation.y=(c.rotation||0)*Math.PI/180,s.updateMatrix();for(const l of mo(c)){a.position.set(l.x,l.y,l.z),a.scale.set(l.w,l.h,l.d),a.rotation.y=l.yaw||0,a.updateMatrix();const d=zt.get(c.type),u=(l.shape||"box")+":"+(d.surface?d.id:"plain");r.has(u)||r.set(u,[]),r.get(u).push({b:c,p:l,matrix:new et().multiplyMatrices(s.matrix,a.matrix)})}}for(const[c,l]of r){const d=zt.get(l[0].b.type);this.materials.has(c)||this.materials.set(c,new _t({color:16777215,map:d.surface&&lh(d.id,d.surface)||null}));const u=new xs(ch(l[0].p),this.materials.get(c),l.length);l.forEach((h,f)=>{u.setMatrixAt(f,h.matrix),u.setColorAt(f,new Ke(h.p.color))}),u.userData.blocks=l.map(h=>h.b),u.computeBoundingSphere(),i.add(u)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i)}rayMeshes(){return[...this.legacy.rayMeshes(),...[...this.groups.values()].flatMap(e=>e.children)]}}let Ii;const Ea=new Map;function hh(n,e=!1){Ii||(Ii=new ao({alpha:!0,antialias:!1}),Ii.setSize(112,96),Ii.setPixelRatio(1));const t=new qc,i=new hn().setFromObject(n),r=i.getCenter(new N),s=i.getSize(new N),a=Math.max(s.x,s.y,s.z)*.8+.25,o=new ro(-a*1.17,a*1.17,a,-a,.01,100);o.position.copy(r).add(new N(a*2,a*1.5,a*2.4)),o.lookAt(r),t.add(new Zc(16777215,8624771,2),new $c(16777215,1),n),Ii.render(t,o);const c=Ii.domElement.toDataURL();if(n.traverse(l=>{l.isMesh&&l.material.dispose()}),e){const l=new Set;n.traverse(d=>{d.isMesh&&l.add(d.geometry)}),l.forEach(d=>d.dispose())}return c}function _g(n){return Ea.has(n)||Ea.set(n,hh(li({x:0,y:0,z:0,type:n}))),Ea.get(n)}function bs(n){const e=[...n.hotbar.filter(i=>si.some(r=>r.id===i)),...n.recent.filter(i=>si.some(r=>r.id===i)),...hi.slice(0,7).map(i=>i.id)],t=[...new Set(e)].slice(0,8);document.querySelector("#palette").innerHTML=t.map(i=>{const r=si.find(s=>s.id===i);return`<button data-item="${r.id}" aria-label="Choose ${r.label}" title="${r.label}" aria-pressed="${n.selected===i}"><span>${r.icon}</span><small>${r.label}</small></button>`}).join("")}function yg(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section class="cataloguePanel"><h1>▦ Build anything</h1><input id="catalogueSearch" aria-label="Search catalogue" placeholder="Search (optional)"><div id="categories"></div><div id="catalogueGrid"></div><div class="cataloguePages"><button id="previousPage" aria-label="Previous catalogue page">◀</button><output id="catalogueCount"></output><button id="nextPage" aria-label="Next catalogue page">▶</button><button id="repeatBuild" aria-label="Pieces in a building row"></button><button id="closeCatalogue">▶ Play</button></div></section>';let t="All",i=0,r=0;const s=()=>{r++,e.hidden=!0,n.paused=!1,n.controls.clear()},a=()=>{r++;const l=r,d=document.querySelector("#catalogueSearch").value.toLowerCase(),u=si.filter(m=>(t==="All"||t==="Favourites"&&n.favourites.includes(m.id)||t==="Recent"&&n.recent.includes(m.id)||m.category===t)&&m.label.toLowerCase().includes(d));i=Math.min(i,Math.max(0,Math.ceil(u.length/24)-1));const h=u.slice(i*24,i*24+24),f=document.querySelector("#catalogueGrid");f.replaceChildren();const y=[];for(const m of h){const p=document.createElement("article");p.className="catalogueCard";const _=document.createElement("button");_.dataset.catalogue=m.id,_.setAttribute("aria-label","Choose "+m.label);const g=document.createElement("img");g.alt=m.label,g.width=112,g.height=96;const v=document.createElement("span");v.textContent=m.label,_.append(g,v),_.onclick=()=>{n.choose(m.id),s()};const A=document.createElement("button");A.className="favourite",A.textContent=n.favourites.includes(m.id)?"★":"☆",A.setAttribute("aria-label","Favourite "+m.label),A.setAttribute("aria-pressed",String(n.favourites.includes(m.id))),A.onclick=()=>{n.favourites=n.favourites.includes(m.id)?n.favourites.filter(C=>C!==m.id):[m.id,...n.favourites].slice(0,32),n.onEdit(),a()};const E=document.createElement("button");E.className="pin",E.textContent="📌",E.setAttribute("aria-label","Pin "+m.label),E.setAttribute("aria-pressed",String(n.hotbar.includes(m.id))),E.onclick=()=>{n.hotbar=n.hotbar.includes(m.id)?n.hotbar.filter(C=>C!==m.id):[m.id,...n.hotbar].slice(0,8),bs(n),n.onEdit(),a()},p.append(_,A,E),f.append(p),y.push(()=>{l===r&&g.isConnected&&(g.src=_g(m.id))})}const x=()=>{var m;l!==r||e.hidden||((m=y.shift())==null||m(),y.length&&requestAnimationFrame(x))};requestAnimationFrame(x),document.querySelector("#catalogueCount").textContent=`${u.length} choices · ${i+1}/${Math.max(1,Math.ceil(u.length/24))}`,document.querySelector("#previousPage").disabled=i===0,document.querySelector("#nextPage").disabled=(i+1)*24>=u.length};for(const l of["All","Favourites","Recent",...new Set(si.map(d=>d.category))]){const d=document.createElement("button");d.textContent=l==="Favourites"?"★ Favourites":l==="Recent"?"◷ Recent":l,d.dataset.category=l;const u={All:"▦",Materials:"🧱",Shapes:"△",Openings:"🚪",Furniture:"🪑",Kitchen:"🍳",Bathroom:"🛁",Workshop:"🛠",Garden:"🌿",Lighting:"💡",Play:"🧸",Street:"🚏",Farm:"🐾",Presets:"⌂"};u[l]&&(d.textContent=u[l]+" "+l),d.onclick=()=>{t=l,i=0,document.querySelectorAll("[data-category]").forEach(h=>h.setAttribute("aria-pressed",String(h.dataset.category===t))),a()},document.querySelector("#categories").append(d)}document.querySelector("#catalogueSearch").oninput=()=>{i=0,a()},document.querySelector("#nextPage").onclick=()=>{i++,a()},document.querySelector("#previousPage").onclick=()=>{i--,a()},document.querySelector("#closeCatalogue").onclick=s;const o=document.querySelector("#repeatBuild"),c=()=>o.textContent=`▦ ×${n.repeatCount}`;o.onclick=()=>{n.repeatCount=n.repeatCount===1?3:n.repeatCount===3?5:1,c()},c(),a()}function dh(n){document.body.classList.toggle("leftHanded",n.leftHanded)}function vg(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section><h1>🎮 Comfortable controls</h1><h2>Look speed</h2><div id="lookSpeeds"></div><button id="handed" aria-label="Swap control sides">↔ Swap hands</button><button id="closeControls">▶ Play</button></section>';for(const[i,r]of[[.6,"🐢 Gentle"],[1,"🚶 Normal"],[1.4,"🐇 Quick"]]){const s=document.createElement("button");s.dataset.speed=String(i),s.textContent=r,s.setAttribute("aria-pressed",String(n.lookSpeed===i)),s.onclick=()=>{n.lookSpeed=i,n.onEdit(),document.querySelectorAll("[data-speed]").forEach(a=>a.setAttribute("aria-pressed",String(Number(a.dataset.speed)===i)))},document.querySelector("#lookSpeeds").append(s)}const t=document.querySelector("#handed");t.setAttribute("aria-pressed",String(n.leftHanded)),t.onclick=()=>{n.leftHanded=!n.leftHanded,dh(n),t.setAttribute("aria-pressed",String(n.leftHanded)),n.onEdit()},document.querySelector("#closeControls").onclick=()=>{e.hidden=!0,n.paused=!1,n.controls.clear()}}function Mg(n,e,t,i,r){if(!n.grounded||!e.some(a=>a.ramp&&t(a,n.x,n.z)!==null))return;const s=i(n);for(const a of e){if(a.ramp||a.maxY<=n.y||a.maxY-n.y>.09||s.minX>=a.maxX||s.maxX<=a.minX||s.minZ>=a.maxZ||s.maxZ<=a.minZ)continue;const o={...n,y:a.maxY};r(o,e)||(n.y=o.y)}}const ec=st.halfSize;st.maxBlocks;const Dn=.28,uh=1.65,os=(n,e,t)=>Math.max(e,Math.min(t,n)),ji=n=>({minX:n.x-Dn,minY:n.y+.001,minZ:n.z-Dn,maxX:n.x+Dn,maxY:n.y+uh,maxZ:n.z+Dn});function tc(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function ti(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:(i.baseY||0)+os((i.length/2-o)/i.length,0,1)*i.rise}function xt(n,e){if(e.ramp){const a=ti(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return xt(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=tc(n),i=tc(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const c=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),l=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=c+l-1e-5)return!1}return!0}const vn=(n,e)=>e.some(t=>xt(ji(n),t));function Xa(n,e){let t=0;for(const i of e){const r=ti(i,n.x,n.z),s=r===null?i:{...i,maxY:r};i.ramp&&r===null||s.maxY<=n.y+.02&&s.maxY>t&&n.x+Dn>s.minX+.01&&n.x-Dn<s.maxX-.01&&n.z+Dn>s.minZ+.01&&n.z-Dn<s.maxZ-.01&&(t=s.maxY)}return t}function nc(n,e){return n.y<=.35?!0:[-.12,.12].every(t=>[-.12,.12].every(i=>e.some(r=>{const s=ti(r,n.x+t,n.z+i);if(r.ramp)return s!==null&&Math.abs(s-n.y)<.3;if(r.maxY>n.y+.025||r.maxY<n.y-.3)return!1;const a={minX:n.x+t-.001,maxX:n.x+t+.001,minZ:n.z+i-.001,maxZ:n.z+i+.001,minY:r.maxY-.003,maxY:r.maxY+.003};return xt(a,r)})))}function ic(n,e){let t=1/0;for(const i of e){if(i.maxY>n.y+.025||i.maxY<n.y-.3)continue;const r=Math.max(i.minX+.12-n.x,0,n.x-(i.maxX-.12)),s=Math.max(i.minZ+.12-n.z,0,n.z-(i.maxZ-.12));t=Math.min(t,r*r+s*s)}return t}function bg(n,e,t,i){const r=Math.ceil(Math.min(t,.1)/.012),s=Math.min(t,.1)/r,a=nh(e.walkSpeed);let o=os(e.forward||0,-1,1),c=os(e.right||0,-1,1),l=Math.max(1,Math.hypot(o,c));const d=(-Math.sin(n.yaw)*o+Math.cos(n.yaw)*c)*a/l,u=(-Math.cos(n.yaw)*o-Math.sin(n.yaw)*c)*a/l;for(let h=0;h<r;h++){const f=Xa(n,i);(n.vy||0)<=0&&n.y>=f-.002&&n.y-f<.035&&(n.y=f,n.vy=0,n.grounded=!0);for(const[m,p]of[["x",d],["z",u]]){const _=n[m];n[m]=os(_+p*s,-ec+.4,ec-.4);const g=n.y;if(n.grounded)for(const v of i){const A=ti(v,n.x,n.z),E=ti(v,m==="x"?_:n.x,m==="z"?_:n.z);A!==null&&A-n.y<=.09&&A-n.y>=-.12&&(E!==null||Math.abs(n.y-(v.ramp.baseY||0))<.1||Math.abs(n.y-v.maxY)<.1)&&(n.y=A)}if(Mg(n,i,ti,ji,vn),vn(n,i)&&(n[m]=_,n.y=g),e.edgeProtection&&n.grounded&&!e.allowDrop&&n.y>.35&&!nc(n,i)){const v={...n,[m]:_};(nc(v,i)||ic(n,i)>=ic(v,i)-1e-6)&&(n[m]=_)}}n.vy=(n.vy||0)-16*s;const y=n.y;if(n.y+=n.vy*s,n.y<=0)n.y=0,n.vy=0,n.grounded=!0;else if(vn(n,i)){const m=i.filter(p=>xt(ji(n),p));n.vy<0?(n.y=Math.max(...m.map(p=>ti(p,n.x,n.z)??p.maxY)),n.grounded=!0):(n.y=Math.min(...m.map(p=>p.minY))-uh-.002,n.grounded=!1),(n.y<0||vn(n,i))&&(n.y=y),n.vy=0}else n.grounded=!1;const x=Xa(n,i);n.vy<=0&&n.y>=x-.002&&n.y-x<.035&&(n.y=x,n.vy=0,n.grounded=!0)}}const fh=n=>Number.isInteger(n.x)&&Number.isInteger(n.z)&&Number.isFinite(n.y)&&Math.abs(n.y*100-Math.round(n.y*100))<1e-7;function wg(n){if(!Array.isArray(n)||n.length>12e3)throw Error("Unsupported build capacity");const e=new Set,t=new bn(4);for(const i of n){if(!i||!zt.has(i.type)||!fh(i)||i.x<-250||i.x>=250||i.z<-250||i.z>=250||i.y<0||i.y>=24||i.rotation!==void 0&&!Number.isFinite(i.rotation)||Math.abs(i.rotation||0)>36e3||i.open!==void 0&&typeof i.open!="boolean"||i.on!==void 0&&typeof i.on!="boolean")throw Error("Invalid catalogue object");const r=`${i.x},${i.y},${i.z}`;if(e.has(r))throw Error("Duplicate build anchor");if(e.add(r),Ms(i).maxY>24.001)throw Error("Object exceeds build ceiling");for(const a of Qe(i))if(t.query(a).some(o=>xt(a,o)))throw Error("Saved objects overlap");for(const a of Qe(i))t.add(a)}}function rc(n,e,t,i,r=!0){if(!n||!zt.has(n.type))return"Choose a building piece";if(!fh(n)||n.x<-250||n.x>=250||n.z<-250||n.z>=250||n.y<0||n.y>=24)return"Build inside the world";if(e.length>=12e3)return"World geometry capacity reached";const s=Ms(n);if(s.maxY>24.001)return"That is above the build ceiling";if(r&&Math.hypot(n.x+.5-i.x,n.y+.5-i.y,n.z+.5-i.z)>6)return"Move a little closer";if(e.some(c=>c.x===n.x&&c.y===n.y&&c.z===n.z))return"Find a clear space";const a=Qe(n),o=[...t,...e.flatMap(Qe)];return a.some(c=>xt(c,ji(i)))?"Take a little step back":a.some(c=>o.some(l=>xt(c,l.ramp?{...l,ramp:null}:l)))?"Find a clear space":n.y>0&&!e.some(c=>Math.abs(c.x-n.x)+Math.abs(c.y-n.y)+Math.abs(c.z-n.z)<=1)&&!o.some(c=>Math.abs(c.maxY-n.y)<.02&&c.minX<s.maxX&&c.maxX>s.minX&&c.minZ<s.maxZ&&c.maxZ>s.minZ)?"Join this piece to a surface":""}function Ns({scene:n,material:e,doors:t,h:i,local:r,id:s=i.id,x:a=-1.4,z:o=i.d/2,width:c=1.26,height:l=2.3}){const d=r(a-c/2,o+.03),u=r(a,o),h=new nt;h.position.set(d.x,0,d.z),h.rotation.y=i.angle;const f=new we(new ht(c,l,.1),e(9726028));f.position.set(c/2,l/2,0),h.add(f);const y=new we(new ht(c*.62,.65,.112),e(11980733));y.position.set(c/2,1.65,0),h.add(y);const x=new we(new Cs(.055,6,5),e(16768118));x.position.set(c-.16,1,.09),h.add(x),n.add(h),t.push({id:s,pivot:h,baseAngle:i.angle,open:!1,center:u,hinge:d,width:c,height:l})}function Fs({scene:n,material:e,doors:t,h:i,put:r,local:s}){const a=-i.w/2-2.1,o=i.d/2,c=o-2.7;r(a,.007,c,4.2,.014,5.4,12959399);for(const f of[-2.1,2.1])r(a+f,1.4,c,.2,2.8,5.4,i.wall,!0);r(a,1.4,o-5.4,4.2,2.8,.2,i.wall,!0),r(a,2.72,o,4.2,.16,.2,i.wall,!0);for(const f of[-1.92,1.92])r(a+f,1.32,o,.36,2.64,.2,i.wall,!0);r(a,2.88,c,4.6,.18,5.8,i.roof,!0);const l=s(a,o),d=new nt;d.position.set(l.x,0,l.z),d.rotation.y=i.angle;const u=new nt,h=new we(new ht(3.46,2.6,.1),e(14144708));h.position.y=1.3,u.add(h);for(let f=.25;f<2.6;f+=.32){const y=new we(new ht(3.42,.035,.12),e(10989475));y.position.y=f,u.add(y)}d.add(u),n.add(d),t.push({id:i.id+"-garage",kind:"roller",pivot:d,leaf:u,baseAngle:i.angle,center:l,hinge:l,width:3.46,height:2.6,open:!1})}function go({h:n,put:e,local:t,scene:i,material:r,doors:s,solids:a,label:o,rooms:c}){const l=n.w,d=n.d,u=d/2,h=n.storeys===2,f=3.2,y=h?6.4:3,x=16774617,m=9725511,p=8501706;e(0,.007,0,l,.014,d,14006419);for(const I of[-u,u]){const H=I>0,L=l/2-2,U=2.1,O=H?[[-l/2,-2.1],[-.7,L-U/2],[L+U/2,l/2]]:[[-l/2,L-U/2],[L+U/2,l/2]];for(const[X,Z]of O)Z>X&&e((X+Z)/2,1.5,I,Z-X,3,.22,n.wall,!0);H&&e(-1.4,2.68,I,1.4,.64,.22,n.wall,!0),e(L,.5,I,U,1,.22,n.wall,!0),e(L,2.65,I,U,.7,.22,n.wall,!0),e(L,1.65,I,U,1.3,.1,p,!0);for(const X of[L-U/2,L,L+U/2])e(X,1.65,I,.065,1.42,.3,x);for(const X of[1,2.3])e(L,X,I,U+.15,.07,.3,x);if(h){e(0,3.22,I,l,.44,.22,n.wall,!0);const X=1.6,Z=n.id==="manor"?[-l/2+2,-1.4,l/2-2]:[-l/2+2,l/2-2];let te=-l/2;for(const ie of Z){e((te+ie-X/2)/2,4.8,I,ie-X/2-te,3.2,.22,n.wall,!0),e(ie,3.7,I,X,1,.22,n.wall,!0),e(ie,5.98,I,X,.84,.22,n.wall,!0),e(ie,4.88,I,X,1.36,.1,p,!0);for(const de of[ie-X/2,ie,ie+X/2])e(de,4.88,I,.065,1.5,.3,x);for(const de of[4.2,5.56])e(ie,de,I,X+.15,.07,.3,x);te=ie+X/2}e((te+l/2)/2,4.8,I,l/2-te,3.2,.22,n.wall,!0)}}for(const I of[-l/2,l/2])for(const H of h?[0,f]:[0]){const L=d>10?[-d/2+2.5,d/2-2.5]:[0],U=1.6;let O=-u;for(const X of L){e(I,H+1.5,(O+X-U/2)/2,.22,3,X-U/2-O,n.wall,!0),e(I,H+.5,X,.22,1,U,n.wall,!0),e(I,H+2.65,X,.22,.7,U,n.wall,!0),e(I,H+1.65,X,.1,1.3,U,p,!0);for(const Z of[X-.8,X,X+.8])e(I,H+1.65,Z,.3,1.42,.065,x);for(const Z of[1,2.3])e(I,H+Z,X,.3,.07,U+.15,x);O=X+U/2}e(I,H+1.5,(O+u)/2,.22,3,u-O,n.wall,!0),h&&(e(I,3.1,0,.22,.2,d,n.wall,!0),e(I,y-.1,0,.22,.2,d,n.wall,!0))}Ns({scene:i,material:r,doors:s,h:n,local:t});const _=y+.06,g=_+(n.id==="manor"?3.3:1.8),v=l/2+.4,A=u+.4,E=[],C=(I,H,L,U)=>E.push(...I,...H,...L,...I,...L,...U);if(n.style==="hip")C([-v,_,A],[v,_,A],[0,g,1],[0,g,1]),C([v,_,A],[v,_,-A],[0,g,-1],[0,g,1]),C([v,_,-A],[-v,_,-A],[0,g,-1],[0,g,-1]),C([-v,_,-A],[-v,_,A],[0,g,1],[0,g,-1]);else if(n.style==="shed"){const I=_+1.4;C([-v,_,A],[v,_,A],[v,I,-A],[-v,I,-A]);for(const H of[-l/2,l/2]){const L=new tt;L.setAttribute("position",new De([H,y,-u,H,I,-u,H,_,u,H,y,-u,H,_,u,H,y,u],3)),L.computeVertexNormals();const U=r(n.wall).clone();U.side=bt;const O=new we(L,U);O.position.set(n.x,0,n.z),O.rotation.y=n.angle,i.add(O)}e(0,(y+I)/2,-u,l,I-y,.22,n.wall,!0)}else{C([-v,_,A],[0,g,A],[0,g,-A],[-v,_,-A]),C([0,g,A],[v,_,A],[v,_,-A],[0,g,-A]);for(const I of[-u,u]){const H=new tt;H.setAttribute("position",new De([-l/2,y,I,l/2,y,I,0,g,I],3)),H.computeVertexNormals();const L=r(n.wall).clone();L.side=bt;const U=new we(H,L);U.position.set(n.x,0,n.z),U.rotation.y=n.angle,i.add(U)}}const z=new tt;z.setAttribute("position",new De(E,3)),z.computeVertexNormals();const M=r(n.roof).clone();M.side=bt;const b=new we(z,M);b.position.set(n.x,0,n.z),b.rotation.y=n.angle,i.add(b),e(0,y+.015,0,l,.09,d,x,!0),e(-1.4,2.64,u+.7,n.porch||2.4,.12,1.5,n.roof,!0);for(const I of[-2.45,-.35])e(I,1.27,u+1.3,.12,2.54,.12,x,!0);if(n.id==="manor"){for(const U of[-4.9,2.1]){e(U,3.15,u+2,.32,6.3,.32,x,!0);for(const O of[.12,6.25])e(U,O,u+2,.65,.24,.65,x,!0)}e(-1.4,6.5,u+1.1,7.9,.24,2.8,x,!0);const I=new tt;I.setAttribute("position",new De([-5.35,6.65,u+2.55,2.55,6.65,u+2.55,-1.4,8.15,u+2.55],3)),I.computeVertexNormals();const H=r(x).clone();H.side=bt;const L=new we(I,H);L.position.set(n.x,0,n.z),L.rotation.y=n.angle,i.add(L),e(3,.34,u-2.5,3.4,.68,1,7183771,!0),e(3,.88,u-2.96,3.4,.72,.18,7183771,!0);for(const U of[1.4,4.6])e(U,.65,u-2.5,.2,.5,1,m,!0);e(3,.36,u-4.2,1.8,.72,.8,m,!0),e(-l/2+3.3,.79,u-3,2.6,.15,1.6,m,!0);for(const U of[-1,1])for(const O of[-.55,.55])e(-l/2+3.3+U,.36,u-3+O,.12,.72,.12,m,!0)}const F=(I,H,L=l/2-.2)=>{e((-l/2+-1.4-1.7/2)/2,I+1.5,H,-1.4-1.7/2+l/2,3,.16,n.wall,!0),e((-1.4+1.7/2+L)/2,I+1.5,H,L- -1.4-1.7/2,3,.16,n.wall,!0),e(-1.4,I+2.72,H,1.7,.56,.16,x,!0)};if(n.rooms&&(F(0,-.4,h?l/2-2.2:l/2-.2),c.push({house:n.id,name:"Back room",...t(-1.4,-u+1.7),y:0})),h){const I=l/2-1.2,H=1.65,L=u-1.4,U=-u+1.4,O=L-U,X=-l/2,Z=I-H/2-.12;e((X+Z)/2,f-.09,0,Z-X,.18,d,14006419,!0);for(const[se,ge]of[[-u+.6,1.2],[u-.6,1.2]])e((Z+l/2)/2,f-.09,se,l/2-Z,.18,ge,14006419,!0);const te=t(I,(L+U)/2),ie=Math.cos(n.angle),de=Math.sin(n.angle),ue=(H*Math.abs(ie)+O*Math.abs(de))/2,J=(H*Math.abs(de)+O*Math.abs(ie))/2;a.push({minX:te.x-ue,maxX:te.x+ue,minZ:te.z-J,maxZ:te.z+J,minY:0,maxY:f,ramp:{cx:te.x,cz:te.z,c:ie,s:de,width:H,length:O,rise:f}});for(let se=0;se<16;se++){const ge=f*(se+1)/16;e(I,ge/2,L-(se+.5)*O/16,H,ge,O/16,m)}e(Z-.04,f+.48,(L+U)/2,.1,.96,O,m,!0);for(const se of[L-.15,U+.15])e(Z-.04,f+.48,se,.12,.96,.12,x,!0);F(f,-.4,Z-.25),c.push({house:n.id,name:"Upper landing",...t(I,-u+.55),y:f},{house:n.id,name:"Upstairs bedroom",...t(-1.4,-u+1.7),y:f})}for(const I of h?[0,f]:[0])e(-l/2+1.3,I+.28,-u+1.6,1.8,.56,2.4,m,!0),e(-l/2+1.3,I+.62,-u+1.6,1.75,.13,2.3,n.roof),e(-l/2+1.3,I+.73,-u+.8,1.5,.16,.5,x),e(-l/2+1.1,I+.45,u-1.1,1.5,.9,.7,m,!0);if(n.shop){e(l/2-1.5,.5,-u+1.2,2,1,1,m,!0);const I=t(0,u+.2);o(n.sign,I.x,2.9,I.z,n.angle,Math.min(l-1,5))}if(n.street){const I=l/2+1.2;e(I,.22,0,1.1,.44,d+3,5933922,!0),e(0,.38,-u-1.6,l+2,.12,.12,m,!0);for(const H of[-l/2-1,0,l/2+1])e(H,.35,-u-1.6,.1,.7,.1,x,!0);e(l/2-1,.18,u+1.5,2,.36,1,5933922,!0);for(const H of[-.6,0,.6])e(l/2-1+H,.43,u+1.5,.3,.18,.3,15118451)}n.garage&&Fs({scene:i,material:r,doors:s,h:n,put:e,local:t}),c.push({house:n.id,name:"Entrance",...t(-1.4,u-1.1),y:0})}function ks(n,e){const t=new Map,i=new et,r=new et,s=new N,a=new N,o=new We,c=[...n.children].filter(x=>x.isMesh&&!e.has(x)),l=new Set,d=new Set;for(const x of c){x.updateMatrixWorld(!0);const m=x.geometry.index?x.geometry.toNonIndexed():x.geometry,p=m.attributes.position,_=m.attributes.normal,g=x.material.color,v=x.isInstancedMesh?x.count:1;for(let A=0;A<v;A++){x.isInstancedMesh?(x.getMatrixAt(A,i),r.multiplyMatrices(x.matrixWorld,i)):r.copy(x.matrixWorld);const E=r.elements[12],C=r.elements[14],z=`${Math.floor(E/st.chunkSize)},${Math.floor(C/st.chunkSize)}`;t.has(z)||t.set(z,{positions:[],normals:[],colors:[]});const M=t.get(z);o.getNormalMatrix(r);for(let b=0;b<p.count;b++)s.fromBufferAttribute(p,b).applyMatrix4(r),a.fromBufferAttribute(_,b).applyMatrix3(o).normalize(),M.positions.push(s.x,s.y,s.z),M.normals.push(a.x,a.y,a.z),M.colors.push(g.r,g.g,g.b);if(x.material.side===bt)for(let b=0;b<p.count;b+=3)for(const F of[b+2,b+1,b])s.fromBufferAttribute(p,F).applyMatrix4(r),a.fromBufferAttribute(_,F).applyMatrix3(o).normalize().negate(),M.positions.push(s.x,s.y,s.z),M.normals.push(a.x,a.y,a.z),M.colors.push(g.r,g.g,g.b)}m!==x.geometry&&m.dispose(),l.add(x.geometry),d.add(x.material),x.isInstancedMesh&&x.dispose(),n.remove(x)}const u=new _t({vertexColors:!0,side:wn}),h=[];let f=0;for(const[x,m]of t){const p=new tt;p.setAttribute("position",new De(m.positions,3)),p.setAttribute("normal",new De(m.normals,3)),p.setAttribute("color",new De(m.colors,3)),p.computeBoundingSphere();const _=new we(p,u);_.name=`scenery ${x}`,n.add(_),h.push(_),f+=m.positions.length/9}const y=new Set;n.traverse(x=>{x.isMesh&&y.add(x.material)});for(const x of l)x.dispose();for(const x of d)y.has(x)||x.dispose();return{chunks:t.size,triangles:f,hidden:0,updateVisibility(x,m,p=!0){const _=x.matrixWorldInverse.elements;let g=0;for(const v of h){const A=v.geometry.boundingSphere,E=A.center,C=-(_[2]*E.x+_[6]*E.y+_[10]*E.z+_[14])-A.radius;v.visible=!p||C<=m+.1,v.visible||g++}return this.hidden=g,g},showAll(){for(const x of h)x.visible=!0;this.hidden=0}}}function Qi(n){const e=new Map,t=new _t({vertexColors:!0}),i=new et,r=new N,s=new N,a=new We;let o=0;for(const c of n){const l=c.leaf||c.pivot,d=[...l.children].filter(x=>x.isMesh);o+=d.length;const u=JSON.stringify(d.map(x=>[x.geometry.parameters,x.position.toArray(),x.rotation.toArray(),x.scale.toArray(),x.material.color.getHex()]));let h=e.get(u),f=0;if(!h){const x=[],m=[],p=[];for(const[_,g]of d.entries()){g.updateMatrix(),i.copy(g.matrix),a.getNormalMatrix(i);const v=g.geometry.index?g.geometry.toNonIndexed():g.geometry,A=v.attributes.position,E=v.attributes.normal,C=g.material.color;_===0&&(f=A.count);for(let z=0;z<A.count;z++)r.fromBufferAttribute(A,z).applyMatrix4(i),s.fromBufferAttribute(E,z).applyMatrix3(a).normalize(),x.push(r.x,r.y,r.z),m.push(s.x,s.y,s.z),p.push(C.r,C.g,C.b);v!==g.geometry&&v.dispose()}h=new tt,h.setAttribute("position",new De(x,3)),h.setAttribute("normal",new De(m,3)),h.setAttribute("color",new De(p,3)),h.computeBoundingSphere(),h.userData.panelVertices=f,e.set(u,h)}for(const x of d)l.remove(x),x.geometry.dispose();const y=new we(h,t);y.name=c.id+" leaf",l.add(y)}return{partsBefore:o,meshesAfter:n.length,sharedGeometries:e.size}}function ph(n){const e=[],t=[],i=[],r=[],s=new ht(1,1,1),a=new Map,o=h=>(a.has(h)||a.set(h,new _t({color:h})),a.get(h));function c(h,f,y,x,m,p,_,g=!1){const v=new we(s,o(_));return v.position.set(h,f,y),v.scale.set(x,m,p),n.add(v),g&&e.push({minX:h-x/2,maxX:h+x/2,minY:f-m/2,maxY:f+m/2,minZ:y-p/2,maxZ:y+p/2}),v}c(0,-.1,0,500,.2,500,10864267);for(const h of[-36,4,36])c(0,.012,h,84,.024,6,8558487);for(const h of[-40,8,40])c(h,.014,0,6,.028,78,8558487);for(let h=-36;h<=36;h+=5)c(h,.03,4,2,.02,.14,16772533);for(const[h,f]of[[-20,-12],[-5,-21],[24,-20],[-22,21]]){const y={id:r.length===0?"home":["cafe","library","workshop"][r.length-1],x:h,z:f,w:12,d:10,angle:r.length===3?Math.PI:0,wall:[15780251,15251368,12111037,13944996][r.length],roof:5209465};r.push(y);const x=Math.cos(y.angle),m=Math.sin(y.angle),p=(v,A)=>({x:h+v*x+A*m,z:f-v*m+A*x}),_=(v,A,E,C,z,M,b,F=!1)=>{const I=p(v,E);return c(I.x,A,I.z,C,z,M,b,F)};_(0,.025,0,12,.05,10,15127212),_(-6,1.6,0,.22,3.2,10,y.wall,!0),_(6,1.6,0,.22,3.2,10,y.wall,!0),_(0,1.6,-5,12,3.2,.22,y.wall,!0),_(-4.05,1.6,5,3.9,3.2,.22,y.wall,!0),_(2.65,1.6,5,6.7,3.2,.22,y.wall,!0),_(-1.4,2.77,5,1.4,.86,.22,y.wall,!0),_(0,3.27,0,12.8,.2,10.8,y.roof,!0);for(const v of[1.5,4])_(v,1.75,5.15,1.6,1.2,.08,9486022),_(v,1.75,5.21,.06,1.3,.08,16773589),_(v,2.35,5.21,1.7,.08,.08,16773589);Ns({scene:n,material:o,doors:t,h:y,local:p}),i.push({id:y.id,x:h,z:f,y:0});const g=(v,A)=>{_(v,.72,A,1.6,.14,1,11501653,!0);for(const E of[-.65,.65])for(const C of[-.35,.35])_(v+E,.34,A+C,.1,.68,.1,8743505)};if(g(2,0),_(2,.36,1.3,1,.72,.65,9942170,!0),_(2,.8,1.6,1,.3,.12,9942170),y.id==="home"&&(_(-3,.32,-2,2.4,.64,3,12029801,!0),_(-3,.72,-2,2.3,.2,2.9,15846028),_(-3,.88,-3,1.8,.25,.6,16774879),_(3,.7,-3,3,1.4,.7,8496284,!0)),y.id==="cafe"&&(_(-3,.7,-2,3.5,1.4,1,12553574,!0),_(-3,1.45,-2,3.7,.1,1.1,16772304),g(2,-3)),y.id==="library")for(const v of[-4,0,4]){_(v,1.1,-3,2.3,2.2,.5,11766370,!0);for(let A=0;A<5;A++)_(v-.8+A*.38,1.45,-2.69,.25,.7,.12,[14588270,7905945,14730099][A%3])}y.id==="workshop"&&(_(-3,.85,-2,3,1.7,1.2,11055526,!0),_(3,.5,-3,2,1,1.5,14923112,!0)),y.id==="home"&&Fs({scene:n,material:o,doors:t,h:y,put:_,local:p})}for(const[h,f]of[[-34,15],[-10,30],[28,7],[30,31],[-32,-27],[13,-32],[34,-7],[-3,15]])c(h,1,f,.35,2,.35,10123350,!0),c(h,2.5,f,3.1,2.5,3.1,6790008);for(const[h,f]of[[17,12],[25,12]])c(h,.42,f,2.5,.16,.8,11701090,!0),c(h,.75,f+.36,2.5,.55,.12,11701090);c(30,.03,25,10,.04,8,8568778),c(15,.3,22,2,.6,2,13872254,!0),c(15,.7,22,1.8,.3,1.8,9678199);const l=new we(new Fn(500,500),new Bi({visible:!1}));l.rotation.x=-Math.PI/2,n.add(l),l.updateMatrixWorld();const d=Qi(t),u=ks(n,new Set([...t.map(h=>h.pivot),l]));return{ground:l,solids:e,doors:t,houses:r,rooms:i,roads:[],doorRender:d,staticRender:u,landmarks:[{name:"Home",icon:"⌂",x:-20,z:0},{name:"Square",icon:"☀",x:18,z:7},{name:"Library",icon:"📚",x:22.6,z:-10},{name:"Workshop",icon:"🛠",x:-20.6,z:13},{name:"Garden",icon:"🌷",x:22,z:20},{name:"Garage",icon:"🚗",x:-28,z:1}]}}const sc=[{id:"sunbeam-cottage",name:"Sunbeam cottage",icon:"🏡",x:-21,z:-46,w:12,d:10,angle:0,wall:15123870,roof:10256756,garage:!0,kind:"home"},{id:"bluebell-house",name:"Bluebell house",icon:"🏠",x:22,z:-46,w:14,d:10,angle:0,wall:11847630,roof:7243909,garage:!0,kind:"home"},{id:"orchard-home",name:"Orchard home",icon:"🍎",x:-51,z:-13,w:12,d:10,angle:Math.PI/2,wall:13879200,roof:10454885,kind:"home"},{id:"school",name:"Sunbeam school",icon:"🎨",x:50,z:-22,w:16,d:10,angle:Math.PI/2,wall:14076320,roof:6852491,kind:"school"},{id:"clinic",name:"Friendly clinic",icon:"✚",x:50,z:4,w:12,d:10,angle:Math.PI/2,wall:13819347,roof:9349276,kind:"clinic"},{id:"bakery",name:"Little bakery",icon:"🥐",x:22,z:25,w:12,d:10,angle:0,wall:15055525,roof:10782067,kind:"bakery"},{id:"garden-studio",name:"Garden studio",icon:"🌿",x:-7,z:47,w:12,d:10,angle:Math.PI,wall:12110250,roof:7771788,kind:"garden"},{id:"stable",name:"Orchard stables",icon:"🐴",x:-51,z:29,w:16,d:10,angle:Math.PI/2,wall:12950905,roof:9205610,kind:"stable"}];function mh(n){const e=ph(n),t=new nt;n.add(t);const i=[],r=[],s=[],a=[],o=[],c=[],l=new ht(1,1,1),d=new Map,u=g=>(d.has(g)||d.set(g,new _t({color:g})),d.get(g));function h(g,v,A,E,C,z,M,b=!1,F=0){const I=new we(l,u(M));if(I.position.set(g,v,A),I.rotation.y=F,I.scale.set(E,C,z),t.add(I),b){const H=Math.cos(F),L=Math.sin(F),U=(Math.abs(H)*E+Math.abs(L)*z)/2,O=(Math.abs(L)*E+Math.abs(H)*z)/2;i.push({minX:g-U,maxX:g+U,minY:v-C/2,maxY:v+C/2,minZ:A-O,maxZ:A+O,obb:{cx:g,cz:A,c:H,s:L,halfW:E/2,halfD:z/2}})}return I}function f(g,v,A,E=0,C=0){const z={x:v-.5,y:C,z:A-.5,type:g,rotation:E},M=li(z);M.updateMatrixWorld(!0),M.traverse(b=>{if(b.isMesh){const F=new we(b.geometry.clone().applyMatrix4(b.matrixWorld),b.material);t.add(F)}}),i.push(...Qe(z)),["chair","armchair","sofa","bench","stool"].includes(g)&&c.push({x:v,y:C,z:A,rotation:E})}function y(g,v,A,E){if(typeof document>"u")return;const C=document.createElement("canvas");C.width=512,C.height=96;const z=C.getContext("2d");z.fillStyle="#fff2d4",z.fillRect(0,0,512,96),z.fillStyle="#315f54",z.textAlign="center",z.font="bold 36px sans-serif",z.fillText(g,256,62);const M=new jc(new lo({map:new vr(C),depthTest:!0}));M.position.set(v,A,E),M.scale.set(5.5,1,1),t.add(M),o.push(M)}const x=[{x:0,z:-56,w:126,d:6},{x:0,z:56,w:126,d:6},{x:-60,z:0,w:6,d:118},{x:60,z:0,w:6,d:118},{x:8,z:0,w:6,d:118}];for(const g of x)h(g.x,.014,g.z,g.w,.028,g.d,8689812);for(const g of sc){a.push(g);const v=Math.cos(g.angle),A=Math.sin(g.angle),E=(L,U)=>({x:g.x+L*v+U*A,z:g.z-L*A+U*v}),C=(L,U,O,X,Z,te,ie,de=!1)=>{const ue=E(L,O);return h(ue.x,U,ue.z,X,Z,te,ie,de,g.angle)},z=g.d/2,M=g.w/2-2;C(0,.025,0,g.w,.05,g.d,14667178);for(const L of[-g.w/2,g.w/2])C(L,1.6,0,.22,3.2,g.d,g.wall,!0);C(0,1.6,-z,g.w,3.2,.22,g.wall,!0);for(const[L,U]of[[-g.w/2,-2.1],[-.7,M-.9],[M+.9,g.w/2]])U>L&&C((L+U)/2,1.6,z,U-L,3.2,.22,g.wall,!0);C(-1.4,2.76,z,1.4,.88,.22,g.wall,!0),C(M,.45,z,1.8,.9,.22,g.wall,!0),C(M,2.75,z,1.8,.9,.22,g.wall,!0),C(M,1.6,z,1.8,1.4,.08,10471628,!0);for(const L of[M-.9,M,M+.9])C(L,1.6,z+.07,.06,1.5,.16,16772555);C(0,3.25,0,g.w+.6,.18,g.d+.6,g.roof,!0),(g.kind==="home"||g.kind==="stable")&&(C(0,3.6,0,g.w+.2,.5,g.d-.2,g.roof,!0),C(0,4,0,g.w-.8,.3,g.d-2,g.roof,!0)),Ns({scene:t,material:u,doors:r,h:g,local:E}),g.garage&&Fs({scene:t,material:u,doors:r,h:g,put:C,local:E}),s.push({id:g.id,x:g.x,y:0,z:g.z});const b=(L,U,O,X=0)=>{const Z=E(U,O);f(L,Z.x,Z.z,g.angle*180/Math.PI+X)};if(g.kind==="home"&&(b("double-bed",-3,-2),b("wardrobe",3,-3),b("sofa",2,1),b("coffee-table",2,-.3),b("floor-lamp",4,1),b("kitchen-counter",-4,1),b("sink",-3,1)),g.kind==="school"){for(const L of[-5,-2,2,5])b("desk",L,-1.5),b("chair",L,.2);b("bookcase",4,-4),b("toy-box",-5,-4)}if(g.kind==="clinic"&&(b("single-bed",-3,-1),b("washbasin",4,-3),b("desk",3,.5),b("chair",3,2),b("wall-cupboard",4,3.5)),g.kind==="bakery"){for(const L of[-4,-3,-2])b("kitchen-counter",L,-3);b("oven",1,-3),b("fridge",3,-3),b("dining-table",3,1),b("chair",3,2.5)}if(g.kind==="garden"){for(const L of[-4,0,4])b("planter",L,-3);b("workbench",3,0),b("garage-shelf",-4,0)}if(g.kind==="stable"){for(const L of[-5,4])b("rail-fence",L,-2),b("storage-crate",L,1);b("workbench",5,3)}const F=E(-1.4,z),I=E(-1.4,z+3);h((F.x+I.x)/2,.008,(F.z+I.z)/2,2.2,.012,3,15127469,!1,g.angle);const H=E(0,z+.2);y(g.name,H.x,2.8,H.z)}const m=[{x:-51,z:8,w:12,d:12},{x:51,z:37,w:12,d:14},{x:-5,z:-47,w:10,d:10},{x:22,z:47,w:12,d:10}];for(const g of m)h(g.x,.005,g.z,g.w,.008,g.d,11914902),y("BUILD HERE",g.x,1.2,g.z+g.d/2);f("play-slide",-1,22),f("sandpit",-6,25),f("goal",1,31),f("bench",0,17),f("bench",18,18),f("flower-bed",-12,6),f("flower-bed",31,9),f("pergola",17,44),f("dining-table",17,44),f("chair",17,46),f("street-lamp",13,0),f("street-lamp",-10,8);for(const g of[-55,-43,-4,8,40,55])for(const v of[-64,64])f("oak-tree",g,v);for(const g of[-68,68])for(const v of[-40,-12,16,40])f("pine-tree",g,v);for(const g of[-12,-8,-4])for(const v of[28,31])f("fruit-tree",g,v);const p=Qi(r),_=ks(t,new Set([...r.map(g=>g.pivot),...o]));return{...e,houses:[...e.houses,...a],rooms:[...e.rooms,...s],doors:[...e.doors,...r],solids:[...e.solids,...i],plots:m,activities:[{x:-1.5,y:0,z:21.5,type:"play-slide"}],seats:c,mapRoads:[...[-36,4,36].map(g=>({x:0,z:g,w:84,d:6})),...[-40,8,40].map(g=>({x:g,z:0,w:6,d:78})),...x],activityRange:70,landmarks:[...e.landmarks,...sc.map(g=>{const v=Math.cos(g.angle),A=Math.sin(g.angle);return{name:g.name,icon:g.icon,x:g.x-1.4*v+(g.d/2+3)*A,z:g.z+1.4*A+(g.d/2+3)*v}}),{name:"Play park",icon:"🛝",x:0,z:20},{name:"Orchard plots",icon:"🧱",x:-51,z:8}],staticRender:{updateVisibility(g,v){e.staticRender.updateVisibility(g,v),_.updateVisibility(g,v)}},extraDoorRender:p}}class xo{group=new nt;solids=[];seats=[];props=[];labels=[];geometry=new ht(1,1,1);materials=new Map;constructor(e){e.add(this.group)}material=e=>(this.materials.has(e)||this.materials.set(e,new _t({color:e})),this.materials.get(e));box=(e,t,i,r,s,a,o,c=!1,l=0)=>{const d=new we(this.geometry,this.material(o));if(d.position.set(e,t,i),d.scale.set(r,s,a),d.rotation.y=l,this.group.add(d),c){const u=Math.cos(l),h=Math.sin(l),f=(Math.abs(u)*r+Math.abs(h)*a)/2,y=(Math.abs(h)*r+Math.abs(u)*a)/2;this.solids.push({minX:e-f,maxX:e+f,minY:t-s/2,maxY:t+s/2,minZ:i-y,maxZ:i+y,obb:{cx:e,cz:i,c:u,s:h,halfW:r/2,halfD:a/2}})}return d};object(e,t,i,r=0,s=0,a){var l;const o={x:t-.5,y:s,z:i-.5,type:e,rotation:r},c=li(o);return a?(this.group.add(c),this.props.push({id:a,block:o,model:c})):(c.updateMatrixWorld(!0),c.traverse(d=>{d.isMesh&&this.group.add(new we(d.geometry.clone().applyMatrix4(d.matrixWorld),d.material))}),this.solids.push(...Qe(o))),(((l=zt.get(e))==null?void 0:l.interaction)==="seat"||e==="bench")&&this.seats.push({x:t,y:s,z:i,rotation:r}),o}label=(e,t,i,r,s=0,a=5.5)=>{if(typeof document>"u")return;const o=document.createElement("canvas");o.width=512,o.height=96;const c=o.getContext("2d");c.fillStyle="#fff1d5",c.fillRect(0,0,512,96),c.fillStyle="#315d52",c.font="bold 34px sans-serif",c.textAlign="center",c.fillText(e,256,62);const l=new jc(new lo({map:new vr(o)}));l.position.set(t,i,r),l.scale.set(a,1,1),this.labels.push(l),this.group.add(l)};finish(e){return ks(this.group,new Set([...e.map(t=>t.pivot),...this.labels]))}}const ac=[{id:"cedar-villa",name:"Cedar villa",x:-111,z:-105,w:16,d:14,angle:0,style:"gable",storeys:2,garage:!0,kind:"home"},{id:"courtyard-home",name:"Courtyard home",x:-73,z:-105,w:18,d:14,angle:0,style:"hip",garage:!0,kind:"home"},{id:"oak-house",name:"Oak family house",x:-35,z:-105,w:18,d:14,angle:0,style:"hip",storeys:2,kind:"home"},{id:"lakeside-lodge",name:"Lakeside lodge",x:4,z:-105,w:16,d:14,angle:0,style:"shed",kind:"home"},{id:"bookshop",name:"Storybook shop",x:42,z:-104,w:18,d:12,angle:0,style:"gable",kind:"books"},{id:"grocer",name:"Garden grocer",x:-112,z:-49,w:16,d:12,angle:Math.PI/2,style:"shed",kind:"grocer"},{id:"museum",name:"Discovery museum",x:-112,z:-12,w:20,d:14,angle:Math.PI/2,style:"hip",kind:"museum"},{id:"community",name:"Community hall",x:-112,z:30,w:22,d:16,angle:Math.PI/2,style:"gable",kind:"community"},{id:"farmhouse",name:"Willow farmhouse",x:-111,z:81,w:18,d:16,angle:Math.PI/2,style:"gable",storeys:2,garage:!0,kind:"home"},{id:"farm-barn",name:"Willow farm barn",x:-70,z:108,w:22,d:14,angle:Math.PI,style:"gable",kind:"farm"},{id:"animal-care",name:"Animal care lodge",x:-33,z:108,w:18,d:12,angle:Math.PI,style:"hip",kind:"animals"},{id:"boathouse",name:"Lakeside boathouse",x:111,z:-65,w:20,d:12,angle:0,style:"shed",kind:"lake"},{id:"greenhouse",name:"Botanical conservatory",x:111,z:13,w:18,d:12,angle:-Math.PI/2,style:"shed",kind:"garden"},{id:"trail-cafe",name:"Woodland trail cafe",x:111,z:64,w:18,d:12,angle:-Math.PI/2,style:"hip",kind:"cafe"}];function gh(n,e=2){const t=mh(n),i=new xo(n),r=[],s=[],a=[],o=[],c=[],l=[{x:0,z:-82,w:180,d:7},{x:0,z:82,w:180,d:7},{x:-86,z:0,w:7,d:171},{x:86,z:0,w:7,d:171},...[-60,8,60].flatMap(x=>[{x,z:-70,w:6,d:24},{x,z:70,w:6,d:24}]),...[-56,4,56].flatMap(x=>[{x:-73,z:x,w:26,d:6},{x:73,z:x,w:26,d:6}])];for(const x of l)i.box(x.x,.014,x.z,x.w,.028,x.d,8558225);for(const x of[-87.5,87.5])i.box(0,.02,x,184,.03,2,14536623);for(const x of[-91.5,91.5])i.box(x,.02,0,2,.03,174,14536623);for(const x of[-86,8,86])for(const m of[-82,82])for(let p=-2;p<=2;p++)i.box(x+p*1.2,.035,m,.6,.01,6,15919569);for(let x=0;x<ac.length;x++){const m=ac[x],p={...m,rooms:m.kind==="home",wall:[14272676,12044734,13678496,13949378][x%4],roof:[9531229,7178880,10914406][x%3]};a.push(p);const _=Math.cos(p.angle),g=Math.sin(p.angle),v=(M,b)=>({x:p.x+M*_+b*g,z:p.z-M*g+b*_}),A=(M,b,F,I,H,L,U,O=!1)=>{p.storeys===2&&Math.abs(b-3.11)<.001&&Math.abs(F+p.d/2-.6)<.001&&Math.abs(L-1.2)<.001&&(F+=.1,L+=.2);const X=v(M,F);return i.box(X.x,b,X.z,I,H,L,U,O,p.angle)};go({h:p,put:A,local:v,scene:i.group,material:i.material,doors:r,solids:i.solids,label:i.label,rooms:s});const E=(M,b,F,I=0,H=0,L)=>{const U=v(b,F);i.object(M,U.x,U.z,p.angle*180/Math.PI+I,H,L?`${p.id}:${L}`:void 0)};if(p.kind==="home")E("sofa",2,2),E("coffee-table",2,.5),E("kitchen-island",-4,1.8),E("sink",-4,-1.5),E("fridge",-5,-3),E("coat-rack",4,3),E("floor-lamp",4,1,0,0,"light"),e===1?E("wall-cupboard",-p.w/2+.3,2,90,1.3,"cupboard"):E("dining-hutch",-p.w/2+.6,2.5,90,0,"cupboard"),p.storeys===2&&(E("double-bed",-4,-4,0,3.2),E("desk",1,-4,0,3.2),E("armchair",1,2,0,3.2),o.push({id:p.id,...v(p.w/2-1.2,p.d/2-1.2),yaw:p.angle,length:p.d-2.8}));else if(p.kind==="books"){for(const M of[-5,2,5])E("bookcase",M,-3);E("round-table",3,1),E("chair",3,3),E("rocking-chair",-5,2)}else if(p.kind==="grocer"){for(const M of[-4,0,4])E("garage-shelf",M,-3),E("storage-crate",M,2);E("kitchen-counter",3,0)}else if(p.kind==="museum")E("fluted-column",-5,0),E("toy-train",3,1,0,.81),E("dining-table",3,1),E("chalkboard",5,-4),E("picture-frame",0,-5,0,1),E("bench",-5,3);else if(p.kind==="community"){for(const M of[-6,2,6])E("round-table",M,0),E("chair",M,2);E("toy-box",-7,-5),E("chalkboard",5,-6)}else if(p.kind==="farm"||p.kind==="animals"){for(const M of[-5,3])E("feeding-trough",M,-2),E("hay-bale",M,2);E("chicken-coop",5,-3),E("kennel",-5,-4),E("workbench",5,3)}else if(p.kind==="garden"){for(const M of[-5,0,5])E("raised-bed",M,-3);E("fern",4,2),E("workbench",-5,2),E("watering-can",-5,2,0,.96)}else if(p.kind==="cafe"){E("corner-counter",-5,-3),E("kettle",-5,-3,0,1.1);for(const M of[1,5])E("round-table",M,0),E("chair",M,2);E("armchair",-5,2)}else p.kind==="lake"&&(E("workbench",-5,-3),E("garage-shelf",5,-3),E("bench",4,2),E("picture-frame",0,-5,0,1.1));const C=v(-1.4,p.d/2+4);c.push({name:p.name,icon:p.kind==="home"?"🏠":p.kind==="farm"?"🐄":"⌂",...C}),A(-1.4,.02,p.d/2+6,2,.025,12,14864298);const z=v(0,p.d/2+.25);i.label(p.name,z.x,2.85,z.z,p.angle)}const d=[{x:111,z:-113,w:44,d:30,shore:{x:84,z:-110}}];i.box(111,.018,-113,44,.025,30,8501446);for(const x of[84,138])i.box(x,.02,-113,2,.025,40,14272675);for(const x of[-133,-93])i.box(111,.02,x,54,.025,2,14272675);i.object("bench",84,-115,90),i.object("willow",80,-127),i.object("willow",138,-96),i.object("street-sign",84,-92),c.push({name:"Willow lake",icon:"💧",x:84,z:-110},{name:"Lakeside lookout",icon:"☀",x:138,z:-112});for(const x of[122,145])for(let m=-87;m<=-60;m+=3)i.object("rail-fence",m,x);for(const x of[-89,-58])for(let m=125;m<=142;m+=3)i.object("rail-fence",x,m,90);i.object("feeding-trough",-73,125),i.object("hay-bale",-83,141),i.object("chicken-coop",-60,116),c.push({name:"Farm paddock",icon:"🐴",x:-72,z:119});for(const x of[36,53,70,87,104,121,138])for(const m of[104,121,138])x===70&&m===121||i.object((x+m)%2?"birch":"pine-tree",x,m);const u=[{x:30,z:98},{x:70,z:98},{x:96,z:118},{x:70,z:132},{x:30,z:132}];for(let x=0;x<u.length;x++){const m=u[x],p=u[(x+1)%u.length],_=Math.hypot(p.x-m.x,p.z-m.z),g=Math.atan2(p.x-m.x,p.z-m.z);i.box((m.x+p.x)/2,.02,(m.z+p.z)/2,2,.025,_,14010276,!1,g),i.object("street-sign",m.x-2,m.z)}i.object("pond-bridge",96,119),i.object("bench",69,127),i.object("round-table",69,124),i.object("flower-arch",30,96),i.object("swing",-10,111,0,0,"region:swing"),i.object("seesaw",-4,111,0,0,"region:seesaw"),i.object("trampoline",3,111,0,0,"region:trampoline"),i.object("play-slide",9,111,0,0,"region:slide"),c.push({name:"Woodland trail",icon:"🌲",x:30,z:98},{name:"Forest picnic",icon:"☀",x:69,z:130},{name:"Adventure playground",icon:"🛝",x:-10,z:106});const h=[...t.plots,{x:25,z:108,w:14,d:14},{x:54,z:108,w:14,d:14},{x:-115,z:123,w:16,d:14},{x:117,z:91,w:14,d:14}];for(const x of h.slice(4))i.box(x.x,.008,x.z,x.w,.012,x.d,11980438),i.label("BUILD HERE",x.x,1.2,x.z+x.d/2);const f=[...t.solids,...i.solids],y=i.finish(r);return Qi(r),{...t,layout:e,houses:[...t.houses,...a],rooms:[...t.rooms,...s],doors:[...t.doors,...r],solids:[...f,...i.props.flatMap(x=>Qe(x.block))],staticSolids:f,authoredProps:i.props,seats:[...t.seats,...i.seats],stairs:o,plots:h,landmarks:[...t.landmarks,...c],waterAreas:d,mapRoads:[...t.mapRoads,...l],activityRange:148,staticRender:{updateVisibility(x,m){t.staticRender.updateVisibility(x,m),y.updateVisibility(x,m)}}}}function qa(n,e){for(let t=0;t<=4;t++)for(let i=-t;i<=t;i++)for(let r=-t;r<=t;r++){if(t&&Math.abs(i)!==t&&Math.abs(r)!==t)continue;const s={...n,x:n.x+i*.6,z:n.z+r*.6,y:n.y||0,vy:0,grounded:!0};if(!vn(s,e)&&Xa(s,e)>=s.y-.04)return s}throw Error("Keep a little space beside the seat")}function kn(n,e){for(let t=0;t<=12;t++)for(let i=-t;i<=t;i++)for(let r=-t;r<=t;r++){if(t&&Math.abs(i)!==t&&Math.abs(r)!==t)continue;const s={x:n.x+i,y:0,z:n.z+r,yaw:n.yaw||0,pitch:0,vy:0,grounded:!0};if(Math.abs(s.x)<249&&Math.abs(s.z)<249&&!vn(s,e))return s}throw Error("No clear arrival space. Your current position is retained.")}function Sg(n){const e=[],t=[],i=[],r=new Set,s=new Set,a=new N,o=new N,c=new We;for(const l of[...n.children]){if(!(l instanceof we)||Array.isArray(l.material)||l.material.transparent)continue;const d=l.material;if(!d.color)continue;l.updateMatrix(),c.getNormalMatrix(l.matrix);const u=l.geometry.index?l.geometry.toNonIndexed():l.geometry,h=u.attributes.position,f=u.attributes.normal;for(let y=0;y<h.count;y++)a.fromBufferAttribute(h,y).applyMatrix4(l.matrix),o.fromBufferAttribute(f,y).applyMatrix3(c).normalize(),e.push(a.x,a.y,a.z),t.push(o.x,o.y,o.z),i.push(d.color.r,d.color.g,d.color.b);u!==l.geometry&&u.dispose(),r.add(l.geometry),s.add(d),l.removeFromParent()}if(e.length){const l=new tt;l.setAttribute("position",new De(e,3)),l.setAttribute("normal",new De(t,3)),l.setAttribute("color",new De(i,3)),l.computeBoundingSphere(),n.add(new we(l,new _t({vertexColors:!0})))}r.forEach(l=>{n.children.some(d=>d instanceof we&&d.geometry===l)||l.dispose()}),s.forEach(l=>{n.children.some(d=>d instanceof we&&d.material===l)||l.dispose()})}const gr={x:178,y:0,z:-156,yaw:0},dr=[{t:0,...gr},{t:6,x:222,y:10,z:-164},{t:12,x:222,y:18,z:-195},{t:22,x:100,y:18,z:-190},{t:35,x:-160,y:18,z:-190},{t:48,x:-190,y:18,z:70},{t:60,x:-80,y:18,z:190},{t:72,x:180,y:18,z:180},{t:84,x:215,y:18,z:-100},{t:94,...gr}];function Eg(n){const e=dr.findIndex(a=>a.t>=n),t=dr[e<0?dr.length-1:Math.max(1,e)],i=dr[Math.max(0,(e<0?dr.length-1:Math.max(1,e))-1)],r=Math.max(0,Math.min(1,(n-i.t)/(t.t-i.t))),s=r*r*(3-2*r);return{x:Ks.lerp(i.x,t.x,r),y:Math.max(0,Math.min(18,Ks.lerp(i.y,t.y,s))),z:Ks.lerp(i.z,t.z,r),yaw:Math.atan2(i.x-t.x,i.z-t.z)}}class Tg{group=new nt;rampGroup=new nt;propeller=new nt;pose={...gr};passenger=!1;elapsed=0;holding=!1;entry=null;localSolids=[];cacheKey="";cache=[];constructor(e){e.add(this.group);const t=new ht(1,1,1),i=new Map,r=(c,l,d,u,h,f,y,x=!0,m=!1)=>{i.has(y)||i.set(y,new _t({color:y,transparent:m,opacity:m?.22:1,depthWrite:!m}));const p=new we(t,i.get(y));return p.position.set(c,l,d),p.scale.set(u,h,f),this.group.add(p),x&&this.localSolids.push({minX:c-u/2,maxX:c+u/2,minY:l-h/2,maxY:l+h/2,minZ:d-f/2,maxZ:d+f/2,owner:"aircraft"}),p};r(0,.5,0,4.2,.2,16,14079428),r(0,3.35,0,4.4,.2,16,14999497);const s=(c,l,d)=>{r(c,.95,l,.16,.7,d,14079428),r(c,2.05,l,.12,1.5,d,10996688,!0,!0),r(c,3,l,.16,.4,d,14079428)};s(2.1,0,16),s(-2.1,-2,12),s(-2.1,7,2),r(-2.1,3,5,.16,.5,2,14079428),r(0,.95,-7.95,4.2,.7,.18,9087396),r(0,2.05,-7.95,4.2,1.5,.12,10996688,!0,!0),r(0,3,-7.95,4.2,.4,.18,14999497),r(0,1.95,7.95,4.2,2.9,.16,14079428),r(0,1,-8.6,3,.7,1.3,9087396);for(const c of[-4.7,4.7])r(c,1.3,-.5,5,.18,2.4,12175806);r(0,2.9,7.2,7,.16,2,9087396),r(0,3.55,6.8,.2,1.3,2,9087396);for(const c of[-1.3,1.3])for(const l of[-3,0,3])r(c,1.08,l,.85,.2,.9,12162682),r(c,1.55,l+.4,.85,1.1,.15,9415330);for(const c of[-1.4,1.4])r(c,.2,3,.25,.4,.65,5071451);r(0,.2,-6,.25,.4,.65,5071451);for(const c of[-3.5,3.5]){r(c,1.4,-1.4,.65,.8,1.6,9087396);const l=new we(new ht(.12,2.1,.12),new _t({color:6717046}));l.position.set(c,1.4,-2.25),this.propeller.add(l)}this.group.add(this.propeller);const a={minX:-5.1,maxX:-2.1,minY:0,maxY:.6,minZ:4.1,maxZ:5.9,ramp:{cx:-3.6,cz:5,c:0,s:-1,width:1.8,length:3,rise:.6,baseY:0},owner:"aircraft:ramp"};this.localSolids.push(a);const o=new we(new ht(3,.1,1.8),new _t({color:12103054}));o.position.set(-3.6,.3,5),o.rotation.z=Math.atan(.6/3),this.rampGroup.add(o),this.group.add(this.rampGroup),Sg(this.group),this.sync()}point(e,t,i){const r=Math.cos(this.pose.yaw),s=Math.sin(this.pose.yaw);return{x:this.pose.x+e*r+i*s,y:this.pose.y+t,z:this.pose.z-e*s+i*r}}sync(){this.group.position.set(this.pose.x,this.pose.y,this.pose.z),this.group.rotation.y=this.pose.yaw,this.cacheKey="",this.rampGroup.visible=!this.passenger}solids(){const e=JSON.stringify(this.pose)+this.passenger;if(e===this.cacheKey)return this.cache;this.cacheKey=e;const t=Math.cos(this.pose.yaw),i=Math.sin(this.pose.yaw);return this.cache=this.localSolids.filter(r=>!this.passenger||!r.ramp).map(r=>{const s=(r.maxX-r.minX)/2,a=(r.maxZ-r.minZ)/2,o=this.point((r.minX+r.maxX)/2,0,(r.minZ+r.maxZ)/2),c=Math.abs(t)*s+Math.abs(i)*a,l=Math.abs(i)*s+Math.abs(t)*a;return{...r,minX:o.x-c,maxX:o.x+c,minZ:o.z-l,maxZ:o.z+l,minY:this.pose.y+r.minY,maxY:this.pose.y+r.maxY,obb:{cx:o.x,cz:o.z,c:t,s:i,halfW:s,halfD:a},...r.ramp?{ramp:{...r.ramp,c:Math.cos(this.pose.yaw-Math.PI/2),s:Math.sin(this.pose.yaw-Math.PI/2),cx:this.point(r.ramp.cx,0,r.ramp.cz).x,cz:this.point(r.ramp.cx,0,r.ramp.cz).z,baseY:this.pose.y}}:{}}}),this.cache}target(){return{...this.point(-1.3,.6,-3),id:"aircraft:tour",kind:"aircraft",range:2.3,icon:"✈",label:"Scenic flight",data:this}}board(e){if(!this.passenger){if(e.y<.5||e.y>.8||Math.hypot(e.x-this.target().x,e.z-this.target().z)>2.3)throw Error("Walk up the ramp and choose a passenger seat");this.entry={...e},this.passenger=!0,this.elapsed=0,this.holding=!1,this.sync(),this.attach(e)}}attach(e){Object.assign(e,{...this.point(-1.3,.6,-3),vy:0,grounded:!0})}returnToPark(e,t){const i=this.pose,r=this.passenger;this.pose={...gr},this.passenger=!1,this.sync();const s=[...t.filter(a=>!String(a.owner).startsWith("aircraft")),...this.solids()];try{let a;try{a=qa(this.entry||this.point(0,.6,5),s)}catch{a=kn(this.point(-6,0,5),s)}Object.assign(e,a),this.holding=!1}catch(a){throw this.pose=i,this.passenger=r,this.sync(),a}}update(e,t,i){if(!this.passenger)return null;if(this.holding)return this.attach(t),null;this.elapsed=Math.min(94,this.elapsed+e);const r=Eg(this.elapsed),s=this.pose,a=(r.yaw-s.yaw+Math.PI*3)%(Math.PI*2)-Math.PI;r.yaw=s.yaw+Math.max(-e,Math.min(e,a)),this.pose=r,this.sync();const o=i(this.pose,12).filter(c=>!String(c.owner).startsWith("aircraft"));if(this.elapsed>=94||this.solids().some(c=>o.some(l=>xt(c,l)))){try{this.returnToPark(t,i(gr,15))}catch{return this.pose=s,this.sync(),this.holding=!0,this.attach(t),"✈ Arrival blocked · use Home or the map for recovery"}return this.elapsed>=94?"✈ Welcome back to Sunbeam":"✈ Route blocked · safely back at the airfield"}return this.attach(t),this.propeller.children.forEach(c=>c.rotation.z+=e*24),null}}function Ag(n){const e=new xo(n),t=[],i=[{id:"airfield-terminal",name:"Sunbeam air terminal",x:150,z:-166,w:22,d:12,angle:0},{id:"airfield-hangar",name:"Sunbeam hangar",x:178,z:-186,w:22,d:22,angle:0}];e.box(150,.015,-166,22,.025,12,14208951);for(const l of[139,161])e.box(l,1.6,-166,.2,3.2,12,12767423,!0);e.box(150,1.6,-172,22,3.2,.2,12767423,!0);for(const[l,d]of[[143.45,8.9],[155.15,11.7]])e.box(l,1.6,-160,d,3.2,.2,12767423,!0);e.box(148.6,2.8,-160,1.4,.8,.2,12767423,!0),e.box(150,3.3,-166,23,.2,13,8428950,!0),Ns({scene:e.group,material:e.material,doors:t,h:i[0],local:(l,d)=>({x:150+l,z:-166+d}),id:"airfield-terminal"});for(const l of[142,145,153])e.object("sofa",l,-168),e.object("coffee-table",l,-166);e.object("kitchen-counter",157,-169),e.object("kettle",157,-169,0,1.1),e.object("floor-lamp",159,-168,0,0,"airfield:light"),e.object("bookcase",142,-171),e.object("toy-box",155,-162),e.object("planter",140,-158),e.label("SUNBEAM AIRFIELD",150,3.8,-160),e.box(178,.015,-186,22,.025,22,12896444);for(const l of[167,189])e.box(l,2.7,-186,.2,5.4,22,10927024,!0);e.box(178,2.7,-197,22,5.4,.2,10927024,!0);for(const l of[168.5,187.5])e.box(l,2.7,-175,3,5.4,.2,10927024,!0);e.box(178,5,-175,16,.8,.2,10927024,!0),e.box(178,5.5,-186,23,.2,23,8297878,!0);for(const l of[168.5,187.5])e.object("tool-cabinet",l,-192),e.object("workbench",l,-195);const r=new nt,s=new nt,a=new we(new ht(16,4.6,.1),e.material(10927024));a.position.y=2.3,s.add(a),r.add(s),r.position.set(178,0,-175),e.group.add(r),t.push({id:"airfield-hangar",kind:"roller",pivot:r,leaf:s,baseAngle:0,center:{x:178,z:-175},hinge:{x:178,z:-175},width:16,height:4.6,open:!1}),e.label("HANGAR",178,5.8,-175),e.box(184,.016,-163,43,.025,34,11714227),e.box(224,.025,-172,10,.025,64,8164235);for(let l=-198;l<=-145;l+=8)e.box(224,.045,l,.3,.015,4,15655881);for(const l of[-202,-142])for(const d of[221,224,227])e.box(d,.045,l,1,.015,3,15655881);e.box(148.6,.03,-150,2,.03,20,14206629),e.box(164,.03,-156,2,.03,30,14206629),e.box(170,.03,-151,12,.03,2,14206629),e.object("bench",216,-181,90),e.object("street-sign",145,-142),e.object("street-sign",199,-174);const o=e.finish(t);Qi(t);const c=new Tg(n);return{...e,doors:t,houses:i,rooms:[{x:150,y:0,z:-166},{x:178,y:0,z:-186}],aircraft:c,render:o,landmarks:[{name:"Airfield terminal",icon:"✈",x:148.6,z:-157},{name:"Aircraft boarding ramp",icon:"✈",x:172,z:-151},{name:"Airfield hangar",icon:"⌂",x:178,z:-171},{name:"Runway lookout",icon:"🔭",x:216,z:-185}]}}const Rg=[{id:"hill-cottage",name:"Hill cottage",x:-116,z:-188,w:14,d:12,angle:Math.PI,style:"gable",kind:"home"},{id:"river-house",name:"River village house",x:-76,z:-188,w:16,d:12,angle:Math.PI,style:"hip",kind:"home",garage:!0},{id:"village-home",name:"Tall village home",x:-36,z:-188,w:16,d:14,angle:Math.PI,style:"gable",kind:"home",storeys:2},{id:"village-hall",name:"Hill village hall",x:35,z:-188,w:20,d:14,angle:Math.PI,style:"hip",kind:"community"},{id:"country-grocer",name:"Country market",x:74,z:-188,w:16,d:12,angle:Math.PI,style:"shed",kind:"shop"},{id:"ranch-lodge",name:"Meadow ranch lodge",x:185,z:112,w:18,d:14,angle:Math.PI/2,style:"gable",kind:"home",garage:!0},{id:"ranch-barn",name:"Meadow riding barn",x:185,z:156,w:22,d:14,angle:Math.PI/2,style:"gable",kind:"farm",garage:!0},{id:"ranger-station",name:"Woodland ranger station",x:-188,z:118,w:16,d:12,angle:-Math.PI/2,style:"shed",kind:"nature"},{id:"bridge-cafe",name:"River bridge cafe",x:-188,z:-105,w:18,d:12,angle:-Math.PI/2,style:"hip",kind:"cafe"},{id:"meadow-garage",name:"Country garage",x:120,z:190,w:18,d:12,angle:0,style:"shed",kind:"workshop",garage:!0}];function Cg(n,e=3){const t=gh(n,2),i=new xo(n),r=[],s=[],a=[],o=[],c=[],l=[{x:0,z:-210,w:430,d:7},{x:0,z:210,w:430,d:7},{x:-210,z:0,w:7,d:427},{x:210,z:0,w:7,d:427},{x:8,z:0,w:7,d:420},{x:-148,z:-56,w:124,d:7},{x:148,z:-56,w:124,d:7},{x:109,z:-140,w:202,d:6}];for(const _ of l)i.box(_.x,.015,_.z,_.w,.03,_.d,8492173);for(const _ of[-204.5,204.5])i.box(0,.025,_,423,.03,2,14206629);for(const _ of[-204.5,204.5])i.box(_,.025,0,2,.03,410,14206629);for(const _ of Rg){const g={..._,rooms:_.kind==="home",wall:_.kind==="farm"?12555380:_.kind==="home"?14271906:12176317,roof:_.style==="shed"?7705227:10190438};a.push(g);const v=Math.cos(g.angle),A=Math.sin(g.angle),E=(F,I)=>({x:g.x+F*v+I*A,z:g.z-F*A+I*v}),C=(F,I,H,L,U,O,X,Z=!1)=>{if(g.kind!=="home"&&(Math.abs(L-1.8)<.001&&Math.abs(U-.56)<.001&&Math.abs(O-2.4)<.001||Math.abs(L-1.75)<.001&&Math.abs(U-.13)<.001||Math.abs(L-1.5)<.001&&(Math.abs(U-.16)<.001||Math.abs(U-.9)<.001)))return;g.storeys===2&&Math.abs(I-3.11)<.001&&Math.abs(H+g.d/2-.6)<.001&&Math.abs(O-1.2)<.001&&(H+=.1,O+=.2);const te=E(F,H);return i.box(te.x,I,te.z,L,U,O,X,Z,g.angle)};go({h:g,put:C,local:E,scene:i.group,material:i.material,doors:r,solids:i.solids,label:i.label,rooms:s});const z=(F,I,H,L=0,U=0,O)=>{const X=E(I,H);i.object(F,X.x,X.z,g.angle*180/Math.PI+U,L,O?`${g.id}:${O}`:void 0)};if(g.kind==="home"&&(z("sofa",3,2),z("coffee-table",3,.5),z("sink",-4,1),z("kitchen-counter",-5,1),z("fridge",-5,-3),z("floor-lamp",4,1,0,0,"light"),g.storeys===2&&(z("desk",1,-4,3.2),z("single-bed",-4,-4,3.2),c.push({id:g.id,...E(g.w/2-1.2,g.d/2-1.2),yaw:g.angle}))),g.kind==="community"){for(const F of[-6,2,6])z("round-table",F,0),z("chair",F,2);z("bookcase",5,-5),z("toy-box",-5,-5)}if(g.kind==="shop"){for(const F of[-5,0,5])z("garage-shelf",F,-3),z("storage-crate",F,2);z("kitchen-counter",3,0)}if(g.kind==="farm"){for(const F of[-6,-3,3,6])z("hay-bale",F,-3);z("feeding-trough",-5,2),z("hitching-post",5,2)}if(g.kind==="nature"&&(z("desk",3,-3),z("chair",3,-1),z("bookcase",-5,-3),z("picture-frame",0,-4,1.2),z("bench",-4,2)),g.kind==="cafe"){z("kitchen-counter",-5,-3),z("kettle",-5,-3,1.1);for(const F of[1,5])z("round-table",F,0),z("chair",F,2)}g.kind==="workshop"&&(z("workbench",-5,-3),z("tool-cabinet",4,-3),z("tyre-stack",5,2),z("air-compressor",-4,2)),z("flower-bed",g.w/2-2,g.d/2+3),z("planter",-g.w/2+2,g.d/2+3),z("post-box",g.w/2+1,g.d/2+2),C(-1.4,.02,g.d/2+6,2,.025,12,14535078);const M=E(-1.4,g.d/2+4);o.push({name:g.name,icon:g.kind==="farm"?"🐴":g.kind==="home"?"🏠":"⌂",...M});const b=E(0,g.d/2+.25);i.label(g.name,b.x,2.9,b.z)}const d=[{x:-198,z:-198},{x:8,z:-198},{x:198,z:-198},{x:198,z:4},{x:198,z:198},{x:8,z:198},{x:-198,z:198},{x:-198,z:4}];for(let _=0;_<d.length;_++){const g=d[_],v=d[(_+1)%d.length],A=Math.hypot(v.x-g.x,v.z-g.z),E=Math.atan2(v.x-g.x,v.z-g.z);i.box((g.x+v.x)/2,.02,(g.z+v.z)/2,2.5,.025,A,13352345,!1,E),i.object("street-sign",g.x+(g.x<0?2:-2),g.z)}for(const[_,g,v]of[[-198,35,"River riding trail"],[198,60,"Ranch riding trail"],[38,198,"Meadow trail"],[-198,180,"Woodland loop"]])o.push({name:v,icon:"🐴",x:_,z:g});i.box(-175,.018,-35,14,.025,150,8632516),i.box(-175,.025,-56,19,.03,8,11704952);for(const _ of[-60.5,-51.5])i.box(-175,.55,_,19,1.1,.12,9337180,!0);const u=[...t.waterAreas,{x:-175,z:-86.5,w:14,d:47,shore:{x:-164,z:-86}},{x:-175,z:-4.5,w:14,d:89,shore:{x:-164,z:0}},{x:-145,z:174,w:52,d:30,shore:{x:-115,z:174}}];i.box(-145,.018,174,52,.025,30,8632516),i.object("willow",-114,185),i.object("bench",-114,176,90),o.push({name:"River crossing",icon:"🌉",x:-175,z:-56},{name:"Meadow lake",icon:"💧",x:-115,z:174});for(const _ of[-225,-160,-140,145,165,225])for(const g of[-145,-85,85,145,205])!(_>130&&g<-120)&&!(_<-130&&g>150)&&i.object((_+g)%3?"birch":"oak-tree",_,g);for(const _ of[-135,-125,-115])for(const g of[135,145,155])i.object("fruit-tree",_,g);for(const _ of[145,155,165])for(const g of[175,184])i.object("raised-bed",_,g);for(const _ of[128,146])for(let g=150;g<178;g+=2)i.object("rail-fence",g,_);for(const _ of[149,178])for(let g=130;g<=144;g+=2)_===178&&g>=134&&g<=140||i.object("rail-fence",_,g,90);i.object("feeding-trough",155,131),i.object("hitching-post",e>=2?175:176,e>=2?130:137),i.object("hay-bale",155,142),i.object("swing",-105,-168,0,0,"county:village-swing"),i.object("bench",-101,-168),o.push({name:"Meadow ranch paddock",icon:"🐴",x:180,z:137},{name:"Airfield reservation",icon:"✈",x:160,z:-140}),i.box(183,.005,-181,100,.008,100,11781787),e<3&&i.label("FUTURE AIRFIELD",160,1.8,-145);const h=[...t.plots,{x:-140,z:-155,w:20,d:16},{x:-42,z:187,w:20,d:18},{x:48,z:174,w:20,d:18},{x:180,z:-90,w:18,d:18},{x:-220,z:55,w:18,d:18},{x:50,z:-220,w:20,d:16}];for(const _ of h.slice(t.plots.length))i.box(_.x,.008,_.z,_.w,.012,_.d,11913878),i.label("BUILD HERE",_.x,1.2,_.z+_.d/2);if(e>=3)for(const _ of[{x:-155,z:-194,name:"Village trail picnic"},{x:194,z:26,name:"East meadow rest"},{x:61,z:193,name:"South meadow picnic"},{x:-193,z:158,name:"Woodland bird garden"}])i.object("bench",_.x,_.z,_.x>190?90:0),i.object("round-table",_.x-3,_.z+2),i.object("flower-bed",_.x-3,_.z-2),i.object("birdhouse",_.x-5,_.z+3),i.object("birch",_.x-7,_.z+4),i.label(_.name,_.x,2,_.z-1),o.push({name:_.name,icon:"🌿",x:_.x,z:_.z-2});const f=e>=3?Ag(n):null,y=new hn().setFromObject(i.group),x=[...t.staticSolids,...i.solids,...(f==null?void 0:f.solids)||[]],m=[...t.authoredProps,...i.props,...(f==null?void 0:f.props)||[]],p=i.finish(r);return Qi(r),{...t,layout:e,houses:[...t.houses,...a,...(f==null?void 0:f.houses)||[]],rooms:[...t.rooms,...s,...(f==null?void 0:f.rooms)||[]],doors:[...t.doors,...r,...(f==null?void 0:f.doors)||[]],staticSolids:x,authoredProps:m,solids:[...x,...m.flatMap(_=>Qe(_.block))],seats:[...t.seats,...i.seats,...(f==null?void 0:f.seats)||[]],stairs:[...t.stairs,...c],landmarks:[...t.landmarks.filter(_=>!(e>=3&&_.name==="Airfield reservation")),...o.filter(_=>!(e>=3&&_.name==="Airfield reservation")),...(f==null?void 0:f.landmarks)||[]],plots:h,waterAreas:u,mapRoads:[...t.mapRoads,...l],activityRange:238,aircraft:f==null?void 0:f.aircraft,dynamicSolids:()=>(f==null?void 0:f.aircraft.solids())||[],developedBounds:{minX:y.min.x,maxX:y.max.x,minZ:y.min.z,maxZ:y.max.z},staticRender:{updateVisibility(_,g){t.staticRender.updateVisibility(_,g),p.updateVisibility(_,g),f==null||f.render.updateVisibility(_,g),f&&(f.aircraft.group.visible=f.aircraft.passenger||Math.hypot(_.position.x-f.aircraft.pose.x,_.position.z-f.aircraft.pose.z)<g)}}}}function Pg({box:n,bench:e,scene:t,material:i,reserved:r}){const l=(u,h)=>{n(u,.76,h,2.5,.15,1.2,9725511,!0);for(const f of[-.95,.95]){n(u,.43,h+f,2.5,.13,.45,9725511,!0);for(const y of[-.85,.85])n(u+y,.22,h+f,.12,.44,.35,5992562,!0)}for(const f of[-.8,.8])n(u+f,.36,h,.16,.72,.9,5992562,!0)},d=(u,h)=>{for(const f of[-3.3,3.3])for(const y of[-2.5,2.5])n(u+f,1.5,h+y,.18,3,.18,9725511,!0);n(u,3.08,h,7.3,.18,5.8,4488320,!0),l(u,h)};n(66,.006,46,29,.012,29,10993279),n(67,.012,43,22,.018,17,14995099);for(const u of[58,64])n(u,1.8,38,.2,3.6,.2,9725511,!0);n(61,3.55,38,6.5,.2,.22,4488320,!0);for(const u of[60,62]){for(const h of[-.3,.3])n(u+h,2.18,38,.035,2.4,.035,5992562);n(u,1,38,.85,.15,.5,11365457,!0)}for(const u of[-1,1])for(const h of[-1,1])n(73+u,1.15,39+h,.15,2.3,.15,9725511,!0);n(73,1.25,39,2.2,.15,2.2,4488320,!0);for(const u of[72,74])n(u,2,38,.12,1.4,.12,9725511,!0);n(73,2.68,39,2.6,.15,2.6,4488320,!0);for(let u=.22;u<1.3;u+=.22)n(73,u,40.1,1.5,.09,.18,16774617);if(!r({minX:74,maxX:79,minZ:38,maxZ:40,minY:0,maxY:2})){const u=new tt;u.setAttribute("position",new De([74,1.32,38.4,74,1.32,39.6,77.8,.12,39.6,74,1.32,38.4,77.8,.12,39.6,77.8,.12,38.4],3)),u.computeVertexNormals();const h=i(15118451).clone();h.side=bt,t.add(new we(u,h))}n(60,.06,48,5,.12,4.2,9725511),n(60,.13,48,4.6,.14,3.8,14995099),n(69,.22,49,.6,.44,1.2,4488320,!0),n(69,.5,49,4.4,.14,.5,11365457,!0);for(const u of[67.2,70.8])n(u,.7,49,.1,.5,.1,16774617),n(u,.79,49,.4,.08,.08,16774617);e(56,44,-Math.PI/2),e(61,55,0),d(82,66);for(const u of[51,81])for(const h of[40,49])n(u,.45,h,.12,.9,.12,9725511,!0),n(u,.65,h,.12,.1,5,9725511,!0);d(195,82),l(204,91),e(204,64,0),e(178,77,-Math.PI/2),e(179,91,-Math.PI/2);for(const u of[190,202]){n(u,.18,64,3.5,.36,1.4,5933922,!0);for(const h of[-1,0,1])n(u+h,.42,64,.4,.2,.4,14728124)}l(-67,-111),n(-74,.5,-113,1.4,1,.14,9725511,!0),n(-74,1.2,-113,2.2,.6,.12,4488320)}const xh=[{id:"orchid",name:"Orchid family house",x:-55,z:-14,w:11,d:9,angle:0,wall:14728124,roof:7042704,style:"hip",garage:!0,garden:1},{id:"cedar",name:"Cedar lodge",x:-78,z:-16,w:7,d:11,angle:0,wall:14268559,roof:4488320,style:"gable",porch:3.6,garden:2},{id:"sunflower",name:"Sunflower courtyard",x:-59,z:24,w:12,d:7,angle:Math.PI,wall:15851437,roof:11365457,style:"shed",garage:!0,garden:3},{id:"bluebell",name:"Bluebell cottage",x:-84,z:-44,w:6,d:7,angle:-Math.PI/2,wall:11914194,roof:7108992,style:"gable",garden:2},{id:"maple",name:"Maple garden house",x:-54,z:-61,w:10,d:10,angle:Math.PI,wall:15185051,roof:7042704,style:"hip",garage:!0,garden:1},{id:"fern",name:"Fern studio",x:-23,z:-62,w:6,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"shed",porch:3.2,garden:3},{id:"bakery",name:"Sunrise bakery",x:44,z:-42,w:10,d:8,angle:0,wall:15851437,roof:11365457,style:"gable",shop:!0,sign:"BAKERY",garden:0},{id:"market",name:"Village market",x:60,z:-43,w:10,d:10,angle:0,wall:12177332,roof:4488320,style:"hip",shop:!0,sign:"MARKET",garden:0},{id:"pottery",name:"Clay corner",x:32,z:-25,w:8,d:9,angle:Math.PI/2,wall:14728124,roof:7042704,style:"shed",shop:!0,sign:"POTTERY",garden:0},{id:"workshop",name:"Oak workshop",x:92,z:-17,w:11,d:10,angle:-Math.PI/2,wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,garden:0},{id:"willow",name:"Willow retreat",x:-10,z:-94,w:7,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"hip",porch:3.4,garden:2},{id:"pavilion",name:"Orchard shelter",x:103,z:90,w:8,d:6,angle:-Math.PI/2,wall:15851437,roof:11365457,style:"gable",porch:4,garden:2},...ng],Lg=[[[-124,6],[-103,6],[-85,6],[-66,3],[-49,3],[-35,6],[-20,6],[-6,6],[6,8.6],[17,9],[26,4],[35,3],[50,2],[65,-8],[72,-28],[70,-55],[52,-68],[25,-66],[-10,-77],[-45,-78],[-80,-69],[-98,-48],[-99,-18],[-85,6]],[[72,-28],[92,-52],[115,-53]],...ig],zg=[[[-35,6],[-36,40],[-45,61],[-41,80],[-15,87],[15,86],[45,86],[66,67],[50,60],[50,33],[53,25],[50,2]],[[45,86],[66,98],[81,94],[94,91],[95,77],[108,62],[104,42],[82,30],[84,41],[84,54],[73,62],[66,67]],[[-80,-69],[-86,-90],[-65,-103],[-45,-108],[-21,-112],[-3,-105],[18,-117],[44,-109],[47,-90],[25,-66]],[[-10,-77],[-18,-89],[-14,-102],[-3,-105]],[[41,-33],[41,-18],[49,-12],[65,-8]],[[18,-117],[18,-104],[37,-103],[47,-90]],...rg];function Wt(n,e,t){let i=1/0,r=null;for(let s=1;s<t.length;s++){const a=t[s-1],o=t[s],c=o[0]-a[0],l=o[1]-a[1],d=Math.max(0,Math.min(1,((n-a[0])*c+(e-a[1])*l)/(c*c+l*l))),u={x:a[0]+c*d,z:a[1]+l*d},h=Math.hypot(n-u.x,e-u.z);h<i&&(i=h,r=u)}return{distance:i,point:r}}function ur(n){let e=n;for(let t=0;t<2;t++){const i=[e[0]];for(let r=1;r<e.length;r++){const s=e[r-1],a=e[r];i.push([s[0]*.75+a[0]*.25,s[1]*.75+a[1]*.25],[s[0]*.25+a[0]*.75,s[1]*.25+a[1]*.75])}i.push(e.at(-1)),e=i}return e}function Dg({scene:n,box:e,material:t,bench:i,disk:r,roads:s,trails:a,drives:o,houses:c,clearings:l,treeAllowed:d,treePositions:u}){e(-8,.006,-197,70,.012,18,14141609);for(const _ of[-32,-8,16])e(_,.25,-205.5,3,.5,3,11906454,!0),e(_,.54,-205.5,2.6,.08,2.6,7052647),i(_===-8?-16:_,-190,0);for(const _ of[-5,5])for(const g of[-204,-199])e(_,1.5,g,.18,3,.18,9725511,!0);for(const _ of[-204,-199])e(0,2.98,_,10.4,.18,.22,9725511,!0);for(let _=-5;_<=5;_+=1)e(_,3.08,-201.5,.15,.16,6,9725511);e(188,.006,-103,14,.012,21,14141609);for(const _ of[-116,-104,-92])i(187,_,Math.PI/2);for(const _ of[199,203,207,211])for(const g of[-27,-34]){e(_,.2,g,2.5,.4,4,9725511,!0),e(_,.43,g,2.2,.06,3.7,7052647);for(let v=0;v<4;v++)e(_,.65,g-1.2+v*.8,.4,.38,.4,v%2?15118451:14728124)}for(const _ of ss){r(_.x,_.z,_.rx+1.6,_.rz+1.6,14141609,.008),r(_.x,_.z,_.rx,_.rz,7515836,.026);for(let g=0;g<30;g++){const v=g*Math.PI*2/30,A=_.x+Math.cos(v)*(_.rx+.7),E=_.z+Math.sin(v)*(_.rz+.7);Math.abs(A-_.x)<2||(e(A,.4,E,.055,.8,.055,5474391),e(A,.85,E,.11,.18,.11,9725511))}}e(-18,.006,200,20,.012,9,14141609);for(const _ of[-76,-70,-64])for(let g=216;g<=234;g+=2)e(_,.12,g,3,.24,1.6,9725511),e(_,.38,g,2.6,.3,1.3,g%4?7052647:15118451);const f=[];for(let _=0;_<20;_++){const g=_*.56;f.push({x:-110+Math.cos(g)*(9+Math.floor(_/7)*4),z:232+Math.sin(g)*(7+Math.floor(_/7)*2),fruit:!0})}const y=[[-210,-190,26,29],[-71,-225,26,10],[181,-185,44,24],[-214,111,19,34],[66,232,43,10],[220,164,17,32],[-220,214,14,22]];let x=19052;const m=()=>(x=Math.imul(x,1664525)+1013904223>>>0,x/4294967296),p=(_,g)=>!!(Math.abs(_)<128&&Math.abs(g)<128||c.some(v=>{const A=Math.abs(Math.cos(v.angle)),E=Math.abs(Math.sin(v.angle));return Math.abs(_-v.x)<(v.w*A+v.d*E)/2+10&&Math.abs(g-v.z)<(v.w*E+v.d*A)/2+10})||[...s,...a].some(v=>Wt(_,g,v).distance<5.3)||o.some(v=>Wt(_,g,v.points).distance<4)||l.some(v=>Math.abs(_-v.x)<v.w/2+4&&Math.abs(g-v.z)<v.d/2+4)||ss.some(v=>((_-v.x)/(v.rx+5))**2+((g-v.z)/(v.rz+5))**2<1)||th.some(v=>Math.hypot(_-(v.signX??v.x+4),g-(v.signZ??v.z+4))<5)||Math.abs(_-197)<18&&Math.abs(g-84)<15||Math.abs(_+8)<39&&Math.abs(g+197)<14||_>-85&&_<-55&&g>208);for(let _=0;_<2100;_++){const g=y[_%y.length],v=m()*Math.PI*2,A=Math.sqrt(m()),E=g[0]+Math.cos(v)*g[2]*A,C=g[1]+Math.sin(v)*g[3]*A;p(E,C)||f.some(z=>Math.hypot(E-z.x,C-z.z)<4.1)||f.push({x:E,z:C})}for(const[_,g]of[[-223,-73],[-143,12],[-205,76],[-143,82],[91,-202],[120,-169],[199,-8],[178,123],[113,222],[-50,235],[-231,159]])for(const[v,A]of[[0,0],[5,4],[-4,6]])p(_+v,g+A)||f.push({x:_+v,z:g+A});for(const[_,g]of f.entries()){if(!d(g.x,g.z))continue;u.push({x:g.x,z:g.z});const v=g.fruit?2.2:2.8+_%4*.4;e(g.x,v/2,g.z,.4,v,.4,9725511,!0);const A=!g.fruit&&_%3===0,E=A?new Mr(2.2,4.8,7):new br(1,1);A||E.scale(2.2,2.05,2.2);const C=new we(E,t(A?5082472:_%2?7052647:5933922));if(C.position.set(g.x,v+.7,g.z),n.add(C),g.fruit)for(const z of[-1,1])e(g.x+z,v+.5,g.z+.4,.22,.22,.22,13075044)}return{trees:f.length,groves:y.length,ponds:ss.length}}function _h(n,e){if(n.kind==="roller"){const u=Math.cos(n.baseAngle),h=Math.sin(n.baseAngle),f=n.width/2,y=.055,x=n.center.x,m=n.center.z,p=Math.abs(u)*f+Math.abs(h)*y,_=Math.abs(h)*f+Math.abs(u)*y,g=Math.min(1,Math.max(0,e/(Math.PI/2)));return{minX:x-p,maxX:x+p,minZ:m-_,maxZ:m+_,minY:n.height*g,maxY:n.height,obb:{cx:x,cz:m,c:u,s:h,halfW:f,halfD:y},door:!0}}const t=n.baseAngle+e,i=Math.cos(t),r=Math.sin(t),s=n.width/2,a=.055,o=n.hinge.x+i*s,c=n.hinge.z-r*s,l=Math.abs(i)*s+Math.abs(r)*a,d=Math.abs(r)*s+Math.abs(i)*a;return{minX:o-l,maxX:o+l,minZ:c-d,maxZ:c+d,minY:0,maxY:n.height??2.3,obb:{cx:o,cz:c,c:i,s:r,halfW:s,halfD:a},door:!0}}function Pn(n,e,t=n.swing??-1){const i=n.angle??(n.open?t*Math.PI/2:0);return _h(n,i)}const oc=[{id:"home",name:"Your home",x:-13,z:-9,w:8,d:7,angle:0,wall:15851437,roof:4488320,style:"gable"},{id:"peach",name:"Peach cottage",x:6,z:-10,w:7,d:8,angle:0,wall:15185051,roof:7042704,style:"hip"},{id:"sage",name:"Sage bungalow",x:-17,z:20,w:9,d:6,angle:Math.PI,wall:12177332,roof:11365457,style:"gable"},{id:"rose",name:"Rose cabin",x:17,z:20,w:6,d:8,angle:Math.PI,wall:14728124,roof:7108992,style:"shed"},...xh,...On];function kt(n,e,t){const i=Math.cos(n.angle),r=Math.sin(n.angle);return{x:n.x+e*i+t*r,z:n.z-e*r+t*i}}function Ig(n,e=[]){const t=new bn(8);for(const S of e)t.add(ei(S));const i=S=>t.query(S).some(w=>qi(w,S)),r=[],s=oc.filter(S=>{if(!S.designed)return!0;const w=Math.max(S.w,S.d)/2+(S.garage?6:2),V=i({minX:S.x-w,maxX:S.x+w,minZ:S.z-w,maxZ:S.z+w,minY:0,maxY:10});return V&&r.push(S.id),!V}),a=[],o=[];let c=!1;const l=[],d=[],u=new Map,h=new ht(1,1,1),f=new Map,y=S=>(f.has(S)||f.set(S,new _t({color:S})),f.get(S)),x=new mt;function m(S,w,V,k,ae,oe,ee,me=!1,R=0){const T=(Math.abs(Math.cos(R))*k+Math.abs(Math.sin(R))*oe)/2+.1,B=(Math.abs(Math.sin(R))*k+Math.abs(Math.cos(R))*oe)/2+.1;if(!(c&&ae>.03&&i({minX:S-T,maxX:S+T,minZ:V-B,maxZ:V+B,minY:w-ae/2,maxY:w+ae/2}))&&(u.has(ee)||u.set(ee,[]),u.get(ee).push({x:S,y:w,z:V,w:k,h:ae,d:oe,angle:R}),me)){const Q=Math.abs(Math.cos(R)),j=Math.abs(Math.sin(R)),ne=(k*Q+oe*j)/2,ye=(k*j+oe*Q)/2;l.push({...Math.abs(Math.sin(R*2))>1e-6?{obb:{cx:S,cz:V,c:Math.cos(R),s:Math.sin(R),halfW:k/2,halfD:oe/2}}:{},minX:S-ne,maxX:S+ne,minY:w-ae/2,maxY:w+ae/2,minZ:V-ye,maxZ:V+ye})}}const p=[];function _(S,w,V,k,ae=0,oe=4){if(typeof document>"u")return;const ee=document.createElement("canvas");ee.width=512,ee.height=96;const me=ee.getContext("2d");me.fillStyle="#fff5d9",me.fillRect(0,0,512,96),me.fillStyle="#496c61",me.font="bold 48px sans-serif",me.textAlign="center",me.textBaseline="middle",me.fillText(S,256,50,480);const R=new vr(ee);R.colorSpace=vt;const T=new we(new Fn(oe,oe*96/512),new Bi({map:R,side:bt}));T.position.set(w,V,k),T.rotation.y=ae,n.add(T),p.push(T)}const g=9418861,v=9725511,A=16774617,E=8501706;m(0,-.18,0,st.halfSize*2+2,.36,st.halfSize*2+2,g,!0);const C=Lg.map(ur),z=zg.map(ur);for(const S of Ha.filter((w,V)=>V!==2)){const w=ur(S);for(const V of[0,w.length-1]){const k=w[V],ae=Wt(k[0],k[1],C[2]).point;V===0?w.unshift([ae.x,ae.z]):w.push([ae.x,ae.z])}C.push(w)}z.push(...eg.map(ur),ur(Ha[2]));const M=C[0];function b(S,w,V,k){const ae=[],oe=[];S.forEach((R,T)=>{const B=S[Math.max(0,T-1)],Q=S[Math.min(S.length-1,T+1)],j=Q[0]-B[0],ne=Q[1]-B[1],ye=Math.hypot(j,ne),xe=-ne/ye*w/2,ve=j/ye*w/2;if(ae.push(R[0]+xe,k,R[1]+ve,R[0]-xe,k,R[1]-ve),T){let Te=T*2;oe.push(Te-2,Te,Te-1,Te-1,Te,Te+1)}});const ee=new tt;ee.setAttribute("position",new De(ae,3)),ee.setIndex(oe),ee.computeVertexNormals();const me=new we(ee,y(V));return n.add(me),me}for(const S of C)b(S,7.4,14601641,.014),b(S,5,6845816,.024);for(const S of z)b(S,2.4,14008212,.019);const F=[];for(const S of C)for(const w of[0,S.length-1]){const V=S[w],k=w===0?S.slice(5):S.slice(0,-5);k.length>1&&Wt(V[0],V[1],k).distance<2.5&&F.push({x:V[0],z:V[1]})}for(const S of C){let w=0,V=1;for(let k=1;k<S.length;k++){const ae=S[k-1],oe=S[k],ee=oe[0]-ae[0],me=oe[1]-ae[1],R=Math.hypot(ee,me);for(;V<w+R;){const T=(V-w)/R,B=ae[0]+ee*T,Q=ae[1]+me*T;!F.some(j=>Math.hypot(B-j.x,Q-j.z)<5.5)&&!C.some(j=>j!==S&&Wt(B,Q,j).distance<5.5)&&m(ae[0]+ee*T,.031,ae[1]+me*T,.1,.012,1.1,15984318,!1,Math.atan2(ee,me)),V+=3.5}w+=R}}const I=s.map(S=>{const w=kt(S,-1.4,S.d/2),V=kt(S,-1.4,S.d/2+2.5),ae=(S.street?[C[{north:4,south:5,elm:6}[S.street]]]:S.route==="trail"?z:S.shop?[...C,z[4]]:S.id==="willow"||S.id==="pavilion"?z:C).map(me=>({...Wt(V.x,V.z,me),isRoad:C.includes(me)})).sort((me,R)=>me.distance-R.distance)[0];let oe=S.approach||{bakery:{x:44,z:-34},market:{x:60,z:-34},pottery:{x:39,z:-25}}[S.id]||ae.point;if(ae.isRoad&&!["bakery","market","pottery"].includes(S.id)){const me=V.x-oe.x,R=V.z-oe.z,T=Math.hypot(me,R);T>3.3&&(oe={x:oe.x+me/T*3.3,z:oe.z+R/T*3.3})}const ee=[[w.x,w.z],[V.x,V.z],[oe.x,oe.z]];if(b(ee,S.shop?2.8:2.4,12959399,.032),S.garage||S.carport){const me=kt(S,-S.w/2-2.1,S.d/2+.15);let R=C.map(j=>Wt(me.x,me.z,j)).sort((j,ne)=>j.distance-ne.distance)[0].point;const T=me.x-R.x,B=me.z-R.z,Q=Math.hypot(T,B);Q>3.3&&(R={x:R.x+T/Q*3.3,z:R.z+B/Q*3.3}),b([[me.x,me.z],[R.x,R.z]],3.6,12959399,.033)}return{entry:w,end:oe,points:ee,w:S.shop?2.8:2.4}});for(const S of s){let me=function(re){const le=S.w>9?2.4:1.8,fe=S.shop?2.6:S.w>9?2.2:1.5,K=1.05,D=1.2,he=re>0?[[-w/2,ae-oe/2],[ae+oe/2,le-fe/2],[le+fe/2,w/2]]:[[-w/2,le-fe/2],[le+fe/2,w/2]];for(const[pe,Ae]of he)Ae>pe&&ee((pe+Ae)/2,1.5,re,Ae-pe,3,.22,S.wall,!0);re>0&&ee(ae,2.675,re,oe,.65,.22,S.wall,!0),ee(le,K/2,re,fe,K,.22,S.wall,!0),ee(le,(K+D+3)/2,re,fe,3-K-D,.22,S.wall,!0),ee(le,K+D/2,re,fe,D,.1,E,!0);for(const pe of[le-fe/2,le,le+fe/2])ee(pe,K+D/2,re+.01,.065,D+.12,.29,A);for(const pe of[K,K+D/2,K+D])ee(le,pe,re+.01,fe+.12,.065,.29,A);ee(le,K-.06,re,fe+.27,.12,.42,A)};var Ie=me;const{w,d:V}=S,k=V/2,ae=-1.4,oe=1.4,ee=(re,le,fe,K,D,he,pe,Ae=!1)=>{const Le=kt(S,re,fe);m(Le.x,le,Le.z,K,D,he,pe,Ae,S.angle)};if(c=!!S.designed,S.designed){go({h:S,put:ee,local:(re,le)=>kt(S,re,le),scene:n,material:y,doors:d,solids:l,label:_,rooms:a}),c=!1;continue}if(ee(0,.006,0,w,.012,V,14006419),me(k),me(-k),S.wing){const re=-k+2.75;for(const[le,fe]of[[-k,re-.9],[re+.9,k]])fe>le&&ee(-w/2,1.5,(le+fe)/2,.22,3,fe-le,S.wall,!0);ee(-w/2,2.72,re,.22,.56,1.8,S.wall,!0),a.push({house:S.id,name:"Side room",...kt(S,-w/2-2.25,re),y:0})}else ee(-w/2,1.5,0,.22,3,V,S.wall,!0);if((S.d>8||S.bay)&&xh.some(re=>re.id===S.id)){const re=S.d>10?[-2.6,2.6]:[0],le=.8;let fe=-k;for(const K of re){const D=K-le;ee(w/2,1.5,(fe+D)/2,.22,3,D-fe,S.wall,!0),ee(w/2,.525,K,.22,1.05,1.6,S.wall,!0),ee(w/2,2.625,K,.22,.75,1.6,S.wall,!0),S.bay||ee(w/2,1.65,K,.1,1.2,1.6,E,!0);for(const he of[K-le,K,K+le])ee(w/2+.01,1.65,he,.29,1.32,.065,A);for(const he of[1.05,1.65,2.25])ee(w/2+.01,he,K,.29,.065,1.72,A);fe=K+le}ee(w/2,1.5,(fe+k)/2,.22,3,k-fe,S.wall,!0)}else ee(w/2,1.5,0,.22,3,V,S.wall,!0);const R=[],T=[],B=(re,le,fe,K)=>{const D=R.length/3;R.push(...re,...le,...fe,...K),T.push(D,D+1,D+2,D,D+2,D+3)},Q=w/2+.4,j=k+.4,ne=3.06,ye=4.7;if(S.style==="gable"){B([-Q,ne,j],[0,ye,j],[0,ye,-j],[-Q,ne,-j]),B([0,ye,j],[Q,ne,j],[Q,ne,-j],[0,ye,-j]);for(const re of[-k,k]){const le=ne+(ye-ne)*.4/Q,fe=new tt;fe.setAttribute("position",new De([-w/2,3,re,w/2,3,re,w/2,le,re,0,ye,re,-w/2,le,re],3)),fe.setIndex([0,1,2,0,2,3,0,3,4]),fe.computeVertexNormals();const K=y(S.wall).clone();K.side=bt;const D=new we(fe,K);D.position.set(S.x,0,S.z),D.rotation.y=S.angle,n.add(D)}}else if(S.style==="gambrel"){const re=[-Q,-Q*.56,0,Q*.56,Q],le=[ne,4.45,5.4,4.45,ne];for(let K=1;K<re.length;K++)B([re[K-1],le[K-1],j],[re[K],le[K],j],[re[K],le[K],-j],[re[K-1],le[K-1],-j]);const fe=ne+(4.45-ne)*.4/(Q*.44);for(const K of[-k,k]){const D=[[-w/2,3,K],[w/2,3,K],[w/2,fe,K],[Q*.56,4.45,K],[0,5.4,K],[-Q*.56,4.45,K],[-w/2,fe,K]],he=new tt;he.setAttribute("position",new De(D.flat(),3)),he.setIndex([0,1,2,0,2,3,0,3,4,0,4,5,0,5,6]),he.computeVertexNormals();const pe=y(S.wall).clone();pe.side=bt;const Ae=new we(he,pe);Ae.position.set(S.x,0,S.z),Ae.rotation.y=S.angle,n.add(Ae)}}else if(S.style==="hip")B([-Q,ne,j],[Q,ne,j],[0,ye,1.5],[0,ye,1.5]),B([Q,ne,j],[Q,ne,-j],[0,ye,-1.5],[0,ye,1.5]),B([Q,ne,-j],[-Q,ne,-j],[0,ye,-1.5],[0,ye,-1.5]),B([-Q,ne,-j],[-Q,ne,j],[0,ye,1.5],[0,ye,-1.5]);else{B([-Q,ne,j],[Q,ne,j],[Q,4.1,-j],[-Q,4.1,-j]);const re=ne+(4.1-ne)*.4/(V+.8),le=4.1-(4.1-ne)*.4/(V+.8);ee(0,(3+le)/2,-k,w,le-3,.22,S.wall),ee(0,(3+re)/2,k,w,re-3,.22,S.wall);for(const fe of[-w/2,w/2]){const K=new tt;K.setAttribute("position",new De([fe,3,-k,fe,le,-k,fe,re,k,fe,3,k],3)),K.setIndex([0,1,2,0,2,3]),K.computeVertexNormals();const D=y(S.wall).clone();D.side=bt;const he=new we(K,D);he.position.set(S.x,0,S.z),he.rotation.y=S.angle,n.add(he)}}const xe=new tt;xe.setAttribute("position",new De(R,3)),xe.setIndex(T),xe.computeVertexNormals();const ve=y(S.roof).clone();ve.side=bt;const Te=new we(xe,ve);Te.position.set(S.x,0,S.z),Te.rotation.y=S.angle,n.add(Te),ee(0,3.015,0,S.style==="shed"?w:w+.8,.09,S.style==="shed"?V:V+.8,A,!0);for(const re of[-w/2,w/2])ee(re,1.5,k+.08,.13,3,.14,A);ee(ae,2.62,k+.7,S.porch||2.2,.15,1.5,S.roof,!0);for(const re of[ae-(S.porch||2.2)/2+.14,ae+(S.porch||2.2)/2-.14])ee(re,1.27,k+1.28,.12,2.54,.12,A,!0);const Ue=new nt,ce=kt(S,ae-oe/2+.07,k+.03),$e=oe-.14;Ue.position.set(ce.x,0,ce.z),Ue.rotation.y=S.angle;const qe=new we(new ht($e,2.3,.1),y(9726028));qe.position.set($e/2,1.15,0),Ue.add(qe);const Ne=new we(new ht(.78,.7,.11),y(11980733));Ne.position.set($e/2,1.66,0),Ue.add(Ne);const Pe=new we(new Cs(.055,6,5),y(16768118));Pe.position.set($e-.18,1,.09),Ue.add(Pe),n.add(Ue);const be=kt(S,ae,k);if(d.push({id:S.id,pivot:Ue,baseAngle:S.angle,open:!1,center:be,hinge:ce,width:$e,height:2.3}),S.shop){ee(w/2-1,.45,-k+1,1.4,.9,1.3,v,!0),ee(w/2-1,.95,-k+1,1.6,.12,1.5,A);for(let le=0;le<3;le++)ee(-w/2+1.2+le*1.6,.6,-k+.7,1.2,1.2,.65,v,!0),ee(-w/2+1.2+le*1.6,1.28,-k+.7,.8,.16,.4,[15118451,12177332,14728124][le]);ee(1,2.6,k+.19,w-1,.25,.6,S.roof);for(let le=0;le<8;le++)ee(-w/2+.5+le*(w-1)/8,2.7,k+.8,(w-1)/8,.12,1.4,le%2?A:S.roof);ee(0,3.28,k+.2,4.05,.82,.12,v);for(const le of[-1.65,1.65])ee(le,2.96,k+.18,.1,.7,.12,v);const re=kt(S,0,k+.28);_(S.sign,re.x,3.28,re.z,S.angle,3.8)}else ee(-w/2+1.15,.29,-k+1.6,1.7,.58,2.4,v,!0),ee(-w/2+1.15,.65,-k+1.45,1.65,.16,2.1,S.id==="home"?7183771:13214055),ee(-w/2+1.15,.78,-k+.65,1.4,.17,.48,A),ee(w/2-.9,.45,-k+.9,1.1,.9,.7,v,!0);if(S.garage&&Fs({scene:n,material:y,doors:d,h:S,put:ee,local:(re,le)=>kt(S,re,le)}),S.carport){const re=-w/2-2.1,le=k-2.7;ee(re,2.55,le,4.6,.18,5.8,S.roof,!0);for(const fe of[-1.9,1.9])for(const K of[-2.35,2.35])ee(re+fe,1.22,le+K,.16,2.44,.16,v,!0);ee(re,.008,le,4.2,.016,5.4,12959399)}if(S.wing){const re=-w/2-2.25,le=-k+2.75;ee(re,.007,le,4.5,.014,5.5,14006419),ee(re-2.25,1.65,le,.22,3.3,5.5,S.wall,!0);for(const fe of[le-2.75,le+2.75])ee(re,1.65,fe,4.5,3.3,.22,S.wall,!0);ee(re,3.4,le,4.9,.2,5.9,S.roof,!0),ee(re,1.7,le+2.78,2.6,1.25,.08,E);for(const fe of[re-1.33,re,re+1.33])ee(fe,1.7,le+2.84,.065,1.38,.1,A);for(const fe of[1.05,2.35])ee(re,fe,le+2.84,2.73,.065,.1,A)}if(S.bay){c=!0,ee(w/2+.32,.525,0,.64,1.05,1.9,S.wall,!0),ee(w/2+.64,1.65,0,.08,1.2,1.8,E,!0);for(const re of[-.87,.87])ee(w/2+.32,1.65,re,.64,1.2,.08,E,!0);ee(w/2+.34,3.015,0,.9,.09,2.15,A,!0),ee(w/2+.64,2.625,0,.1,.75,1.8,S.wall,!0);for(const re of[-.87,.87])ee(w/2+.32,2.625,re,.64,.75,.1,S.wall,!0);for(const re of[-.9,0,.9])ee(w/2+.7,1.65,re,.1,1.35,.065,A)}if(c=!1,S.chimney&&ee(w/2-1,4.2,-k*.3,.8,2.4,.8,13075044,!0),S.tower){const re=w/2+1.8,le=-k+1.8;ee(re,3.4,le,3.6,6.8,3.6,S.wall,!0);for(const he of[le-1.83,le+1.83]){ee(re,5.1,he,1.5,1.5,.08,A),ee(re,5.3,he+(he>le?.06:-.06),.08,.58,.1,v),ee(re+.22,5.1,he+(he>le?.06:-.06),.48,.08,.1,v);for(const pe of[re-.58,re+.58])ee(pe,5.1,he,.08,1.65,.12,A)}const fe=kt(S,re,le),K=new Mr(2.7,1.8,4),D=new we(K,y(S.roof));D.position.set(fe.x,7.7,fe.z),D.rotation.y=S.angle+Math.PI/4,n.add(D)}if(S.garden){c=!!S.wing;const re=S.garage||S.wing?w/2+2:-w/2-2;ee(re,.18,0,2.3,.36,V*.75,5933922,!0);for(let le=0;le<4;le++)ee(re,.42,-V*.25+le*V/6,.4,.2,.4,[15118451,14728124,15851437][S.garden-1]);S.garden===3&&(ee(0,.3,-k-2.2,w*.7,.6,1.2,v,!0),ee(0,.64,-k-2.2,w*.65,.12,1,7052647))}c=!1,ee(.55,.05,k+.5,.8,.09,.6,S.roof);const Fe=kt(S,2.15,k+2.1);m(Fe.x,.5,Fe.z,.11,1,.11,v,!0),m(Fe.x,1.05,Fe.z,.55,.34,.4,S.roof)}const H={x:-10.8,z:-8.1};m(H.x,.88,H.z,1.4,.22,1.1,11368266,!0);for(const S of[-.5,.5])for(const w of[-.35,.35])m(H.x+S,.39,H.z+w,.14,.78,.14,v,!0);for(let S=0;S<3;S++)for(let w=0;w<3;w++)m(H.x-.36+S*.36,1.001,H.z-.32+w*.32,.29,.014,.26,(S+w)%2?15718563:7687734);m(-4,.004,-.5,8,.008,6,10993279);for(const S of[-8,0])for(const w of[-3.5,2.5])m(S,.16,w,.2,.32,.2,v);const L=[[-27,-18],[-23,-7],[-28,17],[-6,-22],[18,-17],[26,-7],[28,20],[2,25],[-28,28],[27,-25],[13,29],[-2,19]];function U(S,w){return C.some(V=>Wt(S,w,V).distance<4.8)||z.some(V=>Wt(S,w,V).distance<2.1)||I.some(V=>Wt(S,w,V.points).distance<2.2)||s.some(V=>{const k=kt({...V,angle:-V.angle,x:0,z:0},S-V.x,w-V.z);return Math.abs(k.x)<V.w/2+(V.garage||V.wing?6:2.8)&&Math.abs(k.z)<V.d/2+3})||[..._s].some(V=>Math.abs(S-V.x)<V.w/2+2&&Math.abs(w-V.z)<V.d/2+2)?!1:!i({minX:S-2,maxX:S+2,minZ:w-2,maxZ:w+2,minY:0,maxY:7})}const O=[];for(const[S,[w,V]]of L.entries()){if(!U(w,V))continue;o.push({x:w,z:V});const k=2.5+S%3*.25;m(w,k/2,V,.42,k,.42,8675908,!0),O.push({x:w,y:k+.7,z:V,scale:1.9+S%2*.3,color:S%2?7052647:5082472})}for(const S of new Set(O.map(w=>w.color))){const w=O.filter(ae=>ae.color===S),V=new br(1,1),k=new xs(V,y(S),w.length);w.forEach((ae,oe)=>{x.position.set(ae.x,ae.y,ae.z),x.scale.set(ae.scale,ae.scale*.85,ae.scale),x.rotation.set(0,oe,.2),x.updateMatrix(),k.setMatrixAt(oe,x.matrix)}),n.add(k)}for(let S=-st.halfSize+1;S<=st.halfSize-1;S+=4){for(const w of[-st.halfSize,st.halfSize])m(S,.7,w,4,1.4,1.4,5933922);for(const w of[-st.halfSize,st.halfSize])m(w,.7,S,1.4,1.4,4,5933922)}m(1,.48,15,2,.15,.65,v,!0),m(1,.94,15.28,2,.8,.12,v,!0);for(const S of[.25,1.75])m(S,.23,15,.12,.46,.5,5992562,!0);for(const[S,w]of[[-8,-14],[-18,-14],[10,-16],[20,15],[-21,17],[0,16]])m(S,.18,w,.07,.36,.07,5474391),m(S,.4,w,.32,.16,.32,15118451);if(m(49,.006,-26,23,.012,23,14141609),m(49,.2,-26,3,.4,3,11906454,!0),m(49,.44,-26,2.6,.08,2.6,7052647),m(49,2,-26,.32,4,.32,v,!0),m(49,4.1,-26,1.4,1.4,.4,15851437),typeof document<"u"){const S=document.createElement("canvas");S.width=S.height=192;const w=S.getContext("2d");w.fillStyle="#fff5d9",w.fillRect(0,0,192,192),w.strokeStyle="#496c61",w.lineWidth=5,w.beginPath(),w.arc(96,96,84,0,Math.PI*2),w.stroke(),w.font="bold 23px sans-serif",w.textAlign="center",w.textBaseline="middle",w.fillStyle="#496c61";for(const[ae,oe,ee]of[["12",96,34],["3",160,98],["6",96,160],["9",34,98]])w.fillText(ae,oe,ee);w.lineCap="round",w.lineWidth=8,w.beginPath(),w.moveTo(96,96),w.lineTo(65,77),w.moveTo(96,96),w.lineTo(132,60),w.stroke();const V=new vr(S);V.colorSpace=vt;const k=new we(new Fn(1.14,1.14),new Bi({map:V}));k.position.set(49,4.1,-25.79),n.add(k),p.push(k)}function X(S,w,V=0){if(i({minX:S-1.4,maxX:S+1.4,minZ:w-1.4,maxZ:w+1.4,minY:0,maxY:1.5}))return;const k=(ae,oe,ee,me,R,T,B,Q=!0)=>{const j=kt({x:S,z:w,angle:V},ae,ee);m(j.x,oe,j.z,me,R,T,B,Q,V)};k(0,.48,0,2,.15,.65,v),k(0,.94,.28,2,.8,.12,v);for(const ae of[-.75,.75])k(ae,.23,0,.12,.46,.5,5992562)}for(const S of[40,58])X(S,-26,Math.PI/2);const Z=[{x:-70,z:61,w:36,d:30,subtle:!0},{x:8,z:61,w:27,d:27},...sg];for(const S of Z){const w=z.map(oe=>Wt(S.x,S.z,oe)).sort((oe,ee)=>oe.distance-ee.distance)[0].point,V=w.x-S.x,k=w.z-S.z,ae=Math.min(Math.abs(V)>1e-6?S.w/2/Math.abs(V):1/0,Math.abs(k)>1e-6?S.d/2/Math.abs(k):1/0);if(ae<1){const oe=[[w.x,w.z],[S.x+V*ae,S.z+k*ae]];z.push(oe),b(oe,2.4,14008212,.019)}m(S.x,.004,S.z,S.w,.008,S.d,S.subtle?9878134:10993279);for(const oe of[-S.w/2,S.w/2])for(const ee of[-S.d/2,S.d/2])m(S.x+oe,.18,S.z+ee,.22,.36,.22,v)}for(const S of _s){Z.push(S);const w=S.roadZ??S.z,V=S.roadX?S.z-6:S.z+(w-S.z)*.45;m(S.x,.005,S.z,S.w,.01,S.d,9878134),b(S.roadX?[[S.x+S.w/2,S.z],[S.roadX-3.3,S.z]]:[[S.x,S.z+(w>S.z?S.d/2:-S.d/2)],[S.x,w+(w>S.z?-3.3:3.3)]],2.4,12959399,.032),m(S.x-S.w/2+.4,.45,V,.12,.9,.12,v),m(S.x-S.w/2+.4,.82,V,1.2,.5,.08,4488320),_("BUILD",S.x-S.w/2+.4,.83,V+.05,0,1.1)}c=!0,Pg({box:m,bench:X,material:y,scene:n,reserved:i}),c=!1;const te={x:18,z:-101,rx:16,rz:10},ie=(S,w,V,k,ae,oe=.02)=>{const ee=new co(1,48);ee.rotateX(-Math.PI/2),ee.scale(V,1,k);const me=new we(ee,y(ae));me.position.set(S,oe,w),n.add(me)};ie(18,-101,18,12,14141609,.006),ie(18,-101,16,10,7515836,.022);for(let S=0;S<9;S++)m(18+(S%2?.3:-.3),.035,-110+S*2.25,1.25,.018,1.45,11906454,!1);X(38,-103,Math.PI/2),X(10,-116,Math.PI);const de=[];for(let S=0;S<18;S++){const w=S*.67;de.push([81+Math.cos(w)*(7+Math.floor(S/6)*4),94+Math.sin(w)*(7+Math.floor(S/6)*4)])}X(81,100),m(81,.015,97,3,.03,2,14728124);const ue=(S,w)=>!!(Math.abs(S)<32&&Math.abs(w)<32||oc.slice(0,16).some(V=>{const k=Math.abs(Math.cos(V.angle)),ae=Math.abs(Math.sin(V.angle));return Math.abs(S-V.x)<(V.w*k+V.d*ae)/2+8&&Math.abs(w-V.z)<(V.w*ae+V.d*k)/2+6})||[...C.slice(0,2),...z.slice(0,6)].some(V=>Wt(S,w,V).distance<5.2)||I.slice(0,16).some(V=>Wt(S,w,V.points).distance<3)||Z.slice(0,2).some(V=>Math.abs(S-V.x)<V.w/2+3&&Math.abs(w-V.z)<V.d/2+3)||Math.abs(S-65)<18&&Math.abs(w-46)<18||Math.abs(S-49)<17&&Math.abs(w+26)<17||Math.abs(S-18)<22&&Math.abs(w+101)<16||Math.hypot(S-81,w-94)<24);let J=73419;const se=()=>(J=Math.imul(J,1664525)+1013904223>>>0,J/4294967296),ge=[];for(let S=0;S<650;S++){const w=-118+se()*236,V=-118+se()*236;ue(w,V)||ge.some(k=>Math.hypot(k[0]-w,k[1]-V)<5)||V>-80&&se()<.42||ge.push([w,V])}for(let S=0;S<600;S++){const w=-95+se()*63,V=-121+se()*36;ue(w,V)||ge.some(k=>Math.hypot(k[0]-w,k[1]-V)<3.8)||ge.push([w,V])}for(let S=0;S<24;S++){const w=S*Math.PI*2/24,V=18+Math.cos(w)*16.8,k=-101+Math.sin(w)*10.8;Math.abs(V-18)<2||(m(V,.35,k,.055,.7,.055,5474391),m(V,.74,k,.12,.17,.12,9725511))}for(const[S,[w,V]]of[...ge,...de].entries()){if(!U(w,V))continue;o.push({x:w,z:V});const k=S>=ge.length,ae=k?2.2:2.6+S%4*.35;m(w,ae/2,V,.38,ae,.38,v,!0);const oe=!k&&V<-80&&S%3===0,ee=oe?new Mr(2.1,4.6,7):new br(1,1);oe||ee.scale(2.2,1.9,2.2);const me=new we(ee,y(oe?5082472:S%2?7052647:5933922));if(me.position.set(w,ae+.7,V),n.add(me),k)for(const R of[-1,1])m(w+R,ae+.5,V+.5,.22,.22,.22,13075044)}c=!0;const Re=Dg({scene:n,box:m,material:y,bench:X,disk:ie,roads:C,trails:z,drives:I,houses:s,treeAllowed:U,treePositions:o,clearings:Z});c=!1;for(const S of ag.filter(w=>w.id!=="home")){c=eh.some(k=>k.id===S.id);const w=S.signX??(S.id==="pond"?39:S.x+4),V=S.signZ??(S.id==="pond"?-94:S.z+4);i({minX:w-2,maxX:w+2,minZ:V-1,maxZ:V+1,minY:0,maxY:2.2})||(m(w,.9,V,.14,1.8,.14,v,!0),m(w,1.7,V,3.8,.8,.12,4488320),_(S.name.toUpperCase(),w,1.72,V+.075,0,3.6))}c=!1;for(const[S,w]of u){const V=new xs(h,y(S),w.length);w.forEach((k,ae)=>{x.position.set(k.x,k.y,k.z),x.rotation.set(0,k.angle,0),x.scale.set(k.w,k.h,k.d),x.updateMatrix(),V.setMatrixAt(ae,x.matrix)}),V.computeBoundingSphere(),n.add(V)}const Ee=new we(new Fn(st.halfSize*2,st.halfSize*2),new Bi({visible:!1}));Ee.rotation.x=-Math.PI/2,Ee.updateMatrixWorld(),n.add(Ee);const Be=Qi(d),He=ks(n,new Set([...d.map(S=>S.pivot),Ee,...p]));return{config:st,roads:C,selfJunctions:F,trails:z,clearings:Z,pond:te,ponds:[te,...ss],outerScenery:Re,staticRender:He,doorRender:Be,treeCount:o.length,treePositions:o,rooms:a,omitted:r,solids:l,doors:d,table:H,ground:Ee,road:M,drives:I,houses:s,treeAllowed:U,batches:u}}const ln=[{id:"sunbeam-county",name:"Sunbeam County",icon:"🌄",layout:3,spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"sunbeam-region",name:"Sunbeam Region",layout:2,icon:"🌳",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"sunbeam-town",name:"Sunbeam Town",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"home-square",name:"Home & Square",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"legacy-06",name:"Legacy neighbourhood",icon:"🏡",spawn:{x:-14.4,y:0,z:-1.2,yaw:0,pitch:0}},{id:"blank",name:"Blank creative",icon:"🧱",spawn:{x:0,y:0,z:8,yaw:0,pitch:0}}];function yh(n){var e;return((e=ln.find(t=>t.id===n))==null?void 0:e.layout)||1}function Ug(n,e,t=[],i=yh(e)){if(e==="sunbeam-county")return Cg(n,i);if(e==="sunbeam-region")return gh(n,i);if(e==="sunbeam-town")return mh(n);if(e==="home-square")return ph(n);if(e==="legacy-06")return Ig(n,t);const r=new we(new Fn(500,500),new _t({color:11127178}));return r.rotation.x=-Math.PI/2,n.add(r),r.updateMatrixWorld(),{ground:r,solids:[],doors:[],houses:[],rooms:[],roads:[],staticRender:{updateVisibility(){}}}}const ci=[{id:"explorer",name:"Explorer",skin:14395767,shirt:7183243,pants:11639667,hair:6638909,hat:"sun",extra:"pack"},{id:"builder",name:"Little builder",skin:12092507,shirt:15122027,pants:7179424,hair:4406066,hat:"hard",extra:"overalls"},{id:"gardener",name:"Gardener",skin:9133890,shirt:13017773,pants:6323816,hair:3945264,hat:"sun",extra:"apron"},{id:"pilot",name:"Friendly pilot",skin:12882024,shirt:8166578,pants:5860992,hair:5915959,hat:"cap",extra:"scarf"},{id:"painter",name:"Painter",skin:15188378,shirt:10849195,pants:8557967,hair:8938314,hat:"beret",extra:"apron"},{id:"sailor",name:"Sailor",skin:9726539,shirt:15327176,pants:6589853,hair:3748912,hat:"sailor",extra:"stripes"},{id:"cosy",name:"Cosy hoodie",skin:13803892,shirt:13143166,pants:7900032,hair:6310971,hat:"hood",extra:"pocket"},{id:"stargazer",name:"Stargazer",skin:11500885,shirt:7832742,pants:5991815,hair:3879985,hat:"cap",extra:"star"},{id:"sporty",name:"Park runner",skin:15054220,shirt:12158841,pants:7440277,hair:7491128,hat:"band",extra:"stripes"},{id:"rainbow",name:"Rainbow jumper",skin:9002304,shirt:11250340,pants:7637906,hair:3485227,hat:"none",extra:"rainbow"},{id:"farmer",name:"Farm friend",skin:13212272,shirt:12032370,pants:8034464,hair:5981235,hat:"sun",extra:"overalls"},{id:"blossom",name:"Blossom",skin:11435867,shirt:14203269,pants:9414033,hair:4535853,hat:"pony",extra:"skirt"}];function ws(n="explorer"){const e=ci.find(g=>g.id===n)||ci[0],t=new nt,i=new ht(1,1,1),r=new Map,s=(g,v,A,E,C,z,M)=>{r.has(M)||r.set(M,new _t({color:M}));const b=new we(i,r.get(M));return b.position.set(g,v,A),b.scale.set(E,C,z),t.add(b),b};s(0,1.43,0,.4,.4,.38,e.skin),s(0,1.65,.025,.43,.12,.4,e.hair),s(0,.93,0,.48,.55,.3,e.shirt);const a=s(-.14,.35,0,.2,.65,.24,e.pants),o=s(.14,.35,0,.2,.65,.24,e.pants),c=[s(-.34,.92,0,.16,.5,.2,e.skin),s(.34,.92,0,.16,.5,.2,e.skin)];for(const g of[-.08,.08])s(g,1.47,-.198,.045,.055,.025,4015424);if(s(0,1.35,-.198,.09,.025,.025,9069389),e.hat==="sun"&&(s(0,1.74,0,.72,.06,.62,14336653),s(0,1.82,0,.43,.16,.4,14336653)),e.hat==="hard"&&(s(0,1.72,0,.53,.07,.52,14925423),s(0,1.81,0,.45,.16,.43,14925423),s(0,1.9,0,.1,.04,.38,15914894)),(e.hat==="cap"||e.hat==="sailor")&&(s(0,1.74,0,.48,.15,.45,e.hat==="sailor"?15788757:e.pants),s(0,1.71,-.27,.48,.05,.2,e.hat==="sailor"?15788757:e.pants)),e.hat==="beret"&&s(-.04,1.78,0,.56,.15,.5,e.shirt),e.hat==="hood"&&(s(0,1.45,.2,.5,.55,.18,e.shirt),s(0,1.74,0,.5,.1,.48,e.shirt)),e.hat==="band"&&s(0,1.62,-.01,.44,.07,.42,15260088),e.hat==="pony"&&s(.2,1.45,.27,.18,.45,.2,e.hair),e.extra==="pack"){s(0,.95,.26,.4,.48,.23,12755318);for(const g of[-.18,.18])s(g,1,-.17,.06,.45,.04,12755318)}if(e.extra==="overalls"){s(0,.88,-.17,.32,.35,.04,e.pants);for(const g of[-.13,.13])s(g,1.12,-.17,.06,.25,.04,e.pants)}if(e.extra==="apron"&&s(0,.78,-.18,.4,.58,.04,14011036),e.extra==="scarf"&&(s(0,1.23,0,.46,.1,.35,14664844),s(.13,1.05,-.18,.1,.3,.05,14664844)),e.extra==="pocket"&&s(0,.83,-.18,.3,.18,.05,14263187),e.extra==="star"&&(s(0,1.02,-.18,.18,.06,.04,15783051),s(0,1.02,-.18,.06,.18,.04,15783051)),e.extra==="stripes"||e.extra==="rainbow")for(let g=0;g<4;g++)s(0,.78+g*.1,-.17,.46,.04,.035,e.extra==="rainbow"?[12879733,14531196,9219217,8495026][g]:e.pants);e.extra==="skirt"&&s(0,.59,0,.58,.35,.4,e.pants);const l=new Set([a,o,...c]),d=t.children.filter(g=>!l.has(g)),u=[],h=[],f=[],y=new N,x=new N,m=new We,p=new Set;for(const g of d){g.updateMatrix(),m.getNormalMatrix(g.matrix);const v=g.geometry.toNonIndexed(),A=v.attributes.position,E=v.attributes.normal,C=g.material.color;for(let z=0;z<A.count;z++)y.fromBufferAttribute(A,z).applyMatrix4(g.matrix),x.fromBufferAttribute(E,z).applyMatrix3(m).normalize(),u.push(y.x,y.y,y.z),h.push(x.x,x.y,x.z),f.push(C.r,C.g,C.b);p.add(g.material),v.dispose(),g.removeFromParent()}const _=new tt;_.setAttribute("position",new De(u,3)),_.setAttribute("normal",new De(h,3)),_.setAttribute("color",new De(f,3)),_.computeBoundingSphere(),t.add(new we(_,new _t({vertexColors:!0})));for(const g of p)t.children.some(v=>v.material===g)||g.dispose();return t.userData.appearance=e.id,{group:t,left:a,right:o,arms:c}}function Ng(n){const e=new Set,t=new Set;n.group.traverse(i=>{i.isMesh&&(e.add(i.geometry),t.add(i.material))}),e.forEach(i=>i.dispose()),t.forEach(i=>i.dispose()),n.group.removeFromParent()}function vh(n){let e=2166136261;for(let t=0;t<n.length;t++)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return(e>>>0).toString(16).padStart(8,"0")}function Os(n){const e=n;if(!e||![1,2,3].includes(e.schema)||!ln.some(s=>s.id===e.template)||!e.world||!e.player||!e.preferences)throw Error("Unsupported world schema or template");for(const s of["x","y","z","yaw","pitch"])if(!Number.isFinite(e.player[s]))throw Error("Invalid player position");if(Math.abs(e.player.x)>=250||Math.abs(e.player.z)>=250||e.player.y<0||e.player.y>26)throw Error("Player outside supported bounds");const t=e.world.layout??(e.template==="sunbeam-region"&&e.schema===3?2:1);if(!Number.isInteger(t)||Number(t)<1||Number(t)>(e.template==="sunbeam-county"?3:2))throw Error("Unsupported template layout");if(e.preferences.avatar!==void 0&&!ci.some(s=>s.id===e.preferences.avatar))throw Error("Unknown avatar appearance");if(e.preferences.lookSpeed!==void 0&&(typeof e.preferences.lookSpeed!="number"||![.6,1,1.4].includes(e.preferences.lookSpeed)))throw Error("Invalid look speed");if(e.preferences.leftHanded!==void 0&&typeof e.preferences.leftHanded!="boolean")throw Error("Invalid control side");for(const[s,a]of[["hotbar",8],["recent",8],["favourites",32]]){const o=e.preferences[s];if(o!==void 0&&(!Array.isArray(o)||o.length>a||o.some(c=>typeof c!="string"||!si.some(l=>l.id===c))))throw Error("Invalid catalogue preferences")}if(wg(e.world.blocks),!["hand",...si.map(s=>s.id)].includes(e.preferences.selected))throw Error("Invalid selected item");if(!e.world.doors||Array.isArray(e.world.doors)||typeof e.world.doors!="object"||Object.values(e.world.doors).some(s=>typeof s!="boolean"))throw Error("Invalid doors");const i=e.world.props;if(i!==void 0&&(!i||Array.isArray(i)||typeof i!="object"||Object.keys(i).length>256||Object.values(i).some(s=>!s||Array.isArray(s)||typeof s!="object"||Object.entries(s).some(([a,o])=>!["open","on"].includes(a)||typeof o!="boolean"))))throw Error("Invalid furniture state");const r=e.world.activity;if(r!==void 0&&(!r||!r.car||![r.car.x,r.car.z,r.car.yaw].every(Number.isFinite)||Math.abs(r.car.x)>249||Math.abs(r.car.z)>249))throw Error("Invalid vehicle checkpoint");if((r==null?void 0:r.vehicles)!==void 0&&(!Array.isArray(r.vehicles)||r.vehicles.length>2||r.vehicles.length&&e.template!=="sunbeam-county"||new Set(r.vehicles.map(s=>s.id)).size!==r.vehicles.length||r.vehicles.some(s=>!s||!["runabout","bicycle"].includes(s.id)||![s.x,s.z,s.yaw].every(Number.isFinite)||Math.abs(s.x)>249||Math.abs(s.z)>249)))throw Error("Invalid vehicle fleet checkpoint");if((r==null?void 0:r.pet)!==void 0&&(!r.pet||!["wander","follow","stay","home"].includes(r.pet.mode)||![r.pet.x,r.pet.z,r.pet.yaw].every(Number.isFinite)||Math.abs(r.pet.x)>249||Math.abs(r.pet.z)>249))throw Error("Invalid companion checkpoint");if((r==null?void 0:r.horses)!==void 0&&(!Array.isArray(r.horses)||r.horses.length>4||new Set(r.horses.map(s=>s.id)).size!==r.horses.length||r.horses.some(s=>!s||!Number.isInteger(s.id)||s.id<0||s.id>3||![s.x,s.z,s.yaw].every(Number.isFinite)||Math.abs(s.x)>249||Math.abs(s.z)>249)))throw Error("Invalid horse checkpoint");return{...structuredClone(e),world:{...structuredClone(e.world),layout:t},schema:3}}function Gi(n){const e=JSON.stringify(Os(n));return{json:e,checksum:vh(e)}}function ls(n){if(!n||typeof n.json!="string"||n.json.length>8e6||vh(n.json)!==n.checksum)throw Error("Checkpoint checksum failed");return Os(JSON.parse(n.json))}function jn(n){return Os({schema:3,template:n.template,world:{blocks:n.blocks,doors:n.doors,props:n.props||{},layout:n.layout??yh(n.template),...n.activity?{activity:n.activity}:{}},player:n.player,preferences:{selected:n.selected,avatar:n.avatar||"explorer",lookSpeed:n.lookSpeed||1,leftHanded:!!n.leftHanded,favourites:n.favourites||[],recent:n.recent||[],hotbar:n.hotbar||[],camera:n.camera||"first",flying:!!n.flying}})}function Fg(n){if(n.length>12e6)throw Error("Backup is too large");const e=JSON.parse(n);if(e.format==="blockworld2"&&e.version===1)return{snapshot:ls(e.checkpoint),...typeof e.legacySource=="string"&&e.legacySource.length<=4e6?{source:e.legacySource}:{},name:typeof e.name=="string"?e.name.slice(0,60):"Imported world"};if(n.length>4e6)throw Error("Legacy backup exceeds 4 MB");const t=ug(e);return{snapshot:Os({schema:3,template:"legacy-06",world:{blocks:t.blocks,doors:t.doors},player:t.player,preferences:{selected:t.selected}}),source:n,name:"Imported legacy neighbourhood"}}class lc extends Error{constructor(){super("This world changed in another tab. Your unsaved work is still here; export or save a new copy.")}}const ns=n=>new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error||Error("Storage request failed"))}),is=n=>new Promise((e,t)=>{n.oncomplete=()=>e(),n.onabort=()=>t(n.error||Error("Storage transaction aborted")),n.onerror=()=>{}});class Ss{constructor(e){this.db=e}static open(e="blockworld2-development"){return new Promise((t,i)=>{const r=indexedDB.open(e,1);r.onupgradeneeded=()=>{for(const s of["worlds","meta"])r.result.objectStoreNames.contains(s)||r.result.createObjectStore(s,{keyPath:s==="worlds"?"id":"key"})},r.onsuccess=()=>{r.result.onversionchange=()=>r.result.close(),t(new Ss(r.result))},r.onerror=()=>i(r.error),r.onblocked=()=>i(Error("Close another BlockWorld tab to open saves"))})}async read(e,t){const i=this.db.transaction(e,"readonly");return ns(i.objectStore(e).get(t))}async list(){const e=this.db.transaction("worlds","readonly");return ns(e.objectStore("worlds").getAll())}async last(){var e;return(e=await this.read("meta","last"))==null?void 0:e.value}async select(e){const t=this.db.transaction("meta","readwrite"),i=is(t);t.objectStore("meta").put({key:"last",value:e}),await i}async create(e,t,i){const r=Gi(t),s={id:crypto.randomUUID(),name:e.trim().slice(0,60)||"My world",template:t.template,revision:0,updated:Date.now(),current:r,previous:[],...i?{importSource:i}:{}},a=this.db.transaction("worlds","readwrite"),o=is(a);return a.objectStore("worlds").add(s),await o,s}async load(e){const t=await this.read("worlds",e);if(!t)throw Error("World was not found");try{return{record:t,snapshot:ls(t.current),recovered:!1}}catch{for(const r of t.previous||[])try{return{record:t,snapshot:ls(r),recovered:!0}}catch{}throw Error("No valid checkpoint. Original data is retained; import a backup or choose another world.")}}async save(e,t,i){const r=Gi(i),s=this.db.transaction("worlds","readwrite"),a=is(s);try{const o=s.objectStore("worlds"),c=await ns(o.get(e));if(!c)throw Error("World no longer exists");if(c.revision!==t)throw new lc;ls(c.current);const l={...c,revision:t+1,current:r,previous:[c.current,...c.previous].slice(0,3),updated:Date.now()};return o.put(l),await a,l}catch(o){try{s.abort()}catch{}throw await a.catch(()=>{}),o}}async rename(e,t,i){const r=this.db.transaction("worlds","readwrite"),s=is(r);try{const a=r.objectStore("worlds"),o=await ns(a.get(e));if(!o||o.revision!==t)throw new lc;const c={...o,name:i.trim().slice(0,60)||o.name,revision:t+1,updated:Date.now()};return a.put(c),await s,c}catch(a){try{r.abort()}catch{}throw await s.catch(()=>{}),a}}async duplicate(e){const{record:t,snapshot:i,recovered:r}=await this.load(e);if(r)throw Error("Recover this world to a new copy before duplicating");return this.create(t.name+" copy",i,t.importSource)}async import(e){const t=Fg(e);return this.create(t.name,t.snapshot,t.source)}export(e,t){return JSON.stringify({format:"blockworld2",version:1,name:e.name,...e.importSource?{legacySource:e.importSource}:{},checkpoint:t?Gi(t):e.current},null,2)}}class kg{constructor(e){this.game=e,e.paused=!0,document.querySelector("#worlds").onclick=()=>void this.menu(),e.onEdit=()=>{this.ready&&this.save().catch(()=>{})},this.init()}store;current=null;blocked=!1;ready=!1;flight=null;last="";async init(){try{this.store=await Ss.open();const e=await this.store.list(),t=await this.store.last(),i=e.find(r=>r.id===t)||e[0]||await this.store.create("My neighbourhood",jn(this.game.snapshot()));await this.open(i.id),this.ready=!0,document.dispatchEvent(new Event("bw2-save-status")),setInterval(()=>{!this.game.paused&&!document.hidden&&this.save().catch(()=>{})},1500),addEventListener("blur",()=>{this.save().catch(()=>{})}),document.addEventListener("visibilitychange",()=>{document.hidden&&this.save().catch(()=>{})})}catch(e){this.ready=!1,this.game.paused=!1,this.failure(e)}}async open(e){var r;this.flight&&await this.flight;const t=await this.store.load(e),i=t.snapshot;this.game.load(i.template,i.world.blocks,i.player,i.world.doors,i.world.activity,i.world.props,i.world.layout),this.game.setAppearance(typeof i.preferences.avatar=="string"?i.preferences.avatar:"explorer"),this.game.lookSpeed=typeof i.preferences.lookSpeed=="number"?i.preferences.lookSpeed:1,this.game.leftHanded=!!i.preferences.leftHanded,dh(this.game),this.game.selected=i.preferences.selected,this.game.favourites=Array.isArray(i.preferences.favourites)?i.preferences.favourites:[],this.game.recent=Array.isArray(i.preferences.recent)?i.preferences.recent:[],this.game.hotbar=Array.isArray(i.preferences.hotbar)?i.preferences.hotbar.slice(0,8):[],bs(this.game),this.game.cameraMode=i.preferences.camera==="third"?"third":"first",this.game.flying=!!i.preferences.flying,document.querySelector("#flightControls").hidden=!this.game.flying,this.game.refreshModes(),this.current=t.record,this.last=Gi(jn(this.game.snapshot())).json,this.blocked=t.recovered,document.dispatchEvent(new Event("bw2-save-status")),await this.store.select(e),this.game.paused=!1,t.recovered?this.failure(Error("An older checkpoint was recovered. The damaged original is retained. Save a new copy before continuing.")):((r=document.querySelector("#saveAlert"))==null||r.remove(),this.game.notice("✓ World ready · saved on this device"))}async save(){if(!this.current||!this.store)return;if(this.flight)return await this.flight,this.save();if(this.blocked)throw Error("Save blocked; export or save a new copy");let e,t;try{e=jn(this.game.snapshot()),t=Gi(e).json}catch(r){throw this.failure(r),r}if(t===this.last)return;const i=this.current;this.flight=(async()=>{try{this.current=await this.store.save(i.id,i.revision,e),this.last=t}catch(r){throw this.failure(r),r}})();try{await this.flight}finally{this.flight=null}}async newWorld(e){await this.save();const t=ln.find(s=>s.id===e),i=jn({template:e,blocks:[],doors:{},player:t.spawn,selected:"hand",avatar:this.game.appearance,lookSpeed:this.game.lookSpeed,leftHanded:this.game.leftHanded}),r=await this.store.create(t.name,i);return await this.open(r.id),this.close(),r}exportCurrent(){const e=this.current||{name:"Unsaved recovered world"},t=this.store?this.store.export(e,jn(this.game.snapshot())):JSON.stringify({format:"blockworld2",version:1,name:e.name,checkpoint:Gi(jn(this.game.snapshot()))},null,2),i=URL.createObjectURL(new Blob([t],{type:"application/json"})),r=document.createElement("a");return r.href=i,r.download="BlockWorld2-backup.bw2",r.click(),setTimeout(()=>URL.revokeObjectURL(i),6e4),t}failure(e){this.blocked=!0,document.dispatchEvent(new Event("bw2-save-status"));let t=document.querySelector("#saveAlert");t||(t=document.createElement("aside"),t.id="saveAlert",t.setAttribute("role","alert"),document.body.append(t)),t.replaceChildren();const i=document.createElement("p");i.textContent="Progress remains in memory. "+String(e),t.append(i);const r=(s,a)=>{const o=document.createElement("button");o.textContent=s,o.onclick=a,t.append(o)};r("Export unsaved work",()=>{try{this.exportCurrent()}catch(s){i.textContent=String(s)}}),r("Save as new copy",()=>{(async()=>{var a,o,c;let s;try{this.flight&&await this.flight.catch(()=>{}),s=await Ss.open();const l=await s.create((((a=this.current)==null?void 0:a.name)||"Recovered world")+" recovered",jn(this.game.snapshot()),(o=this.current)==null?void 0:o.importSource);await s.select(l.id),(c=this.store)==null||c.db.close(),this.store=s,this.current=l,this.last=l.current.json,this.blocked=!1,this.ready=!0,document.dispatchEvent(new Event("bw2-save-status")),t.remove(),this.game.notice("✓ Recovered copy saved")}catch(l){s==null||s.db.close(),i.textContent=String(l)}})()})}close(){document.querySelector("#modal").hidden=!0,this.game.paused=!1,this.game.controls.clear()}async menu(){var e;try{await this.save(),this.game.paused=!0,this.game.controls.clear(),this.game.vertical=0;const t=document.querySelector("#modal");t.hidden=!1,t.innerHTML='<section><h1>🌍 Your worlds</h1><div id="worldList"></div><h2>Create another</h2><div id="templates"></div><div class="backupActions"><button id="export">⇩ Backup</button><label class="fileButton">⇧ Import<input id="import" type="file" accept=".bw2,.json,application/json"></label><button id="resume">▶ Play</button></div><p id="worldError" role="alert"></p></section>';const i=r=>{r().catch(s=>{document.querySelector("#worldError").textContent=String(s)})};for(const r of await this.store.list()){const s=document.createElement("div");s.className="worldRow";const a=document.createElement("button");a.textContent=(r.id===((e=this.current)==null?void 0:e.id)?"▶ ":"")+r.name,a.dataset.world=r.id,a.onclick=()=>i(async()=>{await this.open(r.id),this.close()});const o=document.createElement("input");o.value=r.name,o.setAttribute("aria-label","World name");const c=document.createElement("button");c.textContent="✎",c.setAttribute("aria-label","Rename "+r.name),c.onclick=()=>i(async()=>{var u;const d=await this.store.rename(r.id,r.revision,o.value);((u=this.current)==null?void 0:u.id)===r.id&&(this.current=d),await this.menu()});const l=document.createElement("button");l.textContent="⧉",l.setAttribute("aria-label","Duplicate "+r.name),l.onclick=()=>i(async()=>{await this.store.duplicate(r.id),await this.menu()}),s.append(a,o,c,l),document.querySelector("#worldList").append(s)}for(const r of ln){const s=document.createElement("button");s.dataset.template=r.id,s.textContent=r.icon+" "+r.name,s.onclick=()=>i(()=>this.newWorld(r.id)),document.querySelector("#templates").append(s)}document.querySelector("#resume").onclick=()=>this.close(),document.querySelector("#export").onclick=()=>this.exportCurrent(),document.querySelector("#import").onchange=r=>i(async()=>{var o;const s=(o=r.target.files)==null?void 0:o[0];if(!s)return;if(s.size>12e6)throw Error("Backup exceeds 12 MB");const a=await this.store.import(await s.text());await this.open(a.id),this.close()})}catch(t){this.failure(t)}}}class Og{index=new bn(4);entries=new Map;update(e,t){const i=`${e.x},${e.y},${e.z}`;for(const r of this.entries.get(i)||[])this.index.remove(r);if(this.entries.delete(i),t){const r=Qe(e).map(s=>({...s,block:e,owner:"build:"+i}));this.entries.set(i,r);for(const s of r)this.index.add(s)}}reset(e){this.index=new bn(4),this.entries.clear();for(const t of e)this.update(t,!0)}query(e,t){return this.index.query($n(e,t))}blocksNear(e,t){return[...new Set(this.query(e,t).map(i=>i.block))]}}function Bg(){const n=new nt,e=new ht(1,1,1),t=new _t({color:7442328}),i=new _t({color:4676439}),r=(o,c,l=.065)=>{const d=new we(e,t);d.position.copy(o).add(c).multiplyScalar(.5),d.scale.set(l,o.distanceTo(c),l),d.quaternion.setFromUnitVectors(new N(0,1,0),c.clone().sub(o).normalize()),n.add(d)},s=(o,c,l)=>new N(o,c,l);for(const o of[-.65,.65]){const c=new we(new fo(.32,.06,5,16),i);c.rotation.y=Math.PI/2,c.position.set(0,.38,o),n.add(c)}r(s(0,.38,.65),s(0,.7,.1)),r(s(0,.7,.1),s(0,.42,0)),r(s(0,.42,0),s(0,.38,.65)),r(s(0,.42,0),s(0,.95,-.55)),r(s(0,.95,-.55),s(0,.7,.1)),r(s(0,.95,-.55),s(0,.38,-.65)),r(s(0,.95,-.55),s(0,1.12,-.5)),r(s(-.38,1.12,-.5),s(.38,1.12,-.5)),r(s(0,.42,0),s(0,.87,.1));const a=new we(e,i);a.position.set(0,.9,.15),a.scale.set(.34,.1,.3),n.add(a);for(const o of[-.2,.2]){const c=new we(e,i);c.position.set(o,.4,0),c.scale.set(.2,.08,.16),n.add(c)}return n}function _n(n,e=!1){const t=Math.cos(n.yaw),i=Math.sin(n.yaw),r=Math.abs(t)*.46+Math.abs(i)*1.02,s=Math.abs(i)*.46+Math.abs(t)*1.02;return{minX:n.x-r,maxX:n.x+r,minZ:n.z-s,maxZ:n.z+s,minY:.001,maxY:e?2.55:2.05,obb:{cx:n.x,cz:n.z,c:t,s:i,halfW:.46,halfD:1.02}}}function Gg(n,e,t,i,r=238){let s={...n};for(let a=0,o=Math.max(1,Math.ceil(t/.016));a<o;a++){const c=t/o,l={...s,yaw:s.yaw-e.right*c*1.55*Math.sign(e.forward||1)},d=e.forward*(e.forward<0?2:5.2);l.x-=Math.sin(l.yaw)*d*c,l.z-=Math.cos(l.yaw)*d*c,Math.abs(l.x)<r-1.1&&Math.abs(l.z)<r-1.1&&!i.some(u=>xt(_n(l,!0),u))&&(s=l)}return s}function cc(n,e){return kn({x:n.x+Math.cos(n.yaw)*1.65,z:n.z-Math.sin(n.yaw)*1.65,yaw:n.yaw},[...e,_n(n,!0)])}function Hg(n,e,t,i=160){const r=Math.round(n.x),s=Math.round(n.z),a=Math.hypot(e.x-n.x,e.z-n.z),o={x:Math.round(n.x+(e.x-n.x)*Math.min(1,12/Math.max(a,.01))),z:Math.round(n.z+(e.z-n.z)*Math.min(1,12/Math.max(a,.01)))},c=(f,y)=>`${f},${y}`,l=[{x:r,z:s,g:0}],d=new Map([[c(r,s),0]]),u=new Map;let h=0;for(;l.length&&h++<i;){l.sort((y,x)=>y.g+Math.abs(y.x-o.x)+Math.abs(y.z-o.z)-(x.g+Math.abs(x.x-o.x)+Math.abs(x.z-o.z)));const f=l.shift();if(f.x===o.x&&f.z===o.z){const y=[o];let x=c(f.x,f.z);for(;u.has(x);){const m=u.get(x);y.push(m),x=c(m.x,m.z)}return y.reverse(),y.shift(),y.length?y:null}for(const[y,x]of[[1,0],[0,1],[-1,0],[0,-1]]){const m=f.x+y,p=f.z+x,_=f.g+1;Math.abs(m-r)>14||Math.abs(p-s)>14||_>28||(d.get(c(m,p))??1/0)<=_||t(m,p)||t((m+f.x)/2,(p+f.z)/2)||(d.set(c(m,p),_),u.set(c(m,p),f),l.push({x:m,z:p,g:_}))}}return null}function Vg(n,e,t,i,r){var h,f,y,x;if(!e.length)return!1;if(n.wait>0)return n.wait=Math.max(0,n.wait-t),!1;const s=((h=n.detour)==null?void 0:h[0])||e[n.target%e.length],a=s.x-n.x,o=s.z-n.z,c=Math.hypot(a,o);if(c<.15)return(f=n.detour)!=null&&f.length?(n.detour.shift(),!1):(n.target=(n.target+1)%e.length,n.wait=.6,!1);const l=Math.min(c,i*Math.min(t,.1)),d=n.x+a/c*l,u=n.z+o/c*l;return r(d,u)?(n.stuck+=t,n.stuck>.4&&!((y=n.detour)!=null&&y.length)&&(n.replans||0)<1&&(n.replans=(n.replans||0)+1,n.detour=Hg(n,e[n.target%e.length],r)||void 0),n.stuck>2&&(n.target=(n.target+1)%e.length,n.stuck=0,n.wait=.5,n.detour=void 0,n.replans=0),!1):(n.x=d,n.z=u,n.stuck=0,(x=n.detour)!=null&&x.length||(n.replans=0),!0)}function hc(n){const e=(n%304+304)%304;return e<80?{x:-40+e,z:-36,yaw:-Math.PI/2}:e<152?{x:40,z:-36+e-80,yaw:Math.PI}:e<232?{x:40-(e-152),z:36,yaw:Math.PI/2}:{x:-40,z:36-(e-232),yaw:0}}const dc=[{x:-86,z:-82},{x:8,z:-82},{x:86,z:-82},{x:-86,z:-56},{x:8,z:-56},{x:86,z:-56},{x:-86,z:82},{x:8,z:82},{x:86,z:82}],uc=[[1,3],[0,2,4],[1,5],[0,4,6],[1,3,5,7],[2,4,8],[3,7],[4,6,8],[5,7]];class Wg{cars=[];reservations=new Map;nodes;constructor(e=86){this.nodes=e===86?dc:dc.map(t=>({x:t.x===8?8:Math.sign(t.x)*e,z:t.z===-56?-56:Math.sign(t.z)*e}));for(const[t,i]of[0,2,6,8].entries()){const r=uc[i][0],s=this.nodes[i],a=this.nodes[r],o=Math.hypot(a.x-s.x,a.z-s.z),c=(a.x-s.x)/o,l=(a.z-s.z)/o;this.cars.push({x:s.x+l*1.5,z:s.z-c*1.5,yaw:Math.atan2(-c,-l),from:i,to:r,previous:-1,visits:0,wait:t*.4,blocked:0,seed:t+1,reverse:!1})}}update(e,t){e=Math.min(e,.1);for(const[i,r]of this.reservations)Math.hypot(this.cars[r].x-this.nodes[i].x,this.cars[r].z-this.nodes[i].z)>6&&this.reservations.delete(i);for(const[i,r]of this.cars.entries()){if(r.wait>0){r.wait=Math.max(0,r.wait-e);continue}const s=this.nodes[r.from],a=this.nodes[r.to],o=Math.hypot(a.x-s.x,a.z-s.z),c=(a.x-s.x)/o,l=(a.z-s.z)/o,d=r.reverse?{x:s.x+l*1.5,z:s.z-c*1.5}:{x:a.x+l*1.5,z:a.z-c*1.5},u=Math.hypot(d.x-r.x,d.z-r.z);if(u<.12){const p=r.reverse?r.from:r.to,_=r.reverse?r.to:r.from;r.seed=r.seed*1664525+1013904223>>>0;const g=uc[p].filter(A=>A!==_),v=g[r.seed%g.length]??_;r.from=p,r.to=v,r.previous=_,r.visits++,r.reverse=!1,r.blocked=0,r.wait=r.visits%5===0?1.5:.25;continue}if(!r.reverse&&u<6){const p=this.reservations.get(r.to);if(p!==void 0&&p!==i)continue;this.reservations.set(r.to,i)}const h=2.8*e,f=r.x+(d.x-r.x)/u*Math.min(h,u),y=r.z+(d.z-r.z)/u*Math.min(h,u),x=Math.atan2(r.x-f,r.z-y),m=this.cars.some((p,_)=>_!==i&&Math.hypot(f-p.x,y-p.z)<4.8&&Math.cos(x-p.yaw)>.6&&(p.x-f)*-Math.sin(x)+(p.z-y)*-Math.cos(x)>0);if(m||t(f,y,x,i)){r.blocked+=e,r.blocked>5&&!m&&!r.reverse&&(r.reverse=!0,r.wait=.8,this.reservations.get(r.to)===i&&this.reservations.delete(r.to));continue}r.x=f,r.z=y,r.yaw=x,r.blocked=0}}}function fc(n){const e=new nt,t=new ht(1,1,1),i=[],r=n==="dog"?13019779:n==="cat"?12104869:n==="duck"?16113568:12159848,s=(a,o,c,l,d,u,h=r)=>{const f=new we(t,new _t({color:h}));return f.position.set(a,o,c),f.scale.set(l,d,u),e.add(f),f};if(n==="duck"){s(0,.35,0,.6,.45,.7),s(0,.65,-.35,.34,.35,.35),s(0,.61,-.58,.3,.12,.24,14261592);for(const a of[-.2,.2])i.push(s(a,.1,0,.13,.2,.25,14261592));s(-.34,.4,0,.12,.2,.4),s(.34,.4,0,.12,.2,.4)}else if(n==="chicken"){s(0,.3,0,.4,.45,.5,15919826),s(0,.65,-.2,.25,.3,.25,15919826),s(0,.65,-.4,.15,.1,.16,14068323),s(0,.85,-.2,.08,.15,.15,12943976);for(const a of[-.12,.12])i.push(s(a,.1,0,.06,.2,.1,14068323))}else if(n==="rabbit"){s(0,.3,0,.5,.4,.65,11841700),s(0,.55,-.3,.3,.3,.3,11841700);for(const a of[-.1,.1])s(a,.88,-.3,.09,.5,.12,11841700);for(const a of[-.2,.2])i.push(s(a,.12,.15,.18,.25,.35,14537924));s(0,.4,.4,.2,.2,.2,14537924)}else if(n==="cow"||n==="sheep"){const a=n==="cow",o=a?.9:.8,c=a?.95:.65,l=a?1.5:1.1;if(s(0,c,0,o,a?.75:.7,l,15328204),s(0,c+.15,-l*.55,.5,.5,.45,a?12823444:8550251),a){s(-.35,c+.08,.2,.22,.65,.5,8157033),s(.3,c-.1,-.25,.3,.4,.4,8157033);for(const d of[-.3,.3])s(d,c+.43,-l*.55,.12,.22,.1,14207137)}else for(const d of[-.35,0,.35])s(d,c+.4,0,.3,.3,l*.8,15788761);for(const d of[-o*.3,o*.3])for(const u of[-l*.3,l*.3])i.push(s(d,(c-.3)/2,u,.12,c-.3,.12,8550251))}else{const a=n==="horse",o=a?.95:.36,c=a?1.35:.75;s(0,o,0,a?.7:.5,a?.6:.35,c),s(0,a?1.55:.68,-c*.48,a?.4:.32,a?.6:.32,a?.65:.35);for(const l of[a?-.24:-.16,a?.24:.16])for(const d of[-c*.33,c*.33])i.push(s(l,a?.42:.15,d,.12,a?.85:.3,.12));for(const l of[-.13,.13])s(l,a?1.94:.94,-c*.48,.1,n==="dog"?.23:.18,.12,n==="dog"?9402207:r);s(0,a?1.05:.55,c*.65,.1,a?.65:.55,.12,n==="horse"?7756615:r)}if(n==="horse"){s(0,1.28,.05,.72,.12,.65,7300434),s(0,1.58,-.38,.14,.55,.14,7756615);for(const a of[-.21,.21])s(a,1.68,-.82,.045,.07,.07,4210231)}return e.userData.species=n,{group:e,limbs:i}}function Ya(n,e){const t=new hn,i=new N;if(e.obb){const s=e.obb,a=n.origin.x-s.cx,o=n.origin.z-s.cz,c=new Er(new N(a*s.c-o*s.s,n.origin.y,a*s.s+o*s.c),new N(n.direction.x*s.c-n.direction.z*s.s,n.direction.y,n.direction.x*s.s+n.direction.z*s.c));t.min.set(-s.halfW,e.minY,-s.halfD),t.max.set(s.halfW,e.maxY,s.halfD);const l=c.intersectBox(t,i);return l?c.origin.distanceTo(l):1/0}t.min.set(e.minX,e.minY,e.minZ),t.max.set(e.maxX,e.maxY,e.maxZ);const r=n.intersectBox(t,i);return r?n.origin.distanceTo(r):1/0}function Xg(n,e,t,i,r){const s=Math.max(1,Math.hypot(e.forward,e.right)),a=(-Math.sin(n.yaw)*e.forward+Math.cos(n.yaw)*e.right)*6/s,o=(-Math.cos(n.yaw)*e.forward-Math.sin(n.yaw)*e.right)*6/s,c=Math.max(1,Math.ceil(i/.01));for(let l=0;l<c;l++)for(const[d,u]of[["x",a],["z",o],["y",t*5]]){const h=n[d];n[d]=Math.max(d==="y"?0:-249,Math.min(d==="y"?24:249,h+u*i/c)),vn(n,r)&&(n[d]=h)}n.vy=0,n.grounded=n.y===0}function qg(n=14987622){const e=new nt,t=new ht(1,1,1),i=(a,o,c,l,d,u,h)=>{const f=new we(t,new _t({color:h}));return f.position.set(a,o,c),f.scale.set(l,d,u),e.add(f),f};i(0,1.43,0,.4,.4,.38,15778974),i(0,1.66,.02,.43,.12,.4,7493190),i(0,.93,0,.48,.55,.3,n);const r=i(-.14,.35,0,.2,.65,.24,5602691),s=i(.14,.35,0,.2,.65,.24,5602691);return i(-.34,.92,0,.16,.5,.2,15778974),i(.34,.92,0,.16,.5,.2,15778974),{group:e,left:r,right:s}}function Yg(n,e,t){const i=new N(e.x,e.y+1.3,e.z),r=new N(e.x+Math.sin(e.yaw)*4.5,e.y+3,e.z+Math.cos(e.yaw)*4.5),s=r.clone().sub(i).normalize(),a=new Er(i,s);let o=r.distanceTo(i);for(const c of t){const l={...c,minX:c.minX-.2,maxX:c.maxX+.2,minY:c.minY-.2,maxY:c.maxY+.2,minZ:c.minZ-.2,maxZ:c.maxZ+.2,...c.obb?{obb:{...c.obb,halfW:c.obb.halfW+.2,halfD:c.obb.halfD+.2}}:{}};o=Math.min(o,Ya(a,l)-.2)}return o=Math.max(.15,o),n.position.copy(i.addScaledVector(s,o)),n.lookAt(e.x,e.y+1.3,e.z),n.updateMatrixWorld(),o>.7}function Ta(n,e=0){const t=new nt,i=new ht(1,1,1),r=(s,a,o,c,l,d,u)=>{const h=new we(i,new _t({color:u,transparent:u===13165276,opacity:u===13165276?.35:1,depthWrite:u!==13165276}));h.position.set(s,a,o),h.scale.set(c,l,d),t.add(h)};if(r(0,.65,0,1.5,.65,3,n),r(0,1.2,e===3?-.5:0,1.25,.6,e===3?1.1:1.4,13165276),e!==2&&r(0,1.56,e===3?-.5:e===1?.3:0,1.4,.12,e===1?2.2:1.6,n),e===1&&r(0,1.15,.85,1.4,.7,1.2,n),e===2&&(r(-.4,1,0,.35,.5,.7,7432798),r(.4,1,0,.35,.5,.7,7432798)),e===3){for(const s of[-.68,.68])r(s,1,.85,.12,.35,1.2,n);r(0,1,1.4,1.4,.35,.12,n),r(0,.97,.85,.7,.35,.6,12166785)}for(const s of[-.78,.78])for(const a of[-.95,.95])r(s,.32,a,.22,.58,.58,4149581);return r(0,.65,-1.52,.9,.2,.06,16772278),t}function Zt(n){const e=Math.cos(n.yaw),t=Math.sin(n.yaw),i=n.kind==="bicycle"?.48:.8,r=n.kind==="bicycle"?1.05:1.6,s=Math.abs(e)*i+Math.abs(t)*r,a=Math.abs(t)*i+Math.abs(e)*r;return{minX:n.x-s,maxX:n.x+s,minY:0,maxY:n.kind==="bicycle"?1.8:1.7,minZ:n.z-a,maxZ:n.z+a,obb:{cx:n.x,cz:n.z,c:e,s:t,halfW:i,halfD:r}}}class jg{constructor(e,t=47,i){var c;this.range=t,this.query=i,e.add(this.group),t>200&&this.vehicles.push({id:"runabout",name:"Ranch runabout",icon:"🚙",state:{x:202,z:158,yaw:0},model:Ta(9349532,3)},{id:"bicycle",name:"Village bicycle",icon:"🚲",state:{x:80,z:-202,yaw:-Math.PI/2,kind:"bicycle"},model:Bg()}),this.group.add(...this.vehicles.map(l=>l.model));const r=[[[26,8],[22,10],[12,10],[12,6],[22,6]],[[12,6],[17,6],[24,9],[17,10]],[[56,-12],[56,-20.6],[58,-20.6],[56,-12]],[[56,0],[56,9],[58,5.4]],[[14,32],[29,32],[25,31]],[[-9,16],[-9,22],[-2,22],[3,16]]],s=(l,d,u,h,f,y=0)=>{const x=d.map(([p,_])=>({x:p,z:_})),m={...x[y%x.length],target:(y+1)%x.length,wait:0,stuck:0};l.position.set(m.x,0,m.z),this.group.add(l),this.agents.push({model:l,route:x,state:m,phase:this.agents.length*.4,animal:u,limbs:h,greetUntil:0,species:f})};for(let l=0;l<(t>200?16:t>100?12:t>47?6:4);l++){const d=t>100?ws(ci[l%ci.length].id):qg([14260858,9088931,14139254,9545917,11705009,12171142][l%6]),u=[[[-91,-75],[-91,-30],[-94,-12],[-91,-30]],[[-80,-88],[-40,-88],[0,-88],[-40,-88]],[[91,-45],[91,0],[100,14],[91,0]],[[91,45],[91,70],[70,88],[91,70]],[[-91,55],[-91,85],[-70,88],[-91,85]],[[20,88],[50,88],[70,98],[50,88]]];s(d.group,t>200&&l>=12?[[[-120,-205],[-40,-205],[-120,-205]],[[-205,80],[-205,130],[-205,80]],[[204,90],[204,170],[204,90]],[[40,204],[140,204],[40,204]]][l-12]:t>100&&l>=6?u[l-6]:r[t>47?l:l%2],!1,[d.left,d.right],void 0,t<=47?Math.floor(l/2):0)}const a=t>100?["dog","cat","duck","horse","cow","sheep","chicken","rabbit"]:t>47?["dog","cat","duck","horse"]:["cat","duck"],o={cow:[[-83,130],[-78,130],[-78,137],[-83,137]],sheep:[[-69,130],[-63,130],[-63,138],[-69,138]],chicken:[[-61,117],[-56,117],[-56,120],[-61,120]],rabbit:[[48,119],[52,119],[52,124],[48,124]],dog:[[14,17],[22,17],[22,20],[14,20]],cat:[[-12,-5],[-8,-5],[-8,0],[-12,0]],duck:[[28,24],[32,24],[32,27],[28,27]],horse:[[-54,42],[-48,42],[-48,47],[-54,47]]};t>100&&(o.duck=[[87,-112],[87,-121],[88,-125],[87,-121]]);for(const l of a){const d=fc(l);s(d.group,o[l],!0,d.limbs,l)}if(t>200){const l=fc("horse");s(l.group,[[173,137],[173,141],[160,141],[160,133]],!0,l.limbs,"horse")}t>100&&(this.roadTraffic=new Wg(t>200?210:86));for(let l=0;l<(this.roadTraffic?4:2);l++){const d=Ta([12156781,8628132,13218174,9480629][l],l%3);this.traffic.push(d);const u=((c=this.roadTraffic)==null?void 0:c.cars[l])||hc(this.progress[l]);d.position.set(u.x,0,u.z),d.rotation.y=u.yaw,this.group.add(d)}this.sync()}group=new nt;vehicles=[{id:"buggy",name:"Buggy",icon:"🚗",state:{x:-28,z:-2,yaw:0},model:Ta(15119462)}];activeVehicle=0;get car(){return this.vehicles[this.activeVehicle].state}set car(e){this.vehicles[this.activeVehicle].state={x:e.x,z:e.z,yaw:e.yaw,...this.vehicles[this.activeVehicle].id==="bicycle"?{kind:"bicycle"}:{}}}get vehicle(){return this.vehicles[this.activeVehicle].model}get vehicleKind(){return this.vehicles[this.activeVehicle].id}vehicleEntry=null;vehicleSolids(e=-1){return this.vehicles.filter((t,i)=>i!==e).map(t=>Zt(t.state))}driving=!1;riding=null;rideEntry=null;get controlled(){return this.driving||!!this.riding}stop(){this.driving=!1,this.riding=null}petMode="wander";petElapsed=0;petGoal=null;get pet(){return this.agents.find(e=>e.species==="dog")}setPetMode(e){this.petMode=e,this.petGoal=null;const t=this.pet;t&&(t.state.wait=0,t.state.stuck=0,t.state.detour=void 0,t.state.replans=0,t.greetUntil=0)}time=0;agents=[];traffic=[];progress=[0,152];roadTraffic=null;sync(){for(const e of this.vehicles)e.model.position.set(e.state.x,0,e.state.z),e.model.rotation.y=e.state.yaw}load(e){if(this.activeVehicle=0,e!=null&&e.car){const t=e.car;if(![t.x,t.z,t.yaw].every(Number.isFinite)||Math.abs(t.x)>249||Math.abs(t.z)>249)throw Error("Invalid saved car");this.car={...t}}if(e!=null&&e.vehicles)for(const t of e.vehicles){const i=this.vehicles.find(r=>r.id===t.id);i&&(i.state={x:t.x,z:t.z,yaw:t.yaw,...i.id==="bicycle"?{kind:"bicycle"}:{}})}if(e!=null&&e.horses)for(const t of e.horses){const i=this.agents.filter(r=>r.species==="horse")[t.id];i&&(i.state.x=t.x,i.state.z=t.z,i.model.position.set(t.x,0,t.z),i.model.rotation.y=t.yaw)}e!=null&&e.pet&&this.pet&&(this.petMode=e.pet.mode,this.pet.state.x=e.pet.x,this.pet.state.z=e.pet.z,this.pet.model.position.set(e.pet.x,0,e.pet.z),this.pet.model.rotation.y=e.pet.yaw),this.stop(),this.sync()}snapshot(){return{car:{...this.vehicles[0].state},vehicles:this.vehicles.slice(1).map(e=>({id:e.id,x:e.state.x,z:e.state.z,yaw:e.state.yaw})),...this.pet?{pet:{mode:this.petMode,x:this.pet.state.x,z:this.pet.state.z,yaw:this.pet.model.rotation.y}}:{},horses:this.agents.filter(e=>e.species==="horse").map((e,t)=>({id:t,x:e.state.x,z:e.state.z,yaw:e.model.rotation.y}))}}resolveHorses(){var e;for(const[t,i]of this.vehicles.entries()){const r=a=>{var o;return![...((o=this.query)==null?void 0:o.call(this,a,3))||[],...this.vehicleSolids(t)].some(c=>xt(Zt(a),c))};if(r(i.state))continue;let s=!1;for(let a=1;a<=12&&!s;a++)for(let o=-a;o<=a&&!s;o++)for(let c=-a;c<=a&&!s;c++){if(Math.abs(o)!==a&&Math.abs(c)!==a)continue;const l={...i.state,x:i.state.x+o,z:i.state.z+c};Math.abs(l.x)<this.range-2&&Math.abs(l.z)<this.range-2&&r(l)&&(i.state=l,s=!0)}}if(this.sync(),this.pet){const t=this.pet,i=((e=this.query)==null?void 0:e.call(this,t.state,15))||[],r={minX:t.state.x-.22,maxX:t.state.x+.22,minZ:t.state.z-.22,maxZ:t.state.z+.22,minY:.001,maxY:.95};if(i.some(s=>xt(r,s)))try{const s=kn(t.state,i);t.state.x=s.x,t.state.z=s.z,t.model.position.set(s.x,0,s.z)}catch{t.state.wait=1}}for(const t of this.agents.filter(i=>i.species==="horse")){const i=this.horsePose(t),r=a=>{var o;return![...((o=this.query)==null?void 0:o.call(this,a,2))||[],...this.vehicleSolids()].some(c=>xt(_n(a),c))};if(r(i))continue;let s=!1;for(let a=1;a<=12&&!s;a++)for(let o=-a;o<=a&&!s;o++)for(let c=-a;c<=a&&!s;c++){if(Math.abs(o)!==a&&Math.abs(c)!==a)continue;const l={...i,x:i.x+o,z:i.z+c};Math.abs(l.x)<this.range-1&&Math.abs(l.z)<this.range-1&&r(l)&&(t.state.x=l.x,t.state.z=l.z,t.model.position.set(l.x,0,l.z),s=!0)}}}horsePose(e){return{x:e.state.x,z:e.state.z,yaw:e.model.rotation.y}}entitySolids(e=!1){return[...this.vehicleSolids(e&&this.driving?this.activeVehicle:-1),...this.agents.filter(t=>t.species==="horse"&&!(e&&t===this.riding)).map(t=>_n(this.horsePose(t),t===this.riding))]}mount(e,t,i){if(e.species!=="horse"||Math.abs(t.y)>.5||Math.hypot(t.x-e.state.x,t.z-e.state.z)>2.5)return"Walk beside the horse to ride";const r=this.horsePose(e);return[...i,...this.vehicleSolids(),...this.agents.filter(a=>a.species==="horse"&&a!==e).map(a=>_n(this.horsePose(a)))].some(a=>xt(_n(r,!0),a))?"🐴 Lead the horse to an open space":(this.rideEntry={...t},this.riding=e,this.driving=!1,Object.assign(t,{x:r.x,y:.8,z:r.z,yaw:r.yaw,vy:0,grounded:!0}),"🐴 Ride with the stick · tap Use to walk")}dismount(e,t){if(!this.riding)return;const i=cc(this.horsePose(this.riding),[...t,...this.vehicleSolids(),...this.agents.filter(r=>r.species==="horse"&&r!==this.riding).map(r=>_n(this.horsePose(r)))]);return this.riding.state.wait=2,Object.assign(e,i),this.riding=null,"♡ Horse parked · ready to walk"}savedPlayer(e){var t,i;if(this.driving)try{return kn({x:this.car.x+Math.cos(this.car.yaw)*2,z:this.car.z-Math.sin(this.car.yaw)*2,yaw:this.car.yaw},[...((t=this.query)==null?void 0:t.call(this,this.car,15))||[],...this.entitySolids()])}catch{return this.vehicleEntry||e}if(!this.riding)return e;try{const r=this.horsePose(this.riding);return cc(r,[...((i=this.query)==null?void 0:i.call(this,r,15))||[],...this.vehicleSolids()])}catch{return this.rideEntry}}use(e,t,i){if(this.driving){const s=kn({x:this.car.x+Math.cos(this.car.yaw)*2,z:this.car.z-Math.sin(this.car.yaw)*2,yaw:this.car.yaw},[...t,Zt(this.car)]);return Object.assign(e,s),this.driving=!1,"✓ Parked — ready to walk"}if(i!==void 0&&this.vehicles[i]&&(this.activeVehicle=i),Math.abs(e.y)<2&&Math.hypot(e.x-this.car.x,e.z-this.car.z)<3)return this.vehicleEntry={...e},this.driving=!0,e.y=0,this.sync(),"🚗 Drive with the stick · tap Use to leave";const r=this.agents.find(s=>Math.hypot(s.model.position.x-e.x,s.model.position.z-e.z)<2.5);return r&&Math.abs(e.y)<2?(r.greetUntil=this.time+2,r.model.rotation.y=Math.atan2(e.x-r.state.x,e.z-r.state.z),r.animal?`♡ Hello, ${r.species}!`:"👋 Hello, neighbour!"):null}update(e,t,i,r){var a,o,c;if(this.time+=e,this.riding){const l=this.riding,d=this.horsePose(l),u=Gg(d,i,e,[...((a=this.query)==null?void 0:a.call(this,d,3))||r,...this.vehicleSolids(),...this.traffic.map(f=>Zt({x:f.position.x,z:f.position.z,yaw:f.rotation.y})),...this.agents.filter(f=>f.species==="horse"&&f!==l).map(f=>_n(this.horsePose(f)))],Math.max(82,this.range)),h=Math.hypot(u.x-d.x,u.z-d.z)>1e-4;l.state.x=u.x,l.state.z=u.z,l.model.position.set(u.x,0,u.z),l.model.rotation.y=u.yaw,l.model.visible=!0,l.limbs.forEach((f,y)=>f.rotation.x=h?Math.sin(this.time*9+(y%2?Math.PI:0))*.35:0),Object.assign(t,{x:u.x,y:.8,z:u.z,yaw:u.yaw,vy:0,grounded:!0})}if(this.driving){const l={...this.car,yaw:this.car.yaw-i.right*e*1.3*Math.sign(i.forward||1)},d=i.forward*(this.vehicleKind==="bicycle"?4.5:this.vehicleKind==="runabout"?5.2:6);l.x-=Math.sin(l.yaw)*d*e,l.z-=Math.cos(l.yaw)*d*e,Math.abs(l.x)<this.range&&Math.abs(l.z)<this.range&&![...((o=this.query)==null?void 0:o.call(this,l,3))||r,...this.vehicleSolids(this.activeVehicle),...this.agents.filter(u=>u.species==="horse").map(u=>_n(this.horsePose(u))),...this.traffic.map(u=>Zt({x:u.position.x,z:u.position.z,yaw:u.rotation.y}))].some(u=>xt(Zt(l),u))&&(this.car=l),Object.assign(t,{x:this.car.x,y:0,z:this.car.z,yaw:this.car.yaw,vy:0,grounded:!0}),this.sync()}const s=this.vehicleSolids();for(const l of this.vehicles)l.model.visible=Math.hypot(l.state.x-t.x,l.state.z-t.z)<130;for(const l of this.agents){if(l===this.riding)continue;const d=Math.hypot(l.state.x-t.x,l.state.z-t.z),u=l.species==="dog"&&this.petMode!=="wander";if(l.model.visible=d<105,d>80&&!u)continue;let h=e;if(u&&d>80){if(this.petElapsed+=e,this.petElapsed<.1)continue;h=Math.min(.1,this.petElapsed),this.petElapsed=0}const f=u?this.petMode==="follow"?{x:t.x+(l.state.x-t.x)*2.1/Math.max(d,.01),z:t.z+(l.state.z-t.z)*2.1/Math.max(d,.01)}:l.route[0]:null;u&&(!this.petGoal||Math.hypot(f.x-this.petGoal.x,f.z-this.petGoal.z)>3)&&(this.petGoal={...f},l.state.detour=void 0,l.state.target=0,l.state.stuck=0,l.state.wait=0);const y=(_,g)=>{var v;return Math.hypot(_-t.x,g-t.z)<.8||this.agents.some(A=>A!==l&&Math.hypot(_-A.state.x,g-A.state.z)<.65)||[...((v=this.query)==null?void 0:v.call(this,{x:_,y:0,z:g},1.2))||r,...s,...this.traffic.map(A=>Zt({x:A.position.x,z:A.position.z,yaw:A.rotation.y}))].some(A=>{const E=l.species==="horse"||l.species==="cow"?.4:l.animal?.22:.28,C=l.species==="horse"?2:l.species==="cow"?1.5:l.animal?.95:1.65;return xt({minX:_-E,maxX:_+E,minZ:g-E,maxZ:g+E,minY:.001,maxY:C},A)})},x={x:l.state.x,z:l.state.z};let m=!1;const p=l.state.target;this.time>=l.greetUntil&&(!u||this.petMode!=="stay"&&(this.petMode==="follow"?d>2.4:Math.hypot(f.x-l.state.x,f.z-l.state.z)>.2))&&(m=Vg(l.state,u?[f]:l.route,h,u?3.4:l.animal?.65:1,y)),p!==l.state.target&&(l.state.wait=l.animal?2:1),l.model.position.set(l.state.x,m&&l.species==="rabbit"?Math.abs(Math.sin(this.time*6))*.15:0,l.state.z),m&&(l.model.rotation.y=Math.atan2(-(l.state.x-x.x),-(l.state.z-x.z))),l.limbs.forEach((_,g)=>_.rotation.x=m?Math.sin(this.time*5+l.phase+(g%2?Math.PI:0))*.2:0)}if(this.roadTraffic){this.roadTraffic.update(e,(l,d,u,h)=>{var f;return Math.hypot(l-t.x,d-t.z)<3||this.agents.some(y=>Math.hypot(l-y.state.x,d-y.state.z)<2)||[...((f=this.query)==null?void 0:f.call(this,{x:l,y:0,z:d},3))||r,...s,...this.roadTraffic.cars.filter((y,x)=>x!==h).map(Zt)].some(y=>xt(Zt({x:l,z:d,yaw:u}),y))}),this.roadTraffic.cars.forEach((l,d)=>{this.traffic[d].position.set(l.x,0,l.z),this.traffic[d].rotation.y=l.yaw});return}for(let l=0;l<this.traffic.length;l++){const d=(this.progress[l]+e*2)%304,u=hc(d),h=Zt(u),f=this.traffic.filter((x,m)=>m!==l).map(x=>Zt({x:x.position.x,z:x.position.z,yaw:x.rotation.y}));!this.progress.some((x,m)=>m!==l&&(x-d+304)%304<6)&&Math.hypot(u.x-t.x,u.z-t.z)>3&&!this.agents.some(x=>Math.hypot(x.state.x-u.x,x.state.z-u.z)<2.5)&&![...((c=this.query)==null?void 0:c.call(this,u,3))||r,...s,...f].some(x=>xt(h,x))&&(this.progress[l]=d,this.traffic[l].position.set(u.x,0,u.z),this.traffic[l].rotation.y=u.yaw)}}dispose(){const e=new Set,t=new Set;this.group.traverse(i=>{i.isMesh&&(e.add(i.geometry),t.add(i.material))}),e.forEach(i=>i.dispose()),t.forEach(i=>i.dispose()),this.group.removeFromParent()}}const Aa=new Map;function Zg(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section class="wardrobe"><h1>👤 Choose your look</h1><div id="avatarGrid"></div><button id="closeWardrobe">▶ Play</button></section>';let t=!0;const i=[];for(const s of ci){const a=document.createElement("button");a.dataset.avatar=s.id,a.setAttribute("aria-label","Wear "+s.name),a.setAttribute("aria-pressed",String(n.appearance===s.id));const o=document.createElement("img");o.alt=s.name,o.width=112,o.height=96;const c=document.createElement("span");c.textContent=s.name,a.append(o,c),a.onclick=()=>{n.setAppearance(s.id),n.onEdit(),document.querySelectorAll("[data-avatar]").forEach(l=>l.setAttribute("aria-pressed",String(l.dataset.avatar===s.id)))},document.querySelector("#avatarGrid").append(a),i.push(()=>{if(t){if(!Aa.has(s.id)){const l=ws(s.id).group;l.rotation.y=Math.PI,Aa.set(s.id,hh(l,!0))}o.src=Aa.get(s.id)}})}const r=()=>{var s;t&&((s=i.shift())==null||s(),i.length&&requestAnimationFrame(r))};requestAnimationFrame(r),document.querySelector("#closeWardrobe").onclick=()=>{t=!1,e.hidden=!0,n.paused=!1,n.controls.clear()}}function Kg(n){var r;if(!((r=n.activity)==null?void 0:r.pet))return;n.paused=!0,n.controls.clear(),n.vertical=0;const t=document.querySelector("#modal");t.hidden=!1,t.innerHTML='<section><h1>🐕 Your friend</h1><p style="font-size:72px;margin:8px">🐕 ♡</p><div id="petChoices"></div><button id="closePet">▶ Play</button></section>';const i=()=>{t.hidden=!0,n.paused=!1,n.controls.clear()};for(const[s,a,o]of[["follow","🐾","Follow"],["stay","✋","Stay"],["home","⌂","Home"]]){const c=document.createElement("button");c.dataset.petMode=s,c.textContent=a+" "+o,c.setAttribute("aria-pressed",String(n.activity.petMode===s)),c.onclick=()=>{n.activity.setPetMode(s),n.onEdit(),i(),n.notice("🐕 "+a+" "+o)},document.querySelector("#petChoices").append(c)}document.querySelector("#closePet").onclick=i}function $g(n){var f,y;const e=document.querySelector("#modal");n.paused=!0,n.controls.clear(),n.vertical=0,e.hidden=!1,e.innerHTML='<section><h1>🗺 Let’s explore</h1><canvas id="mapCanvas" width="560" height="420" aria-label="Drag map; choose a landmark to travel"></canvas><div id="mapPlaces"></div><div><button id="zoomIn" aria-label="Zoom in">＋</button><button id="zoomOut" aria-label="Zoom out">−</button><button id="closeMap">▶ Play</button></div><p id="mapMessage">Drag to look around. Choose a picture to travel.</p></section>';const t=document.querySelector("#mapCanvas"),i=t.getContext("2d");let r=n.template==="sunbeam-county"?.9:n.template==="sunbeam-region"?1.4:n.template==="sunbeam-town"?2.7:n.template==="home-square"?4:.8,s=280,a=210,o=null;const c=()=>{i.fillStyle="#c4d39e",i.fillRect(0,0,560,420),i.save(),i.translate(s,a),i.scale(r,r),i.fillStyle="#859995",i.fillStyle="#81b8c6";for(const x of n.world.waterAreas||[])i.fillRect(x.x-x.w/2,x.z-x.d/2,x.w,x.d);if(i.fillStyle="#859995",n.world.mapRoads)for(const x of n.world.mapRoads)i.fillRect(x.x-x.w/2,x.z-x.d/2,x.w,x.d);else if(n.template==="home-square"){for(const x of[-36,4,36])i.fillRect(-43,x-3,86,6);for(const x of[-40,8,40])i.fillRect(x-3,-39,6,78)}for(const x of n.world.houses)i.fillStyle="#b88361",i.save(),i.translate(x.x,x.z),i.rotate(-(x.angle||0)),i.fillRect(-x.w/2,-x.d/2,x.w,x.d),i.restore();i.fillStyle="#edb447",i.beginPath(),i.arc(n.player.x,n.player.z,2,0,Math.PI*2),i.fill(),i.restore()};c(),t.onpointerdown=x=>{t.setPointerCapture(x.pointerId),o={x:x.clientX,y:x.clientY}},t.onpointermove=x=>{if(!o)return;const m=t.getBoundingClientRect();s+=(x.clientX-o.x)*560/m.width,a+=(x.clientY-o.y)*420/m.height,o={x:x.clientX,y:x.clientY},c()},t.onpointerup=t.onpointercancel=()=>{o=null},document.querySelector("#zoomIn").onclick=()=>{r=Math.min(10,r*1.3),c()},document.querySelector("#zoomOut").onclick=()=>{r=Math.max(.3,r/1.3),c()};const l=()=>{e.hidden=!0,n.paused=!1,n.controls.clear()};document.querySelector("#closeMap").onclick=l;const d=n.world.landmarks||[{name:"Home",icon:"⌂",x:n.template==="blank"?0:-14.4,z:n.template==="blank"?8:-1.2}],u=(f=n.activity)==null?void 0:f.pet,h=((y=n.activity)==null?void 0:y.vehicles.map(x=>({name:x.name,icon:x.icon,x:x.state.x,z:x.state.z})))||[];for(const x of[...d,...h,...u?[{name:"Your dog",icon:"🐕",x:u.state.x,z:u.state.z}]:[]]){const m=document.createElement("button");m.textContent=x.icon+" "+x.name,m.dataset.place=x.name,m.onclick=()=>{try{if(!n.endFlight())return;const p=kn(x,[...n.obstacles(),...n.commands.blocks.flatMap(Qe)]);n.endPlay(!1),Object.assign(n.player,p),n.seated=null,n.flying=!1,n.activity&&n.activity.stop(),n.vertical=0,n.refreshModes(),n.cancel(),n.onEdit(),l()}catch(p){document.querySelector("#mapMessage").textContent=String(p)}},document.querySelector("#mapPlaces").append(m)}}function Jg(n,e,t){return e.filter(i=>Math.abs(i.y-n.y)<1.8&&Math.hypot(i.x-n.x,i.z-n.z)<i.range).sort((i,r)=>Math.hypot(i.x-n.x,i.z-n.z)-Math.hypot(r.x-n.x,r.z-n.z)).find(t)}const pc=new Set(["swing","seesaw","bounce","slide","rock"]);function ja(n){return n==="slide"?1.8:4}function Ra(n,e,t){const i=(e.rotation||0)*Math.PI/180,r=Math.min(t/ja(n),1);let s=0,a=0,o=.3,c=i;return n==="slide"&&(a=-.65+r*1.3,o=1-r,c+=Math.PI),n==="swing"&&(a=Math.sin(t*2)*.65,o=.3+(1-Math.cos(t*2))*.18),n==="seesaw"&&(s=1.2,o=.4+Math.sin(t*2)*.2),n==="bounce"&&(o=.5+Math.abs(Math.sin(r*Math.PI*3))*.85),n==="rock"&&(o=.2+Math.sin(t*3)*.04),{x:e.x+.5+s*Math.cos(i)+a*Math.sin(i),y:e.y+o,z:e.z+.5-s*Math.sin(i)+a*Math.cos(i),yaw:c}}function Mh(n){const e=n.model.parent;n.model.traverse(t=>{t.isMesh&&t.material.dispose()}),n.model.removeFromParent(),n.model=li(n.block),e==null||e.add(n.model)}function mc(n,e){if(n.authoredProps){for(const t of n.authoredProps)e!=null&&e[t.id]&&(Object.assign(t.block,e[t.id]),Mh(t));n.solids=[...n.staticSolids,...n.authoredProps.flatMap(t=>Qe(t.block).map(i=>({...i,owner:"prop:"+t.id})))]}}function Qg(n){return Object.fromEntries((n.authoredProps||[]).map(e=>[e.id,{...e.block.open!==void 0?{open:e.block.open}:{},...e.block.on!==void 0?{on:e.block.on}:{}}]))}function e1(n){const e=new ao({canvas:n,antialias:!1,powerPreference:"low-power"});e.setPixelRatio(Math.min(devicePixelRatio,1.25)),e.outputColorSpace=vt;const t=new qc;t.background=new Ke("#badbdc"),t.fog=new oo("#badbdc",70,155),t.add(new Zc(16774620,6720624,2.2));const i=new $c(16770744,1.8);i.position.set(-30,50,20),t.add(i);const r=new Xt(67,1,.06,180);r.rotation.order="YXZ";function s(){e.setSize(innerWidth,innerHeight),r.aspect=innerWidth/innerHeight,r.updateProjectionMatrix()}return s(),addEventListener("resize",s),{renderer:e,scene:t,camera:r,dispose(){removeEventListener("resize",s),e.dispose()}}}class t1{constructor(e=1/60,t=5){this.step=e,this.maxSteps=t}previous=0;accumulator=0;reset(e){this.previous=e,this.accumulator=0}tick(e,t){const i=Math.max(0,Math.min(.1,(e-this.previous)/1e3));this.previous=e,this.accumulator=Math.min(this.accumulator+i,this.step*this.maxSteps);let r=0;for(;this.accumulator+1e-9>=this.step&&r<this.maxSteps;)t(this.step),this.accumulator-=this.step,r++;return r}}function n1(n,e){let t=null,i=null;const r=()=>{clearTimeout(i),i=null};function s(){var a;r(),t=null,(a=e.onIndicator)==null||a.call(e,null)}n.addEventListener("pointerdown",a=>{var o;if(t){s();return}e.canStart()&&(a.preventDefault(),n.setPointerCapture(a.pointerId),t={id:a.pointerId,x:a.clientX,y:a.clientY,lastX:a.clientX,lastY:a.clientY,drag:!1,held:!1},(o=e.onStart)==null||o.call(e,t),i=setTimeout(()=>{var c;!t||t.drag||(t.held=!0,(c=e.onIndicator)==null||c.call(e,null),e.onHold(t.x,t.y))},550))}),n.addEventListener("pointermove",a=>{var l;if(!t||a.pointerId!==t.id)return;const o=a.clientX-t.lastX,c=a.clientY-t.lastY;!t.drag&&Math.hypot(a.clientX-t.x,a.clientY-t.y)>10?(t.drag=!0,r(),(l=e.onIndicator)==null||l.call(e,null),e.onLook(a.clientX-t.x,a.clientY-t.y)):t.drag&&e.onLook(o,c),t.lastX=a.clientX,t.lastY=a.clientY}),n.addEventListener("pointerup",a=>{var c;if(!t||a.pointerId!==t.id)return;const o=t;s(),!o.drag&&!o.held&&e.onTap(o.x,o.y),(c=e.onEnd)==null||c.call(e)});for(const a of["pointercancel","lostpointercapture"])n.addEventListener(a,o=>{(t==null?void 0:t.id)===o.pointerId&&s()});return n.addEventListener("contextmenu",a=>a.preventDefault()),{cancel:s}}function i1(n=document){const e=new Map;let t=!1,i=0;n.addEventListener("pointerdown",r=>{var a,o;i=0;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button");(r.pointerType==="touch"||r.pointerType==="pen")&&s&&!s.disabled&&e.set(r.pointerId,{button:s,x:r.clientX,y:r.clientY,moved:!1})},!0),n.addEventListener("keydown",()=>{i=0},!0),n.addEventListener("pointermove",r=>{const s=e.get(r.pointerId);s&&Math.hypot(r.clientX-s.x,r.clientY-s.y)>10&&(s.moved=!0)},!0),n.addEventListener("pointercancel",r=>{e.has(r.pointerId)&&(i=performance.now()+900),e.delete(r.pointerId)},!0),n.addEventListener("pointerup",r=>{var a,o;const s=e.get(r.pointerId);if(e.delete(r.pointerId),(r.pointerType==="touch"||r.pointerType==="pen")&&((o=(a=r.target).closest)!=null&&o.call(a,"#world"))&&(i=performance.now()+900),!!s&&(i=performance.now()+900,!s.moved&&!s.button.disabled&&s.button.isConnected!==!1)){r.preventDefault(),t=!0;try{s.button.click()}finally{t=!1}}},!0),n.addEventListener("click",r=>{var a,o;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button,summary,.file-button");!t&&s&&performance.now()<i&&(r.preventDefault(),r.stopImmediatePropagation())},!0)}class r1{stick={x:0,y:0};keys=new Set;pointer=null;gestures;constructor(e,t,i){i1();let r=null;this.gestures=n1(e,{canStart:t,onStart:()=>{r=i.pose?{...i.pose()}:null},onTap:i.tap,onHold:(o,c)=>{var d;const l=(d=i.pose)==null?void 0:d.call(i);r&&l&&(Math.hypot(l.x-r.x,l.y-r.y,l.z-r.z)>.08||Math.abs(l.yaw-r.yaw)+Math.abs(l.pitch-r.pitch)>.01)||i.hold(o,c)},onLook:i.look});const s=document.querySelector("#joystick"),a=o=>{const c=s.getBoundingClientRect(),l=o.clientX-c.left-c.width/2,d=o.clientY-c.top-c.height/2,u=Math.max(1,Math.hypot(l,d)/40);this.stick={x:l/u/40,y:d/u/40},document.querySelector("#knob").style.transform=`translate(${this.stick.x*36}px,${this.stick.y*36}px)`};s.addEventListener("pointerdown",o=>{!t()||this.pointer!==null||(o.preventDefault(),this.pointer=o.pointerId,s.setPointerCapture(o.pointerId),a(o))}),s.addEventListener("pointermove",o=>{this.pointer===o.pointerId&&a(o)});for(const o of["pointerup","pointercancel","lostpointercapture"])s.addEventListener(o,c=>{this.pointer===c.pointerId&&this.clear()});addEventListener("keydown",o=>{var c;(c=o.target)!=null&&c.matches("input,textarea,select")||!t()&&o.code!=="Escape"||(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(o.code)&&o.preventDefault(),this.keys.add(o.code),o.repeat||i.action(o.code))}),addEventListener("keyup",o=>this.keys.delete(o.code)),addEventListener("blur",()=>this.clear()),document.addEventListener("visibilitychange",()=>this.clear())}clear(){var t;this.keys.clear(),this.pointer=null,this.stick={x:0,y:0},(t=this.gestures)==null||t.cancel();const e=document.querySelector("#knob");e&&(e.style.transform="")}movement(){return{forward:+(this.keys.has("KeyW")||this.keys.has("ArrowUp"))-+(this.keys.has("KeyS")||this.keys.has("ArrowDown"))-this.stick.y,right:+(this.keys.has("KeyD")||this.keys.has("ArrowRight"))-+(this.keys.has("KeyA")||this.keys.has("ArrowLeft"))+this.stick.x}}}const jt=n=>`${n.x},${n.y},${n.z}`;class Ca{constructor(e,t,i,r=()=>{}){this.obstacles=e,this.player=t,this.changed=i,this.completed=r}blocks=[];past=[];future=[];reason(e,t=!0,i){return rc(e,this.blocks.filter(r=>!i||jt(r)!==jt(i)),this.obstacles(),this.player(),t)}apply(e,t,i=!1,r=!1){const s=t?e.before:e.after,a=t?e.after:e.before,o=new Set(s.map(jt));if(s.some(l=>!this.blocks.some(d=>jt(d)===jt(l))))return"The original object changed";const c=this.blocks.filter(l=>!o.has(jt(l)));for(const l of a){if(c.some(d=>jt(d)===jt(l)))return"Find a clear space";if(i){const d=rc(l,c,this.obstacles(),this.player(),r);if(d)return d}else if(Qe(l).some(d=>xt(d,ji(this.player()))||[...this.obstacles(),...c.flatMap(Qe)].some(u=>xt(d,u))))return"That space is occupied";c.push({...l})}return this.blocks.splice(0,this.blocks.length,...c),""}notify(e,t){for(const i of t?e.before:e.after)this.changed(i,!1);for(const i of t?e.after:e.before)this.changed(i,!0);this.completed()}execute(e,t,i=!0){const r=this.apply(e,!0,i,t);return r||(this.past.push(structuredClone(e)),this.past.length>100&&this.past.shift(),this.future=[],this.notify(e,!0),"")}place(e,t=!0){return this.execute({before:[],after:[{...e}]},t)}placeMany(e,t=!0){return this.execute({before:[],after:e.map(i=>({...i}))},t)}move(e,t,i=!0){return this.execute({before:[{...e}],after:[{...t}]},i)}toggle(e){const t=zt.get(e.type);if((t==null?void 0:t.interaction)==="door"||(t==null?void 0:t.interaction)==="cabinet"){const i=[...this.obstacles(),...this.blocks.filter(r=>jt(r)!==jt(e)).flatMap(r=>Qe(r)),ji(this.player())];for(let r=0;r<=12;r++){const s=(e.open?1:0)+(e.open?-1:1)*r/12;if(pg(e,s).some(a=>i.some(o=>xt(a,o))))return"Door swing blocked — make a little room"}}return this.execute({before:[{...e}],after:[{...e,...(t==null?void 0:t.interaction)==="light"?{on:e.on===!1}:{open:!e.open}}]},!1,!1)}remove(e){const t=this.blocks.find(i=>jt(i)===jt(e));return!!t&&this.execute({before:[{...t}],after:[]},!1)===""}undo(){const e=this.past.at(-1);return!e||this.apply(e,!1)?!1:(this.past.pop(),this.future.push(e),this.notify(e,!1),!0)}redo(){const e=this.future.at(-1);return!e||this.apply(e,!0)?!1:(this.future.pop(),this.past.push(e),this.notify(e,!0),!0)}reset(e){this.blocks.splice(0,this.blocks.length,...e.map(t=>({...t}))),this.past=[],this.future=[]}get canUndo(){return!!this.past.length}get canRedo(){return!!this.future.length}}const Zi=Math.PI/2,s1=Zi/.65,a1=2.25,o1=3.1,l1=1.2;function bh(n){if(n.kind==="roller"){const e=Math.max(0,Math.min(1,n.angle/Zi));n.leaf.scale.y=Math.max(.001,1-e),n.leaf.position.y=e*n.height,n.pivot.rotation.y=n.baseAngle}else n.pivot.rotation.y=n.baseAngle+n.angle}function c1(n,e=!1,t=-1){n.kind==="roller"&&(t=1),Object.assign(n,{open:e,targetOpen:e,swing:t,angle:e?t*Zi:0,leaveSince:null,manualHold:!1,lastAttempt:-1/0,blocked:!1}),bh(n)}function gc(n,e,t){return Math.abs(e.y)<2.3&&Math.hypot(e.x-n.center.x,e.z-n.center.z)<t}function Za(n,e,t,i,r,s){const a=Math.max(1,Math.ceil(Math.abs(t-e)/.02)),o=[rh(i),...r.map(ei),...s];for(let c=0;c<=a;c++){const l=_h(n,e+(t-e)*c/a);if(o.some(d=>qi(l,d)))return!1}return!0}function Ka(n,e,t,i,r=[],s=!1){const a=n.angle??(n.open?(n.swing??-1)*Zi:0);if(e){const o=(t.x-n.center.x)*Math.sin(n.baseAngle)+(t.z-n.center.z)*Math.cos(n.baseAngle),c=n.kind==="roller"?1:Math.abs(a)>.01?n.swing??-1:o>=0?1:-1;for(const l of Math.abs(a)>.01?[c]:[c,-c])if(Za(n,a,l*Zi,t,i,r))return n.swing=l,n.targetOpen=n.open=!0,n.manualHold=s,n.blocked=!1,{ok:!0}}else if(Za(n,a,0,t,i,r))return n.targetOpen=n.open=!1,n.manualHold=s,n.blocked=!1,{ok:!0};return{ok:!1,message:e?"There is something in the door’s swing. Make room beside it.":"The door stays open while someone or something is in its way."}}function h1(n,e,t,i,r,s,a,o=null,c="normal"){const l=a1*nh(c)/3.4,d=Math.max(o1,l+.85);let u=!1;for(const h of n){let f;const y=()=>f??=(o==null?void 0:o(h))??{blocks:t,solids:i},x=gc(h,e,d);x?h.leaveSince=null:(h.leaveSince??=s,h.manualHold=!1),r&&!h.manualHold&&s-h.lastAttempt>.3&&(gc(h,e,l)&&!h.targetOpen?(h.lastAttempt=s,Ka(h,!0,e,y().blocks,y().solids)):!x&&h.targetOpen&&s-h.leaveSince>l1&&(h.lastAttempt=s,Ka(h,!1,e,y().blocks,y().solids)));let p=(h.targetOpen?h.swing*Zi:0)-h.angle;const _=Math.sign(p)*Math.min(Math.abs(p),Math.max(0,a)*s1),g=Math.max(1,Math.ceil(Math.abs(_)/.02));for(let v=0;v<g&&Math.abs(_)>1e-8;v++){const A=h.angle+_/g;if(!Za(h,h.angle,A,e,y().blocks,y().solids)){h.blocked=!0,h.targetOpen||(h.targetOpen=h.open=!0,h.manualHold=!1,h.leaveSince=null);break}h.angle=A,h.blocked=!1,u=!0}bh(h)}return u}const d1=h1;class u1{activity=null;seated=null;playing=null;contextTime=0;appearance="explorer";body=ws();lookSpeed=1;leftHanded=!1;lightPool=[];dirtyBuilds=[];gait=0;walkAmount=0;cameraMode="first";flying=!1;vertical=0;view;world;worldGroup=new nt;buildGroup=new nt;preview=new nt;player={...ln[0].spawn,vy:0,grounded:!0};selected="hand";favourites=[];recent=[];hotbar=[];repeatCount=1;pending=null;moving=null;pickingMove=!1;automatic=!0;guard=!0;paused=!1;template="legacy-06";controls;commands;chunks;index=new bn;builds=new Og;clock=new t1;ray=new Qm;geometry=new ht(1,1,1);materials={};decor=new Map;noticeTimer=0;onEdit=()=>{};constructor(){document.querySelector("#app").innerHTML='<canvas id="world" tabindex="-1" aria-label="Drag to look; tap to build; hold to remove"></canvas><div class="brand">BLOCKWORLD <b>2.0</b><small>Sunbeam Town · Development preview</small></div><nav id="top"><button id="home" aria-label="Return home">⌂</button><button id="doorMode" aria-label="Automatic doors" aria-pressed="true">🚪 Auto</button><button id="guard" aria-label="Edge protection" aria-pressed="true">🛡</button><button id="cameraMode" aria-label="Switch camera">👤</button><button id="flyMode" aria-label="Creative flight" aria-pressed="false">🪽</button><button id="mapButton" aria-label="World map">🗺</button><button id="catalogueButton" aria-label="Building catalogue">▦</button><button id="avatarButton" aria-label="Choose avatar">👕</button><button id="controlsButton" aria-label="Control settings">🎮</button><button id="worlds" aria-label="Worlds">🌍</button></nav><output id="status" role="status" aria-live="polite">Starting…</output><div id="crosshair">+</div><div id="joystick" aria-label="Move joystick"><div id="knob"></div></div><div id="actions"><button id="use" aria-label="Use nearby object">🚪</button><button id="undo" aria-label="Undo">↶</button><button id="redo" aria-label="Redo">↷</button><button id="jump" aria-label="Jump">↑</button></div><div id="palette" aria-label="Building hotbar"></div><button id="moveObject" aria-label="Move a built object">✥ Move</button><div id="flightControls" hidden><button id="flyUp" aria-label="Fly up">⇧</button><button id="flyDown" aria-label="Fly down">⇩</button></div><div id="previewControls" hidden><button id="cancel" aria-label="Cancel placement">✕</button><button id="lower" aria-label="Lower preview">⇩</button><button id="raise" aria-label="Raise preview">⇧</button><button id="rotate" aria-label="Rotate preview">↻</button><button id="confirm" aria-label="Confirm placement">✓</button></div><div id="modal" hidden></div>',this.view=e1(document.querySelector("#world")),this.view.scene.add(this.worldGroup,this.buildGroup,this.preview,this.body.group);for(let e=0;e<3;e++){const t=new $m(16768917,0,8,2);this.lightPool.push(t),this.view.scene.add(t)}for(const e of hi)this.materials[e.id]=new _t({color:e.color});this.chunks=new xg(this.buildGroup,this.geometry,this.materials,e=>(this.decor.has(e)||this.decor.set(e,new _t({color:e})),this.decor.get(e))),this.commands=new Ca(()=>this.obstacles(),()=>this.player,(e,t)=>{this.dirtyBuilds.push({block:e,present:t}),this.builds.update(e,t)},()=>{this.chunks.updateMany(this.dirtyBuilds.splice(0)),this.refreshHistory(),this.onEdit()}),this.load("sunbeam-county"),this.controls=new r1(document.querySelector("#world"),()=>!this.paused,{tap:(e,t)=>this.tap(e,t),hold:(e,t)=>this.removeAt(e,t),look:(e,t)=>{this.player.yaw-=e*.004*this.lookSpeed,this.player.pitch=Math.max(-1.3,Math.min(1.3,this.player.pitch-t*.0035*this.lookSpeed))},action:e=>this.key(e),pose:()=>this.player}),this.ui(),this.clock.reset(performance.now()),requestAnimationFrame(e=>this.frame(e)),this.notice("Ready · choose a picture to build")}load(e,t=[],i,r={},s,a,o){var u,h,f,y;const c=new nt,l=Ug(c,e,t,o),d=new bn;mc(l,a);for(const x of l.solids)d.add(x);if(t.some(x=>{var m;return[...d.query(Ms(x)),...((m=l.dynamicSolids)==null?void 0:m.call(l))||[]].some(p=>Qe(x).some(_=>xt(_,p.ramp?{...p,ramp:null}:p)))}))throw this.clearGroup(c),Error("Saved objects overlap permanent structures; active progress is unchanged");if((e==="home-square"||e==="sunbeam-town"||e==="sunbeam-region"||e==="sunbeam-county")&&(s!=null&&s.car)&&[s.car,...(s.vehicles||[]).map(x=>({...x,...x.id==="bicycle"?{kind:"bicycle"}:{}}))].some(x=>{var m;return[...l.solids,...((m=l.dynamicSolids)==null?void 0:m.call(l))||[],...t.flatMap(Qe)].some(p=>xt(Zt(x),p))}))throw this.clearGroup(c),Error("Saved vehicle overlaps structures; active world is retained");this.endPlay(!1),this.seated=null,(u=this.activity)==null||u.dispose(),this.activity=null,this.flying=!1,this.vertical=0,this.clearGroup(this.worldGroup);for(const x of[...c.children])this.worldGroup.add(x);this.chunks.clear(),this.template=e,document.querySelector(".brand small").textContent=`${(h=ln.find(x=>x.id===e))==null?void 0:h.name} · Development preview`,this.world=l,this.index=d,(e==="home-square"||e==="sunbeam-town"||e==="sunbeam-region"||e==="sunbeam-county")&&(this.activity=new jg(this.view.scene,this.world.activityRange||47,(x,m)=>this.querySolids(x,m)),this.activity.load(s));for(const x of this.world.doors)c1(x,r[x.id]===!0,-1);this.player={...((f=ln.find(x=>x.id===e))==null?void 0:f.spawn)||ln[0].spawn,...i,vy:0,grounded:!0},this.commands.reset(t),this.builds.reset(t),(y=this.activity)==null||y.resolveHorses(),this.chunks.reset(t),this.cancel(),vn(this.player,this.nearbySolids())&&this.home(),this.refreshHistory(),this.updateCamera()}clearGroup(e){const t=new Set,i=new Set,r=new Set;e.traverse(s=>{if(s.isSprite&&(i.add(s.material),s.material.map&&r.add(s.material.map)),s.isMesh){s.userData.sharedGeometry||t.add(s.geometry);for(const a of Array.isArray(s.material)?s.material:[s.material])i.add(a),a.map&&!a.map.userData.shared&&r.add(a.map);s.isInstancedMesh&&s.dispose()}}),t.forEach(s=>s.dispose()),i.forEach(s=>s.dispose()),r.forEach(s=>s.dispose()),e.clear()}obstacles(){var e,t,i;return[...this.world.solids,...((t=(e=this.world).dynamicSolids)==null?void 0:t.call(e))||[],...this.waterHazards(),...this.world.doors.map(r=>Pn(r)),...((i=this.activity)==null?void 0:i.entitySolids())||[]]}waterHazards(){return(this.world.waterAreas||[]).map(e=>({minX:e.x-e.w/2,maxX:e.x+e.w/2,minZ:e.z-e.d/2,maxZ:e.z+e.d/2,minY:0,maxY:.08}))}querySolids(e,t){var i,r;return[...this.index.query($n(e,t)),...(((r=(i=this.world).dynamicSolids)==null?void 0:r.call(i))||[]).filter(s=>s.minX<e.x+t&&s.maxX>e.x-t&&s.minZ<e.z+t&&s.maxZ>e.z-t),...this.builds.query(e,t),...this.world.doors.filter(s=>Math.hypot(s.center.x-e.x,s.center.z-e.z)<t+3).map(s=>Pn(s)),...this.waterHazards().filter(s=>s.minX<e.x+t&&s.maxX>e.x-t&&s.minZ<e.z+t&&s.maxZ>e.z-t)]}nearbySolids(){var e,t,i;return[...((e=this.activity)==null?void 0:e.entitySolids(!0))||[],...((i=(t=this.world).dynamicSolids)==null?void 0:i.call(t))||[],...this.index.query($n(this.player,3)),...this.builds.query(this.player,3),...this.world.doors.filter(r=>Math.hypot(r.center.x-this.player.x,r.center.z-this.player.z)<6).map(r=>Pn(r))]}update(e){var a,o,c,l,d,u;if(d1(this.world.doors,this.player,this.commands.blocks,this.world.solids,this.automatic,performance.now()/1e3,e,h=>{var f;return{solids:[...this.index.query($n({...h.center,y:0},4)),...((f=this.activity)==null?void 0:f.entitySolids())||[],...this.builds.query({...h.center,y:0},4).map(y=>y.ramp?{...y,ramp:null}:y)],blocks:[]}}),(a=this.world.aircraft)!=null&&a.passenger){const h=this.world.aircraft.update(e,this.player,(f,y)=>{var x;return[...this.querySolids(f,y),...((x=this.activity)==null?void 0:x.entitySolids())||[]]});(o=this.activity)==null||o.update(e,this.player,{forward:0,right:0},[]),h&&(this.notice(h),this.controls.clear(),this.refreshModes(),this.onEdit());return}const t=this.controls.movement(),i=this.nearbySolids(),r=[];if(this.walkAmount=Math.min(1,Math.hypot(t.forward,t.right)),this.gait+=e*this.walkAmount*6,this.contextTime+=e,this.contextTime>.2&&(this.contextTime=0,this.refreshModes(),this.refreshLights()),this.playing){Math.abs(t.forward)+Math.abs(t.right)>.2?this.endPlay():(this.playing.elapsed+=e,Object.assign(this.player,Ra(this.playing.kind,this.playing.block,this.playing.elapsed)),this.animatePlay(),this.playing.elapsed>=ja(this.playing.kind)&&this.endPlay()),(c=this.activity)==null||c.update(e,this.player,{forward:0,right:0},r);return}this.seated&&Math.abs(t.forward)+Math.abs(t.right)>.2&&this.stand(),!((l=this.activity)!=null&&l.controlled)&&!this.seated&&(this.flying?Xg(this.player,t,this.vertical+ +this.controls.keys.has("Space")-+(this.controls.keys.has("ShiftLeft")||this.controls.keys.has("ShiftRight")),e,i):bg(this.player,{...t,edgeProtection:this.guard,walkSpeed:"normal"},e,i)),(d=this.activity)==null||d.update(e,this.player,t,r);const s=(this.world.waterAreas||[]).find(h=>Math.abs(this.player.x-h.x)<h.w/2&&Math.abs(this.player.z-h.z)<h.d/2);s&&!this.flying&&!((u=this.activity)!=null&&u.controlled)&&this.player.y<.25&&(Object.assign(this.player,kn(s.shore,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)])),this.notice("💧 Back to the lakeside path"))}refreshLights(){const e=[...this.builds.blocksNear(this.player,12),...(this.world.authoredProps||[]).map(t=>t.block)].filter(t=>{var i;return((i=zt.get(t.type))==null?void 0:i.interaction)==="light"&&t.on!==!1&&Math.hypot(t.x-this.player.x,t.z-this.player.z)<12}).sort((t,i)=>Math.hypot(t.x-this.player.x,t.z-this.player.z)-Math.hypot(i.x-this.player.x,i.z-this.player.z));this.lightPool.forEach((t,i)=>{const r=e[i];t.intensity=r?2.5:0,r&&t.position.set(r.x+.5,Ms(r).maxY-.1,r.z+.5)})}frame(e){if(requestAnimationFrame(t=>this.frame(t)),this.paused||document.hidden){this.clock.reset(e);return}this.clock.tick(e,t=>this.update(t)),this.updateCamera(),this.world.staticRender.updateVisibility(this.view.camera,155),this.view.renderer.render(this.view.scene,this.view.camera)}updateCamera(){var t,i,r,s,a,o,c,l,d;this.body.group.scale.setScalar((t=this.activity)!=null&&t.driving?this.activity.vehicleKind==="bicycle"?1:.72:(i=this.activity)!=null&&i.riding?.82:1),this.body.group.position.set(this.player.x,(r=this.activity)!=null&&r.driving?.22:this.seated?this.seated.height-.65:this.player.y,this.player.z);const e=this.seated||this.playing||((s=this.activity)==null?void 0:s.controlled)||((a=this.world.aircraft)==null?void 0:a.passenger);if(this.body.left.rotation.x=e?-1.2:Math.sin(this.gait)*.25*this.walkAmount,this.body.right.rotation.x=e?-1.2:-Math.sin(this.gait)*.25*this.walkAmount,this.body.arms.forEach((u,h)=>{var f;return u.rotation.x=(f=this.activity)!=null&&f.driving?-1:e?-.1:Math.sin(this.gait+(h?Math.PI:0))*.2*this.walkAmount}),this.body.group.rotation.y=(o=this.world.aircraft)!=null&&o.passenger?this.world.aircraft.pose.yaw:this.player.yaw,this.body.group.visible=!1,this.cameraMode==="third"&&((c=this.world.aircraft)!=null&&c.passenger)){const u=this.world.aircraft.pose;this.body.group.visible=!0,this.view.camera.position.set(u.x+Math.sin(this.player.yaw)*16,u.y+7,u.z+Math.cos(this.player.yaw)*16),this.view.camera.lookAt(u.x,u.y+1.5,u.z),this.view.camera.updateMatrixWorld()}else this.cameraMode==="third"?this.body.group.visible=Yg(this.view.camera,this.player,[...this.index.query($n(this.player,8)),...((d=(l=this.world).dynamicSolids)==null?void 0:d.call(l))||[],...this.world.doors.map(u=>Pn(u)),...this.builds.query(this.player,8)]):(this.view.camera.position.set(this.player.x,this.seated?this.seated.height+.9:this.player.y+1.53,this.player.z),this.view.camera.rotation.set(this.player.pitch,this.player.yaw,0),this.view.camera.updateMatrixWorld())}hit(e=innerWidth/2,t=innerHeight/2){var o,c,l;this.updateCamera(),this.view.scene.updateMatrixWorld(!0),this.ray.setFromCamera(new Oe(e/innerWidth*2-1,1-t/innerHeight*2),this.view.camera);const i=this.ray.intersectObjects([...this.chunks.rayMeshes(),this.world.ground],!1)[0];if(!i||i.distance>8)return null;for(const d of[...this.index.query($n(this.player,9)),...this.world.doors.map(u=>Pn(u))])if(Ya(this.ray.ray,d)<i.distance-.02)return null;const r=i.object.userData,s=((o=r.faceBlocks)==null?void 0:o[i.faceIndex])||((c=r.blocks)==null?void 0:c[i.instanceId])||r.block;let a;if(s){const d=i.face.normal.clone().transformDirection(i.object.matrixWorld);if(i.object.isInstancedMesh){const h=new et;i.object.getMatrixAt(i.instanceId,h),d.copy(i.face.normal).transformDirection(h).transformDirection(i.object.matrixWorld)}const u=i.point.clone().addScaledVector(d,.015);if(a={x:Math.floor(u.x),y:d.y>.9?Math.ceil(i.point.y*100-1e-5)/100:d.y<-.9?Math.floor(i.point.y)-1:s.y,z:Math.floor(u.z),type:this.selected},!((l=zt.get(s.type))!=null&&l.cube)){const h=["x","y","z"].sort((f,y)=>Math.abs(d[y])-Math.abs(d[f]))[0];h!=="y"?(a={...s,type:this.selected},a[h]+=Math.sign(d[h])):d.y<0&&(a.y=Math.floor(i.point.y)-1)}}else a={x:Math.floor(i.point.x),y:0,z:Math.floor(i.point.z),type:this.selected};return{target:s,aim:a}}tap(e,t){var a,o,c,l;if(this.paused)return;if(this.playing){this.notice("Tap Use to finish playing");return}if((a=this.activity)!=null&&a.controlled||(o=this.world.aircraft)!=null&&o.passenger){this.notice("Walk before building");return}const i=this.hit(e,t);if(this.pickingMove){if(!(i!=null&&i.target)){this.notice("Tap an object you built");return}this.moving={...i.target},this.pending={...i.target},this.pickingMove=!1,this.showPreview(),this.notice("Tap its new spot, turn it, then confirm");return}if(this.moving&&i){this.pending={...i.aim,type:this.moving.type,rotation:((c=this.pending)==null?void 0:c.rotation)||0},this.showPreview();return}if(this.selected==="hand"){this.use();return}const r=i;if(!r){this.notice("Move closer to a clear space");return}const s=this.placementReason(r.aim);if(s){this.notice(s);return}!((l=zt.get(this.selected))!=null&&l.cube)||this.repeatCount>1?(this.pending={...r.aim,rotation:0},this.showPreview()):this.notice(this.commands.place(r.aim)||"✓ Placed")}removeAt(e,t){var r,s;if((r=this.activity)!=null&&r.controlled||(s=this.world.aircraft)!=null&&s.passenger||this.paused||this.playing)return;const i=this.hit(e,t);i!=null&&i.target&&(this.cancel(),this.commands.remove(i.target),this.notice("↶ Removed — Undo brings it back"))}showPreview(){if(this.preview.traverse(e=>{e.isMesh&&e.material.dispose()}),this.preview.clear(),!!this.pending){for(const e of this.planned(this.pending))this.preview.add(li(e,!0));document.querySelector("#previewControls").hidden=!1,document.querySelector("#confirm").disabled=!!this.placementReason(this.pending)}}cancel(){this.pending=null,this.moving=null,this.pickingMove=!1,this.preview.traverse(t=>{t.isMesh&&t.material.dispose()}),this.preview.clear();const e=document.querySelector("#previewControls");e&&(e.hidden=!0)}confirm(){var t,i;if((t=this.activity)!=null&&t.controlled||(i=this.world.aircraft)!=null&&i.passenger){this.notice("Walk before building");return}if(!this.pending)return;const e=this.placementReason(this.pending)||(this.moving?this.commands.move(this.moving,this.pending):this.commands.placeMany(this.planned(this.pending),!1));e?this.notice(e):(this.cancel(),this.notice("✓ Placed"))}stand(){if(!this.seated)return!0;try{return Object.assign(this.player,qa(this.seated.entry,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)])),this.seated=null,this.refreshModes(),this.onEdit(),!0}catch(e){return this.notice(String(e)),!1}}contextTarget(){const e=[],t=(i,r={})=>{var a;const s=(a=zt.get(i.type))==null?void 0:a.interaction;s&&e.push({id:r.prop?"prop:"+r.prop.id:`build:${i.x},${i.y},${i.z}`,kind:"object",x:i.x+.5,y:i.y,z:i.z+.5,range:2.5,icon:s==="light"?"💡":s==="seat"?"🪑":pc.has(s)?"🛝":"🚪",label:zt.get(i.type).label,data:{block:i,...r}})};for(const i of this.builds.blocksNear(this.player,3))Math.abs(i.x-this.player.x)<3&&Math.abs(i.z-this.player.z)<3&&t(i,{built:!0});for(const i of this.world.authoredProps||[])t(i.block,{prop:i});for(const i of this.world.activities||[])t(i,{static:!0});for(const[i,r]of(this.world.seats||[]).entries())e.push({id:"seat:"+i,kind:"seat",x:r.x,y:r.y||0,z:r.z,range:2,icon:"🪑",label:"Sit",data:r});for(const i of this.world.doors)e.push({id:"door:"+i.id,kind:"door",x:i.center.x,y:0,z:i.center.z,range:3.2,icon:"🚪",label:"Door",data:i});if(this.activity){for(const[i,r]of this.activity.vehicles.entries())e.push({id:"vehicle:"+i,kind:"vehicle",x:r.state.x,y:0,z:r.state.z,range:3,icon:r.icon,label:r.name,data:{index:i}});for(const[i,r]of this.activity.agents.entries())e.push({id:"agent:"+i,kind:"agent",x:r.state.x,y:0,z:r.state.z,range:2.5,icon:r.species==="horse"?"🐴":r.animal?"🐾":"👋",label:r.species||"Neighbour",data:r})}return this.world.aircraft&&!this.world.aircraft.passenger&&e.push(this.world.aircraft.target()),Jg(this.player,e,i=>{var d,u,h;const r=new N(this.player.x,this.player.y+1.3,this.player.z),s=new N(i.x,i.y+1.2,i.z),a=r.distanceTo(s),o=new Er(r,s.sub(r).normalize()),c=i.kind==="object"?Qe(i.data.block):[];return![...((u=(d=this.world).dynamicSolids)==null?void 0:u.call(d))||[],...this.index.query($n(this.player,4)).filter(f=>f.owner!==i.id&&!c.some(y=>["minX","maxX","minY","maxY","minZ","maxZ"].every(x=>Math.abs(y[x]-f[x])<1e-5))),...this.world.doors.filter(f=>i.id!=="door:"+f.id).map(f=>Pn(f)),...this.commands.blocks.filter(f=>i.id!==`build:${f.x},${f.y},${f.z}`&&Math.abs(f.x-this.player.x)<4&&Math.abs(f.z-this.player.z)<4).flatMap(Qe),...((h=this.activity)==null?void 0:h.vehicleSolids(i.kind==="vehicle"?i.data.index:-1))||[]].some(f=>Ya(o,f)<a-.2)})}sit(e){this.seated={entry:{...this.player},height:(e.y||0)+.4},Object.assign(this.player,{x:e.x,y:e.y||0,z:e.z,yaw:(e.rotation||0)*Math.PI/180,vy:0,grounded:!0}),this.flying=!1,this.vertical=0,this.controls.clear(),this.refreshModes(),this.notice("🪑 Sitting · move or tap Use to stand"),this.onEdit()}startPlay(e,t){var c;const i=t.block,r={...this.player},s=Qe(i),a=[...this.world.solids.filter(l=>{var d;return l.owner!=="prop:"+((d=t.prop)==null?void 0:d.id)&&!s.some(u=>["minX","maxX","minY","maxY","minZ","maxZ"].every(h=>Math.abs(u[h]-l[h])<1e-5))}),...this.world.doors.map(l=>Pn(l)),...this.commands.blocks.filter(l=>l.x!==i.x||l.y!==i.y||l.z!==i.z).flatMap(Qe)];for(let l=0;l<=24;l++)if(vn(Ra(e,i,ja(e)*l/24),a)){this.notice("Leave a little space around the play equipment");return}let o=null;t.static||(o=li(i),o.children.forEach(l=>l.userData.basePosition=l.position.clone()),this.view.scene.add(o),t.built&&this.chunks.update(i,!1),t.prop&&(t.prop.model.visible=!1)),this.playing={kind:e,block:{...i},entry:r,elapsed:0,model:o,built:!!t.built,original:(c=t.prop)==null?void 0:c.model},this.flying=!1,this.vertical=0,this.controls.clear(),Object.assign(this.player,Ra(e,i,0)),this.refreshModes(),this.notice("🛝 Playing · tap Use or move to finish"),this.onEdit()}animatePlay(){const e=this.playing;if(!(e!=null&&e.model))return;const t=Math.sin(e.elapsed*2);e.kind==="swing"&&e.model.children.slice(3).forEach(i=>{const r=i.userData.basePosition;i.position.z=r.z+t*.4}),e.kind==="seesaw"&&e.model.children.slice(1).forEach(i=>{const r=i.userData.basePosition;i.position.y=r.y+r.x*t*.17,i.rotation.z=t*.17}),e.kind==="rock"&&(e.model.rotation.x=t*.08)}endPlay(e=!0){var i,r,s;const t=this.playing;if(!t)return!0;if(e)try{Object.assign(this.player,qa(t.entry,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)]))}catch(a){return this.notice(String(a)),!1}return(i=t.model)==null||i.traverse(a=>{a.isMesh&&a.material.dispose()}),(r=t.model)==null||r.removeFromParent(),t.built&&this.chunks.update(t.block,!0),t.original&&(t.original.visible=!0),this.playing=null,(s=this.controls)==null||s.clear(),this.refreshModes(),e&&this.onEdit(),!0}use(){var e,t,i,r,s;if((e=this.world.aircraft)!=null&&e.passenger){this.endFlight();return}if(this.playing){this.endPlay();return}if(this.seated){this.stand();return}try{if((t=this.activity)!=null&&t.riding){this.notice(this.activity.dismount(this.player,[...this.querySolids(this.player,15)])||""),this.controls.clear(),this.refreshModes(),this.onEdit();return}if((i=this.activity)!=null&&i.driving){this.notice(this.activity.use(this.player,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)])||""),this.controls.clear(),this.refreshModes(),this.onEdit();return}const a=this.contextTarget();if(!a){this.notice("Walk closer to something to use");return}if(a.kind==="object"){const{block:o,prop:c}=a.data,l=zt.get(o.type).interaction;if(pc.has(l)){this.startPlay(l,a.data);return}if(l==="seat"){this.sit({x:o.x+.5,y:o.y,z:o.z+.5,rotation:o.rotation});return}if(c){const d=new Ca(()=>{var h;return[...this.world.solids.filter(f=>f.owner!=="prop:"+c.id),...this.world.doors.map(f=>Pn(f)),...this.commands.blocks.flatMap(Qe),...((h=this.activity)==null?void 0:h.entitySolids())||[]]},()=>this.player,()=>{});d.reset([o]);const u=d.toggle(d.blocks[0]);if(u){this.notice(u);return}c.block={...d.blocks[0]},Mh(c),mc(this.world),this.index=new bn;for(const h of this.world.solids)this.index.add(h);this.onEdit(),this.notice("✓ Used")}else this.notice(this.commands.toggle(o)||"✓ Used")}else if(a.kind==="aircraft"){if((r=this.activity)!=null&&r.controlled)return;this.world.aircraft.board(this.player),this.flying=!1,this.vertical=0,this.cancel(),this.controls.clear(),this.refreshModes(),this.notice("✈ Scenic flight · Use to return safely"),this.onEdit()}else if(a.kind==="seat")this.sit(a.data);else if(a.kind==="agent"){const o=a.data;if(o.species==="horse"){this.notice(this.activity.mount(o,this.player,this.querySolids(o.state,4))),this.activity.riding&&(this.flying=!1,this.vertical=0,this.cancel()),this.controls.clear(),this.refreshModes(),this.onEdit();return}if(o.species==="dog"){Kg(this);return}o.greetUntil=this.activity.time+2,o.model.rotation.y=Math.atan2(this.player.x-o.state.x,this.player.z-o.state.z),this.notice(o.animal?`♡ Hello, ${o.species}!`:"👋 Hello, neighbour!")}else if(a.kind==="vehicle")this.notice(this.activity.use(this.player,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)],a.data.index)||""),this.flying=!1,this.vertical=0,this.controls.clear(),this.refreshModes(),this.onEdit();else{const o=a.data,c=Ka(o,!o.targetOpen,this.player,[],[...this.world.solids,...this.commands.blocks.flatMap(Qe).map(l=>l.ramp?{...l,ramp:null}:l),...((s=this.activity)==null?void 0:s.entitySolids())||[]],!0);this.notice(c.ok?"🚪 Door":c.message||"Clear the doorway"),this.onEdit()}}catch(a){this.notice(String(a))}}endFlight(){var e;if(!((e=this.world.aircraft)!=null&&e.passenger))return!0;try{return this.world.aircraft.returnToPark(this.player,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)]),this.controls.clear(),this.refreshModes(),this.notice("✈ Back at the airfield"),this.onEdit(),!0}catch(t){return this.notice(String(t)),!1}}home(){var e,t;this.endFlight()&&(this.endPlay(!1),Object.assign(this.player,kn(((e=ln.find(i=>i.id===this.template))==null?void 0:e.spawn)||ln[0].spawn,[...this.obstacles(),...this.commands.blocks.flatMap(Qe)])),this.seated=null,this.flying=!1,this.activity&&this.activity.stop(),this.vertical=0,this.refreshModes(),(t=this.controls)==null||t.clear(),this.cancel())}jump(){var e,t;if((e=this.world.aircraft)!=null&&e.passenger){this.endFlight();return}if(this.playing){this.endPlay();return}if(this.seated){this.stand();return}!this.paused&&!this.flying&&!((t=this.activity)!=null&&t.controlled)&&this.player.grounded&&(this.player.vy=6,this.player.grounded=!1)}key(e){var t,i;e==="Space"&&this.jump(),e==="KeyE"&&this.use(),e==="KeyF"&&this.tap(innerWidth/2,innerHeight/2),e==="KeyR"&&(this.pending?(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview()):this.removeAt(innerWidth/2,innerHeight/2)),e==="Enter"&&this.confirm(),e==="KeyZ"&&!((t=this.world.aircraft)!=null&&t.passenger)&&this.endPlay()&&this.commands.undo(),e==="KeyY"&&!((i=this.world.aircraft)!=null&&i.passenger)&&this.endPlay()&&this.commands.redo(),e==="Escape"&&this.cancel()}ui(){const e=(t,i)=>document.querySelector("#"+t).onclick=i;e("cameraMode",()=>{this.cameraMode=this.cameraMode==="first"?"third":"first",this.updateCamera(),this.refreshModes(),this.onEdit()}),e("flyMode",()=>{var t,i;if((t=this.world.aircraft)!=null&&t.passenger){this.notice("Land before flying");return}if(!(this.playing&&!this.endPlay())&&!(this.seated&&!this.stand())){if((i=this.activity)!=null&&i.controlled){this.notice("Walk before flying");return}this.controls.clear(),this.vertical=0,this.flying=!this.flying,this.player.vy=0,document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),this.onEdit()}}),e("mapButton",()=>$g(this)),e("catalogueButton",()=>this.catalogue()),e("avatarButton",()=>Zg(this)),e("controlsButton",()=>vg(this));for(const[t,i]of[["flyUp",1],["flyDown",-1]]){const r=document.querySelector("#"+t);r.onpointerdown=s=>{s.preventDefault(),r.setPointerCapture(s.pointerId),this.vertical=i};for(const s of["pointerup","pointercancel","lostpointercapture"])r.addEventListener(s,()=>this.vertical=0)}addEventListener("blur",()=>this.vertical=0),e("moveObject",()=>{this.paused||(this.cancel(),this.pickingMove=!0,this.notice("Tap an object you built to move it"))}),document.addEventListener("visibilitychange",()=>this.vertical=0),e("home",()=>this.home()),e("jump",()=>this.jump()),e("use",()=>this.use()),e("undo",()=>{var t;return!((t=this.world.aircraft)!=null&&t.passenger)&&this.endPlay()&&this.commands.undo()}),e("redo",()=>{var t;return!((t=this.world.aircraft)!=null&&t.passenger)&&this.endPlay()&&this.commands.redo()}),e("cancel",()=>this.cancel()),e("rotate",()=>{this.pending&&(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview())});for(const[t,i]of[["raise",1],["lower",-1]])e(t,()=>{this.pending&&(this.pending.y=Math.max(0,Math.min(23.75,Math.round((this.pending.y+i*.25)*100)/100)),this.showPreview())});e("confirm",()=>this.confirm()),e("doorMode",()=>{this.automatic=!this.automatic,document.querySelector("#doorMode").setAttribute("aria-pressed",String(this.automatic))}),e("guard",()=>{this.guard=!this.guard,document.querySelector("#guard").setAttribute("aria-pressed",String(this.guard))}),bs(this),document.querySelector("#palette").addEventListener("click",t=>{const i=t.target.closest("[data-item]");!i||this.paused||this.choose(i.dataset.item,!0)})}setAppearance(e){ci.some(t=>t.id===e)||(e="explorer"),Ng(this.body),this.appearance=e,this.body=ws(e),this.view.scene.add(this.body.group),this.updateCamera()}catalogue(){yg(this)}choose(e,t=!1){this.selected=t&&this.selected===e?"hand":e,this.recent=[e,...this.recent.filter(i=>i!==e)].slice(0,8),this.cancel(),bs(this),this.refreshSelection(),this.onEdit()}planned(e){var r;if(this.moving)return[e];const t=oh(e);if(t.length>1||!((r=zt.get(e.type))!=null&&r.cube))return t;const i=(e.rotation||0)*Math.PI/180;return Array.from({length:this.repeatCount},(s,a)=>({...e,x:e.x+a*Math.round(Math.cos(i)),z:e.z-a*Math.round(Math.sin(i))}))}placementReason(e){if(this.moving)return this.commands.reason(e,!0,this.moving);if(!Is.some(i=>i.id===e.type)&&this.repeatCount===1)return this.commands.reason(e);if(Math.hypot(e.x+.5-this.player.x,e.y-this.player.y,e.z+.5-this.player.z)>6)return"Move a little closer";const t=new Ca(()=>this.obstacles(),()=>this.player,()=>{});return t.reset(this.commands.blocks),t.placeMany(this.planned(e),!1)}refreshSelection(){document.querySelectorAll("[data-item]").forEach(e=>e.setAttribute("aria-pressed",String(e.dataset.item===this.selected)))}refreshModes(){var e,t,i;this.refreshHistory(),this.refreshSelection(),document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),document.querySelector("#cameraMode").setAttribute("aria-pressed",String(this.cameraMode==="third")),document.querySelector("#use").textContent=(e=this.world.aircraft)!=null&&e.passenger?"🛬":this.playing?"🚶":this.seated?"🪑":(t=this.activity)!=null&&t.controlled?"🚶":((i=this.contextTarget())==null?void 0:i.icon)||"✋"}refreshHistory(){var i,r;const e=document.querySelector("#undo"),t=document.querySelector("#redo");e&&(e.disabled=!!((i=this.world.aircraft)!=null&&i.passenger)||!this.commands.canUndo),t&&(t.disabled=!!((r=this.world.aircraft)!=null&&r.passenger)||!this.commands.canRedo)}notice(e){const t=document.querySelector("#status");t.textContent=e,clearTimeout(this.noticeTimer),this.noticeTimer=window.setTimeout(()=>t.textContent="",5e3)}snapshot(){var t,i,r,s,a;const e=(t=this.world.aircraft)!=null&&t.passenger?this.world.aircraft.entry:((i=this.playing)==null?void 0:i.entry)||((r=this.seated)==null?void 0:r.entry)||((s=this.activity)==null?void 0:s.savedPlayer(this.player))||this.player;return{avatar:this.appearance,lookSpeed:this.lookSpeed,leftHanded:this.leftHanded,favourites:this.favourites,recent:this.recent,hotbar:this.hotbar,camera:this.cameraMode,flying:this.flying,activity:(a=this.activity)==null?void 0:a.snapshot(),template:this.template,player:{...e},props:Qg(this.world),layout:this.world.layout||1,blocks:this.commands.blocks.map(o=>({...o})),doors:Object.fromEntries(this.world.doors.map(o=>[o.id,o.targetOpen])),selected:this.selected}}}async function f1(n,e,t=()=>{}){if(!n.ready||n.blocked)throw Error("Save or export your world before updating");if(await n.save(),n.blocked)throw Error("Save failed; update is paused");t(),e.postMessage({type:"BW2_ACTIVATE"})}async function p1(n){const e=document.createElement("output");if(e.id="offlineState",e.setAttribute("aria-live","polite"),document.querySelector(".brand").append(e),document.documentElement.dataset.standalone==="true"||location.protocol==="file:"){e.textContent="Local HTML · keep portable backups";return}if(!("serviceWorker"in navigator)){e.textContent="Use portable backups on this browser";return}e.textContent="◌ Preparing offline play…";try{const t=await navigator.serviceWorker.register("./sw.js",{scope:"./",updateViaCache:"none"}),i=document.createElement("button");i.id="updateReady",i.hidden=!0,i.textContent="↻ Update",i.setAttribute("aria-label","Save and update game"),document.body.append(i);let r=!1;navigator.serviceWorker.addEventListener("controllerchange",()=>{r&&location.reload()});const s=()=>{i.hidden=!t.waiting,i.disabled=!n.ready||n.blocked};document.addEventListener("bw2-save-status",s);const a=async()=>{try{const o=await fetch(new URL("release.json",t.scope)).then(l=>l.json()),c="bw2:development:"+encodeURIComponent(t.scope)+":"+o.build;await caches.has(c)&&await(await caches.open(c)).match(new URL("index.html",t.scope).href)?e.textContent="✓ Offline ready · "+String(o.build).slice(0,6):e.textContent="Open online once to prepare offline play"}catch{e.textContent="Offline preparation unavailable · keep backups"}};t.addEventListener("updatefound",()=>{const o=t.installing;o==null||o.addEventListener("statechange",()=>{o.state==="installed"&&setTimeout(s,0),o.state==="activated"&&a()})}),s(),i.onclick=()=>{(async()=>{i.disabled=!0;try{const o=t.waiting;if(!o){s();return}await f1(n,o,()=>{r=!0})}catch(o){n.game.notice(String(o)),r=!1}finally{s()}})()},await navigator.serviceWorker.ready,await a()}catch{e.textContent="Offline preparation unavailable · keep backups"}}try{const n=new u1,e=new kg(n);new URLSearchParams(location.search).get("test")==="1"&&Object.assign(window,{bw2:{session:e,game:n,snapshot:()=>n.snapshot(),setPlayer:t=>Object.assign(n.player,t),simulate:(t,i)=>{const r=n.controls.movement;n.controls.movement=()=>t;for(let s=0;s<i;s+=1/60)n.update(1/60);n.controls.movement=r},add:t=>n.commands.place(t,!1)}}),p1(e)}catch(n){const e=document.createElement("p");e.textContent=`Could not start: ${String(n)}`,document.querySelector("#app").append(e),console.error(n)}
