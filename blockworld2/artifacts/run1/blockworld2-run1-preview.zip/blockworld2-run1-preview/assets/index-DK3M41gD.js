(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Pa="160",jl=0,to=1,Kl=2,Wc=1,$l=2,pn=3,_n=0,Ft=1,xt=2,Cn=0,Ti=1,no=2,io=3,ro=4,Jl=5,qn=100,Ql=101,eh=102,so=103,ao=104,th=200,nh=201,ih=202,rh=203,ha=204,ua=205,sh=206,ah=207,oh=208,ch=209,lh=210,hh=211,uh=212,dh=213,fh=214,ph=0,mh=1,gh=2,$r=3,_h=4,xh=5,vh=6,Mh=7,La=0,yh=1,Sh=2,Pn=0,bh=1,Eh=2,wh=3,Th=4,Ah=5,Rh=6,Xc=300,Di=301,Ui=302,da=303,fa=304,us=306,pa=1e3,rn=1001,ma=1002,Ct=1003,oo=1004,Rs=1005,Zt=1006,Ch=1007,ir=1008,Ln=1009,Ph=1010,Lh=1011,Da=1012,qc=1013,Tn=1014,An=1015,rr=1016,Yc=1017,Zc=1018,jn=1020,Dh=1021,sn=1023,Uh=1024,Ih=1025,Kn=1026,Ii=1027,Nh=1028,jc=1029,zh=1030,Kc=1031,$c=1033,Cs=33776,Ps=33777,Ls=33778,Ds=33779,co=35840,lo=35841,ho=35842,uo=35843,Jc=36196,fo=37492,po=37496,mo=37808,go=37809,_o=37810,xo=37811,vo=37812,Mo=37813,yo=37814,So=37815,bo=37816,Eo=37817,wo=37818,To=37819,Ao=37820,Ro=37821,Us=36492,Co=36494,Po=36495,Fh=36283,Lo=36284,Do=36285,Uo=36286,Qc=3e3,$n=3001,Oh=3200,Bh=3201,el=0,kh=1,$t="",mt="srgb",xn="srgb-linear",Ua="display-p3",ds="display-p3-linear",Jr="linear",ot="srgb",Qr="rec709",es="p3",ei=7680,Io=519,Gh=512,Hh=513,Vh=514,tl=515,Wh=516,Xh=517,qh=518,Yh=519,ga=35044,No="300 es",_a=1035,gn=2e3,ts=2001;class Gi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const r=this._listeners[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const At=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Is=Math.PI/180,xa=180/Math.PI;function Dn(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(At[n&255]+At[n>>8&255]+At[n>>16&255]+At[n>>24&255]+"-"+At[e&255]+At[e>>8&255]+"-"+At[e>>16&15|64]+At[e>>24&255]+"-"+At[t&63|128]+At[t>>8&255]+"-"+At[t>>16&255]+At[t>>24&255]+At[i&255]+At[i>>8&255]+At[i>>16&255]+At[i>>24&255]).toLowerCase()}function zt(n,e,t){return Math.max(e,Math.min(t,n))}function Zh(n,e){return(n%e+e)%e}function Ns(n,e,t){return(1-t)*n+t*e}function zo(n){return(n&n-1)===0&&n!==0}function va(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function mn(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function tt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}class Oe{constructor(e=0,t=0){Oe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(zt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*r+e.x,this.y=s*r+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Xe{constructor(e,t,i,r,s,a,o,c,l){Xe.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,c,l)}set(e,t,i,r,s,a,o,c,l){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=c,d[6]=i,d[7]=a,d[8]=l,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[3],c=i[6],l=i[1],d=i[4],h=i[7],u=i[2],m=i[5],M=i[8],_=r[0],p=r[3],f=r[6],x=r[1],g=r[4],v=r[7],C=r[2],P=r[5],A=r[8];return s[0]=a*_+o*x+c*C,s[3]=a*p+o*g+c*P,s[6]=a*f+o*v+c*A,s[1]=l*_+d*x+h*C,s[4]=l*p+d*g+h*P,s[7]=l*f+d*v+h*A,s[2]=u*_+m*x+M*C,s[5]=u*p+m*g+M*P,s[8]=u*f+m*v+M*A,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8];return t*a*d-t*o*l-i*s*d+i*o*c+r*s*l-r*a*c}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8],h=d*a-o*l,u=o*c-d*s,m=l*s-a*c,M=t*h+i*u+r*m;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const _=1/M;return e[0]=h*_,e[1]=(r*l-d*i)*_,e[2]=(o*i-r*a)*_,e[3]=u*_,e[4]=(d*t-r*c)*_,e[5]=(r*s-o*t)*_,e[6]=m*_,e[7]=(i*c-l*t)*_,e[8]=(a*t-i*s)*_,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,a,o){const c=Math.cos(s),l=Math.sin(s);return this.set(i*c,i*l,-i*(c*a+l*o)+a+e,-r*l,r*c,-r*(-l*a+c*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(zs.makeScale(e,t)),this}rotate(e){return this.premultiply(zs.makeRotation(-e)),this}translate(e,t){return this.premultiply(zs.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const zs=new Xe;function nl(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function ns(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function jh(){const n=ns("canvas");return n.style.display="block",n}const Fo={};function nr(n){n in Fo||(Fo[n]=!0,console.warn(n))}const Oo=new Xe().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Bo=new Xe().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),pr={[xn]:{transfer:Jr,primaries:Qr,toReference:n=>n,fromReference:n=>n},[mt]:{transfer:ot,primaries:Qr,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[ds]:{transfer:Jr,primaries:es,toReference:n=>n.applyMatrix3(Bo),fromReference:n=>n.applyMatrix3(Oo)},[Ua]:{transfer:ot,primaries:es,toReference:n=>n.convertSRGBToLinear().applyMatrix3(Bo),fromReference:n=>n.applyMatrix3(Oo).convertLinearToSRGB()}},Kh=new Set([xn,ds]),et={enabled:!0,_workingColorSpace:xn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!Kh.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,e,t){if(this.enabled===!1||e===t||!e||!t)return n;const i=pr[e].toReference,r=pr[t].fromReference;return r(i(n))},fromWorkingColorSpace:function(n,e){return this.convert(n,this._workingColorSpace,e)},toWorkingColorSpace:function(n,e){return this.convert(n,e,this._workingColorSpace)},getPrimaries:function(n){return pr[n].primaries},getTransfer:function(n){return n===$t?Jr:pr[n].transfer}};function Ai(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function Fs(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let ti;class il{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{ti===void 0&&(ti=ns("canvas")),ti.width=e.width,ti.height=e.height;const i=ti.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=ti}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=ns("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=Ai(s[a]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Ai(t[i]/255)*255):t[i]=Ai(t[i]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let $h=0;class rl{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:$h++}),this.uuid=Dn(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(Os(r[a].image)):s.push(Os(r[a]))}else s=Os(r);i.url=s}return t||(e.images[this.uuid]=i),i}}function Os(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?il.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Jh=0;class Ot extends Gi{constructor(e=Ot.DEFAULT_IMAGE,t=Ot.DEFAULT_MAPPING,i=rn,r=rn,s=Zt,a=ir,o=sn,c=Ln,l=Ot.DEFAULT_ANISOTROPY,d=$t){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Jh++}),this.uuid=Dn(),this.name="",this.source=new rl(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=l,this.format=o,this.internalFormat=null,this.type=c,this.offset=new Oe(0,0),this.repeat=new Oe(1,1),this.center=new Oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Xe,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof d=="string"?this.colorSpace=d:(nr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=d===$n?mt:$t),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Xc)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case pa:e.x=e.x-Math.floor(e.x);break;case rn:e.x=e.x<0?0:1;break;case ma:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case pa:e.y=e.y-Math.floor(e.y);break;case rn:e.y=e.y<0?0:1;break;case ma:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return nr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===mt?$n:Qc}set encoding(e){nr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===$n?mt:$t}}Ot.DEFAULT_IMAGE=null;Ot.DEFAULT_MAPPING=Xc;Ot.DEFAULT_ANISOTROPY=1;class wt{constructor(e=0,t=0,i=0,r=1){wt.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*r+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s;const c=e.elements,l=c[0],d=c[4],h=c[8],u=c[1],m=c[5],M=c[9],_=c[2],p=c[6],f=c[10];if(Math.abs(d-u)<.01&&Math.abs(h-_)<.01&&Math.abs(M-p)<.01){if(Math.abs(d+u)<.1&&Math.abs(h+_)<.1&&Math.abs(M+p)<.1&&Math.abs(l+m+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const g=(l+1)/2,v=(m+1)/2,C=(f+1)/2,P=(d+u)/4,A=(h+_)/4,N=(M+p)/4;return g>v&&g>C?g<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(g),r=P/i,s=A/i):v>C?v<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(v),i=P/r,s=N/r):C<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(C),i=A/s,r=N/s),this.set(i,r,s,t),this}let x=Math.sqrt((p-M)*(p-M)+(h-_)*(h-_)+(u-d)*(u-d));return Math.abs(x)<.001&&(x=1),this.x=(p-M)/x,this.y=(h-_)/x,this.z=(u-d)/x,this.w=Math.acos((l+m+f-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class Qh extends Gi{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new wt(0,0,e,t),this.scissorTest=!1,this.viewport=new wt(0,0,e,t);const r={width:e,height:t,depth:1};i.encoding!==void 0&&(nr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===$n?mt:$t),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Zt,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Ot(r,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){(this.width!==e||this.height!==t||this.depth!==i)&&(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new rl(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Jn extends Qh{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class sl extends Ot{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Ct,this.minFilter=Ct,this.wrapR=rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class eu extends Ot{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Ct,this.minFilter=Ct,this.wrapR=rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class cr{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,a,o){let c=i[r+0],l=i[r+1],d=i[r+2],h=i[r+3];const u=s[a+0],m=s[a+1],M=s[a+2],_=s[a+3];if(o===0){e[t+0]=c,e[t+1]=l,e[t+2]=d,e[t+3]=h;return}if(o===1){e[t+0]=u,e[t+1]=m,e[t+2]=M,e[t+3]=_;return}if(h!==_||c!==u||l!==m||d!==M){let p=1-o;const f=c*u+l*m+d*M+h*_,x=f>=0?1:-1,g=1-f*f;if(g>Number.EPSILON){const C=Math.sqrt(g),P=Math.atan2(C,f*x);p=Math.sin(p*P)/C,o=Math.sin(o*P)/C}const v=o*x;if(c=c*p+u*v,l=l*p+m*v,d=d*p+M*v,h=h*p+_*v,p===1-o){const C=1/Math.sqrt(c*c+l*l+d*d+h*h);c*=C,l*=C,d*=C,h*=C}}e[t]=c,e[t+1]=l,e[t+2]=d,e[t+3]=h}static multiplyQuaternionsFlat(e,t,i,r,s,a){const o=i[r],c=i[r+1],l=i[r+2],d=i[r+3],h=s[a],u=s[a+1],m=s[a+2],M=s[a+3];return e[t]=o*M+d*h+c*m-l*u,e[t+1]=c*M+d*u+l*h-o*m,e[t+2]=l*M+d*m+o*u-c*h,e[t+3]=d*M-o*h-c*u-l*m,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,c=Math.sin,l=o(i/2),d=o(r/2),h=o(s/2),u=c(i/2),m=c(r/2),M=c(s/2);switch(a){case"XYZ":this._x=u*d*h+l*m*M,this._y=l*m*h-u*d*M,this._z=l*d*M+u*m*h,this._w=l*d*h-u*m*M;break;case"YXZ":this._x=u*d*h+l*m*M,this._y=l*m*h-u*d*M,this._z=l*d*M-u*m*h,this._w=l*d*h+u*m*M;break;case"ZXY":this._x=u*d*h-l*m*M,this._y=l*m*h+u*d*M,this._z=l*d*M+u*m*h,this._w=l*d*h-u*m*M;break;case"ZYX":this._x=u*d*h-l*m*M,this._y=l*m*h+u*d*M,this._z=l*d*M-u*m*h,this._w=l*d*h+u*m*M;break;case"YZX":this._x=u*d*h+l*m*M,this._y=l*m*h+u*d*M,this._z=l*d*M-u*m*h,this._w=l*d*h-u*m*M;break;case"XZY":this._x=u*d*h-l*m*M,this._y=l*m*h-u*d*M,this._z=l*d*M+u*m*h,this._w=l*d*h+u*m*M;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],r=t[4],s=t[8],a=t[1],o=t[5],c=t[9],l=t[2],d=t[6],h=t[10],u=i+o+h;if(u>0){const m=.5/Math.sqrt(u+1);this._w=.25/m,this._x=(d-c)*m,this._y=(s-l)*m,this._z=(a-r)*m}else if(i>o&&i>h){const m=2*Math.sqrt(1+i-o-h);this._w=(d-c)/m,this._x=.25*m,this._y=(r+a)/m,this._z=(s+l)/m}else if(o>h){const m=2*Math.sqrt(1+o-i-h);this._w=(s-l)/m,this._x=(r+a)/m,this._y=.25*m,this._z=(c+d)/m}else{const m=2*Math.sqrt(1+h-i-o);this._w=(a-r)/m,this._x=(s+l)/m,this._y=(c+d)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(zt(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,r=e._y,s=e._z,a=e._w,o=t._x,c=t._y,l=t._z,d=t._w;return this._x=i*d+a*o+r*l-s*c,this._y=r*d+a*c+s*o-i*l,this._z=s*d+a*l+i*c-r*o,this._w=a*d-i*o-r*c-s*l,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const i=this._x,r=this._y,s=this._z,a=this._w;let o=a*e._w+i*e._x+r*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=r,this._z=s,this;const c=1-o*o;if(c<=Number.EPSILON){const m=1-t;return this._w=m*a+t*this._w,this._x=m*i+t*this._x,this._y=m*r+t*this._y,this._z=m*s+t*this._z,this.normalize(),this}const l=Math.sqrt(c),d=Math.atan2(l,o),h=Math.sin((1-t)*d)/l,u=Math.sin(t*d)/l;return this._w=a*h+this._w*u,this._x=i*h+this._x*u,this._y=r*h+this._y*u,this._z=s*h+this._z*u,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),r=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(r),i*Math.sin(s),i*Math.cos(s),t*Math.sin(r))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class z{constructor(e=0,t=0,i=0){z.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(ko.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(ko.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,r=this.z,s=e.x,a=e.y,o=e.z,c=e.w,l=2*(a*r-o*i),d=2*(o*t-s*r),h=2*(s*i-a*t);return this.x=t+c*l+a*h-o*d,this.y=i+c*d+o*l-s*h,this.z=r+c*h+s*d-a*l,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,r=e.y,s=e.z,a=t.x,o=t.y,c=t.z;return this.x=r*c-s*o,this.y=s*a-i*c,this.z=i*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Bs.copy(this).projectOnVector(e),this.sub(Bs)}reflect(e){return this.sub(Bs.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(zt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Bs=new z,ko=new cr;class vn{constructor(e=new z(1/0,1/0,1/0),t=new z(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(en.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(en.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=en.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,en):en.fromBufferAttribute(s,a),en.applyMatrix4(e.matrixWorld),this.expandByPoint(en);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),mr.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),mr.copy(i.boundingBox)),mr.applyMatrix4(e.matrixWorld),this.union(mr)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,en),en.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Xi),gr.subVectors(this.max,Xi),ni.subVectors(e.a,Xi),ii.subVectors(e.b,Xi),ri.subVectors(e.c,Xi),Mn.subVectors(ii,ni),yn.subVectors(ri,ii),Fn.subVectors(ni,ri);let t=[0,-Mn.z,Mn.y,0,-yn.z,yn.y,0,-Fn.z,Fn.y,Mn.z,0,-Mn.x,yn.z,0,-yn.x,Fn.z,0,-Fn.x,-Mn.y,Mn.x,0,-yn.y,yn.x,0,-Fn.y,Fn.x,0];return!ks(t,ni,ii,ri,gr)||(t=[1,0,0,0,1,0,0,0,1],!ks(t,ni,ii,ri,gr))?!1:(_r.crossVectors(Mn,yn),t=[_r.x,_r.y,_r.z],ks(t,ni,ii,ri,gr))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,en).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(en).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ln[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ln[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ln[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ln[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ln[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ln[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ln[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ln[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ln),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const ln=[new z,new z,new z,new z,new z,new z,new z,new z],en=new z,mr=new vn,ni=new z,ii=new z,ri=new z,Mn=new z,yn=new z,Fn=new z,Xi=new z,gr=new z,_r=new z,On=new z;function ks(n,e,t,i,r){for(let s=0,a=n.length-3;s<=a;s+=3){On.fromArray(n,s);const o=r.x*Math.abs(On.x)+r.y*Math.abs(On.y)+r.z*Math.abs(On.z),c=e.dot(On),l=t.dot(On),d=i.dot(On);if(Math.max(-Math.max(c,l,d),Math.min(c,l,d))>o)return!1}return!0}const tu=new vn,qi=new z,Gs=new z;class lr{constructor(e=new z,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):tu.setFromPoints(e).getCenter(i);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;qi.subVectors(e,this.center);const t=qi.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(qi,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Gs.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(qi.copy(e.center).add(Gs)),this.expandByPoint(qi.copy(e.center).sub(Gs))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const hn=new z,Hs=new z,xr=new z,Sn=new z,Vs=new z,vr=new z,Ws=new z;class hr{constructor(e=new z,t=new z(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,hn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=hn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(hn.copy(this.origin).addScaledVector(this.direction,t),hn.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){Hs.copy(e).add(t).multiplyScalar(.5),xr.copy(t).sub(e).normalize(),Sn.copy(this.origin).sub(Hs);const s=e.distanceTo(t)*.5,a=-this.direction.dot(xr),o=Sn.dot(this.direction),c=-Sn.dot(xr),l=Sn.lengthSq(),d=Math.abs(1-a*a);let h,u,m,M;if(d>0)if(h=a*c-o,u=a*o-c,M=s*d,h>=0)if(u>=-M)if(u<=M){const _=1/d;h*=_,u*=_,m=h*(h+a*u+2*o)+u*(a*h+u+2*c)+l}else u=s,h=Math.max(0,-(a*u+o)),m=-h*h+u*(u+2*c)+l;else u=-s,h=Math.max(0,-(a*u+o)),m=-h*h+u*(u+2*c)+l;else u<=-M?(h=Math.max(0,-(-a*s+o)),u=h>0?-s:Math.min(Math.max(-s,-c),s),m=-h*h+u*(u+2*c)+l):u<=M?(h=0,u=Math.min(Math.max(-s,-c),s),m=u*(u+2*c)+l):(h=Math.max(0,-(a*s+o)),u=h>0?s:Math.min(Math.max(-s,-c),s),m=-h*h+u*(u+2*c)+l);else u=a>0?-s:s,h=Math.max(0,-(a*u+o)),m=-h*h+u*(u+2*c)+l;return i&&i.copy(this.origin).addScaledVector(this.direction,h),r&&r.copy(Hs).addScaledVector(xr,u),m}intersectSphere(e,t){hn.subVectors(e.center,this.origin);const i=hn.dot(this.direction),r=hn.dot(hn)-i*i,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=i-a,c=i+a;return c<0?null:o<0?this.at(c,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,a,o,c;const l=1/this.direction.x,d=1/this.direction.y,h=1/this.direction.z,u=this.origin;return l>=0?(i=(e.min.x-u.x)*l,r=(e.max.x-u.x)*l):(i=(e.max.x-u.x)*l,r=(e.min.x-u.x)*l),d>=0?(s=(e.min.y-u.y)*d,a=(e.max.y-u.y)*d):(s=(e.max.y-u.y)*d,a=(e.min.y-u.y)*d),i>a||s>r||((s>i||isNaN(i))&&(i=s),(a<r||isNaN(r))&&(r=a),h>=0?(o=(e.min.z-u.z)*h,c=(e.max.z-u.z)*h):(o=(e.max.z-u.z)*h,c=(e.min.z-u.z)*h),i>c||o>r)||((o>i||i!==i)&&(i=o),(c<r||r!==r)&&(r=c),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,hn)!==null}intersectTriangle(e,t,i,r,s){Vs.subVectors(t,e),vr.subVectors(i,e),Ws.crossVectors(Vs,vr);let a=this.direction.dot(Ws),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;Sn.subVectors(this.origin,e);const c=o*this.direction.dot(vr.crossVectors(Sn,vr));if(c<0)return null;const l=o*this.direction.dot(Vs.cross(Sn));if(l<0||c+l>a)return null;const d=-o*Sn.dot(Ws);return d<0?null:this.at(d/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Qe{constructor(e,t,i,r,s,a,o,c,l,d,h,u,m,M,_,p){Qe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,c,l,d,h,u,m,M,_,p)}set(e,t,i,r,s,a,o,c,l,d,h,u,m,M,_,p){const f=this.elements;return f[0]=e,f[4]=t,f[8]=i,f[12]=r,f[1]=s,f[5]=a,f[9]=o,f[13]=c,f[2]=l,f[6]=d,f[10]=h,f[14]=u,f[3]=m,f[7]=M,f[11]=_,f[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Qe().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,r=1/si.setFromMatrixColumn(e,0).length(),s=1/si.setFromMatrixColumn(e,1).length(),a=1/si.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,r=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),c=Math.cos(r),l=Math.sin(r),d=Math.cos(s),h=Math.sin(s);if(e.order==="XYZ"){const u=a*d,m=a*h,M=o*d,_=o*h;t[0]=c*d,t[4]=-c*h,t[8]=l,t[1]=m+M*l,t[5]=u-_*l,t[9]=-o*c,t[2]=_-u*l,t[6]=M+m*l,t[10]=a*c}else if(e.order==="YXZ"){const u=c*d,m=c*h,M=l*d,_=l*h;t[0]=u+_*o,t[4]=M*o-m,t[8]=a*l,t[1]=a*h,t[5]=a*d,t[9]=-o,t[2]=m*o-M,t[6]=_+u*o,t[10]=a*c}else if(e.order==="ZXY"){const u=c*d,m=c*h,M=l*d,_=l*h;t[0]=u-_*o,t[4]=-a*h,t[8]=M+m*o,t[1]=m+M*o,t[5]=a*d,t[9]=_-u*o,t[2]=-a*l,t[6]=o,t[10]=a*c}else if(e.order==="ZYX"){const u=a*d,m=a*h,M=o*d,_=o*h;t[0]=c*d,t[4]=M*l-m,t[8]=u*l+_,t[1]=c*h,t[5]=_*l+u,t[9]=m*l-M,t[2]=-l,t[6]=o*c,t[10]=a*c}else if(e.order==="YZX"){const u=a*c,m=a*l,M=o*c,_=o*l;t[0]=c*d,t[4]=_-u*h,t[8]=M*h+m,t[1]=h,t[5]=a*d,t[9]=-o*d,t[2]=-l*d,t[6]=m*h+M,t[10]=u-_*h}else if(e.order==="XZY"){const u=a*c,m=a*l,M=o*c,_=o*l;t[0]=c*d,t[4]=-h,t[8]=l*d,t[1]=u*h+_,t[5]=a*d,t[9]=m*h-M,t[2]=M*h-m,t[6]=o*d,t[10]=_*h+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(nu,e,iu)}lookAt(e,t,i){const r=this.elements;return kt.subVectors(e,t),kt.lengthSq()===0&&(kt.z=1),kt.normalize(),bn.crossVectors(i,kt),bn.lengthSq()===0&&(Math.abs(i.z)===1?kt.x+=1e-4:kt.z+=1e-4,kt.normalize(),bn.crossVectors(i,kt)),bn.normalize(),Mr.crossVectors(kt,bn),r[0]=bn.x,r[4]=Mr.x,r[8]=kt.x,r[1]=bn.y,r[5]=Mr.y,r[9]=kt.y,r[2]=bn.z,r[6]=Mr.z,r[10]=kt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[4],c=i[8],l=i[12],d=i[1],h=i[5],u=i[9],m=i[13],M=i[2],_=i[6],p=i[10],f=i[14],x=i[3],g=i[7],v=i[11],C=i[15],P=r[0],A=r[4],N=r[8],E=r[12],w=r[1],H=r[5],U=r[9],W=r[13],L=r[2],I=r[6],k=r[10],X=r[14],$=r[3],ie=r[7],ne=r[11],ue=r[15];return s[0]=a*P+o*w+c*L+l*$,s[4]=a*A+o*H+c*I+l*ie,s[8]=a*N+o*U+c*k+l*ne,s[12]=a*E+o*W+c*X+l*ue,s[1]=d*P+h*w+u*L+m*$,s[5]=d*A+h*H+u*I+m*ie,s[9]=d*N+h*U+u*k+m*ne,s[13]=d*E+h*W+u*X+m*ue,s[2]=M*P+_*w+p*L+f*$,s[6]=M*A+_*H+p*I+f*ie,s[10]=M*N+_*U+p*k+f*ne,s[14]=M*E+_*W+p*X+f*ue,s[3]=x*P+g*w+v*L+C*$,s[7]=x*A+g*H+v*I+C*ie,s[11]=x*N+g*U+v*k+C*ne,s[15]=x*E+g*W+v*X+C*ue,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],a=e[1],o=e[5],c=e[9],l=e[13],d=e[2],h=e[6],u=e[10],m=e[14],M=e[3],_=e[7],p=e[11],f=e[15];return M*(+s*c*h-r*l*h-s*o*u+i*l*u+r*o*m-i*c*m)+_*(+t*c*m-t*l*u+s*a*u-r*a*m+r*l*d-s*c*d)+p*(+t*l*h-t*o*m-s*a*h+i*a*m+s*o*d-i*l*d)+f*(-r*o*d-t*c*h+t*o*u+r*a*h-i*a*u+i*c*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],c=e[6],l=e[7],d=e[8],h=e[9],u=e[10],m=e[11],M=e[12],_=e[13],p=e[14],f=e[15],x=h*p*l-_*u*l+_*c*m-o*p*m-h*c*f+o*u*f,g=M*u*l-d*p*l-M*c*m+a*p*m+d*c*f-a*u*f,v=d*_*l-M*h*l+M*o*m-a*_*m-d*o*f+a*h*f,C=M*h*c-d*_*c-M*o*u+a*_*u+d*o*p-a*h*p,P=t*x+i*g+r*v+s*C;if(P===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/P;return e[0]=x*A,e[1]=(_*u*s-h*p*s-_*r*m+i*p*m+h*r*f-i*u*f)*A,e[2]=(o*p*s-_*c*s+_*r*l-i*p*l-o*r*f+i*c*f)*A,e[3]=(h*c*s-o*u*s-h*r*l+i*u*l+o*r*m-i*c*m)*A,e[4]=g*A,e[5]=(d*p*s-M*u*s+M*r*m-t*p*m-d*r*f+t*u*f)*A,e[6]=(M*c*s-a*p*s-M*r*l+t*p*l+a*r*f-t*c*f)*A,e[7]=(a*u*s-d*c*s+d*r*l-t*u*l-a*r*m+t*c*m)*A,e[8]=v*A,e[9]=(M*h*s-d*_*s-M*i*m+t*_*m+d*i*f-t*h*f)*A,e[10]=(a*_*s-M*o*s+M*i*l-t*_*l-a*i*f+t*o*f)*A,e[11]=(d*o*s-a*h*s-d*i*l+t*h*l+a*i*m-t*o*m)*A,e[12]=C*A,e[13]=(d*_*r-M*h*r+M*i*u-t*_*u-d*i*p+t*h*p)*A,e[14]=(M*o*r-a*_*r-M*i*c+t*_*c+a*i*p-t*o*p)*A,e[15]=(a*h*r-d*o*r+d*i*c-t*h*c-a*i*u+t*o*u)*A,this}scale(e){const t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),r=Math.sin(t),s=1-i,a=e.x,o=e.y,c=e.z,l=s*a,d=s*o;return this.set(l*a+i,l*o-r*c,l*c+r*o,0,l*o+r*c,d*o+i,d*c-r*a,0,l*c-r*o,d*c+r*a,s*c*c+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,a){return this.set(1,i,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){const r=this.elements,s=t._x,a=t._y,o=t._z,c=t._w,l=s+s,d=a+a,h=o+o,u=s*l,m=s*d,M=s*h,_=a*d,p=a*h,f=o*h,x=c*l,g=c*d,v=c*h,C=i.x,P=i.y,A=i.z;return r[0]=(1-(_+f))*C,r[1]=(m+v)*C,r[2]=(M-g)*C,r[3]=0,r[4]=(m-v)*P,r[5]=(1-(u+f))*P,r[6]=(p+x)*P,r[7]=0,r[8]=(M+g)*A,r[9]=(p-x)*A,r[10]=(1-(u+_))*A,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){const r=this.elements;let s=si.set(r[0],r[1],r[2]).length();const a=si.set(r[4],r[5],r[6]).length(),o=si.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],tn.copy(this);const l=1/s,d=1/a,h=1/o;return tn.elements[0]*=l,tn.elements[1]*=l,tn.elements[2]*=l,tn.elements[4]*=d,tn.elements[5]*=d,tn.elements[6]*=d,tn.elements[8]*=h,tn.elements[9]*=h,tn.elements[10]*=h,t.setFromRotationMatrix(tn),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,r,s,a,o=gn){const c=this.elements,l=2*s/(t-e),d=2*s/(i-r),h=(t+e)/(t-e),u=(i+r)/(i-r);let m,M;if(o===gn)m=-(a+s)/(a-s),M=-2*a*s/(a-s);else if(o===ts)m=-a/(a-s),M=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return c[0]=l,c[4]=0,c[8]=h,c[12]=0,c[1]=0,c[5]=d,c[9]=u,c[13]=0,c[2]=0,c[6]=0,c[10]=m,c[14]=M,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,i,r,s,a,o=gn){const c=this.elements,l=1/(t-e),d=1/(i-r),h=1/(a-s),u=(t+e)*l,m=(i+r)*d;let M,_;if(o===gn)M=(a+s)*h,_=-2*h;else if(o===ts)M=s*h,_=-1*h;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return c[0]=2*l,c[4]=0,c[8]=0,c[12]=-u,c[1]=0,c[5]=2*d,c[9]=0,c[13]=-m,c[2]=0,c[6]=0,c[10]=_,c[14]=-M,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const si=new z,tn=new Qe,nu=new z(0,0,0),iu=new z(1,1,1),bn=new z,Mr=new z,kt=new z,Go=new Qe,Ho=new cr;class fs{constructor(e=0,t=0,i=0,r=fs.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],c=r[1],l=r[5],d=r[9],h=r[2],u=r[6],m=r[10];switch(t){case"XYZ":this._y=Math.asin(zt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,m),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(u,l),this._z=0);break;case"YXZ":this._x=Math.asin(-zt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(c,l)):(this._y=Math.atan2(-h,s),this._z=0);break;case"ZXY":this._x=Math.asin(zt(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-h,m),this._z=Math.atan2(-a,l)):(this._y=0,this._z=Math.atan2(c,s));break;case"ZYX":this._y=Math.asin(-zt(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(u,m),this._z=Math.atan2(c,s)):(this._x=0,this._z=Math.atan2(-a,l));break;case"YZX":this._z=Math.asin(zt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(-d,l),this._y=Math.atan2(-h,s)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-zt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,l),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return Go.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Go,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Ho.setFromEuler(this),this.setFromQuaternion(Ho,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}fs.DEFAULT_ORDER="XYZ";class Ia{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let ru=0;const Vo=new z,ai=new cr,un=new Qe,yr=new z,Yi=new z,su=new z,au=new cr,Wo=new z(1,0,0),Xo=new z(0,1,0),qo=new z(0,0,1),ou={type:"added"},cu={type:"removed"};class ut extends Gi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:ru++}),this.uuid=Dn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ut.DEFAULT_UP.clone();const e=new z,t=new fs,i=new cr,r=new z(1,1,1);function s(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new Qe},normalMatrix:{value:new Xe}}),this.matrix=new Qe,this.matrixWorld=new Qe,this.matrixAutoUpdate=ut.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Ia,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ai.setFromAxisAngle(e,t),this.quaternion.multiply(ai),this}rotateOnWorldAxis(e,t){return ai.setFromAxisAngle(e,t),this.quaternion.premultiply(ai),this}rotateX(e){return this.rotateOnAxis(Wo,e)}rotateY(e){return this.rotateOnAxis(Xo,e)}rotateZ(e){return this.rotateOnAxis(qo,e)}translateOnAxis(e,t){return Vo.copy(e).applyQuaternion(this.quaternion),this.position.add(Vo.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Wo,e)}translateY(e){return this.translateOnAxis(Xo,e)}translateZ(e){return this.translateOnAxis(qo,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(un.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?yr.copy(e):yr.set(e,t,i);const r=this.parent;this.updateWorldMatrix(!0,!1),Yi.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?un.lookAt(Yi,yr,this.up):un.lookAt(yr,Yi,this.up),this.quaternion.setFromRotationMatrix(un),r&&(un.extractRotation(r.matrixWorld),ai.setFromRotationMatrix(un),this.quaternion.premultiply(ai.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(ou)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(cu)),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),un.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),un.multiply(e.parent.matrixWorld)),e.applyMatrix4(un),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Yi,e,su),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Yi,au,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,r=t.length;i<r;i++){const s=t[i];(s.matrixWorldAutoUpdate===!0||e===!0)&&s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){const r=this.children;for(let s=0,a=r.length;s<a;s++){const o=r[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.visibility=this._visibility,r.active=this._active,r.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),r.maxGeometryCount=this._maxGeometryCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.geometryCount=this._geometryCount,r.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(r.boundingSphere={center:r.boundingSphere.center.toArray(),radius:r.boundingSphere.radius}),this.boundingBox!==null&&(r.boundingBox={min:r.boundingBox.min.toArray(),max:r.boundingBox.max.toArray()}));function s(o,c){return o[c.uuid]===void 0&&(o[c.uuid]=c.toJSON(e)),c.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const c=o.shapes;if(Array.isArray(c))for(let l=0,d=c.length;l<d;l++){const h=c[l];s(e.shapes,h)}else s(e.shapes,c)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let c=0,l=this.material.length;c<l;c++)o.push(s(e.materials,this.material[c]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const c=this.animations[o];r.animations.push(s(e.animations,c))}}if(t){const o=a(e.geometries),c=a(e.materials),l=a(e.textures),d=a(e.images),h=a(e.shapes),u=a(e.skeletons),m=a(e.animations),M=a(e.nodes);o.length>0&&(i.geometries=o),c.length>0&&(i.materials=c),l.length>0&&(i.textures=l),d.length>0&&(i.images=d),h.length>0&&(i.shapes=h),u.length>0&&(i.skeletons=u),m.length>0&&(i.animations=m),M.length>0&&(i.nodes=M)}return i.object=r,i;function a(o){const c=[];for(const l in o){const d=o[l];delete d.metadata,c.push(d)}return c}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}}ut.DEFAULT_UP=new z(0,1,0);ut.DEFAULT_MATRIX_AUTO_UPDATE=!0;ut.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const nn=new z,dn=new z,Xs=new z,fn=new z,oi=new z,ci=new z,Yo=new z,qs=new z,Ys=new z,Zs=new z;let Sr=!1;class jt{constructor(e=new z,t=new z,i=new z){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),nn.subVectors(e,t),r.cross(nn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){nn.subVectors(r,t),dn.subVectors(i,t),Xs.subVectors(e,t);const a=nn.dot(nn),o=nn.dot(dn),c=nn.dot(Xs),l=dn.dot(dn),d=dn.dot(Xs),h=a*l-o*o;if(h===0)return s.set(0,0,0),null;const u=1/h,m=(l*c-o*d)*u,M=(a*d-o*c)*u;return s.set(1-m-M,M,m)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,fn)===null?!1:fn.x>=0&&fn.y>=0&&fn.x+fn.y<=1}static getUV(e,t,i,r,s,a,o,c){return Sr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Sr=!0),this.getInterpolation(e,t,i,r,s,a,o,c)}static getInterpolation(e,t,i,r,s,a,o,c){return this.getBarycoord(e,t,i,r,fn)===null?(c.x=0,c.y=0,"z"in c&&(c.z=0),"w"in c&&(c.w=0),null):(c.setScalar(0),c.addScaledVector(s,fn.x),c.addScaledVector(a,fn.y),c.addScaledVector(o,fn.z),c)}static isFrontFacing(e,t,i,r){return nn.subVectors(i,t),dn.subVectors(e,t),nn.cross(dn).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return nn.subVectors(this.c,this.b),dn.subVectors(this.a,this.b),nn.cross(dn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return jt.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return jt.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,r,s){return Sr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Sr=!0),jt.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}getInterpolation(e,t,i,r,s){return jt.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return jt.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return jt.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,r=this.b,s=this.c;let a,o;oi.subVectors(r,i),ci.subVectors(s,i),qs.subVectors(e,i);const c=oi.dot(qs),l=ci.dot(qs);if(c<=0&&l<=0)return t.copy(i);Ys.subVectors(e,r);const d=oi.dot(Ys),h=ci.dot(Ys);if(d>=0&&h<=d)return t.copy(r);const u=c*h-d*l;if(u<=0&&c>=0&&d<=0)return a=c/(c-d),t.copy(i).addScaledVector(oi,a);Zs.subVectors(e,s);const m=oi.dot(Zs),M=ci.dot(Zs);if(M>=0&&m<=M)return t.copy(s);const _=m*l-c*M;if(_<=0&&l>=0&&M<=0)return o=l/(l-M),t.copy(i).addScaledVector(ci,o);const p=d*M-m*h;if(p<=0&&h-d>=0&&m-M>=0)return Yo.subVectors(s,r),o=(h-d)/(h-d+(m-M)),t.copy(r).addScaledVector(Yo,o);const f=1/(p+_+u);return a=_*f,o=u*f,t.copy(i).addScaledVector(oi,a).addScaledVector(ci,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const al={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},En={h:0,s:0,l:0},br={h:0,s:0,l:0};function js(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class je{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=mt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,et.toWorkingColorSpace(this,t),this}setRGB(e,t,i,r=et.workingColorSpace){return this.r=e,this.g=t,this.b=i,et.toWorkingColorSpace(this,r),this}setHSL(e,t,i,r=et.workingColorSpace){if(e=Zh(e,1),t=zt(t,0,1),i=zt(i,0,1),t===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=js(a,s,e+1/3),this.g=js(a,s,e),this.b=js(a,s,e-1/3)}return et.toWorkingColorSpace(this,r),this}setStyle(e,t=mt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=mt){const i=al[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ai(e.r),this.g=Ai(e.g),this.b=Ai(e.b),this}copyLinearToSRGB(e){return this.r=Fs(e.r),this.g=Fs(e.g),this.b=Fs(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=mt){return et.fromWorkingColorSpace(Rt.copy(this),e),Math.round(zt(Rt.r*255,0,255))*65536+Math.round(zt(Rt.g*255,0,255))*256+Math.round(zt(Rt.b*255,0,255))}getHexString(e=mt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=et.workingColorSpace){et.fromWorkingColorSpace(Rt.copy(this),t);const i=Rt.r,r=Rt.g,s=Rt.b,a=Math.max(i,r,s),o=Math.min(i,r,s);let c,l;const d=(o+a)/2;if(o===a)c=0,l=0;else{const h=a-o;switch(l=d<=.5?h/(a+o):h/(2-a-o),a){case i:c=(r-s)/h+(r<s?6:0);break;case r:c=(s-i)/h+2;break;case s:c=(i-r)/h+4;break}c/=6}return e.h=c,e.s=l,e.l=d,e}getRGB(e,t=et.workingColorSpace){return et.fromWorkingColorSpace(Rt.copy(this),t),e.r=Rt.r,e.g=Rt.g,e.b=Rt.b,e}getStyle(e=mt){et.fromWorkingColorSpace(Rt.copy(this),e);const t=Rt.r,i=Rt.g,r=Rt.b;return e!==mt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL(En),this.setHSL(En.h+e,En.s+t,En.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(En),e.getHSL(br);const i=Ns(En.h,br.h,t),r=Ns(En.s,br.s,t),s=Ns(En.l,br.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Rt=new je;je.NAMES=al;let lu=0;class Hi extends Gi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:lu++}),this.uuid=Dn(),this.name="",this.type="Material",this.blending=Ti,this.side=_n,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ha,this.blendDst=ua,this.blendEquation=qn,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new je(0,0,0),this.blendAlpha=0,this.depthFunc=$r,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Io,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=ei,this.stencilZFail=ei,this.stencilZPass=ei,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Ti&&(i.blending=this.blending),this.side!==_n&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==ha&&(i.blendSrc=this.blendSrc),this.blendDst!==ua&&(i.blendDst=this.blendDst),this.blendEquation!==qn&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==$r&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Io&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==ei&&(i.stencilFail=this.stencilFail),this.stencilZFail!==ei&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==ei&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){const a=[];for(const o in s){const c=s[o];delete c.metadata,a.push(c)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Ri extends Hi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new je(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=La,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const _t=new z,Er=new Oe;class Qt{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=ga,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=An,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Er.fromBufferAttribute(this,t),Er.applyMatrix3(e),this.setXY(t,Er.x,Er.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.applyMatrix3(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.applyMatrix4(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.applyNormalMatrix(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)_t.fromBufferAttribute(this,t),_t.transformDirection(e),this.setXYZ(t,_t.x,_t.y,_t.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=mn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=tt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=mn(t,this.array)),t}setX(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=mn(t,this.array)),t}setY(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=mn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=mn(t,this.array)),t}setW(e,t){return this.normalized&&(t=tt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),r=tt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),r=tt(r,this.array),s=tt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==ga&&(e.usage=this.usage),e}}class ol extends Qt{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class cl extends Qt{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class Ye extends Qt{constructor(e,t,i){super(new Float32Array(e),t,i)}}let hu=0;const Xt=new Qe,Ks=new ut,li=new z,Gt=new vn,Zi=new vn,Et=new z;class at extends Gi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:hu++}),this.uuid=Dn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(nl(e)?cl:ol)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new Xe().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Xt.makeRotationFromQuaternion(e),this.applyMatrix4(Xt),this}rotateX(e){return Xt.makeRotationX(e),this.applyMatrix4(Xt),this}rotateY(e){return Xt.makeRotationY(e),this.applyMatrix4(Xt),this}rotateZ(e){return Xt.makeRotationZ(e),this.applyMatrix4(Xt),this}translate(e,t,i){return Xt.makeTranslation(e,t,i),this.applyMatrix4(Xt),this}scale(e,t,i){return Xt.makeScale(e,t,i),this.applyMatrix4(Xt),this}lookAt(e){return Ks.lookAt(e),Ks.updateMatrix(),this.applyMatrix4(Ks.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(li).negate(),this.translate(li.x,li.y,li.z),this}setFromPoints(e){const t=[];for(let i=0,r=e.length;i<r;i++){const s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Ye(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new vn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new z(-1/0,-1/0,-1/0),new z(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){const s=t[i];Gt.setFromBufferAttribute(s),this.morphTargetsRelative?(Et.addVectors(this.boundingBox.min,Gt.min),this.boundingBox.expandByPoint(Et),Et.addVectors(this.boundingBox.max,Gt.max),this.boundingBox.expandByPoint(Et)):(this.boundingBox.expandByPoint(Gt.min),this.boundingBox.expandByPoint(Gt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new lr);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new z,1/0);return}if(e){const i=this.boundingSphere.center;if(Gt.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];Zi.setFromBufferAttribute(o),this.morphTargetsRelative?(Et.addVectors(Gt.min,Zi.min),Gt.expandByPoint(Et),Et.addVectors(Gt.max,Zi.max),Gt.expandByPoint(Et)):(Gt.expandByPoint(Zi.min),Gt.expandByPoint(Zi.max))}Gt.getCenter(i);let r=0;for(let s=0,a=e.count;s<a;s++)Et.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(Et));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],c=this.morphTargetsRelative;for(let l=0,d=o.count;l<d;l++)Et.fromBufferAttribute(o,l),c&&(li.fromBufferAttribute(e,l),Et.add(li)),r=Math.max(r,i.distanceToSquared(Et))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=e.array,r=t.position.array,s=t.normal.array,a=t.uv.array,o=r.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Qt(new Float32Array(4*o),4));const c=this.getAttribute("tangent").array,l=[],d=[];for(let w=0;w<o;w++)l[w]=new z,d[w]=new z;const h=new z,u=new z,m=new z,M=new Oe,_=new Oe,p=new Oe,f=new z,x=new z;function g(w,H,U){h.fromArray(r,w*3),u.fromArray(r,H*3),m.fromArray(r,U*3),M.fromArray(a,w*2),_.fromArray(a,H*2),p.fromArray(a,U*2),u.sub(h),m.sub(h),_.sub(M),p.sub(M);const W=1/(_.x*p.y-p.x*_.y);isFinite(W)&&(f.copy(u).multiplyScalar(p.y).addScaledVector(m,-_.y).multiplyScalar(W),x.copy(m).multiplyScalar(_.x).addScaledVector(u,-p.x).multiplyScalar(W),l[w].add(f),l[H].add(f),l[U].add(f),d[w].add(x),d[H].add(x),d[U].add(x))}let v=this.groups;v.length===0&&(v=[{start:0,count:i.length}]);for(let w=0,H=v.length;w<H;++w){const U=v[w],W=U.start,L=U.count;for(let I=W,k=W+L;I<k;I+=3)g(i[I+0],i[I+1],i[I+2])}const C=new z,P=new z,A=new z,N=new z;function E(w){A.fromArray(s,w*3),N.copy(A);const H=l[w];C.copy(H),C.sub(A.multiplyScalar(A.dot(H))).normalize(),P.crossVectors(N,H);const W=P.dot(d[w])<0?-1:1;c[w*4]=C.x,c[w*4+1]=C.y,c[w*4+2]=C.z,c[w*4+3]=W}for(let w=0,H=v.length;w<H;++w){const U=v[w],W=U.start,L=U.count;for(let I=W,k=W+L;I<k;I+=3)E(i[I+0]),E(i[I+1]),E(i[I+2])}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Qt(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let u=0,m=i.count;u<m;u++)i.setXYZ(u,0,0,0);const r=new z,s=new z,a=new z,o=new z,c=new z,l=new z,d=new z,h=new z;if(e)for(let u=0,m=e.count;u<m;u+=3){const M=e.getX(u+0),_=e.getX(u+1),p=e.getX(u+2);r.fromBufferAttribute(t,M),s.fromBufferAttribute(t,_),a.fromBufferAttribute(t,p),d.subVectors(a,s),h.subVectors(r,s),d.cross(h),o.fromBufferAttribute(i,M),c.fromBufferAttribute(i,_),l.fromBufferAttribute(i,p),o.add(d),c.add(d),l.add(d),i.setXYZ(M,o.x,o.y,o.z),i.setXYZ(_,c.x,c.y,c.z),i.setXYZ(p,l.x,l.y,l.z)}else for(let u=0,m=t.count;u<m;u+=3)r.fromBufferAttribute(t,u+0),s.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),d.subVectors(a,s),h.subVectors(r,s),d.cross(h),i.setXYZ(u+0,d.x,d.y,d.z),i.setXYZ(u+1,d.x,d.y,d.z),i.setXYZ(u+2,d.x,d.y,d.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Et.fromBufferAttribute(e,t),Et.normalize(),e.setXYZ(t,Et.x,Et.y,Et.z)}toNonIndexed(){function e(o,c){const l=o.array,d=o.itemSize,h=o.normalized,u=new l.constructor(c.length*d);let m=0,M=0;for(let _=0,p=c.length;_<p;_++){o.isInterleavedBufferAttribute?m=c[_]*o.data.stride+o.offset:m=c[_]*d;for(let f=0;f<d;f++)u[M++]=l[m++]}return new Qt(u,d,h)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new at,i=this.index.array,r=this.attributes;for(const o in r){const c=r[o],l=e(c,i);t.setAttribute(o,l)}const s=this.morphAttributes;for(const o in s){const c=[],l=s[o];for(let d=0,h=l.length;d<h;d++){const u=l[d],m=e(u,i);c.push(m)}t.morphAttributes[o]=c}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,c=a.length;o<c;o++){const l=a[o];t.addGroup(l.start,l.count,l.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const c=this.parameters;for(const l in c)c[l]!==void 0&&(e[l]=c[l]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const c in i){const l=i[c];e.data.attributes[c]=l.toJSON(e.data)}const r={};let s=!1;for(const c in this.morphAttributes){const l=this.morphAttributes[c],d=[];for(let h=0,u=l.length;h<u;h++){const m=l[h];d.push(m.toJSON(e.data))}d.length>0&&(r[c]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(t));const r=e.attributes;for(const l in r){const d=r[l];this.setAttribute(l,d.clone(t))}const s=e.morphAttributes;for(const l in s){const d=[],h=s[l];for(let u=0,m=h.length;u<m;u++)d.push(h[u].clone(t));this.morphAttributes[l]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let l=0,d=a.length;l<d;l++){const h=a[l];this.addGroup(h.start,h.count,h.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const c=e.boundingSphere;return c!==null&&(this.boundingSphere=c.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Zo=new Qe,Bn=new hr,wr=new lr,jo=new z,hi=new z,ui=new z,di=new z,$s=new z,Tr=new z,Ar=new Oe,Rr=new Oe,Cr=new Oe,Ko=new z,$o=new z,Jo=new z,Pr=new z,Lr=new z;class Ie extends ut{constructor(e=new at,t=new Ri){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){Tr.set(0,0,0);for(let c=0,l=s.length;c<l;c++){const d=o[c],h=s[c];d!==0&&($s.fromBufferAttribute(h,e),a?Tr.addScaledVector($s,d):Tr.addScaledVector($s.sub(t),d))}t.add(Tr)}return t}raycast(e,t){const i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),wr.copy(i.boundingSphere),wr.applyMatrix4(s),Bn.copy(e.ray).recast(e.near),!(wr.containsPoint(Bn.origin)===!1&&(Bn.intersectSphere(wr,jo)===null||Bn.origin.distanceToSquared(jo)>(e.far-e.near)**2))&&(Zo.copy(s).invert(),Bn.copy(e.ray).applyMatrix4(Zo),!(i.boundingBox!==null&&Bn.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,Bn)))}_computeIntersections(e,t,i){let r;const s=this.geometry,a=this.material,o=s.index,c=s.attributes.position,l=s.attributes.uv,d=s.attributes.uv1,h=s.attributes.normal,u=s.groups,m=s.drawRange;if(o!==null)if(Array.isArray(a))for(let M=0,_=u.length;M<_;M++){const p=u[M],f=a[p.materialIndex],x=Math.max(p.start,m.start),g=Math.min(o.count,Math.min(p.start+p.count,m.start+m.count));for(let v=x,C=g;v<C;v+=3){const P=o.getX(v),A=o.getX(v+1),N=o.getX(v+2);r=Dr(this,f,e,i,l,d,h,P,A,N),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const M=Math.max(0,m.start),_=Math.min(o.count,m.start+m.count);for(let p=M,f=_;p<f;p+=3){const x=o.getX(p),g=o.getX(p+1),v=o.getX(p+2);r=Dr(this,a,e,i,l,d,h,x,g,v),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}else if(c!==void 0)if(Array.isArray(a))for(let M=0,_=u.length;M<_;M++){const p=u[M],f=a[p.materialIndex],x=Math.max(p.start,m.start),g=Math.min(c.count,Math.min(p.start+p.count,m.start+m.count));for(let v=x,C=g;v<C;v+=3){const P=v,A=v+1,N=v+2;r=Dr(this,f,e,i,l,d,h,P,A,N),r&&(r.faceIndex=Math.floor(v/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const M=Math.max(0,m.start),_=Math.min(c.count,m.start+m.count);for(let p=M,f=_;p<f;p+=3){const x=p,g=p+1,v=p+2;r=Dr(this,a,e,i,l,d,h,x,g,v),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}}}function uu(n,e,t,i,r,s,a,o){let c;if(e.side===Ft?c=i.intersectTriangle(a,s,r,!0,o):c=i.intersectTriangle(r,s,a,e.side===_n,o),c===null)return null;Lr.copy(o),Lr.applyMatrix4(n.matrixWorld);const l=t.ray.origin.distanceTo(Lr);return l<t.near||l>t.far?null:{distance:l,point:Lr.clone(),object:n}}function Dr(n,e,t,i,r,s,a,o,c,l){n.getVertexPosition(o,hi),n.getVertexPosition(c,ui),n.getVertexPosition(l,di);const d=uu(n,e,t,i,hi,ui,di,Pr);if(d){r&&(Ar.fromBufferAttribute(r,o),Rr.fromBufferAttribute(r,c),Cr.fromBufferAttribute(r,l),d.uv=jt.getInterpolation(Pr,hi,ui,di,Ar,Rr,Cr,new Oe)),s&&(Ar.fromBufferAttribute(s,o),Rr.fromBufferAttribute(s,c),Cr.fromBufferAttribute(s,l),d.uv1=jt.getInterpolation(Pr,hi,ui,di,Ar,Rr,Cr,new Oe),d.uv2=d.uv1),a&&(Ko.fromBufferAttribute(a,o),$o.fromBufferAttribute(a,c),Jo.fromBufferAttribute(a,l),d.normal=jt.getInterpolation(Pr,hi,ui,di,Ko,$o,Jo,new z),d.normal.dot(i.direction)>0&&d.normal.multiplyScalar(-1));const h={a:o,b:c,c:l,normal:new z,materialIndex:0};jt.getNormal(hi,ui,di,h.normal),d.face=h}return d}class vt extends at{constructor(e=1,t=1,i=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const c=[],l=[],d=[],h=[];let u=0,m=0;M("z","y","x",-1,-1,i,t,e,a,s,0),M("z","y","x",1,-1,i,t,-e,a,s,1),M("x","z","y",1,1,e,i,t,r,a,2),M("x","z","y",1,-1,e,i,-t,r,a,3),M("x","y","z",1,-1,e,t,i,r,s,4),M("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(c),this.setAttribute("position",new Ye(l,3)),this.setAttribute("normal",new Ye(d,3)),this.setAttribute("uv",new Ye(h,2));function M(_,p,f,x,g,v,C,P,A,N,E){const w=v/A,H=C/N,U=v/2,W=C/2,L=P/2,I=A+1,k=N+1;let X=0,$=0;const ie=new z;for(let ne=0;ne<k;ne++){const ue=ne*H-W;for(let de=0;de<I;de++){const J=de*w-U;ie[_]=J*x,ie[p]=ue*g,ie[f]=L,l.push(ie.x,ie.y,ie.z),ie[_]=0,ie[p]=0,ie[f]=P>0?1:-1,d.push(ie.x,ie.y,ie.z),h.push(de/A),h.push(1-ne/N),X+=1}}for(let ne=0;ne<N;ne++)for(let ue=0;ue<A;ue++){const de=u+ue+I*ne,J=u+ue+I*(ne+1),se=u+(ue+1)+I*(ne+1),ge=u+(ue+1)+I*ne;c.push(de,J,ge),c.push(J,se,ge),$+=6}o.addGroup(m,$,E),m+=$,u+=X}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new vt(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Ni(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const r=n[t][i];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone():Array.isArray(r)?e[t][i]=r.slice():e[t][i]=r}}return e}function Ut(n){const e={};for(let t=0;t<n.length;t++){const i=Ni(n[t]);for(const r in i)e[r]=i[r]}return e}function du(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function ll(n){return n.getRenderTarget()===null?n.outputColorSpace:et.workingColorSpace}const fu={clone:Ni,merge:Ut};var pu=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,mu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Qn extends Hi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=pu,this.fragmentShader=mu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Ni(e.uniforms),this.uniformsGroups=du(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class hl extends ut{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Qe,this.projectionMatrix=new Qe,this.projectionMatrixInverse=new Qe,this.coordinateSystem=gn}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class Kt extends hl{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=xa*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Is*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return xa*2*Math.atan(Math.tan(Is*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Is*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const c=a.fullWidth,l=a.fullHeight;s+=a.offsetX*r/c,t-=a.offsetY*i/l,r*=a.width/c,i*=a.height/l}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const fi=-90,pi=1;class gu extends ut{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Kt(fi,pi,e,t);r.layers=this.layers,this.add(r);const s=new Kt(fi,pi,e,t);s.layers=this.layers,this.add(s);const a=new Kt(fi,pi,e,t);a.layers=this.layers,this.add(a);const o=new Kt(fi,pi,e,t);o.layers=this.layers,this.add(o);const c=new Kt(fi,pi,e,t);c.layers=this.layers,this.add(c);const l=new Kt(fi,pi,e,t);l.layers=this.layers,this.add(l)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,r,s,a,o,c]=t;for(const l of t)this.remove(l);if(e===gn)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),c.up.set(0,1,0),c.lookAt(0,0,-1);else if(e===ts)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),c.up.set(0,-1,0),c.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const l of t)this.add(l),l.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,c,l,d]=this.children,h=e.getRenderTarget(),u=e.getActiveCubeFace(),m=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const _=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,r),e.render(t,s),e.setRenderTarget(i,1,r),e.render(t,a),e.setRenderTarget(i,2,r),e.render(t,o),e.setRenderTarget(i,3,r),e.render(t,c),e.setRenderTarget(i,4,r),e.render(t,l),i.texture.generateMipmaps=_,e.setRenderTarget(i,5,r),e.render(t,d),e.setRenderTarget(h,u,m),e.xr.enabled=M,i.texture.needsPMREMUpdate=!0}}class ul extends Ot{constructor(e,t,i,r,s,a,o,c,l,d){e=e!==void 0?e:[],t=t!==void 0?t:Di,super(e,t,i,r,s,a,o,c,l,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class _u extends Jn{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];t.encoding!==void 0&&(nr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===$n?mt:$t),this.texture=new ul(r,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Zt}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new vt(5,5,5),s=new Qn({name:"CubemapFromEquirect",uniforms:Ni(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Ft,blending:Cn});s.uniforms.tEquirect.value=t;const a=new Ie(r,s),o=t.minFilter;return t.minFilter===ir&&(t.minFilter=Zt),new gu(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,r){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,r);e.setRenderTarget(s)}}const Js=new z,xu=new z,vu=new Xe;class Wn{constructor(e=new z(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const r=Js.subVectors(i,t).cross(xu.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(Js),r=this.normal.dot(i);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||vu.getNormalMatrix(e),r=this.coplanarPoint(Js).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const kn=new lr,Ur=new z;class Na{constructor(e=new Wn,t=new Wn,i=new Wn,r=new Wn,s=new Wn,a=new Wn){this.planes=[e,t,i,r,s,a]}set(e,t,i,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=gn){const i=this.planes,r=e.elements,s=r[0],a=r[1],o=r[2],c=r[3],l=r[4],d=r[5],h=r[6],u=r[7],m=r[8],M=r[9],_=r[10],p=r[11],f=r[12],x=r[13],g=r[14],v=r[15];if(i[0].setComponents(c-s,u-l,p-m,v-f).normalize(),i[1].setComponents(c+s,u+l,p+m,v+f).normalize(),i[2].setComponents(c+a,u+d,p+M,v+x).normalize(),i[3].setComponents(c-a,u-d,p-M,v-x).normalize(),i[4].setComponents(c-o,u-h,p-_,v-g).normalize(),t===gn)i[5].setComponents(c+o,u+h,p+_,v+g).normalize();else if(t===ts)i[5].setComponents(o,h,_,g).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),kn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),kn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(kn)}intersectsSprite(e){return kn.center.set(0,0,0),kn.radius=.7071067811865476,kn.applyMatrix4(e.matrixWorld),this.intersectsSphere(kn)}intersectsSphere(e){const t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const r=t[i];if(Ur.x=r.normal.x>0?e.max.x:e.min.x,Ur.y=r.normal.y>0?e.max.y:e.min.y,Ur.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ur)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function dl(){let n=null,e=!1,t=null,i=null;function r(s,a){t(s,a),i=n.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function Mu(n,e){const t=e.isWebGL2,i=new WeakMap;function r(l,d){const h=l.array,u=l.usage,m=h.byteLength,M=n.createBuffer();n.bindBuffer(d,M),n.bufferData(d,h,u),l.onUploadCallback();let _;if(h instanceof Float32Array)_=n.FLOAT;else if(h instanceof Uint16Array)if(l.isFloat16BufferAttribute)if(t)_=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else _=n.UNSIGNED_SHORT;else if(h instanceof Int16Array)_=n.SHORT;else if(h instanceof Uint32Array)_=n.UNSIGNED_INT;else if(h instanceof Int32Array)_=n.INT;else if(h instanceof Int8Array)_=n.BYTE;else if(h instanceof Uint8Array)_=n.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)_=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:M,type:_,bytesPerElement:h.BYTES_PER_ELEMENT,version:l.version,size:m}}function s(l,d,h){const u=d.array,m=d._updateRange,M=d.updateRanges;if(n.bindBuffer(h,l),m.count===-1&&M.length===0&&n.bufferSubData(h,0,u),M.length!==0){for(let _=0,p=M.length;_<p;_++){const f=M[_];t?n.bufferSubData(h,f.start*u.BYTES_PER_ELEMENT,u,f.start,f.count):n.bufferSubData(h,f.start*u.BYTES_PER_ELEMENT,u.subarray(f.start,f.start+f.count))}d.clearUpdateRanges()}m.count!==-1&&(t?n.bufferSubData(h,m.offset*u.BYTES_PER_ELEMENT,u,m.offset,m.count):n.bufferSubData(h,m.offset*u.BYTES_PER_ELEMENT,u.subarray(m.offset,m.offset+m.count)),m.count=-1),d.onUploadCallback()}function a(l){return l.isInterleavedBufferAttribute&&(l=l.data),i.get(l)}function o(l){l.isInterleavedBufferAttribute&&(l=l.data);const d=i.get(l);d&&(n.deleteBuffer(d.buffer),i.delete(l))}function c(l,d){if(l.isGLBufferAttribute){const u=i.get(l);(!u||u.version<l.version)&&i.set(l,{buffer:l.buffer,type:l.type,bytesPerElement:l.elementSize,version:l.version});return}l.isInterleavedBufferAttribute&&(l=l.data);const h=i.get(l);if(h===void 0)i.set(l,r(l,d));else if(h.version<l.version){if(h.size!==l.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(h.buffer,l,d),h.version=l.version}}return{get:a,remove:o,update:c}}class Un extends at{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(i),c=Math.floor(r),l=o+1,d=c+1,h=e/o,u=t/c,m=[],M=[],_=[],p=[];for(let f=0;f<d;f++){const x=f*u-a;for(let g=0;g<l;g++){const v=g*h-s;M.push(v,-x,0),_.push(0,0,1),p.push(g/o),p.push(1-f/c)}}for(let f=0;f<c;f++)for(let x=0;x<o;x++){const g=x+l*f,v=x+l*(f+1),C=x+1+l*(f+1),P=x+1+l*f;m.push(g,v,P),m.push(v,C,P)}this.setIndex(m),this.setAttribute("position",new Ye(M,3)),this.setAttribute("normal",new Ye(_,3)),this.setAttribute("uv",new Ye(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Un(e.width,e.height,e.widthSegments,e.heightSegments)}}var yu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Su=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,bu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Eu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,wu=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Tu=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Au=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Ru=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Cu=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Pu=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Lu=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Du=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Uu=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Iu=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Nu=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,zu=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,Fu=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Ou=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Bu=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,ku=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Gu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Hu=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,Vu=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,Wu=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Xu=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,qu=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,Yu=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Zu=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,ju=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Ku=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,$u="gl_FragColor = linearToOutputTexel( gl_FragColor );",Ju=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,Qu=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,ed=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,td=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,nd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,id=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,rd=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,sd=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,ad=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,od=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,cd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,ld=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,hd=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,ud=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,dd=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,fd=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,pd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,md=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,gd=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,_d=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,xd=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,vd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Md=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,yd=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Sd=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,bd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Ed=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,wd=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Td=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,Ad=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Rd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Cd=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Pd=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Ld=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Dd=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Ud=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Id=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Nd=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,zd=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,Fd=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,Od=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Bd=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,kd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Gd=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Hd=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Vd=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Wd=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Xd=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,qd=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Yd=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Zd=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,jd=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,Kd=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,$d=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,Jd=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Qd=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,ef=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,tf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,nf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,rf=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,sf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,af=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,of=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,cf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,lf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,hf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,uf=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,df=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,ff=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,pf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,mf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,gf=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,_f=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,xf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,vf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Mf=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const yf=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Sf=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,bf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ef=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,wf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Tf=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Af=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Rf=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,Cf=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Pf=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Lf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Df=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Uf=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,If=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Nf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,zf=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ff=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Of=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Bf=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,kf=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Gf=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Hf=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Vf=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Wf=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xf=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,qf=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Yf=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zf=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jf=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Kf=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,$f=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Jf=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Qf=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,ep=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,We={alphahash_fragment:yu,alphahash_pars_fragment:Su,alphamap_fragment:bu,alphamap_pars_fragment:Eu,alphatest_fragment:wu,alphatest_pars_fragment:Tu,aomap_fragment:Au,aomap_pars_fragment:Ru,batching_pars_vertex:Cu,batching_vertex:Pu,begin_vertex:Lu,beginnormal_vertex:Du,bsdfs:Uu,iridescence_fragment:Iu,bumpmap_pars_fragment:Nu,clipping_planes_fragment:zu,clipping_planes_pars_fragment:Fu,clipping_planes_pars_vertex:Ou,clipping_planes_vertex:Bu,color_fragment:ku,color_pars_fragment:Gu,color_pars_vertex:Hu,color_vertex:Vu,common:Wu,cube_uv_reflection_fragment:Xu,defaultnormal_vertex:qu,displacementmap_pars_vertex:Yu,displacementmap_vertex:Zu,emissivemap_fragment:ju,emissivemap_pars_fragment:Ku,colorspace_fragment:$u,colorspace_pars_fragment:Ju,envmap_fragment:Qu,envmap_common_pars_fragment:ed,envmap_pars_fragment:td,envmap_pars_vertex:nd,envmap_physical_pars_fragment:pd,envmap_vertex:id,fog_vertex:rd,fog_pars_vertex:sd,fog_fragment:ad,fog_pars_fragment:od,gradientmap_pars_fragment:cd,lightmap_fragment:ld,lightmap_pars_fragment:hd,lights_lambert_fragment:ud,lights_lambert_pars_fragment:dd,lights_pars_begin:fd,lights_toon_fragment:md,lights_toon_pars_fragment:gd,lights_phong_fragment:_d,lights_phong_pars_fragment:xd,lights_physical_fragment:vd,lights_physical_pars_fragment:Md,lights_fragment_begin:yd,lights_fragment_maps:Sd,lights_fragment_end:bd,logdepthbuf_fragment:Ed,logdepthbuf_pars_fragment:wd,logdepthbuf_pars_vertex:Td,logdepthbuf_vertex:Ad,map_fragment:Rd,map_pars_fragment:Cd,map_particle_fragment:Pd,map_particle_pars_fragment:Ld,metalnessmap_fragment:Dd,metalnessmap_pars_fragment:Ud,morphcolor_vertex:Id,morphnormal_vertex:Nd,morphtarget_pars_vertex:zd,morphtarget_vertex:Fd,normal_fragment_begin:Od,normal_fragment_maps:Bd,normal_pars_fragment:kd,normal_pars_vertex:Gd,normal_vertex:Hd,normalmap_pars_fragment:Vd,clearcoat_normal_fragment_begin:Wd,clearcoat_normal_fragment_maps:Xd,clearcoat_pars_fragment:qd,iridescence_pars_fragment:Yd,opaque_fragment:Zd,packing:jd,premultiplied_alpha_fragment:Kd,project_vertex:$d,dithering_fragment:Jd,dithering_pars_fragment:Qd,roughnessmap_fragment:ef,roughnessmap_pars_fragment:tf,shadowmap_pars_fragment:nf,shadowmap_pars_vertex:rf,shadowmap_vertex:sf,shadowmask_pars_fragment:af,skinbase_vertex:of,skinning_pars_vertex:cf,skinning_vertex:lf,skinnormal_vertex:hf,specularmap_fragment:uf,specularmap_pars_fragment:df,tonemapping_fragment:ff,tonemapping_pars_fragment:pf,transmission_fragment:mf,transmission_pars_fragment:gf,uv_pars_fragment:_f,uv_pars_vertex:xf,uv_vertex:vf,worldpos_vertex:Mf,background_vert:yf,background_frag:Sf,backgroundCube_vert:bf,backgroundCube_frag:Ef,cube_vert:wf,cube_frag:Tf,depth_vert:Af,depth_frag:Rf,distanceRGBA_vert:Cf,distanceRGBA_frag:Pf,equirect_vert:Lf,equirect_frag:Df,linedashed_vert:Uf,linedashed_frag:If,meshbasic_vert:Nf,meshbasic_frag:zf,meshlambert_vert:Ff,meshlambert_frag:Of,meshmatcap_vert:Bf,meshmatcap_frag:kf,meshnormal_vert:Gf,meshnormal_frag:Hf,meshphong_vert:Vf,meshphong_frag:Wf,meshphysical_vert:Xf,meshphysical_frag:qf,meshtoon_vert:Yf,meshtoon_frag:Zf,points_vert:jf,points_frag:Kf,shadow_vert:$f,shadow_frag:Jf,sprite_vert:Qf,sprite_frag:ep},xe={common:{diffuse:{value:new je(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Xe},alphaMap:{value:null},alphaMapTransform:{value:new Xe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Xe}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Xe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Xe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Xe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Xe},normalScale:{value:new Oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Xe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Xe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Xe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Xe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new je(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new je(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Xe},alphaTest:{value:0},uvTransform:{value:new Xe}},sprite:{diffuse:{value:new je(16777215)},opacity:{value:1},center:{value:new Oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Xe},alphaMap:{value:null},alphaMapTransform:{value:new Xe},alphaTest:{value:0}}},on={basic:{uniforms:Ut([xe.common,xe.specularmap,xe.envmap,xe.aomap,xe.lightmap,xe.fog]),vertexShader:We.meshbasic_vert,fragmentShader:We.meshbasic_frag},lambert:{uniforms:Ut([xe.common,xe.specularmap,xe.envmap,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.fog,xe.lights,{emissive:{value:new je(0)}}]),vertexShader:We.meshlambert_vert,fragmentShader:We.meshlambert_frag},phong:{uniforms:Ut([xe.common,xe.specularmap,xe.envmap,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.fog,xe.lights,{emissive:{value:new je(0)},specular:{value:new je(1118481)},shininess:{value:30}}]),vertexShader:We.meshphong_vert,fragmentShader:We.meshphong_frag},standard:{uniforms:Ut([xe.common,xe.envmap,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.roughnessmap,xe.metalnessmap,xe.fog,xe.lights,{emissive:{value:new je(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:We.meshphysical_vert,fragmentShader:We.meshphysical_frag},toon:{uniforms:Ut([xe.common,xe.aomap,xe.lightmap,xe.emissivemap,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.gradientmap,xe.fog,xe.lights,{emissive:{value:new je(0)}}]),vertexShader:We.meshtoon_vert,fragmentShader:We.meshtoon_frag},matcap:{uniforms:Ut([xe.common,xe.bumpmap,xe.normalmap,xe.displacementmap,xe.fog,{matcap:{value:null}}]),vertexShader:We.meshmatcap_vert,fragmentShader:We.meshmatcap_frag},points:{uniforms:Ut([xe.points,xe.fog]),vertexShader:We.points_vert,fragmentShader:We.points_frag},dashed:{uniforms:Ut([xe.common,xe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:We.linedashed_vert,fragmentShader:We.linedashed_frag},depth:{uniforms:Ut([xe.common,xe.displacementmap]),vertexShader:We.depth_vert,fragmentShader:We.depth_frag},normal:{uniforms:Ut([xe.common,xe.bumpmap,xe.normalmap,xe.displacementmap,{opacity:{value:1}}]),vertexShader:We.meshnormal_vert,fragmentShader:We.meshnormal_frag},sprite:{uniforms:Ut([xe.sprite,xe.fog]),vertexShader:We.sprite_vert,fragmentShader:We.sprite_frag},background:{uniforms:{uvTransform:{value:new Xe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:We.background_vert,fragmentShader:We.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:We.backgroundCube_vert,fragmentShader:We.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:We.cube_vert,fragmentShader:We.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:We.equirect_vert,fragmentShader:We.equirect_frag},distanceRGBA:{uniforms:Ut([xe.common,xe.displacementmap,{referencePosition:{value:new z},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:We.distanceRGBA_vert,fragmentShader:We.distanceRGBA_frag},shadow:{uniforms:Ut([xe.lights,xe.fog,{color:{value:new je(0)},opacity:{value:1}}]),vertexShader:We.shadow_vert,fragmentShader:We.shadow_frag}};on.physical={uniforms:Ut([on.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Xe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Xe},clearcoatNormalScale:{value:new Oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Xe},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Xe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Xe},sheen:{value:0},sheenColor:{value:new je(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Xe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Xe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Xe},transmissionSamplerSize:{value:new Oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Xe},attenuationDistance:{value:0},attenuationColor:{value:new je(0)},specularColor:{value:new je(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Xe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Xe},anisotropyVector:{value:new Oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Xe}}]),vertexShader:We.meshphysical_vert,fragmentShader:We.meshphysical_frag};const Ir={r:0,b:0,g:0};function tp(n,e,t,i,r,s,a){const o=new je(0);let c=s===!0?0:1,l,d,h=null,u=0,m=null;function M(p,f){let x=!1,g=f.isScene===!0?f.background:null;g&&g.isTexture&&(g=(f.backgroundBlurriness>0?t:e).get(g)),g===null?_(o,c):g&&g.isColor&&(_(g,1),x=!0);const v=n.xr.getEnvironmentBlendMode();v==="additive"?i.buffers.color.setClear(0,0,0,1,a):v==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||x)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),g&&(g.isCubeTexture||g.mapping===us)?(d===void 0&&(d=new Ie(new vt(1,1,1),new Qn({name:"BackgroundCubeMaterial",uniforms:Ni(on.backgroundCube.uniforms),vertexShader:on.backgroundCube.vertexShader,fragmentShader:on.backgroundCube.fragmentShader,side:Ft,depthTest:!1,depthWrite:!1,fog:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(C,P,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(d)),d.material.uniforms.envMap.value=g,d.material.uniforms.flipEnvMap.value=g.isCubeTexture&&g.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,d.material.toneMapped=et.getTransfer(g.colorSpace)!==ot,(h!==g||u!==g.version||m!==n.toneMapping)&&(d.material.needsUpdate=!0,h=g,u=g.version,m=n.toneMapping),d.layers.enableAll(),p.unshift(d,d.geometry,d.material,0,0,null)):g&&g.isTexture&&(l===void 0&&(l=new Ie(new Un(2,2),new Qn({name:"BackgroundMaterial",uniforms:Ni(on.background.uniforms),vertexShader:on.background.vertexShader,fragmentShader:on.background.fragmentShader,side:_n,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(l)),l.material.uniforms.t2D.value=g,l.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,l.material.toneMapped=et.getTransfer(g.colorSpace)!==ot,g.matrixAutoUpdate===!0&&g.updateMatrix(),l.material.uniforms.uvTransform.value.copy(g.matrix),(h!==g||u!==g.version||m!==n.toneMapping)&&(l.material.needsUpdate=!0,h=g,u=g.version,m=n.toneMapping),l.layers.enableAll(),p.unshift(l,l.geometry,l.material,0,0,null))}function _(p,f){p.getRGB(Ir,ll(n)),i.buffers.color.setClear(Ir.r,Ir.g,Ir.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(p,f=1){o.set(p),c=f,_(o,c)},getClearAlpha:function(){return c},setClearAlpha:function(p){c=p,_(o,c)},render:M}}function np(n,e,t,i){const r=n.getParameter(n.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},c=p(null);let l=c,d=!1;function h(L,I,k,X,$){let ie=!1;if(a){const ne=_(X,k,I);l!==ne&&(l=ne,m(l.object)),ie=f(L,X,k,$),ie&&x(L,X,k,$)}else{const ne=I.wireframe===!0;(l.geometry!==X.id||l.program!==k.id||l.wireframe!==ne)&&(l.geometry=X.id,l.program=k.id,l.wireframe=ne,ie=!0)}$!==null&&t.update($,n.ELEMENT_ARRAY_BUFFER),(ie||d)&&(d=!1,N(L,I,k,X),$!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,t.get($).buffer))}function u(){return i.isWebGL2?n.createVertexArray():s.createVertexArrayOES()}function m(L){return i.isWebGL2?n.bindVertexArray(L):s.bindVertexArrayOES(L)}function M(L){return i.isWebGL2?n.deleteVertexArray(L):s.deleteVertexArrayOES(L)}function _(L,I,k){const X=k.wireframe===!0;let $=o[L.id];$===void 0&&($={},o[L.id]=$);let ie=$[I.id];ie===void 0&&(ie={},$[I.id]=ie);let ne=ie[X];return ne===void 0&&(ne=p(u()),ie[X]=ne),ne}function p(L){const I=[],k=[],X=[];for(let $=0;$<r;$++)I[$]=0,k[$]=0,X[$]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:I,enabledAttributes:k,attributeDivisors:X,object:L,attributes:{},index:null}}function f(L,I,k,X){const $=l.attributes,ie=I.attributes;let ne=0;const ue=k.getAttributes();for(const de in ue)if(ue[de].location>=0){const se=$[de];let ge=ie[de];if(ge===void 0&&(de==="instanceMatrix"&&L.instanceMatrix&&(ge=L.instanceMatrix),de==="instanceColor"&&L.instanceColor&&(ge=L.instanceColor)),se===void 0||se.attribute!==ge||ge&&se.data!==ge.data)return!0;ne++}return l.attributesNum!==ne||l.index!==X}function x(L,I,k,X){const $={},ie=I.attributes;let ne=0;const ue=k.getAttributes();for(const de in ue)if(ue[de].location>=0){let se=ie[de];se===void 0&&(de==="instanceMatrix"&&L.instanceMatrix&&(se=L.instanceMatrix),de==="instanceColor"&&L.instanceColor&&(se=L.instanceColor));const ge={};ge.attribute=se,se&&se.data&&(ge.data=se.data),$[de]=ge,ne++}l.attributes=$,l.attributesNum=ne,l.index=X}function g(){const L=l.newAttributes;for(let I=0,k=L.length;I<k;I++)L[I]=0}function v(L){C(L,0)}function C(L,I){const k=l.newAttributes,X=l.enabledAttributes,$=l.attributeDivisors;k[L]=1,X[L]===0&&(n.enableVertexAttribArray(L),X[L]=1),$[L]!==I&&((i.isWebGL2?n:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,I),$[L]=I)}function P(){const L=l.newAttributes,I=l.enabledAttributes;for(let k=0,X=I.length;k<X;k++)I[k]!==L[k]&&(n.disableVertexAttribArray(k),I[k]=0)}function A(L,I,k,X,$,ie,ne){ne===!0?n.vertexAttribIPointer(L,I,k,$,ie):n.vertexAttribPointer(L,I,k,X,$,ie)}function N(L,I,k,X){if(i.isWebGL2===!1&&(L.isInstancedMesh||X.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;g();const $=X.attributes,ie=k.getAttributes(),ne=I.defaultAttributeValues;for(const ue in ie){const de=ie[ue];if(de.location>=0){let J=$[ue];if(J===void 0&&(ue==="instanceMatrix"&&L.instanceMatrix&&(J=L.instanceMatrix),ue==="instanceColor"&&L.instanceColor&&(J=L.instanceColor)),J!==void 0){const se=J.normalized,ge=J.itemSize,Ae=t.get(J);if(Ae===void 0)continue;const Ee=Ae.buffer,Be=Ae.type,ke=Ae.bytesPerElement,De=i.isWebGL2===!0&&(Be===n.INT||Be===n.UNSIGNED_INT||J.gpuType===qc);if(J.isInterleavedBufferAttribute){const S=J.data,y=S.stride,G=J.offset;if(S.isInstancedInterleavedBuffer){for(let F=0;F<de.locationSize;F++)C(de.location+F,S.meshPerAttribute);L.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=S.meshPerAttribute*S.count)}else for(let F=0;F<de.locationSize;F++)v(de.location+F);n.bindBuffer(n.ARRAY_BUFFER,Ee);for(let F=0;F<de.locationSize;F++)A(de.location+F,ge/de.locationSize,Be,se,y*ke,(G+ge/de.locationSize*F)*ke,De)}else{if(J.isInstancedBufferAttribute){for(let S=0;S<de.locationSize;S++)C(de.location+S,J.meshPerAttribute);L.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let S=0;S<de.locationSize;S++)v(de.location+S);n.bindBuffer(n.ARRAY_BUFFER,Ee);for(let S=0;S<de.locationSize;S++)A(de.location+S,ge/de.locationSize,Be,se,ge*ke,ge/de.locationSize*S*ke,De)}}else if(ne!==void 0){const se=ne[ue];if(se!==void 0)switch(se.length){case 2:n.vertexAttrib2fv(de.location,se);break;case 3:n.vertexAttrib3fv(de.location,se);break;case 4:n.vertexAttrib4fv(de.location,se);break;default:n.vertexAttrib1fv(de.location,se)}}}}P()}function E(){U();for(const L in o){const I=o[L];for(const k in I){const X=I[k];for(const $ in X)M(X[$].object),delete X[$];delete I[k]}delete o[L]}}function w(L){if(o[L.id]===void 0)return;const I=o[L.id];for(const k in I){const X=I[k];for(const $ in X)M(X[$].object),delete X[$];delete I[k]}delete o[L.id]}function H(L){for(const I in o){const k=o[I];if(k[L.id]===void 0)continue;const X=k[L.id];for(const $ in X)M(X[$].object),delete X[$];delete k[L.id]}}function U(){W(),d=!0,l!==c&&(l=c,m(l.object))}function W(){c.geometry=null,c.program=null,c.wireframe=!1}return{setup:h,reset:U,resetDefaultState:W,dispose:E,releaseStatesOfGeometry:w,releaseStatesOfProgram:H,initAttributes:g,enableAttribute:v,disableUnusedAttributes:P}}function ip(n,e,t,i){const r=i.isWebGL2;let s;function a(d){s=d}function o(d,h){n.drawArrays(s,d,h),t.update(h,s,1)}function c(d,h,u){if(u===0)return;let m,M;if(r)m=n,M="drawArraysInstanced";else if(m=e.get("ANGLE_instanced_arrays"),M="drawArraysInstancedANGLE",m===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[M](s,d,h,u),t.update(h,s,u)}function l(d,h,u){if(u===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let M=0;M<u;M++)this.render(d[M],h[M]);else{m.multiDrawArraysWEBGL(s,d,0,h,0,u);let M=0;for(let _=0;_<u;_++)M+=h[_];t.update(M,s,1)}}this.setMode=a,this.render=o,this.renderInstances=c,this.renderMultiDraw=l}function rp(n,e,t){let i;function r(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");i=n.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function s(A){if(A==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext";let o=t.precision!==void 0?t.precision:"highp";const c=s(o);c!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",c,"instead."),o=c);const l=a||e.has("WEBGL_draw_buffers"),d=t.logarithmicDepthBuffer===!0,h=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),u=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),m=n.getParameter(n.MAX_TEXTURE_SIZE),M=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),_=n.getParameter(n.MAX_VERTEX_ATTRIBS),p=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),f=n.getParameter(n.MAX_VARYING_VECTORS),x=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),g=u>0,v=a||e.has("OES_texture_float"),C=g&&v,P=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:l,getMaxAnisotropy:r,getMaxPrecision:s,precision:o,logarithmicDepthBuffer:d,maxTextures:h,maxVertexTextures:u,maxTextureSize:m,maxCubemapSize:M,maxAttributes:_,maxVertexUniforms:p,maxVaryings:f,maxFragmentUniforms:x,vertexTextures:g,floatFragmentTextures:v,floatVertexTextures:C,maxSamples:P}}function sp(n){const e=this;let t=null,i=0,r=!1,s=!1;const a=new Wn,o=new Xe,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(h,u){const m=h.length!==0||u||i!==0||r;return r=u,i=h.length,m},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(h,u){t=d(h,u,0)},this.setState=function(h,u,m){const M=h.clippingPlanes,_=h.clipIntersection,p=h.clipShadows,f=n.get(h);if(!r||M===null||M.length===0||s&&!p)s?d(null):l();else{const x=s?0:i,g=x*4;let v=f.clippingState||null;c.value=v,v=d(M,u,g,m);for(let C=0;C!==g;++C)v[C]=t[C];f.clippingState=v,this.numIntersection=_?this.numPlanes:0,this.numPlanes+=x}};function l(){c.value!==t&&(c.value=t,c.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function d(h,u,m,M){const _=h!==null?h.length:0;let p=null;if(_!==0){if(p=c.value,M!==!0||p===null){const f=m+_*4,x=u.matrixWorldInverse;o.getNormalMatrix(x),(p===null||p.length<f)&&(p=new Float32Array(f));for(let g=0,v=m;g!==_;++g,v+=4)a.copy(h[g]).applyMatrix4(x,o),a.normal.toArray(p,v),p[v+3]=a.constant}c.value=p,c.needsUpdate=!0}return e.numPlanes=_,e.numIntersection=0,p}}function ap(n){let e=new WeakMap;function t(a,o){return o===da?a.mapping=Di:o===fa&&(a.mapping=Ui),a}function i(a){if(a&&a.isTexture){const o=a.mapping;if(o===da||o===fa)if(e.has(a)){const c=e.get(a).texture;return t(c,a.mapping)}else{const c=a.image;if(c&&c.height>0){const l=new _u(c.height/2);return l.fromEquirectangularTexture(n,a),e.set(a,l),a.addEventListener("dispose",r),t(l.texture,a.mapping)}else return null}}return a}function r(a){const o=a.target;o.removeEventListener("dispose",r);const c=e.get(o);c!==void 0&&(e.delete(o),c.dispose())}function s(){e=new WeakMap}return{get:i,dispose:s}}class za extends hl{constructor(e=-1,t=1,i=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=i-e,a=i+e,o=r+t,c=r-t;if(this.view!==null&&this.view.enabled){const l=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=l*this.view.offsetX,a=s+l*this.view.width,o-=d*this.view.offsetY,c=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,c,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const Ei=4,Qo=[.125,.215,.35,.446,.526,.582],Yn=20,Qs=new za,ec=new je;let ea=null,ta=0,na=0;const Xn=(1+Math.sqrt(5))/2,mi=1/Xn,tc=[new z(1,1,1),new z(-1,1,1),new z(1,1,-1),new z(-1,1,-1),new z(0,Xn,mi),new z(0,Xn,-mi),new z(mi,0,Xn),new z(-mi,0,Xn),new z(Xn,mi,0),new z(-Xn,mi,0)];class nc{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,r=100){ea=this._renderer.getRenderTarget(),ta=this._renderer.getActiveCubeFace(),na=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,r,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=sc(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=rc(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(ea,ta,na),e.scissorTest=!1,Nr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Di||e.mapping===Ui?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ea=this._renderer.getRenderTarget(),ta=this._renderer.getActiveCubeFace(),na=this._renderer.getActiveMipmapLevel();const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Zt,minFilter:Zt,generateMipmaps:!1,type:rr,format:sn,colorSpace:xn,depthBuffer:!1},r=ic(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=ic(e,t,i);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=op(s)),this._blurMaterial=cp(s,e,t)}return r}_compileMaterial(e){const t=new Ie(this._lodPlanes[0],e);this._renderer.compile(t,Qs)}_sceneToCubeUV(e,t,i,r){const o=new Kt(90,1,t,i),c=[1,-1,1,1,1,1],l=[1,1,1,-1,-1,-1],d=this._renderer,h=d.autoClear,u=d.toneMapping;d.getClearColor(ec),d.toneMapping=Pn,d.autoClear=!1;const m=new Ri({name:"PMREM.Background",side:Ft,depthWrite:!1,depthTest:!1}),M=new Ie(new vt,m);let _=!1;const p=e.background;p?p.isColor&&(m.color.copy(p),e.background=null,_=!0):(m.color.copy(ec),_=!0);for(let f=0;f<6;f++){const x=f%3;x===0?(o.up.set(0,c[f],0),o.lookAt(l[f],0,0)):x===1?(o.up.set(0,0,c[f]),o.lookAt(0,l[f],0)):(o.up.set(0,c[f],0),o.lookAt(0,0,l[f]));const g=this._cubeSize;Nr(r,x*g,f>2?g:0,g,g),d.setRenderTarget(r),_&&d.render(M,o),d.render(e,o)}M.geometry.dispose(),M.material.dispose(),d.toneMapping=u,d.autoClear=h,e.background=p}_textureToCubeUV(e,t){const i=this._renderer,r=e.mapping===Di||e.mapping===Ui;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=sc()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=rc());const s=r?this._cubemapMaterial:this._equirectMaterial,a=new Ie(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;const c=this._cubeSize;Nr(t,0,0,3*c,2*c),i.setRenderTarget(t),i.render(a,Qs)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let r=1;r<this._lodPlanes.length;r++){const s=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=tc[(r-1)%tc.length];this._blur(e,r-1,r,s,a)}t.autoClear=i}_blur(e,t,i,r,s){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,r,"latitudinal",s),this._halfBlur(a,e,i,i,r,"longitudinal",s)}_halfBlur(e,t,i,r,s,a,o){const c=this._renderer,l=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,h=new Ie(this._lodPlanes[r],l),u=l.uniforms,m=this._sizeLods[i]-1,M=isFinite(s)?Math.PI/(2*m):2*Math.PI/(2*Yn-1),_=s/M,p=isFinite(s)?1+Math.floor(d*_):Yn;p>Yn&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${Yn}`);const f=[];let x=0;for(let A=0;A<Yn;++A){const N=A/_,E=Math.exp(-N*N/2);f.push(E),A===0?x+=E:A<p&&(x+=2*E)}for(let A=0;A<f.length;A++)f[A]=f[A]/x;u.envMap.value=e.texture,u.samples.value=p,u.weights.value=f,u.latitudinal.value=a==="latitudinal",o&&(u.poleAxis.value=o);const{_lodMax:g}=this;u.dTheta.value=M,u.mipInt.value=g-i;const v=this._sizeLods[r],C=3*v*(r>g-Ei?r-g+Ei:0),P=4*(this._cubeSize-v);Nr(t,C,P,3*v,2*v),c.setRenderTarget(t),c.render(h,Qs)}}function op(n){const e=[],t=[],i=[];let r=n;const s=n-Ei+1+Qo.length;for(let a=0;a<s;a++){const o=Math.pow(2,r);t.push(o);let c=1/o;a>n-Ei?c=Qo[a-n+Ei-1]:a===0&&(c=0),i.push(c);const l=1/(o-2),d=-l,h=1+l,u=[d,d,h,d,h,h,d,d,h,h,d,h],m=6,M=6,_=3,p=2,f=1,x=new Float32Array(_*M*m),g=new Float32Array(p*M*m),v=new Float32Array(f*M*m);for(let P=0;P<m;P++){const A=P%3*2/3-1,N=P>2?0:-1,E=[A,N,0,A+2/3,N,0,A+2/3,N+1,0,A,N,0,A+2/3,N+1,0,A,N+1,0];x.set(E,_*M*P),g.set(u,p*M*P);const w=[P,P,P,P,P,P];v.set(w,f*M*P)}const C=new at;C.setAttribute("position",new Qt(x,_)),C.setAttribute("uv",new Qt(g,p)),C.setAttribute("faceIndex",new Qt(v,f)),e.push(C),r>Ei&&r--}return{lodPlanes:e,sizeLods:t,sigmas:i}}function ic(n,e,t){const i=new Jn(n,e,t);return i.texture.mapping=us,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Nr(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function cp(n,e,t){const i=new Float32Array(Yn),r=new z(0,1,0);return new Qn({name:"SphericalGaussianBlur",defines:{n:Yn,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Fa(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Cn,depthTest:!1,depthWrite:!1})}function rc(){return new Qn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Fa(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Cn,depthTest:!1,depthWrite:!1})}function sc(){return new Qn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Fa(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Cn,depthTest:!1,depthWrite:!1})}function Fa(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function lp(n){let e=new WeakMap,t=null;function i(o){if(o&&o.isTexture){const c=o.mapping,l=c===da||c===fa,d=c===Di||c===Ui;if(l||d)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let h=e.get(o);return t===null&&(t=new nc(n)),h=l?t.fromEquirectangular(o,h):t.fromCubemap(o,h),e.set(o,h),h.texture}else{if(e.has(o))return e.get(o).texture;{const h=o.image;if(l&&h&&h.height>0||d&&h&&r(h)){t===null&&(t=new nc(n));const u=l?t.fromEquirectangular(o):t.fromCubemap(o);return e.set(o,u),o.addEventListener("dispose",s),u.texture}else return null}}}return o}function r(o){let c=0;const l=6;for(let d=0;d<l;d++)o[d]!==void 0&&c++;return c===l}function s(o){const c=o.target;c.removeEventListener("dispose",s);const l=e.get(c);l!==void 0&&(e.delete(c),l.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:a}}function hp(n){const e={};function t(i){if(e[i]!==void 0)return e[i];let r;switch(i){case"WEBGL_depth_texture":r=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=n.getExtension(i)}return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){const r=t(i);return r===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),r}}}function up(n,e,t,i){const r={},s=new WeakMap;function a(h){const u=h.target;u.index!==null&&e.remove(u.index);for(const M in u.attributes)e.remove(u.attributes[M]);for(const M in u.morphAttributes){const _=u.morphAttributes[M];for(let p=0,f=_.length;p<f;p++)e.remove(_[p])}u.removeEventListener("dispose",a),delete r[u.id];const m=s.get(u);m&&(e.remove(m),s.delete(u)),i.releaseStatesOfGeometry(u),u.isInstancedBufferGeometry===!0&&delete u._maxInstanceCount,t.memory.geometries--}function o(h,u){return r[u.id]===!0||(u.addEventListener("dispose",a),r[u.id]=!0,t.memory.geometries++),u}function c(h){const u=h.attributes;for(const M in u)e.update(u[M],n.ARRAY_BUFFER);const m=h.morphAttributes;for(const M in m){const _=m[M];for(let p=0,f=_.length;p<f;p++)e.update(_[p],n.ARRAY_BUFFER)}}function l(h){const u=[],m=h.index,M=h.attributes.position;let _=0;if(m!==null){const x=m.array;_=m.version;for(let g=0,v=x.length;g<v;g+=3){const C=x[g+0],P=x[g+1],A=x[g+2];u.push(C,P,P,A,A,C)}}else if(M!==void 0){const x=M.array;_=M.version;for(let g=0,v=x.length/3-1;g<v;g+=3){const C=g+0,P=g+1,A=g+2;u.push(C,P,P,A,A,C)}}else return;const p=new(nl(u)?cl:ol)(u,1);p.version=_;const f=s.get(h);f&&e.remove(f),s.set(h,p)}function d(h){const u=s.get(h);if(u){const m=h.index;m!==null&&u.version<m.version&&l(h)}else l(h);return s.get(h)}return{get:o,update:c,getWireframeAttribute:d}}function dp(n,e,t,i){const r=i.isWebGL2;let s;function a(m){s=m}let o,c;function l(m){o=m.type,c=m.bytesPerElement}function d(m,M){n.drawElements(s,M,o,m*c),t.update(M,s,1)}function h(m,M,_){if(_===0)return;let p,f;if(r)p=n,f="drawElementsInstanced";else if(p=e.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",p===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[f](s,M,o,m*c,_),t.update(M,s,_)}function u(m,M,_){if(_===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let f=0;f<_;f++)this.render(m[f]/c,M[f]);else{p.multiDrawElementsWEBGL(s,M,0,o,m,0,_);let f=0;for(let x=0;x<_;x++)f+=M[x];t.update(f,s,1)}}this.setMode=a,this.setIndex=l,this.render=d,this.renderInstances=h,this.renderMultiDraw=u}function fp(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,a,o){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=o*(s/3);break;case n.LINES:t.lines+=o*(s/2);break;case n.LINE_STRIP:t.lines+=o*(s-1);break;case n.LINE_LOOP:t.lines+=o*s;break;case n.POINTS:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function pp(n,e){return n[0]-e[0]}function mp(n,e){return Math.abs(e[1])-Math.abs(n[1])}function gp(n,e,t){const i={},r=new Float32Array(8),s=new WeakMap,a=new wt,o=[];for(let l=0;l<8;l++)o[l]=[l,0];function c(l,d,h){const u=l.morphTargetInfluences;if(e.isWebGL2===!0){const M=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,_=M!==void 0?M.length:0;let p=s.get(d);if(p===void 0||p.count!==_){let I=function(){W.dispose(),s.delete(d),d.removeEventListener("dispose",I)};var m=I;p!==void 0&&p.texture.dispose();const g=d.morphAttributes.position!==void 0,v=d.morphAttributes.normal!==void 0,C=d.morphAttributes.color!==void 0,P=d.morphAttributes.position||[],A=d.morphAttributes.normal||[],N=d.morphAttributes.color||[];let E=0;g===!0&&(E=1),v===!0&&(E=2),C===!0&&(E=3);let w=d.attributes.position.count*E,H=1;w>e.maxTextureSize&&(H=Math.ceil(w/e.maxTextureSize),w=e.maxTextureSize);const U=new Float32Array(w*H*4*_),W=new sl(U,w,H,_);W.type=An,W.needsUpdate=!0;const L=E*4;for(let k=0;k<_;k++){const X=P[k],$=A[k],ie=N[k],ne=w*H*4*k;for(let ue=0;ue<X.count;ue++){const de=ue*L;g===!0&&(a.fromBufferAttribute(X,ue),U[ne+de+0]=a.x,U[ne+de+1]=a.y,U[ne+de+2]=a.z,U[ne+de+3]=0),v===!0&&(a.fromBufferAttribute($,ue),U[ne+de+4]=a.x,U[ne+de+5]=a.y,U[ne+de+6]=a.z,U[ne+de+7]=0),C===!0&&(a.fromBufferAttribute(ie,ue),U[ne+de+8]=a.x,U[ne+de+9]=a.y,U[ne+de+10]=a.z,U[ne+de+11]=ie.itemSize===4?a.w:1)}}p={count:_,texture:W,size:new Oe(w,H)},s.set(d,p),d.addEventListener("dispose",I)}let f=0;for(let g=0;g<u.length;g++)f+=u[g];const x=d.morphTargetsRelative?1:1-f;h.getUniforms().setValue(n,"morphTargetBaseInfluence",x),h.getUniforms().setValue(n,"morphTargetInfluences",u),h.getUniforms().setValue(n,"morphTargetsTexture",p.texture,t),h.getUniforms().setValue(n,"morphTargetsTextureSize",p.size)}else{const M=u===void 0?0:u.length;let _=i[d.id];if(_===void 0||_.length!==M){_=[];for(let v=0;v<M;v++)_[v]=[v,0];i[d.id]=_}for(let v=0;v<M;v++){const C=_[v];C[0]=v,C[1]=u[v]}_.sort(mp);for(let v=0;v<8;v++)v<M&&_[v][1]?(o[v][0]=_[v][0],o[v][1]=_[v][1]):(o[v][0]=Number.MAX_SAFE_INTEGER,o[v][1]=0);o.sort(pp);const p=d.morphAttributes.position,f=d.morphAttributes.normal;let x=0;for(let v=0;v<8;v++){const C=o[v],P=C[0],A=C[1];P!==Number.MAX_SAFE_INTEGER&&A?(p&&d.getAttribute("morphTarget"+v)!==p[P]&&d.setAttribute("morphTarget"+v,p[P]),f&&d.getAttribute("morphNormal"+v)!==f[P]&&d.setAttribute("morphNormal"+v,f[P]),r[v]=A,x+=A):(p&&d.hasAttribute("morphTarget"+v)===!0&&d.deleteAttribute("morphTarget"+v),f&&d.hasAttribute("morphNormal"+v)===!0&&d.deleteAttribute("morphNormal"+v),r[v]=0)}const g=d.morphTargetsRelative?1:1-x;h.getUniforms().setValue(n,"morphTargetBaseInfluence",g),h.getUniforms().setValue(n,"morphTargetInfluences",r)}}return{update:c}}function _p(n,e,t,i){let r=new WeakMap;function s(c){const l=i.render.frame,d=c.geometry,h=e.get(c,d);if(r.get(h)!==l&&(e.update(h),r.set(h,l)),c.isInstancedMesh&&(c.hasEventListener("dispose",o)===!1&&c.addEventListener("dispose",o),r.get(c)!==l&&(t.update(c.instanceMatrix,n.ARRAY_BUFFER),c.instanceColor!==null&&t.update(c.instanceColor,n.ARRAY_BUFFER),r.set(c,l))),c.isSkinnedMesh){const u=c.skeleton;r.get(u)!==l&&(u.update(),r.set(u,l))}return h}function a(){r=new WeakMap}function o(c){const l=c.target;l.removeEventListener("dispose",o),t.remove(l.instanceMatrix),l.instanceColor!==null&&t.remove(l.instanceColor)}return{update:s,dispose:a}}class fl extends Ot{constructor(e,t,i,r,s,a,o,c,l,d){if(d=d!==void 0?d:Kn,d!==Kn&&d!==Ii)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&d===Kn&&(i=Tn),i===void 0&&d===Ii&&(i=jn),super(null,r,s,a,o,c,d,i,l),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:Ct,this.minFilter=c!==void 0?c:Ct,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const pl=new Ot,ml=new fl(1,1);ml.compareFunction=tl;const gl=new sl,_l=new eu,xl=new ul,ac=[],oc=[],cc=new Float32Array(16),lc=new Float32Array(9),hc=new Float32Array(4);function Vi(n,e,t){const i=n[0];if(i<=0||i>0)return n;const r=e*t;let s=ac[r];if(s===void 0&&(s=new Float32Array(r),ac[r]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,n[a].toArray(s,o)}return s}function Mt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function yt(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function ps(n,e){let t=oc[e];t===void 0&&(t=new Int32Array(e),oc[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function xp(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function vp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2fv(this.addr,e),yt(t,e)}}function Mp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Mt(t,e))return;n.uniform3fv(this.addr,e),yt(t,e)}}function yp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4fv(this.addr,e),yt(t,e)}}function Sp(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),yt(t,e)}else{if(Mt(t,i))return;hc.set(i),n.uniformMatrix2fv(this.addr,!1,hc),yt(t,i)}}function bp(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),yt(t,e)}else{if(Mt(t,i))return;lc.set(i),n.uniformMatrix3fv(this.addr,!1,lc),yt(t,i)}}function Ep(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),yt(t,e)}else{if(Mt(t,i))return;cc.set(i),n.uniformMatrix4fv(this.addr,!1,cc),yt(t,i)}}function wp(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function Tp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2iv(this.addr,e),yt(t,e)}}function Ap(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;n.uniform3iv(this.addr,e),yt(t,e)}}function Rp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4iv(this.addr,e),yt(t,e)}}function Cp(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function Pp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2uiv(this.addr,e),yt(t,e)}}function Lp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;n.uniform3uiv(this.addr,e),yt(t,e)}}function Dp(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4uiv(this.addr,e),yt(t,e)}}function Up(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);const s=this.type===n.SAMPLER_2D_SHADOW?ml:pl;t.setTexture2D(e||s,r)}function Ip(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||_l,r)}function Np(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||xl,r)}function zp(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||gl,r)}function Fp(n){switch(n){case 5126:return xp;case 35664:return vp;case 35665:return Mp;case 35666:return yp;case 35674:return Sp;case 35675:return bp;case 35676:return Ep;case 5124:case 35670:return wp;case 35667:case 35671:return Tp;case 35668:case 35672:return Ap;case 35669:case 35673:return Rp;case 5125:return Cp;case 36294:return Pp;case 36295:return Lp;case 36296:return Dp;case 35678:case 36198:case 36298:case 36306:case 35682:return Up;case 35679:case 36299:case 36307:return Ip;case 35680:case 36300:case 36308:case 36293:return Np;case 36289:case 36303:case 36311:case 36292:return zp}}function Op(n,e){n.uniform1fv(this.addr,e)}function Bp(n,e){const t=Vi(e,this.size,2);n.uniform2fv(this.addr,t)}function kp(n,e){const t=Vi(e,this.size,3);n.uniform3fv(this.addr,t)}function Gp(n,e){const t=Vi(e,this.size,4);n.uniform4fv(this.addr,t)}function Hp(n,e){const t=Vi(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function Vp(n,e){const t=Vi(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function Wp(n,e){const t=Vi(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function Xp(n,e){n.uniform1iv(this.addr,e)}function qp(n,e){n.uniform2iv(this.addr,e)}function Yp(n,e){n.uniform3iv(this.addr,e)}function Zp(n,e){n.uniform4iv(this.addr,e)}function jp(n,e){n.uniform1uiv(this.addr,e)}function Kp(n,e){n.uniform2uiv(this.addr,e)}function $p(n,e){n.uniform3uiv(this.addr,e)}function Jp(n,e){n.uniform4uiv(this.addr,e)}function Qp(n,e,t){const i=this.cache,r=e.length,s=ps(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),yt(i,s));for(let a=0;a!==r;++a)t.setTexture2D(e[a]||pl,s[a])}function em(n,e,t){const i=this.cache,r=e.length,s=ps(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),yt(i,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||_l,s[a])}function tm(n,e,t){const i=this.cache,r=e.length,s=ps(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),yt(i,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||xl,s[a])}function nm(n,e,t){const i=this.cache,r=e.length,s=ps(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),yt(i,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||gl,s[a])}function im(n){switch(n){case 5126:return Op;case 35664:return Bp;case 35665:return kp;case 35666:return Gp;case 35674:return Hp;case 35675:return Vp;case 35676:return Wp;case 5124:case 35670:return Xp;case 35667:case 35671:return qp;case 35668:case 35672:return Yp;case 35669:case 35673:return Zp;case 5125:return jp;case 36294:return Kp;case 36295:return $p;case 36296:return Jp;case 35678:case 36198:case 36298:case 36306:case 35682:return Qp;case 35679:case 36299:case 36307:return em;case 35680:case 36300:case 36308:case 36293:return tm;case 36289:case 36303:case 36311:case 36292:return nm}}class rm{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=Fp(t.type)}}class sm{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=im(t.type)}}class am{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],i)}}}const ia=/(\w+)(\])?(\[|\.)?/g;function uc(n,e){n.seq.push(e),n.map[e.id]=e}function om(n,e,t){const i=n.name,r=i.length;for(ia.lastIndex=0;;){const s=ia.exec(i),a=ia.lastIndex;let o=s[1];const c=s[2]==="]",l=s[3];if(c&&(o=o|0),l===void 0||l==="["&&a+2===r){uc(t,l===void 0?new rm(o,n,e):new sm(o,n,e));break}else{let h=t.map[o];h===void 0&&(h=new am(o),uc(t,h)),t=h}}}class qr{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<i;++r){const s=e.getActiveUniform(t,r),a=e.getUniformLocation(t,s.name);om(s,a,this)}}setValue(e,t,i,r){const s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){const r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],c=i[o.id];c.needsUpdate!==!1&&o.setValue(e,c.value,r)}}static seqWithValue(e,t){const i=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&i.push(a)}return i}}function dc(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const cm=37297;let lm=0;function hm(n,e){const t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;i.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return i.join(`
`)}function um(n){const e=et.getPrimaries(et.workingColorSpace),t=et.getPrimaries(n);let i;switch(e===t?i="":e===es&&t===Qr?i="LinearDisplayP3ToLinearSRGB":e===Qr&&t===es&&(i="LinearSRGBToLinearDisplayP3"),n){case xn:case ds:return[i,"LinearTransferOETF"];case mt:case Ua:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function fc(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=n.getShaderInfoLog(e).trim();if(i&&r==="")return"";const s=/ERROR: 0:(\d+)/.exec(r);if(s){const a=parseInt(s[1]);return t.toUpperCase()+`

`+r+`

`+hm(n.getShaderSource(e),a)}else return r}function dm(n,e){const t=um(e);return`vec4 ${n}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function fm(n,e){let t;switch(e){case bh:t="Linear";break;case Eh:t="Reinhard";break;case wh:t="OptimizedCineon";break;case Th:t="ACESFilmic";break;case Rh:t="AgX";break;case Ah:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function pm(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(wi).join(`
`)}function mm(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(wi).join(`
`)}function gm(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function _m(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const s=n.getActiveAttrib(e,r),a=s.name;let o=1;s.type===n.FLOAT_MAT2&&(o=2),s.type===n.FLOAT_MAT3&&(o=3),s.type===n.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:n.getAttribLocation(e,a),locationSize:o}}return t}function wi(n){return n!==""}function pc(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function mc(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const xm=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ma(n){return n.replace(xm,Mm)}const vm=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Mm(n,e){let t=We[e];if(t===void 0){const i=vm.get(e);if(i!==void 0)t=We[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return Ma(t)}const ym=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function gc(n){return n.replace(ym,Sm)}function Sm(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function _c(n){let e="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function bm(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===Wc?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===$l?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===pn&&(e="SHADOWMAP_TYPE_VSM"),e}function Em(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Di:case Ui:e="ENVMAP_TYPE_CUBE";break;case us:e="ENVMAP_TYPE_CUBE_UV";break}return e}function wm(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Ui:e="ENVMAP_MODE_REFRACTION";break}return e}function Tm(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case La:e="ENVMAP_BLENDING_MULTIPLY";break;case yh:e="ENVMAP_BLENDING_MIX";break;case Sh:e="ENVMAP_BLENDING_ADD";break}return e}function Am(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Rm(n,e,t,i){const r=n.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const c=bm(t),l=Em(t),d=wm(t),h=Tm(t),u=Am(t),m=t.isWebGL2?"":pm(t),M=mm(t),_=gm(s),p=r.createProgram();let f,x,g=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_].filter(wi).join(`
`),f.length>0&&(f+=`
`),x=[m,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_].filter(wi).join(`
`),x.length>0&&(x+=`
`)):(f=[_c(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(wi).join(`
`),x=[m,_c(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+l:"",t.envMap?"#define "+d:"",t.envMap?"#define "+h:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+c:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Pn?"#define TONE_MAPPING":"",t.toneMapping!==Pn?We.tonemapping_pars_fragment:"",t.toneMapping!==Pn?fm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",We.colorspace_pars_fragment,dm("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(wi).join(`
`)),a=Ma(a),a=pc(a,t),a=mc(a,t),o=Ma(o),o=pc(o,t),o=mc(o,t),a=gc(a),o=gc(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,f=[M,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,x=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===No?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===No?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+x);const v=g+f+a,C=g+x+o,P=dc(r,r.VERTEX_SHADER,v),A=dc(r,r.FRAGMENT_SHADER,C);r.attachShader(p,P),r.attachShader(p,A),t.index0AttributeName!==void 0?r.bindAttribLocation(p,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(p,0,"position"),r.linkProgram(p);function N(U){if(n.debug.checkShaderErrors){const W=r.getProgramInfoLog(p).trim(),L=r.getShaderInfoLog(P).trim(),I=r.getShaderInfoLog(A).trim();let k=!0,X=!0;if(r.getProgramParameter(p,r.LINK_STATUS)===!1)if(k=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,p,P,A);else{const $=fc(r,P,"vertex"),ie=fc(r,A,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(p,r.VALIDATE_STATUS)+`

Program Info Log: `+W+`
`+$+`
`+ie)}else W!==""?console.warn("THREE.WebGLProgram: Program Info Log:",W):(L===""||I==="")&&(X=!1);X&&(U.diagnostics={runnable:k,programLog:W,vertexShader:{log:L,prefix:f},fragmentShader:{log:I,prefix:x}})}r.deleteShader(P),r.deleteShader(A),E=new qr(r,p),w=_m(r,p)}let E;this.getUniforms=function(){return E===void 0&&N(this),E};let w;this.getAttributes=function(){return w===void 0&&N(this),w};let H=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return H===!1&&(H=r.getProgramParameter(p,cm)),H},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(p),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=lm++,this.cacheKey=e,this.usedTimes=1,this.program=p,this.vertexShader=P,this.fragmentShader=A,this}let Cm=0;class Pm{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(r)===!1&&(a.add(r),r.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new Lm(e),t.set(e,i)),i}}class Lm{constructor(e){this.id=Cm++,this.code=e,this.usedTimes=0}}function Dm(n,e,t,i,r,s,a){const o=new Ia,c=new Pm,l=[],d=r.isWebGL2,h=r.logarithmicDepthBuffer,u=r.vertexTextures;let m=r.precision;const M={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function _(E){return E===0?"uv":`uv${E}`}function p(E,w,H,U,W){const L=U.fog,I=W.geometry,k=E.isMeshStandardMaterial?U.environment:null,X=(E.isMeshStandardMaterial?t:e).get(E.envMap||k),$=X&&X.mapping===us?X.image.height:null,ie=M[E.type];E.precision!==null&&(m=r.getMaxPrecision(E.precision),m!==E.precision&&console.warn("THREE.WebGLProgram.getParameters:",E.precision,"not supported, using",m,"instead."));const ne=I.morphAttributes.position||I.morphAttributes.normal||I.morphAttributes.color,ue=ne!==void 0?ne.length:0;let de=0;I.morphAttributes.position!==void 0&&(de=1),I.morphAttributes.normal!==void 0&&(de=2),I.morphAttributes.color!==void 0&&(de=3);let J,se,ge,Ae;if(ie){const Pt=on[ie];J=Pt.vertexShader,se=Pt.fragmentShader}else J=E.vertexShader,se=E.fragmentShader,c.update(E),ge=c.getVertexShaderID(E),Ae=c.getFragmentShaderID(E);const Ee=n.getRenderTarget(),Be=W.isInstancedMesh===!0,ke=W.isBatchedMesh===!0,De=!!E.map,S=!!E.matcap,y=!!X,G=!!E.aoMap,F=!!E.lightMap,ae=!!E.bumpMap,oe=!!E.normalMap,ee=!!E.displacementMap,me=!!E.emissiveMap,T=!!E.metalnessMap,b=!!E.roughnessMap,O=E.anisotropy>0,Q=E.clearcoat>0,Z=E.iridescence>0,te=E.sheen>0,ve=E.transmission>0,_e=O&&!!E.anisotropyMap,Me=Q&&!!E.clearcoatMap,we=Q&&!!E.clearcoatNormalMap,Ue=Q&&!!E.clearcoatRoughnessMap,le=Z&&!!E.iridescenceMap,Ke=Z&&!!E.iridescenceThicknessMap,Ve=te&&!!E.sheenColorMap,Ne=te&&!!E.sheenRoughnessMap,Ce=!!E.specularMap,Se=!!E.specularColorMap,ze=!!E.specularIntensityMap,re=ve&&!!E.transmissionMap,ce=ve&&!!E.thicknessMap,fe=!!E.gradientMap,j=!!E.alphaMap,D=E.alphaTest>0,he=!!E.alphaHash,pe=!!E.extensions,Te=!!I.attributes.uv1,Pe=!!I.attributes.uv2,it=!!I.attributes.uv3;let rt=Pn;return E.toneMapped&&(Ee===null||Ee.isXRRenderTarget===!0)&&(rt=n.toneMapping),{isWebGL2:d,shaderID:ie,shaderType:E.type,shaderName:E.name,vertexShader:J,fragmentShader:se,defines:E.defines,customVertexShaderID:ge,customFragmentShaderID:Ae,isRawShaderMaterial:E.isRawShaderMaterial===!0,glslVersion:E.glslVersion,precision:m,batching:ke,instancing:Be,instancingColor:Be&&W.instanceColor!==null,supportsVertexTextures:u,outputColorSpace:Ee===null?n.outputColorSpace:Ee.isXRRenderTarget===!0?Ee.texture.colorSpace:xn,map:De,matcap:S,envMap:y,envMapMode:y&&X.mapping,envMapCubeUVHeight:$,aoMap:G,lightMap:F,bumpMap:ae,normalMap:oe,displacementMap:u&&ee,emissiveMap:me,normalMapObjectSpace:oe&&E.normalMapType===kh,normalMapTangentSpace:oe&&E.normalMapType===el,metalnessMap:T,roughnessMap:b,anisotropy:O,anisotropyMap:_e,clearcoat:Q,clearcoatMap:Me,clearcoatNormalMap:we,clearcoatRoughnessMap:Ue,iridescence:Z,iridescenceMap:le,iridescenceThicknessMap:Ke,sheen:te,sheenColorMap:Ve,sheenRoughnessMap:Ne,specularMap:Ce,specularColorMap:Se,specularIntensityMap:ze,transmission:ve,transmissionMap:re,thicknessMap:ce,gradientMap:fe,opaque:E.transparent===!1&&E.blending===Ti,alphaMap:j,alphaTest:D,alphaHash:he,combine:E.combine,mapUv:De&&_(E.map.channel),aoMapUv:G&&_(E.aoMap.channel),lightMapUv:F&&_(E.lightMap.channel),bumpMapUv:ae&&_(E.bumpMap.channel),normalMapUv:oe&&_(E.normalMap.channel),displacementMapUv:ee&&_(E.displacementMap.channel),emissiveMapUv:me&&_(E.emissiveMap.channel),metalnessMapUv:T&&_(E.metalnessMap.channel),roughnessMapUv:b&&_(E.roughnessMap.channel),anisotropyMapUv:_e&&_(E.anisotropyMap.channel),clearcoatMapUv:Me&&_(E.clearcoatMap.channel),clearcoatNormalMapUv:we&&_(E.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&_(E.clearcoatRoughnessMap.channel),iridescenceMapUv:le&&_(E.iridescenceMap.channel),iridescenceThicknessMapUv:Ke&&_(E.iridescenceThicknessMap.channel),sheenColorMapUv:Ve&&_(E.sheenColorMap.channel),sheenRoughnessMapUv:Ne&&_(E.sheenRoughnessMap.channel),specularMapUv:Ce&&_(E.specularMap.channel),specularColorMapUv:Se&&_(E.specularColorMap.channel),specularIntensityMapUv:ze&&_(E.specularIntensityMap.channel),transmissionMapUv:re&&_(E.transmissionMap.channel),thicknessMapUv:ce&&_(E.thicknessMap.channel),alphaMapUv:j&&_(E.alphaMap.channel),vertexTangents:!!I.attributes.tangent&&(oe||O),vertexColors:E.vertexColors,vertexAlphas:E.vertexColors===!0&&!!I.attributes.color&&I.attributes.color.itemSize===4,vertexUv1s:Te,vertexUv2s:Pe,vertexUv3s:it,pointsUvs:W.isPoints===!0&&!!I.attributes.uv&&(De||j),fog:!!L,useFog:E.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:E.flatShading===!0,sizeAttenuation:E.sizeAttenuation===!0,logarithmicDepthBuffer:h,skinning:W.isSkinnedMesh===!0,morphTargets:I.morphAttributes.position!==void 0,morphNormals:I.morphAttributes.normal!==void 0,morphColors:I.morphAttributes.color!==void 0,morphTargetsCount:ue,morphTextureStride:de,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:E.dithering,shadowMapEnabled:n.shadowMap.enabled&&H.length>0,shadowMapType:n.shadowMap.type,toneMapping:rt,useLegacyLights:n._useLegacyLights,decodeVideoTexture:De&&E.map.isVideoTexture===!0&&et.getTransfer(E.map.colorSpace)===ot,premultipliedAlpha:E.premultipliedAlpha,doubleSided:E.side===xt,flipSided:E.side===Ft,useDepthPacking:E.depthPacking>=0,depthPacking:E.depthPacking||0,index0AttributeName:E.index0AttributeName,extensionDerivatives:pe&&E.extensions.derivatives===!0,extensionFragDepth:pe&&E.extensions.fragDepth===!0,extensionDrawBuffers:pe&&E.extensions.drawBuffers===!0,extensionShaderTextureLOD:pe&&E.extensions.shaderTextureLOD===!0,extensionClipCullDistance:pe&&E.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:d||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:d||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:d||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:E.customProgramCacheKey()}}function f(E){const w=[];if(E.shaderID?w.push(E.shaderID):(w.push(E.customVertexShaderID),w.push(E.customFragmentShaderID)),E.defines!==void 0)for(const H in E.defines)w.push(H),w.push(E.defines[H]);return E.isRawShaderMaterial===!1&&(x(w,E),g(w,E),w.push(n.outputColorSpace)),w.push(E.customProgramCacheKey),w.join()}function x(E,w){E.push(w.precision),E.push(w.outputColorSpace),E.push(w.envMapMode),E.push(w.envMapCubeUVHeight),E.push(w.mapUv),E.push(w.alphaMapUv),E.push(w.lightMapUv),E.push(w.aoMapUv),E.push(w.bumpMapUv),E.push(w.normalMapUv),E.push(w.displacementMapUv),E.push(w.emissiveMapUv),E.push(w.metalnessMapUv),E.push(w.roughnessMapUv),E.push(w.anisotropyMapUv),E.push(w.clearcoatMapUv),E.push(w.clearcoatNormalMapUv),E.push(w.clearcoatRoughnessMapUv),E.push(w.iridescenceMapUv),E.push(w.iridescenceThicknessMapUv),E.push(w.sheenColorMapUv),E.push(w.sheenRoughnessMapUv),E.push(w.specularMapUv),E.push(w.specularColorMapUv),E.push(w.specularIntensityMapUv),E.push(w.transmissionMapUv),E.push(w.thicknessMapUv),E.push(w.combine),E.push(w.fogExp2),E.push(w.sizeAttenuation),E.push(w.morphTargetsCount),E.push(w.morphAttributeCount),E.push(w.numDirLights),E.push(w.numPointLights),E.push(w.numSpotLights),E.push(w.numSpotLightMaps),E.push(w.numHemiLights),E.push(w.numRectAreaLights),E.push(w.numDirLightShadows),E.push(w.numPointLightShadows),E.push(w.numSpotLightShadows),E.push(w.numSpotLightShadowsWithMaps),E.push(w.numLightProbes),E.push(w.shadowMapType),E.push(w.toneMapping),E.push(w.numClippingPlanes),E.push(w.numClipIntersection),E.push(w.depthPacking)}function g(E,w){o.disableAll(),w.isWebGL2&&o.enable(0),w.supportsVertexTextures&&o.enable(1),w.instancing&&o.enable(2),w.instancingColor&&o.enable(3),w.matcap&&o.enable(4),w.envMap&&o.enable(5),w.normalMapObjectSpace&&o.enable(6),w.normalMapTangentSpace&&o.enable(7),w.clearcoat&&o.enable(8),w.iridescence&&o.enable(9),w.alphaTest&&o.enable(10),w.vertexColors&&o.enable(11),w.vertexAlphas&&o.enable(12),w.vertexUv1s&&o.enable(13),w.vertexUv2s&&o.enable(14),w.vertexUv3s&&o.enable(15),w.vertexTangents&&o.enable(16),w.anisotropy&&o.enable(17),w.alphaHash&&o.enable(18),w.batching&&o.enable(19),E.push(o.mask),o.disableAll(),w.fog&&o.enable(0),w.useFog&&o.enable(1),w.flatShading&&o.enable(2),w.logarithmicDepthBuffer&&o.enable(3),w.skinning&&o.enable(4),w.morphTargets&&o.enable(5),w.morphNormals&&o.enable(6),w.morphColors&&o.enable(7),w.premultipliedAlpha&&o.enable(8),w.shadowMapEnabled&&o.enable(9),w.useLegacyLights&&o.enable(10),w.doubleSided&&o.enable(11),w.flipSided&&o.enable(12),w.useDepthPacking&&o.enable(13),w.dithering&&o.enable(14),w.transmission&&o.enable(15),w.sheen&&o.enable(16),w.opaque&&o.enable(17),w.pointsUvs&&o.enable(18),w.decodeVideoTexture&&o.enable(19),E.push(o.mask)}function v(E){const w=M[E.type];let H;if(w){const U=on[w];H=fu.clone(U.uniforms)}else H=E.uniforms;return H}function C(E,w){let H;for(let U=0,W=l.length;U<W;U++){const L=l[U];if(L.cacheKey===w){H=L,++H.usedTimes;break}}return H===void 0&&(H=new Rm(n,w,E,s),l.push(H)),H}function P(E){if(--E.usedTimes===0){const w=l.indexOf(E);l[w]=l[l.length-1],l.pop(),E.destroy()}}function A(E){c.remove(E)}function N(){c.dispose()}return{getParameters:p,getProgramCacheKey:f,getUniforms:v,acquireProgram:C,releaseProgram:P,releaseShaderCache:A,programs:l,dispose:N}}function Um(){let n=new WeakMap;function e(s){let a=n.get(s);return a===void 0&&(a={},n.set(s,a)),a}function t(s){n.delete(s)}function i(s,a,o){n.get(s)[a]=o}function r(){n=new WeakMap}return{get:e,remove:t,update:i,dispose:r}}function Im(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function xc(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function vc(){const n=[];let e=0;const t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function a(h,u,m,M,_,p){let f=n[e];return f===void 0?(f={id:h.id,object:h,geometry:u,material:m,groupOrder:M,renderOrder:h.renderOrder,z:_,group:p},n[e]=f):(f.id=h.id,f.object=h,f.geometry=u,f.material=m,f.groupOrder=M,f.renderOrder=h.renderOrder,f.z=_,f.group=p),e++,f}function o(h,u,m,M,_,p){const f=a(h,u,m,M,_,p);m.transmission>0?i.push(f):m.transparent===!0?r.push(f):t.push(f)}function c(h,u,m,M,_,p){const f=a(h,u,m,M,_,p);m.transmission>0?i.unshift(f):m.transparent===!0?r.unshift(f):t.unshift(f)}function l(h,u){t.length>1&&t.sort(h||Im),i.length>1&&i.sort(u||xc),r.length>1&&r.sort(u||xc)}function d(){for(let h=e,u=n.length;h<u;h++){const m=n[h];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:o,unshift:c,finish:d,sort:l}}function Nm(){let n=new WeakMap;function e(i,r){const s=n.get(i);let a;return s===void 0?(a=new vc,n.set(i,[a])):r>=s.length?(a=new vc,s.push(a)):a=s[r],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function zm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new z,color:new je};break;case"SpotLight":t={position:new z,direction:new z,color:new je,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new z,color:new je,distance:0,decay:0};break;case"HemisphereLight":t={direction:new z,skyColor:new je,groundColor:new je};break;case"RectAreaLight":t={color:new je,position:new z,halfWidth:new z,halfHeight:new z};break}return n[e.id]=t,t}}}function Fm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let Om=0;function Bm(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function km(n,e){const t=new zm,i=Fm(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)r.probe.push(new z);const s=new z,a=new Qe,o=new Qe;function c(d,h){let u=0,m=0,M=0;for(let U=0;U<9;U++)r.probe[U].set(0,0,0);let _=0,p=0,f=0,x=0,g=0,v=0,C=0,P=0,A=0,N=0,E=0;d.sort(Bm);const w=h===!0?Math.PI:1;for(let U=0,W=d.length;U<W;U++){const L=d[U],I=L.color,k=L.intensity,X=L.distance,$=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)u+=I.r*k*w,m+=I.g*k*w,M+=I.b*k*w;else if(L.isLightProbe){for(let ie=0;ie<9;ie++)r.probe[ie].addScaledVector(L.sh.coefficients[ie],k);E++}else if(L.isDirectionalLight){const ie=t.get(L);if(ie.color.copy(L.color).multiplyScalar(L.intensity*w),L.castShadow){const ne=L.shadow,ue=i.get(L);ue.shadowBias=ne.bias,ue.shadowNormalBias=ne.normalBias,ue.shadowRadius=ne.radius,ue.shadowMapSize=ne.mapSize,r.directionalShadow[_]=ue,r.directionalShadowMap[_]=$,r.directionalShadowMatrix[_]=L.shadow.matrix,v++}r.directional[_]=ie,_++}else if(L.isSpotLight){const ie=t.get(L);ie.position.setFromMatrixPosition(L.matrixWorld),ie.color.copy(I).multiplyScalar(k*w),ie.distance=X,ie.coneCos=Math.cos(L.angle),ie.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),ie.decay=L.decay,r.spot[f]=ie;const ne=L.shadow;if(L.map&&(r.spotLightMap[A]=L.map,A++,ne.updateMatrices(L),L.castShadow&&N++),r.spotLightMatrix[f]=ne.matrix,L.castShadow){const ue=i.get(L);ue.shadowBias=ne.bias,ue.shadowNormalBias=ne.normalBias,ue.shadowRadius=ne.radius,ue.shadowMapSize=ne.mapSize,r.spotShadow[f]=ue,r.spotShadowMap[f]=$,P++}f++}else if(L.isRectAreaLight){const ie=t.get(L);ie.color.copy(I).multiplyScalar(k),ie.halfWidth.set(L.width*.5,0,0),ie.halfHeight.set(0,L.height*.5,0),r.rectArea[x]=ie,x++}else if(L.isPointLight){const ie=t.get(L);if(ie.color.copy(L.color).multiplyScalar(L.intensity*w),ie.distance=L.distance,ie.decay=L.decay,L.castShadow){const ne=L.shadow,ue=i.get(L);ue.shadowBias=ne.bias,ue.shadowNormalBias=ne.normalBias,ue.shadowRadius=ne.radius,ue.shadowMapSize=ne.mapSize,ue.shadowCameraNear=ne.camera.near,ue.shadowCameraFar=ne.camera.far,r.pointShadow[p]=ue,r.pointShadowMap[p]=$,r.pointShadowMatrix[p]=L.shadow.matrix,C++}r.point[p]=ie,p++}else if(L.isHemisphereLight){const ie=t.get(L);ie.skyColor.copy(L.color).multiplyScalar(k*w),ie.groundColor.copy(L.groundColor).multiplyScalar(k*w),r.hemi[g]=ie,g++}}x>0&&(e.isWebGL2?n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=xe.LTC_FLOAT_1,r.rectAreaLTC2=xe.LTC_FLOAT_2):(r.rectAreaLTC1=xe.LTC_HALF_1,r.rectAreaLTC2=xe.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=xe.LTC_FLOAT_1,r.rectAreaLTC2=xe.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(r.rectAreaLTC1=xe.LTC_HALF_1,r.rectAreaLTC2=xe.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),r.ambient[0]=u,r.ambient[1]=m,r.ambient[2]=M;const H=r.hash;(H.directionalLength!==_||H.pointLength!==p||H.spotLength!==f||H.rectAreaLength!==x||H.hemiLength!==g||H.numDirectionalShadows!==v||H.numPointShadows!==C||H.numSpotShadows!==P||H.numSpotMaps!==A||H.numLightProbes!==E)&&(r.directional.length=_,r.spot.length=f,r.rectArea.length=x,r.point.length=p,r.hemi.length=g,r.directionalShadow.length=v,r.directionalShadowMap.length=v,r.pointShadow.length=C,r.pointShadowMap.length=C,r.spotShadow.length=P,r.spotShadowMap.length=P,r.directionalShadowMatrix.length=v,r.pointShadowMatrix.length=C,r.spotLightMatrix.length=P+A-N,r.spotLightMap.length=A,r.numSpotLightShadowsWithMaps=N,r.numLightProbes=E,H.directionalLength=_,H.pointLength=p,H.spotLength=f,H.rectAreaLength=x,H.hemiLength=g,H.numDirectionalShadows=v,H.numPointShadows=C,H.numSpotShadows=P,H.numSpotMaps=A,H.numLightProbes=E,r.version=Om++)}function l(d,h){let u=0,m=0,M=0,_=0,p=0;const f=h.matrixWorldInverse;for(let x=0,g=d.length;x<g;x++){const v=d[x];if(v.isDirectionalLight){const C=r.directional[u];C.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),C.direction.sub(s),C.direction.transformDirection(f),u++}else if(v.isSpotLight){const C=r.spot[M];C.position.setFromMatrixPosition(v.matrixWorld),C.position.applyMatrix4(f),C.direction.setFromMatrixPosition(v.matrixWorld),s.setFromMatrixPosition(v.target.matrixWorld),C.direction.sub(s),C.direction.transformDirection(f),M++}else if(v.isRectAreaLight){const C=r.rectArea[_];C.position.setFromMatrixPosition(v.matrixWorld),C.position.applyMatrix4(f),o.identity(),a.copy(v.matrixWorld),a.premultiply(f),o.extractRotation(a),C.halfWidth.set(v.width*.5,0,0),C.halfHeight.set(0,v.height*.5,0),C.halfWidth.applyMatrix4(o),C.halfHeight.applyMatrix4(o),_++}else if(v.isPointLight){const C=r.point[m];C.position.setFromMatrixPosition(v.matrixWorld),C.position.applyMatrix4(f),m++}else if(v.isHemisphereLight){const C=r.hemi[p];C.direction.setFromMatrixPosition(v.matrixWorld),C.direction.transformDirection(f),p++}}}return{setup:c,setupView:l,state:r}}function Mc(n,e){const t=new km(n,e),i=[],r=[];function s(){i.length=0,r.length=0}function a(h){i.push(h)}function o(h){r.push(h)}function c(h){t.setup(i,h)}function l(h){t.setupView(i,h)}return{init:s,state:{lightsArray:i,shadowsArray:r,lights:t},setupLights:c,setupLightsView:l,pushLight:a,pushShadow:o}}function Gm(n,e){let t=new WeakMap;function i(s,a=0){const o=t.get(s);let c;return o===void 0?(c=new Mc(n,e),t.set(s,[c])):a>=o.length?(c=new Mc(n,e),o.push(c)):c=o[a],c}function r(){t=new WeakMap}return{get:i,dispose:r}}class Hm extends Hi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Oh,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Vm extends Hi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Wm=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Xm=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function qm(n,e,t){let i=new Na;const r=new Oe,s=new Oe,a=new wt,o=new Hm({depthPacking:Bh}),c=new Vm,l={},d=t.maxTextureSize,h={[_n]:Ft,[Ft]:_n,[xt]:xt},u=new Qn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Oe},radius:{value:4}},vertexShader:Wm,fragmentShader:Xm}),m=u.clone();m.defines.HORIZONTAL_PASS=1;const M=new at;M.setAttribute("position",new Qt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const _=new Ie(M,u),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Wc;let f=this.type;this.render=function(P,A,N){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||P.length===0)return;const E=n.getRenderTarget(),w=n.getActiveCubeFace(),H=n.getActiveMipmapLevel(),U=n.state;U.setBlending(Cn),U.buffers.color.setClear(1,1,1,1),U.buffers.depth.setTest(!0),U.setScissorTest(!1);const W=f!==pn&&this.type===pn,L=f===pn&&this.type!==pn;for(let I=0,k=P.length;I<k;I++){const X=P[I],$=X.shadow;if($===void 0){console.warn("THREE.WebGLShadowMap:",X,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;r.copy($.mapSize);const ie=$.getFrameExtents();if(r.multiply(ie),s.copy($.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/ie.x),r.x=s.x*ie.x,$.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/ie.y),r.y=s.y*ie.y,$.mapSize.y=s.y)),$.map===null||W===!0||L===!0){const ue=this.type!==pn?{minFilter:Ct,magFilter:Ct}:{};$.map!==null&&$.map.dispose(),$.map=new Jn(r.x,r.y,ue),$.map.texture.name=X.name+".shadowMap",$.camera.updateProjectionMatrix()}n.setRenderTarget($.map),n.clear();const ne=$.getViewportCount();for(let ue=0;ue<ne;ue++){const de=$.getViewport(ue);a.set(s.x*de.x,s.y*de.y,s.x*de.z,s.y*de.w),U.viewport(a),$.updateMatrices(X,ue),i=$.getFrustum(),v(A,N,$.camera,X,this.type)}$.isPointLightShadow!==!0&&this.type===pn&&x($,N),$.needsUpdate=!1}f=this.type,p.needsUpdate=!1,n.setRenderTarget(E,w,H)};function x(P,A){const N=e.update(_);u.defines.VSM_SAMPLES!==P.blurSamples&&(u.defines.VSM_SAMPLES=P.blurSamples,m.defines.VSM_SAMPLES=P.blurSamples,u.needsUpdate=!0,m.needsUpdate=!0),P.mapPass===null&&(P.mapPass=new Jn(r.x,r.y)),u.uniforms.shadow_pass.value=P.map.texture,u.uniforms.resolution.value=P.mapSize,u.uniforms.radius.value=P.radius,n.setRenderTarget(P.mapPass),n.clear(),n.renderBufferDirect(A,null,N,u,_,null),m.uniforms.shadow_pass.value=P.mapPass.texture,m.uniforms.resolution.value=P.mapSize,m.uniforms.radius.value=P.radius,n.setRenderTarget(P.map),n.clear(),n.renderBufferDirect(A,null,N,m,_,null)}function g(P,A,N,E){let w=null;const H=N.isPointLight===!0?P.customDistanceMaterial:P.customDepthMaterial;if(H!==void 0)w=H;else if(w=N.isPointLight===!0?c:o,n.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){const U=w.uuid,W=A.uuid;let L=l[U];L===void 0&&(L={},l[U]=L);let I=L[W];I===void 0&&(I=w.clone(),L[W]=I,A.addEventListener("dispose",C)),w=I}if(w.visible=A.visible,w.wireframe=A.wireframe,E===pn?w.side=A.shadowSide!==null?A.shadowSide:A.side:w.side=A.shadowSide!==null?A.shadowSide:h[A.side],w.alphaMap=A.alphaMap,w.alphaTest=A.alphaTest,w.map=A.map,w.clipShadows=A.clipShadows,w.clippingPlanes=A.clippingPlanes,w.clipIntersection=A.clipIntersection,w.displacementMap=A.displacementMap,w.displacementScale=A.displacementScale,w.displacementBias=A.displacementBias,w.wireframeLinewidth=A.wireframeLinewidth,w.linewidth=A.linewidth,N.isPointLight===!0&&w.isMeshDistanceMaterial===!0){const U=n.properties.get(w);U.light=N}return w}function v(P,A,N,E,w){if(P.visible===!1)return;if(P.layers.test(A.layers)&&(P.isMesh||P.isLine||P.isPoints)&&(P.castShadow||P.receiveShadow&&w===pn)&&(!P.frustumCulled||i.intersectsObject(P))){P.modelViewMatrix.multiplyMatrices(N.matrixWorldInverse,P.matrixWorld);const W=e.update(P),L=P.material;if(Array.isArray(L)){const I=W.groups;for(let k=0,X=I.length;k<X;k++){const $=I[k],ie=L[$.materialIndex];if(ie&&ie.visible){const ne=g(P,ie,E,w);P.onBeforeShadow(n,P,A,N,W,ne,$),n.renderBufferDirect(N,null,W,ne,P,$),P.onAfterShadow(n,P,A,N,W,ne,$)}}}else if(L.visible){const I=g(P,L,E,w);P.onBeforeShadow(n,P,A,N,W,I,null),n.renderBufferDirect(N,null,W,I,P,null),P.onAfterShadow(n,P,A,N,W,I,null)}}const U=P.children;for(let W=0,L=U.length;W<L;W++)v(U[W],A,N,E,w)}function C(P){P.target.removeEventListener("dispose",C);for(const N in l){const E=l[N],w=P.target.uuid;w in E&&(E[w].dispose(),delete E[w])}}}function Ym(n,e,t){const i=t.isWebGL2;function r(){let D=!1;const he=new wt;let pe=null;const Te=new wt(0,0,0,0);return{setMask:function(Pe){pe!==Pe&&!D&&(n.colorMask(Pe,Pe,Pe,Pe),pe=Pe)},setLocked:function(Pe){D=Pe},setClear:function(Pe,it,rt,St,Pt){Pt===!0&&(Pe*=St,it*=St,rt*=St),he.set(Pe,it,rt,St),Te.equals(he)===!1&&(n.clearColor(Pe,it,rt,St),Te.copy(he))},reset:function(){D=!1,pe=null,Te.set(-1,0,0,0)}}}function s(){let D=!1,he=null,pe=null,Te=null;return{setTest:function(Pe){Pe?ke(n.DEPTH_TEST):De(n.DEPTH_TEST)},setMask:function(Pe){he!==Pe&&!D&&(n.depthMask(Pe),he=Pe)},setFunc:function(Pe){if(pe!==Pe){switch(Pe){case ph:n.depthFunc(n.NEVER);break;case mh:n.depthFunc(n.ALWAYS);break;case gh:n.depthFunc(n.LESS);break;case $r:n.depthFunc(n.LEQUAL);break;case _h:n.depthFunc(n.EQUAL);break;case xh:n.depthFunc(n.GEQUAL);break;case vh:n.depthFunc(n.GREATER);break;case Mh:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}pe=Pe}},setLocked:function(Pe){D=Pe},setClear:function(Pe){Te!==Pe&&(n.clearDepth(Pe),Te=Pe)},reset:function(){D=!1,he=null,pe=null,Te=null}}}function a(){let D=!1,he=null,pe=null,Te=null,Pe=null,it=null,rt=null,St=null,Pt=null;return{setTest:function(st){D||(st?ke(n.STENCIL_TEST):De(n.STENCIL_TEST))},setMask:function(st){he!==st&&!D&&(n.stencilMask(st),he=st)},setFunc:function(st,Lt,an){(pe!==st||Te!==Lt||Pe!==an)&&(n.stencilFunc(st,Lt,an),pe=st,Te=Lt,Pe=an)},setOp:function(st,Lt,an){(it!==st||rt!==Lt||St!==an)&&(n.stencilOp(st,Lt,an),it=st,rt=Lt,St=an)},setLocked:function(st){D=st},setClear:function(st){Pt!==st&&(n.clearStencil(st),Pt=st)},reset:function(){D=!1,he=null,pe=null,Te=null,Pe=null,it=null,rt=null,St=null,Pt=null}}}const o=new r,c=new s,l=new a,d=new WeakMap,h=new WeakMap;let u={},m={},M=new WeakMap,_=[],p=null,f=!1,x=null,g=null,v=null,C=null,P=null,A=null,N=null,E=new je(0,0,0),w=0,H=!1,U=null,W=null,L=null,I=null,k=null;const X=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let $=!1,ie=0;const ne=n.getParameter(n.VERSION);ne.indexOf("WebGL")!==-1?(ie=parseFloat(/^WebGL (\d)/.exec(ne)[1]),$=ie>=1):ne.indexOf("OpenGL ES")!==-1&&(ie=parseFloat(/^OpenGL ES (\d)/.exec(ne)[1]),$=ie>=2);let ue=null,de={};const J=n.getParameter(n.SCISSOR_BOX),se=n.getParameter(n.VIEWPORT),ge=new wt().fromArray(J),Ae=new wt().fromArray(se);function Ee(D,he,pe,Te){const Pe=new Uint8Array(4),it=n.createTexture();n.bindTexture(D,it),n.texParameteri(D,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(D,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let rt=0;rt<pe;rt++)i&&(D===n.TEXTURE_3D||D===n.TEXTURE_2D_ARRAY)?n.texImage3D(he,0,n.RGBA,1,1,Te,0,n.RGBA,n.UNSIGNED_BYTE,Pe):n.texImage2D(he+rt,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Pe);return it}const Be={};Be[n.TEXTURE_2D]=Ee(n.TEXTURE_2D,n.TEXTURE_2D,1),Be[n.TEXTURE_CUBE_MAP]=Ee(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(Be[n.TEXTURE_2D_ARRAY]=Ee(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),Be[n.TEXTURE_3D]=Ee(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),c.setClear(1),l.setClear(0),ke(n.DEPTH_TEST),c.setFunc($r),me(!1),T(to),ke(n.CULL_FACE),oe(Cn);function ke(D){u[D]!==!0&&(n.enable(D),u[D]=!0)}function De(D){u[D]!==!1&&(n.disable(D),u[D]=!1)}function S(D,he){return m[D]!==he?(n.bindFramebuffer(D,he),m[D]=he,i&&(D===n.DRAW_FRAMEBUFFER&&(m[n.FRAMEBUFFER]=he),D===n.FRAMEBUFFER&&(m[n.DRAW_FRAMEBUFFER]=he)),!0):!1}function y(D,he){let pe=_,Te=!1;if(D)if(pe=M.get(he),pe===void 0&&(pe=[],M.set(he,pe)),D.isWebGLMultipleRenderTargets){const Pe=D.texture;if(pe.length!==Pe.length||pe[0]!==n.COLOR_ATTACHMENT0){for(let it=0,rt=Pe.length;it<rt;it++)pe[it]=n.COLOR_ATTACHMENT0+it;pe.length=Pe.length,Te=!0}}else pe[0]!==n.COLOR_ATTACHMENT0&&(pe[0]=n.COLOR_ATTACHMENT0,Te=!0);else pe[0]!==n.BACK&&(pe[0]=n.BACK,Te=!0);Te&&(t.isWebGL2?n.drawBuffers(pe):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(pe))}function G(D){return p!==D?(n.useProgram(D),p=D,!0):!1}const F={[qn]:n.FUNC_ADD,[Ql]:n.FUNC_SUBTRACT,[eh]:n.FUNC_REVERSE_SUBTRACT};if(i)F[so]=n.MIN,F[ao]=n.MAX;else{const D=e.get("EXT_blend_minmax");D!==null&&(F[so]=D.MIN_EXT,F[ao]=D.MAX_EXT)}const ae={[th]:n.ZERO,[nh]:n.ONE,[ih]:n.SRC_COLOR,[ha]:n.SRC_ALPHA,[lh]:n.SRC_ALPHA_SATURATE,[oh]:n.DST_COLOR,[sh]:n.DST_ALPHA,[rh]:n.ONE_MINUS_SRC_COLOR,[ua]:n.ONE_MINUS_SRC_ALPHA,[ch]:n.ONE_MINUS_DST_COLOR,[ah]:n.ONE_MINUS_DST_ALPHA,[hh]:n.CONSTANT_COLOR,[uh]:n.ONE_MINUS_CONSTANT_COLOR,[dh]:n.CONSTANT_ALPHA,[fh]:n.ONE_MINUS_CONSTANT_ALPHA};function oe(D,he,pe,Te,Pe,it,rt,St,Pt,st){if(D===Cn){f===!0&&(De(n.BLEND),f=!1);return}if(f===!1&&(ke(n.BLEND),f=!0),D!==Jl){if(D!==x||st!==H){if((g!==qn||P!==qn)&&(n.blendEquation(n.FUNC_ADD),g=qn,P=qn),st)switch(D){case Ti:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case no:n.blendFunc(n.ONE,n.ONE);break;case io:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case ro:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case Ti:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case no:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case io:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case ro:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}v=null,C=null,A=null,N=null,E.set(0,0,0),w=0,x=D,H=st}return}Pe=Pe||he,it=it||pe,rt=rt||Te,(he!==g||Pe!==P)&&(n.blendEquationSeparate(F[he],F[Pe]),g=he,P=Pe),(pe!==v||Te!==C||it!==A||rt!==N)&&(n.blendFuncSeparate(ae[pe],ae[Te],ae[it],ae[rt]),v=pe,C=Te,A=it,N=rt),(St.equals(E)===!1||Pt!==w)&&(n.blendColor(St.r,St.g,St.b,Pt),E.copy(St),w=Pt),x=D,H=!1}function ee(D,he){D.side===xt?De(n.CULL_FACE):ke(n.CULL_FACE);let pe=D.side===Ft;he&&(pe=!pe),me(pe),D.blending===Ti&&D.transparent===!1?oe(Cn):oe(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),c.setFunc(D.depthFunc),c.setTest(D.depthTest),c.setMask(D.depthWrite),o.setMask(D.colorWrite);const Te=D.stencilWrite;l.setTest(Te),Te&&(l.setMask(D.stencilWriteMask),l.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),l.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),O(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?ke(n.SAMPLE_ALPHA_TO_COVERAGE):De(n.SAMPLE_ALPHA_TO_COVERAGE)}function me(D){U!==D&&(D?n.frontFace(n.CW):n.frontFace(n.CCW),U=D)}function T(D){D!==jl?(ke(n.CULL_FACE),D!==W&&(D===to?n.cullFace(n.BACK):D===Kl?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):De(n.CULL_FACE),W=D}function b(D){D!==L&&($&&n.lineWidth(D),L=D)}function O(D,he,pe){D?(ke(n.POLYGON_OFFSET_FILL),(I!==he||k!==pe)&&(n.polygonOffset(he,pe),I=he,k=pe)):De(n.POLYGON_OFFSET_FILL)}function Q(D){D?ke(n.SCISSOR_TEST):De(n.SCISSOR_TEST)}function Z(D){D===void 0&&(D=n.TEXTURE0+X-1),ue!==D&&(n.activeTexture(D),ue=D)}function te(D,he,pe){pe===void 0&&(ue===null?pe=n.TEXTURE0+X-1:pe=ue);let Te=de[pe];Te===void 0&&(Te={type:void 0,texture:void 0},de[pe]=Te),(Te.type!==D||Te.texture!==he)&&(ue!==pe&&(n.activeTexture(pe),ue=pe),n.bindTexture(D,he||Be[D]),Te.type=D,Te.texture=he)}function ve(){const D=de[ue];D!==void 0&&D.type!==void 0&&(n.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function _e(){try{n.compressedTexImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Me(){try{n.compressedTexImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function we(){try{n.texSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ue(){try{n.texSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function le(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ke(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ve(){try{n.texStorage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ne(){try{n.texStorage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ce(){try{n.texImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Se(){try{n.texImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ze(D){ge.equals(D)===!1&&(n.scissor(D.x,D.y,D.z,D.w),ge.copy(D))}function re(D){Ae.equals(D)===!1&&(n.viewport(D.x,D.y,D.z,D.w),Ae.copy(D))}function ce(D,he){let pe=h.get(he);pe===void 0&&(pe=new WeakMap,h.set(he,pe));let Te=pe.get(D);Te===void 0&&(Te=n.getUniformBlockIndex(he,D.name),pe.set(D,Te))}function fe(D,he){const Te=h.get(he).get(D);d.get(he)!==Te&&(n.uniformBlockBinding(he,Te,D.__bindingPointIndex),d.set(he,Te))}function j(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),u={},ue=null,de={},m={},M=new WeakMap,_=[],p=null,f=!1,x=null,g=null,v=null,C=null,P=null,A=null,N=null,E=new je(0,0,0),w=0,H=!1,U=null,W=null,L=null,I=null,k=null,ge.set(0,0,n.canvas.width,n.canvas.height),Ae.set(0,0,n.canvas.width,n.canvas.height),o.reset(),c.reset(),l.reset()}return{buffers:{color:o,depth:c,stencil:l},enable:ke,disable:De,bindFramebuffer:S,drawBuffers:y,useProgram:G,setBlending:oe,setMaterial:ee,setFlipSided:me,setCullFace:T,setLineWidth:b,setPolygonOffset:O,setScissorTest:Q,activeTexture:Z,bindTexture:te,unbindTexture:ve,compressedTexImage2D:_e,compressedTexImage3D:Me,texImage2D:Ce,texImage3D:Se,updateUBOMapping:ce,uniformBlockBinding:fe,texStorage2D:Ve,texStorage3D:Ne,texSubImage2D:we,texSubImage3D:Ue,compressedTexSubImage2D:le,compressedTexSubImage3D:Ke,scissor:ze,viewport:re,reset:j}}function Zm(n,e,t,i,r,s,a){const o=r.isWebGL2,c=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new WeakMap;let h;const u=new WeakMap;let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function M(T,b){return m?new OffscreenCanvas(T,b):ns("canvas")}function _(T,b,O,Q){let Z=1;if((T.width>Q||T.height>Q)&&(Z=Q/Math.max(T.width,T.height)),Z<1||b===!0)if(typeof HTMLImageElement<"u"&&T instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&T instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&T instanceof ImageBitmap){const te=b?va:Math.floor,ve=te(Z*T.width),_e=te(Z*T.height);h===void 0&&(h=M(ve,_e));const Me=O?M(ve,_e):h;return Me.width=ve,Me.height=_e,Me.getContext("2d").drawImage(T,0,0,ve,_e),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+T.width+"x"+T.height+") to ("+ve+"x"+_e+")."),Me}else return"data"in T&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+T.width+"x"+T.height+")."),T;return T}function p(T){return zo(T.width)&&zo(T.height)}function f(T){return o?!1:T.wrapS!==rn||T.wrapT!==rn||T.minFilter!==Ct&&T.minFilter!==Zt}function x(T,b){return T.generateMipmaps&&b&&T.minFilter!==Ct&&T.minFilter!==Zt}function g(T){n.generateMipmap(T)}function v(T,b,O,Q,Z=!1){if(o===!1)return b;if(T!==null){if(n[T]!==void 0)return n[T];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+T+"'")}let te=b;if(b===n.RED&&(O===n.FLOAT&&(te=n.R32F),O===n.HALF_FLOAT&&(te=n.R16F),O===n.UNSIGNED_BYTE&&(te=n.R8)),b===n.RED_INTEGER&&(O===n.UNSIGNED_BYTE&&(te=n.R8UI),O===n.UNSIGNED_SHORT&&(te=n.R16UI),O===n.UNSIGNED_INT&&(te=n.R32UI),O===n.BYTE&&(te=n.R8I),O===n.SHORT&&(te=n.R16I),O===n.INT&&(te=n.R32I)),b===n.RG&&(O===n.FLOAT&&(te=n.RG32F),O===n.HALF_FLOAT&&(te=n.RG16F),O===n.UNSIGNED_BYTE&&(te=n.RG8)),b===n.RGBA){const ve=Z?Jr:et.getTransfer(Q);O===n.FLOAT&&(te=n.RGBA32F),O===n.HALF_FLOAT&&(te=n.RGBA16F),O===n.UNSIGNED_BYTE&&(te=ve===ot?n.SRGB8_ALPHA8:n.RGBA8),O===n.UNSIGNED_SHORT_4_4_4_4&&(te=n.RGBA4),O===n.UNSIGNED_SHORT_5_5_5_1&&(te=n.RGB5_A1)}return(te===n.R16F||te===n.R32F||te===n.RG16F||te===n.RG32F||te===n.RGBA16F||te===n.RGBA32F)&&e.get("EXT_color_buffer_float"),te}function C(T,b,O){return x(T,O)===!0||T.isFramebufferTexture&&T.minFilter!==Ct&&T.minFilter!==Zt?Math.log2(Math.max(b.width,b.height))+1:T.mipmaps!==void 0&&T.mipmaps.length>0?T.mipmaps.length:T.isCompressedTexture&&Array.isArray(T.image)?b.mipmaps.length:1}function P(T){return T===Ct||T===oo||T===Rs?n.NEAREST:n.LINEAR}function A(T){const b=T.target;b.removeEventListener("dispose",A),E(b),b.isVideoTexture&&d.delete(b)}function N(T){const b=T.target;b.removeEventListener("dispose",N),H(b)}function E(T){const b=i.get(T);if(b.__webglInit===void 0)return;const O=T.source,Q=u.get(O);if(Q){const Z=Q[b.__cacheKey];Z.usedTimes--,Z.usedTimes===0&&w(T),Object.keys(Q).length===0&&u.delete(O)}i.remove(T)}function w(T){const b=i.get(T);n.deleteTexture(b.__webglTexture);const O=T.source,Q=u.get(O);delete Q[b.__cacheKey],a.memory.textures--}function H(T){const b=T.texture,O=i.get(T),Q=i.get(b);if(Q.__webglTexture!==void 0&&(n.deleteTexture(Q.__webglTexture),a.memory.textures--),T.depthTexture&&T.depthTexture.dispose(),T.isWebGLCubeRenderTarget)for(let Z=0;Z<6;Z++){if(Array.isArray(O.__webglFramebuffer[Z]))for(let te=0;te<O.__webglFramebuffer[Z].length;te++)n.deleteFramebuffer(O.__webglFramebuffer[Z][te]);else n.deleteFramebuffer(O.__webglFramebuffer[Z]);O.__webglDepthbuffer&&n.deleteRenderbuffer(O.__webglDepthbuffer[Z])}else{if(Array.isArray(O.__webglFramebuffer))for(let Z=0;Z<O.__webglFramebuffer.length;Z++)n.deleteFramebuffer(O.__webglFramebuffer[Z]);else n.deleteFramebuffer(O.__webglFramebuffer);if(O.__webglDepthbuffer&&n.deleteRenderbuffer(O.__webglDepthbuffer),O.__webglMultisampledFramebuffer&&n.deleteFramebuffer(O.__webglMultisampledFramebuffer),O.__webglColorRenderbuffer)for(let Z=0;Z<O.__webglColorRenderbuffer.length;Z++)O.__webglColorRenderbuffer[Z]&&n.deleteRenderbuffer(O.__webglColorRenderbuffer[Z]);O.__webglDepthRenderbuffer&&n.deleteRenderbuffer(O.__webglDepthRenderbuffer)}if(T.isWebGLMultipleRenderTargets)for(let Z=0,te=b.length;Z<te;Z++){const ve=i.get(b[Z]);ve.__webglTexture&&(n.deleteTexture(ve.__webglTexture),a.memory.textures--),i.remove(b[Z])}i.remove(b),i.remove(T)}let U=0;function W(){U=0}function L(){const T=U;return T>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+T+" texture units while this GPU supports only "+r.maxTextures),U+=1,T}function I(T){const b=[];return b.push(T.wrapS),b.push(T.wrapT),b.push(T.wrapR||0),b.push(T.magFilter),b.push(T.minFilter),b.push(T.anisotropy),b.push(T.internalFormat),b.push(T.format),b.push(T.type),b.push(T.generateMipmaps),b.push(T.premultiplyAlpha),b.push(T.flipY),b.push(T.unpackAlignment),b.push(T.colorSpace),b.join()}function k(T,b){const O=i.get(T);if(T.isVideoTexture&&ee(T),T.isRenderTargetTexture===!1&&T.version>0&&O.__version!==T.version){const Q=T.image;if(Q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ge(O,T,b);return}}t.bindTexture(n.TEXTURE_2D,O.__webglTexture,n.TEXTURE0+b)}function X(T,b){const O=i.get(T);if(T.version>0&&O.__version!==T.version){ge(O,T,b);return}t.bindTexture(n.TEXTURE_2D_ARRAY,O.__webglTexture,n.TEXTURE0+b)}function $(T,b){const O=i.get(T);if(T.version>0&&O.__version!==T.version){ge(O,T,b);return}t.bindTexture(n.TEXTURE_3D,O.__webglTexture,n.TEXTURE0+b)}function ie(T,b){const O=i.get(T);if(T.version>0&&O.__version!==T.version){Ae(O,T,b);return}t.bindTexture(n.TEXTURE_CUBE_MAP,O.__webglTexture,n.TEXTURE0+b)}const ne={[pa]:n.REPEAT,[rn]:n.CLAMP_TO_EDGE,[ma]:n.MIRRORED_REPEAT},ue={[Ct]:n.NEAREST,[oo]:n.NEAREST_MIPMAP_NEAREST,[Rs]:n.NEAREST_MIPMAP_LINEAR,[Zt]:n.LINEAR,[Ch]:n.LINEAR_MIPMAP_NEAREST,[ir]:n.LINEAR_MIPMAP_LINEAR},de={[Gh]:n.NEVER,[Yh]:n.ALWAYS,[Hh]:n.LESS,[tl]:n.LEQUAL,[Vh]:n.EQUAL,[qh]:n.GEQUAL,[Wh]:n.GREATER,[Xh]:n.NOTEQUAL};function J(T,b,O){if(O?(n.texParameteri(T,n.TEXTURE_WRAP_S,ne[b.wrapS]),n.texParameteri(T,n.TEXTURE_WRAP_T,ne[b.wrapT]),(T===n.TEXTURE_3D||T===n.TEXTURE_2D_ARRAY)&&n.texParameteri(T,n.TEXTURE_WRAP_R,ne[b.wrapR]),n.texParameteri(T,n.TEXTURE_MAG_FILTER,ue[b.magFilter]),n.texParameteri(T,n.TEXTURE_MIN_FILTER,ue[b.minFilter])):(n.texParameteri(T,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(T,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(T===n.TEXTURE_3D||T===n.TEXTURE_2D_ARRAY)&&n.texParameteri(T,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(b.wrapS!==rn||b.wrapT!==rn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(T,n.TEXTURE_MAG_FILTER,P(b.magFilter)),n.texParameteri(T,n.TEXTURE_MIN_FILTER,P(b.minFilter)),b.minFilter!==Ct&&b.minFilter!==Zt&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),b.compareFunction&&(n.texParameteri(T,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(T,n.TEXTURE_COMPARE_FUNC,de[b.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){const Q=e.get("EXT_texture_filter_anisotropic");if(b.magFilter===Ct||b.minFilter!==Rs&&b.minFilter!==ir||b.type===An&&e.has("OES_texture_float_linear")===!1||o===!1&&b.type===rr&&e.has("OES_texture_half_float_linear")===!1)return;(b.anisotropy>1||i.get(b).__currentAnisotropy)&&(n.texParameterf(T,Q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(b.anisotropy,r.getMaxAnisotropy())),i.get(b).__currentAnisotropy=b.anisotropy)}}function se(T,b){let O=!1;T.__webglInit===void 0&&(T.__webglInit=!0,b.addEventListener("dispose",A));const Q=b.source;let Z=u.get(Q);Z===void 0&&(Z={},u.set(Q,Z));const te=I(b);if(te!==T.__cacheKey){Z[te]===void 0&&(Z[te]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,O=!0),Z[te].usedTimes++;const ve=Z[T.__cacheKey];ve!==void 0&&(Z[T.__cacheKey].usedTimes--,ve.usedTimes===0&&w(b)),T.__cacheKey=te,T.__webglTexture=Z[te].texture}return O}function ge(T,b,O){let Q=n.TEXTURE_2D;(b.isDataArrayTexture||b.isCompressedArrayTexture)&&(Q=n.TEXTURE_2D_ARRAY),b.isData3DTexture&&(Q=n.TEXTURE_3D);const Z=se(T,b),te=b.source;t.bindTexture(Q,T.__webglTexture,n.TEXTURE0+O);const ve=i.get(te);if(te.version!==ve.__version||Z===!0){t.activeTexture(n.TEXTURE0+O);const _e=et.getPrimaries(et.workingColorSpace),Me=b.colorSpace===$t?null:et.getPrimaries(b.colorSpace),we=b.colorSpace===$t||_e===Me?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,b.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,b.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,we);const Ue=f(b)&&p(b.image)===!1;let le=_(b.image,Ue,!1,r.maxTextureSize);le=me(b,le);const Ke=p(le)||o,Ve=s.convert(b.format,b.colorSpace);let Ne=s.convert(b.type),Ce=v(b.internalFormat,Ve,Ne,b.colorSpace,b.isVideoTexture);J(Q,b,Ke);let Se;const ze=b.mipmaps,re=o&&b.isVideoTexture!==!0&&Ce!==Jc,ce=ve.__version===void 0||Z===!0,fe=C(b,le,Ke);if(b.isDepthTexture)Ce=n.DEPTH_COMPONENT,o?b.type===An?Ce=n.DEPTH_COMPONENT32F:b.type===Tn?Ce=n.DEPTH_COMPONENT24:b.type===jn?Ce=n.DEPTH24_STENCIL8:Ce=n.DEPTH_COMPONENT16:b.type===An&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),b.format===Kn&&Ce===n.DEPTH_COMPONENT&&b.type!==Da&&b.type!==Tn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),b.type=Tn,Ne=s.convert(b.type)),b.format===Ii&&Ce===n.DEPTH_COMPONENT&&(Ce=n.DEPTH_STENCIL,b.type!==jn&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),b.type=jn,Ne=s.convert(b.type))),ce&&(re?t.texStorage2D(n.TEXTURE_2D,1,Ce,le.width,le.height):t.texImage2D(n.TEXTURE_2D,0,Ce,le.width,le.height,0,Ve,Ne,null));else if(b.isDataTexture)if(ze.length>0&&Ke){re&&ce&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,ze[0].width,ze[0].height);for(let j=0,D=ze.length;j<D;j++)Se=ze[j],re?t.texSubImage2D(n.TEXTURE_2D,j,0,0,Se.width,Se.height,Ve,Ne,Se.data):t.texImage2D(n.TEXTURE_2D,j,Ce,Se.width,Se.height,0,Ve,Ne,Se.data);b.generateMipmaps=!1}else re?(ce&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,le.width,le.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,le.width,le.height,Ve,Ne,le.data)):t.texImage2D(n.TEXTURE_2D,0,Ce,le.width,le.height,0,Ve,Ne,le.data);else if(b.isCompressedTexture)if(b.isCompressedArrayTexture){re&&ce&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Ce,ze[0].width,ze[0].height,le.depth);for(let j=0,D=ze.length;j<D;j++)Se=ze[j],b.format!==sn?Ve!==null?re?t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,j,0,0,0,Se.width,Se.height,le.depth,Ve,Se.data,0,0):t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,j,Ce,Se.width,Se.height,le.depth,0,Se.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?t.texSubImage3D(n.TEXTURE_2D_ARRAY,j,0,0,0,Se.width,Se.height,le.depth,Ve,Ne,Se.data):t.texImage3D(n.TEXTURE_2D_ARRAY,j,Ce,Se.width,Se.height,le.depth,0,Ve,Ne,Se.data)}else{re&&ce&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,ze[0].width,ze[0].height);for(let j=0,D=ze.length;j<D;j++)Se=ze[j],b.format!==sn?Ve!==null?re?t.compressedTexSubImage2D(n.TEXTURE_2D,j,0,0,Se.width,Se.height,Ve,Se.data):t.compressedTexImage2D(n.TEXTURE_2D,j,Ce,Se.width,Se.height,0,Se.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?t.texSubImage2D(n.TEXTURE_2D,j,0,0,Se.width,Se.height,Ve,Ne,Se.data):t.texImage2D(n.TEXTURE_2D,j,Ce,Se.width,Se.height,0,Ve,Ne,Se.data)}else if(b.isDataArrayTexture)re?(ce&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Ce,le.width,le.height,le.depth),t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,le.width,le.height,le.depth,Ve,Ne,le.data)):t.texImage3D(n.TEXTURE_2D_ARRAY,0,Ce,le.width,le.height,le.depth,0,Ve,Ne,le.data);else if(b.isData3DTexture)re?(ce&&t.texStorage3D(n.TEXTURE_3D,fe,Ce,le.width,le.height,le.depth),t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,le.width,le.height,le.depth,Ve,Ne,le.data)):t.texImage3D(n.TEXTURE_3D,0,Ce,le.width,le.height,le.depth,0,Ve,Ne,le.data);else if(b.isFramebufferTexture){if(ce)if(re)t.texStorage2D(n.TEXTURE_2D,fe,Ce,le.width,le.height);else{let j=le.width,D=le.height;for(let he=0;he<fe;he++)t.texImage2D(n.TEXTURE_2D,he,Ce,j,D,0,Ve,Ne,null),j>>=1,D>>=1}}else if(ze.length>0&&Ke){re&&ce&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,ze[0].width,ze[0].height);for(let j=0,D=ze.length;j<D;j++)Se=ze[j],re?t.texSubImage2D(n.TEXTURE_2D,j,0,0,Ve,Ne,Se):t.texImage2D(n.TEXTURE_2D,j,Ce,Ve,Ne,Se);b.generateMipmaps=!1}else re?(ce&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,le.width,le.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,Ve,Ne,le)):t.texImage2D(n.TEXTURE_2D,0,Ce,Ve,Ne,le);x(b,Ke)&&g(Q),ve.__version=te.version,b.onUpdate&&b.onUpdate(b)}T.__version=b.version}function Ae(T,b,O){if(b.image.length!==6)return;const Q=se(T,b),Z=b.source;t.bindTexture(n.TEXTURE_CUBE_MAP,T.__webglTexture,n.TEXTURE0+O);const te=i.get(Z);if(Z.version!==te.__version||Q===!0){t.activeTexture(n.TEXTURE0+O);const ve=et.getPrimaries(et.workingColorSpace),_e=b.colorSpace===$t?null:et.getPrimaries(b.colorSpace),Me=b.colorSpace===$t||ve===_e?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,b.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,b.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,b.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Me);const we=b.isCompressedTexture||b.image[0].isCompressedTexture,Ue=b.image[0]&&b.image[0].isDataTexture,le=[];for(let j=0;j<6;j++)!we&&!Ue?le[j]=_(b.image[j],!1,!0,r.maxCubemapSize):le[j]=Ue?b.image[j].image:b.image[j],le[j]=me(b,le[j]);const Ke=le[0],Ve=p(Ke)||o,Ne=s.convert(b.format,b.colorSpace),Ce=s.convert(b.type),Se=v(b.internalFormat,Ne,Ce,b.colorSpace),ze=o&&b.isVideoTexture!==!0,re=te.__version===void 0||Q===!0;let ce=C(b,Ke,Ve);J(n.TEXTURE_CUBE_MAP,b,Ve);let fe;if(we){ze&&re&&t.texStorage2D(n.TEXTURE_CUBE_MAP,ce,Se,Ke.width,Ke.height);for(let j=0;j<6;j++){fe=le[j].mipmaps;for(let D=0;D<fe.length;D++){const he=fe[D];b.format!==sn?Ne!==null?ze?t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D,0,0,he.width,he.height,Ne,he.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D,Se,he.width,he.height,0,he.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):ze?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D,0,0,he.width,he.height,Ne,Ce,he.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D,Se,he.width,he.height,0,Ne,Ce,he.data)}}}else{fe=b.mipmaps,ze&&re&&(fe.length>0&&ce++,t.texStorage2D(n.TEXTURE_CUBE_MAP,ce,Se,le[0].width,le[0].height));for(let j=0;j<6;j++)if(Ue){ze?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,0,0,le[j].width,le[j].height,Ne,Ce,le[j].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,Se,le[j].width,le[j].height,0,Ne,Ce,le[j].data);for(let D=0;D<fe.length;D++){const pe=fe[D].image[j].image;ze?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D+1,0,0,pe.width,pe.height,Ne,Ce,pe.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D+1,Se,pe.width,pe.height,0,Ne,Ce,pe.data)}}else{ze?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,0,0,Ne,Ce,le[j]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,0,Se,Ne,Ce,le[j]);for(let D=0;D<fe.length;D++){const he=fe[D];ze?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D+1,0,0,Ne,Ce,he.image[j]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+j,D+1,Se,Ne,Ce,he.image[j])}}}x(b,Ve)&&g(n.TEXTURE_CUBE_MAP),te.__version=Z.version,b.onUpdate&&b.onUpdate(b)}T.__version=b.version}function Ee(T,b,O,Q,Z,te){const ve=s.convert(O.format,O.colorSpace),_e=s.convert(O.type),Me=v(O.internalFormat,ve,_e,O.colorSpace);if(!i.get(b).__hasExternalTextures){const Ue=Math.max(1,b.width>>te),le=Math.max(1,b.height>>te);Z===n.TEXTURE_3D||Z===n.TEXTURE_2D_ARRAY?t.texImage3D(Z,te,Me,Ue,le,b.depth,0,ve,_e,null):t.texImage2D(Z,te,Me,Ue,le,0,ve,_e,null)}t.bindFramebuffer(n.FRAMEBUFFER,T),oe(b)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,Q,Z,i.get(O).__webglTexture,0,ae(b)):(Z===n.TEXTURE_2D||Z>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&Z<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,Q,Z,i.get(O).__webglTexture,te),t.bindFramebuffer(n.FRAMEBUFFER,null)}function Be(T,b,O){if(n.bindRenderbuffer(n.RENDERBUFFER,T),b.depthBuffer&&!b.stencilBuffer){let Q=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(O||oe(b)){const Z=b.depthTexture;Z&&Z.isDepthTexture&&(Z.type===An?Q=n.DEPTH_COMPONENT32F:Z.type===Tn&&(Q=n.DEPTH_COMPONENT24));const te=ae(b);oe(b)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,te,Q,b.width,b.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,te,Q,b.width,b.height)}else n.renderbufferStorage(n.RENDERBUFFER,Q,b.width,b.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,T)}else if(b.depthBuffer&&b.stencilBuffer){const Q=ae(b);O&&oe(b)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Q,n.DEPTH24_STENCIL8,b.width,b.height):oe(b)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Q,n.DEPTH24_STENCIL8,b.width,b.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,b.width,b.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,T)}else{const Q=b.isWebGLMultipleRenderTargets===!0?b.texture:[b.texture];for(let Z=0;Z<Q.length;Z++){const te=Q[Z],ve=s.convert(te.format,te.colorSpace),_e=s.convert(te.type),Me=v(te.internalFormat,ve,_e,te.colorSpace),we=ae(b);O&&oe(b)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,we,Me,b.width,b.height):oe(b)?c.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,we,Me,b.width,b.height):n.renderbufferStorage(n.RENDERBUFFER,Me,b.width,b.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function ke(T,b){if(b&&b.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,T),!(b.depthTexture&&b.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(b.depthTexture).__webglTexture||b.depthTexture.image.width!==b.width||b.depthTexture.image.height!==b.height)&&(b.depthTexture.image.width=b.width,b.depthTexture.image.height=b.height,b.depthTexture.needsUpdate=!0),k(b.depthTexture,0);const Q=i.get(b.depthTexture).__webglTexture,Z=ae(b);if(b.depthTexture.format===Kn)oe(b)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Q,0,Z):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Q,0);else if(b.depthTexture.format===Ii)oe(b)?c.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Q,0,Z):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Q,0);else throw new Error("Unknown depthTexture format")}function De(T){const b=i.get(T),O=T.isWebGLCubeRenderTarget===!0;if(T.depthTexture&&!b.__autoAllocateDepthBuffer){if(O)throw new Error("target.depthTexture not supported in Cube render targets");ke(b.__webglFramebuffer,T)}else if(O){b.__webglDepthbuffer=[];for(let Q=0;Q<6;Q++)t.bindFramebuffer(n.FRAMEBUFFER,b.__webglFramebuffer[Q]),b.__webglDepthbuffer[Q]=n.createRenderbuffer(),Be(b.__webglDepthbuffer[Q],T,!1)}else t.bindFramebuffer(n.FRAMEBUFFER,b.__webglFramebuffer),b.__webglDepthbuffer=n.createRenderbuffer(),Be(b.__webglDepthbuffer,T,!1);t.bindFramebuffer(n.FRAMEBUFFER,null)}function S(T,b,O){const Q=i.get(T);b!==void 0&&Ee(Q.__webglFramebuffer,T,T.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),O!==void 0&&De(T)}function y(T){const b=T.texture,O=i.get(T),Q=i.get(b);T.addEventListener("dispose",N),T.isWebGLMultipleRenderTargets!==!0&&(Q.__webglTexture===void 0&&(Q.__webglTexture=n.createTexture()),Q.__version=b.version,a.memory.textures++);const Z=T.isWebGLCubeRenderTarget===!0,te=T.isWebGLMultipleRenderTargets===!0,ve=p(T)||o;if(Z){O.__webglFramebuffer=[];for(let _e=0;_e<6;_e++)if(o&&b.mipmaps&&b.mipmaps.length>0){O.__webglFramebuffer[_e]=[];for(let Me=0;Me<b.mipmaps.length;Me++)O.__webglFramebuffer[_e][Me]=n.createFramebuffer()}else O.__webglFramebuffer[_e]=n.createFramebuffer()}else{if(o&&b.mipmaps&&b.mipmaps.length>0){O.__webglFramebuffer=[];for(let _e=0;_e<b.mipmaps.length;_e++)O.__webglFramebuffer[_e]=n.createFramebuffer()}else O.__webglFramebuffer=n.createFramebuffer();if(te)if(r.drawBuffers){const _e=T.texture;for(let Me=0,we=_e.length;Me<we;Me++){const Ue=i.get(_e[Me]);Ue.__webglTexture===void 0&&(Ue.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&T.samples>0&&oe(T)===!1){const _e=te?b:[b];O.__webglMultisampledFramebuffer=n.createFramebuffer(),O.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,O.__webglMultisampledFramebuffer);for(let Me=0;Me<_e.length;Me++){const we=_e[Me];O.__webglColorRenderbuffer[Me]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,O.__webglColorRenderbuffer[Me]);const Ue=s.convert(we.format,we.colorSpace),le=s.convert(we.type),Ke=v(we.internalFormat,Ue,le,we.colorSpace,T.isXRRenderTarget===!0),Ve=ae(T);n.renderbufferStorageMultisample(n.RENDERBUFFER,Ve,Ke,T.width,T.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Me,n.RENDERBUFFER,O.__webglColorRenderbuffer[Me])}n.bindRenderbuffer(n.RENDERBUFFER,null),T.depthBuffer&&(O.__webglDepthRenderbuffer=n.createRenderbuffer(),Be(O.__webglDepthRenderbuffer,T,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(Z){t.bindTexture(n.TEXTURE_CUBE_MAP,Q.__webglTexture),J(n.TEXTURE_CUBE_MAP,b,ve);for(let _e=0;_e<6;_e++)if(o&&b.mipmaps&&b.mipmaps.length>0)for(let Me=0;Me<b.mipmaps.length;Me++)Ee(O.__webglFramebuffer[_e][Me],T,b,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+_e,Me);else Ee(O.__webglFramebuffer[_e],T,b,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+_e,0);x(b,ve)&&g(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(te){const _e=T.texture;for(let Me=0,we=_e.length;Me<we;Me++){const Ue=_e[Me],le=i.get(Ue);t.bindTexture(n.TEXTURE_2D,le.__webglTexture),J(n.TEXTURE_2D,Ue,ve),Ee(O.__webglFramebuffer,T,Ue,n.COLOR_ATTACHMENT0+Me,n.TEXTURE_2D,0),x(Ue,ve)&&g(n.TEXTURE_2D)}t.unbindTexture()}else{let _e=n.TEXTURE_2D;if((T.isWebGL3DRenderTarget||T.isWebGLArrayRenderTarget)&&(o?_e=T.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(_e,Q.__webglTexture),J(_e,b,ve),o&&b.mipmaps&&b.mipmaps.length>0)for(let Me=0;Me<b.mipmaps.length;Me++)Ee(O.__webglFramebuffer[Me],T,b,n.COLOR_ATTACHMENT0,_e,Me);else Ee(O.__webglFramebuffer,T,b,n.COLOR_ATTACHMENT0,_e,0);x(b,ve)&&g(_e),t.unbindTexture()}T.depthBuffer&&De(T)}function G(T){const b=p(T)||o,O=T.isWebGLMultipleRenderTargets===!0?T.texture:[T.texture];for(let Q=0,Z=O.length;Q<Z;Q++){const te=O[Q];if(x(te,b)){const ve=T.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,_e=i.get(te).__webglTexture;t.bindTexture(ve,_e),g(ve),t.unbindTexture()}}}function F(T){if(o&&T.samples>0&&oe(T)===!1){const b=T.isWebGLMultipleRenderTargets?T.texture:[T.texture],O=T.width,Q=T.height;let Z=n.COLOR_BUFFER_BIT;const te=[],ve=T.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,_e=i.get(T),Me=T.isWebGLMultipleRenderTargets===!0;if(Me)for(let we=0;we<b.length;we++)t.bindFramebuffer(n.FRAMEBUFFER,_e.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+we,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,_e.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+we,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,_e.__webglMultisampledFramebuffer),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,_e.__webglFramebuffer);for(let we=0;we<b.length;we++){te.push(n.COLOR_ATTACHMENT0+we),T.depthBuffer&&te.push(ve);const Ue=_e.__ignoreDepthValues!==void 0?_e.__ignoreDepthValues:!1;if(Ue===!1&&(T.depthBuffer&&(Z|=n.DEPTH_BUFFER_BIT),T.stencilBuffer&&(Z|=n.STENCIL_BUFFER_BIT)),Me&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,_e.__webglColorRenderbuffer[we]),Ue===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[ve]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[ve])),Me){const le=i.get(b[we]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,le,0)}n.blitFramebuffer(0,0,O,Q,0,0,O,Q,Z,n.NEAREST),l&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,te)}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),Me)for(let we=0;we<b.length;we++){t.bindFramebuffer(n.FRAMEBUFFER,_e.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+we,n.RENDERBUFFER,_e.__webglColorRenderbuffer[we]);const Ue=i.get(b[we]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,_e.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+we,n.TEXTURE_2D,Ue,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,_e.__webglMultisampledFramebuffer)}}function ae(T){return Math.min(r.maxSamples,T.samples)}function oe(T){const b=i.get(T);return o&&T.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&b.__useRenderToTexture!==!1}function ee(T){const b=a.render.frame;d.get(T)!==b&&(d.set(T,b),T.update())}function me(T,b){const O=T.colorSpace,Q=T.format,Z=T.type;return T.isCompressedTexture===!0||T.isVideoTexture===!0||T.format===_a||O!==xn&&O!==$t&&(et.getTransfer(O)===ot?o===!1?e.has("EXT_sRGB")===!0&&Q===sn?(T.format=_a,T.minFilter=Zt,T.generateMipmaps=!1):b=il.sRGBToLinear(b):(Q!==sn||Z!==Ln)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",O)),b}this.allocateTextureUnit=L,this.resetTextureUnits=W,this.setTexture2D=k,this.setTexture2DArray=X,this.setTexture3D=$,this.setTextureCube=ie,this.rebindTextures=S,this.setupRenderTarget=y,this.updateRenderTargetMipmap=G,this.updateMultisampleRenderTarget=F,this.setupDepthRenderbuffer=De,this.setupFrameBufferTexture=Ee,this.useMultisampledRTT=oe}function jm(n,e,t){const i=t.isWebGL2;function r(s,a=$t){let o;const c=et.getTransfer(a);if(s===Ln)return n.UNSIGNED_BYTE;if(s===Yc)return n.UNSIGNED_SHORT_4_4_4_4;if(s===Zc)return n.UNSIGNED_SHORT_5_5_5_1;if(s===Ph)return n.BYTE;if(s===Lh)return n.SHORT;if(s===Da)return n.UNSIGNED_SHORT;if(s===qc)return n.INT;if(s===Tn)return n.UNSIGNED_INT;if(s===An)return n.FLOAT;if(s===rr)return i?n.HALF_FLOAT:(o=e.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(s===Dh)return n.ALPHA;if(s===sn)return n.RGBA;if(s===Uh)return n.LUMINANCE;if(s===Ih)return n.LUMINANCE_ALPHA;if(s===Kn)return n.DEPTH_COMPONENT;if(s===Ii)return n.DEPTH_STENCIL;if(s===_a)return o=e.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(s===Nh)return n.RED;if(s===jc)return n.RED_INTEGER;if(s===zh)return n.RG;if(s===Kc)return n.RG_INTEGER;if(s===$c)return n.RGBA_INTEGER;if(s===Cs||s===Ps||s===Ls||s===Ds)if(c===ot)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(s===Cs)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Ps)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===Ls)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Ds)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(s===Cs)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Ps)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===Ls)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Ds)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===co||s===lo||s===ho||s===uo)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(s===co)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===lo)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===ho)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===uo)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===Jc)return o=e.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===fo||s===po)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(s===fo)return c===ot?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(s===po)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===mo||s===go||s===_o||s===xo||s===vo||s===Mo||s===yo||s===So||s===bo||s===Eo||s===wo||s===To||s===Ao||s===Ro)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(s===mo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===go)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===_o)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===xo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===vo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Mo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===yo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===So)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===bo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Eo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===wo)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===To)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Ao)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Ro)return c===ot?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Us||s===Co||s===Po)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(s===Us)return c===ot?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Co)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Po)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===Fh||s===Lo||s===Do||s===Uo)if(o=e.get("EXT_texture_compression_rgtc"),o!==null){if(s===Us)return o.COMPRESSED_RED_RGTC1_EXT;if(s===Lo)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===Do)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Uo)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===jn?i?n.UNSIGNED_INT_24_8:(o=e.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[s]!==void 0?n[s]:null}return{convert:r}}class Km extends Kt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class gt extends ut{constructor(){super(),this.isGroup=!0,this.type="Group"}}const $m={type:"move"};class ra{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new gt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new gt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new z,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new z),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new gt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new z,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new z),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,a=null;const o=this._targetRay,c=this._grip,l=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(l&&e.hand){a=!0;for(const _ of e.hand.values()){const p=t.getJointPose(_,i),f=this._getHandJoint(l,_);p!==null&&(f.matrix.fromArray(p.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=p.radius),f.visible=p!==null}const d=l.joints["index-finger-tip"],h=l.joints["thumb-tip"],u=d.position.distanceTo(h.position),m=.02,M=.005;l.inputState.pinching&&u>m+M?(l.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!l.inputState.pinching&&u<=m-M&&(l.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else c!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(c.matrix.fromArray(s.transform.matrix),c.matrix.decompose(c.position,c.rotation,c.scale),c.matrixWorldNeedsUpdate=!0,s.linearVelocity?(c.hasLinearVelocity=!0,c.linearVelocity.copy(s.linearVelocity)):c.hasLinearVelocity=!1,s.angularVelocity?(c.hasAngularVelocity=!0,c.angularVelocity.copy(s.angularVelocity)):c.hasAngularVelocity=!1));o!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent($m)))}return o!==null&&(o.visible=r!==null),c!==null&&(c.visible=s!==null),l!==null&&(l.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new gt;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class Jm extends Gi{constructor(e,t){super();const i=this;let r=null,s=1,a=null,o="local-floor",c=1,l=null,d=null,h=null,u=null,m=null,M=null;const _=t.getContextAttributes();let p=null,f=null;const x=[],g=[],v=new Oe;let C=null;const P=new Kt;P.layers.enable(1),P.viewport=new wt;const A=new Kt;A.layers.enable(2),A.viewport=new wt;const N=[P,A],E=new Km;E.layers.enable(1),E.layers.enable(2);let w=null,H=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let se=x[J];return se===void 0&&(se=new ra,x[J]=se),se.getTargetRaySpace()},this.getControllerGrip=function(J){let se=x[J];return se===void 0&&(se=new ra,x[J]=se),se.getGripSpace()},this.getHand=function(J){let se=x[J];return se===void 0&&(se=new ra,x[J]=se),se.getHandSpace()};function U(J){const se=g.indexOf(J.inputSource);if(se===-1)return;const ge=x[se];ge!==void 0&&(ge.update(J.inputSource,J.frame,l||a),ge.dispatchEvent({type:J.type,data:J.inputSource}))}function W(){r.removeEventListener("select",U),r.removeEventListener("selectstart",U),r.removeEventListener("selectend",U),r.removeEventListener("squeeze",U),r.removeEventListener("squeezestart",U),r.removeEventListener("squeezeend",U),r.removeEventListener("end",W),r.removeEventListener("inputsourceschange",L);for(let J=0;J<x.length;J++){const se=g[J];se!==null&&(g[J]=null,x[J].disconnect(se))}w=null,H=null,e.setRenderTarget(p),m=null,u=null,h=null,r=null,f=null,de.stop(),i.isPresenting=!1,e.setPixelRatio(C),e.setSize(v.width,v.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){s=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){o=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return l||a},this.setReferenceSpace=function(J){l=J},this.getBaseLayer=function(){return u!==null?u:m},this.getBinding=function(){return h},this.getFrame=function(){return M},this.getSession=function(){return r},this.setSession=async function(J){if(r=J,r!==null){if(p=e.getRenderTarget(),r.addEventListener("select",U),r.addEventListener("selectstart",U),r.addEventListener("selectend",U),r.addEventListener("squeeze",U),r.addEventListener("squeezestart",U),r.addEventListener("squeezeend",U),r.addEventListener("end",W),r.addEventListener("inputsourceschange",L),_.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(v),r.renderState.layers===void 0||e.capabilities.isWebGL2===!1){const se={antialias:r.renderState.layers===void 0?_.antialias:!0,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:s};m=new XRWebGLLayer(r,t,se),r.updateRenderState({baseLayer:m}),e.setPixelRatio(1),e.setSize(m.framebufferWidth,m.framebufferHeight,!1),f=new Jn(m.framebufferWidth,m.framebufferHeight,{format:sn,type:Ln,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil})}else{let se=null,ge=null,Ae=null;_.depth&&(Ae=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,se=_.stencil?Ii:Kn,ge=_.stencil?jn:Tn);const Ee={colorFormat:t.RGBA8,depthFormat:Ae,scaleFactor:s};h=new XRWebGLBinding(r,t),u=h.createProjectionLayer(Ee),r.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),f=new Jn(u.textureWidth,u.textureHeight,{format:sn,type:Ln,depthTexture:new fl(u.textureWidth,u.textureHeight,ge,void 0,void 0,void 0,void 0,void 0,void 0,se),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0});const Be=e.properties.get(f);Be.__ignoreDepthValues=u.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(c),l=null,a=await r.requestReferenceSpace(o),de.setContext(r),de.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode};function L(J){for(let se=0;se<J.removed.length;se++){const ge=J.removed[se],Ae=g.indexOf(ge);Ae>=0&&(g[Ae]=null,x[Ae].disconnect(ge))}for(let se=0;se<J.added.length;se++){const ge=J.added[se];let Ae=g.indexOf(ge);if(Ae===-1){for(let Be=0;Be<x.length;Be++)if(Be>=g.length){g.push(ge),Ae=Be;break}else if(g[Be]===null){g[Be]=ge,Ae=Be;break}if(Ae===-1)break}const Ee=x[Ae];Ee&&Ee.connect(ge)}}const I=new z,k=new z;function X(J,se,ge){I.setFromMatrixPosition(se.matrixWorld),k.setFromMatrixPosition(ge.matrixWorld);const Ae=I.distanceTo(k),Ee=se.projectionMatrix.elements,Be=ge.projectionMatrix.elements,ke=Ee[14]/(Ee[10]-1),De=Ee[14]/(Ee[10]+1),S=(Ee[9]+1)/Ee[5],y=(Ee[9]-1)/Ee[5],G=(Ee[8]-1)/Ee[0],F=(Be[8]+1)/Be[0],ae=ke*G,oe=ke*F,ee=Ae/(-G+F),me=ee*-G;se.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(me),J.translateZ(ee),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert();const T=ke+ee,b=De+ee,O=ae-me,Q=oe+(Ae-me),Z=S*De/b*T,te=y*De/b*T;J.projectionMatrix.makePerspective(O,Q,Z,te,T,b),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}function $(J,se){se===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(se.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(r===null)return;E.near=A.near=P.near=J.near,E.far=A.far=P.far=J.far,(w!==E.near||H!==E.far)&&(r.updateRenderState({depthNear:E.near,depthFar:E.far}),w=E.near,H=E.far);const se=J.parent,ge=E.cameras;$(E,se);for(let Ae=0;Ae<ge.length;Ae++)$(ge[Ae],se);ge.length===2?X(E,P,A):E.projectionMatrix.copy(P.projectionMatrix),ie(J,E,se)};function ie(J,se,ge){ge===null?J.matrix.copy(se.matrixWorld):(J.matrix.copy(ge.matrixWorld),J.matrix.invert(),J.matrix.multiply(se.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(se.projectionMatrix),J.projectionMatrixInverse.copy(se.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=xa*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return E},this.getFoveation=function(){if(!(u===null&&m===null))return c},this.setFoveation=function(J){c=J,u!==null&&(u.fixedFoveation=J),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=J)};let ne=null;function ue(J,se){if(d=se.getViewerPose(l||a),M=se,d!==null){const ge=d.views;m!==null&&(e.setRenderTargetFramebuffer(f,m.framebuffer),e.setRenderTarget(f));let Ae=!1;ge.length!==E.cameras.length&&(E.cameras.length=0,Ae=!0);for(let Ee=0;Ee<ge.length;Ee++){const Be=ge[Ee];let ke=null;if(m!==null)ke=m.getViewport(Be);else{const S=h.getViewSubImage(u,Be);ke=S.viewport,Ee===0&&(e.setRenderTargetTextures(f,S.colorTexture,u.ignoreDepthValues?void 0:S.depthStencilTexture),e.setRenderTarget(f))}let De=N[Ee];De===void 0&&(De=new Kt,De.layers.enable(Ee),De.viewport=new wt,N[Ee]=De),De.matrix.fromArray(Be.transform.matrix),De.matrix.decompose(De.position,De.quaternion,De.scale),De.projectionMatrix.fromArray(Be.projectionMatrix),De.projectionMatrixInverse.copy(De.projectionMatrix).invert(),De.viewport.set(ke.x,ke.y,ke.width,ke.height),Ee===0&&(E.matrix.copy(De.matrix),E.matrix.decompose(E.position,E.quaternion,E.scale)),Ae===!0&&E.cameras.push(De)}}for(let ge=0;ge<x.length;ge++){const Ae=g[ge],Ee=x[ge];Ae!==null&&Ee!==void 0&&Ee.update(Ae,se,l||a)}ne&&ne(J,se),se.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:se}),M=null}const de=new dl;de.setAnimationLoop(ue),this.setAnimationLoop=function(J){ne=J},this.dispose=function(){}}}function Qm(n,e){function t(p,f){p.matrixAutoUpdate===!0&&p.updateMatrix(),f.value.copy(p.matrix)}function i(p,f){f.color.getRGB(p.fogColor.value,ll(n)),f.isFog?(p.fogNear.value=f.near,p.fogFar.value=f.far):f.isFogExp2&&(p.fogDensity.value=f.density)}function r(p,f,x,g,v){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(p,f):f.isMeshToonMaterial?(s(p,f),h(p,f)):f.isMeshPhongMaterial?(s(p,f),d(p,f)):f.isMeshStandardMaterial?(s(p,f),u(p,f),f.isMeshPhysicalMaterial&&m(p,f,v)):f.isMeshMatcapMaterial?(s(p,f),M(p,f)):f.isMeshDepthMaterial?s(p,f):f.isMeshDistanceMaterial?(s(p,f),_(p,f)):f.isMeshNormalMaterial?s(p,f):f.isLineBasicMaterial?(a(p,f),f.isLineDashedMaterial&&o(p,f)):f.isPointsMaterial?c(p,f,x,g):f.isSpriteMaterial?l(p,f):f.isShadowMaterial?(p.color.value.copy(f.color),p.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(p,f){p.opacity.value=f.opacity,f.color&&p.diffuse.value.copy(f.color),f.emissive&&p.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(p.map.value=f.map,t(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.bumpMap&&(p.bumpMap.value=f.bumpMap,t(f.bumpMap,p.bumpMapTransform),p.bumpScale.value=f.bumpScale,f.side===Ft&&(p.bumpScale.value*=-1)),f.normalMap&&(p.normalMap.value=f.normalMap,t(f.normalMap,p.normalMapTransform),p.normalScale.value.copy(f.normalScale),f.side===Ft&&p.normalScale.value.negate()),f.displacementMap&&(p.displacementMap.value=f.displacementMap,t(f.displacementMap,p.displacementMapTransform),p.displacementScale.value=f.displacementScale,p.displacementBias.value=f.displacementBias),f.emissiveMap&&(p.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,p.emissiveMapTransform)),f.specularMap&&(p.specularMap.value=f.specularMap,t(f.specularMap,p.specularMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);const x=e.get(f).envMap;if(x&&(p.envMap.value=x,p.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=f.reflectivity,p.ior.value=f.ior,p.refractionRatio.value=f.refractionRatio),f.lightMap){p.lightMap.value=f.lightMap;const g=n._useLegacyLights===!0?Math.PI:1;p.lightMapIntensity.value=f.lightMapIntensity*g,t(f.lightMap,p.lightMapTransform)}f.aoMap&&(p.aoMap.value=f.aoMap,p.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,p.aoMapTransform))}function a(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,f.map&&(p.map.value=f.map,t(f.map,p.mapTransform))}function o(p,f){p.dashSize.value=f.dashSize,p.totalSize.value=f.dashSize+f.gapSize,p.scale.value=f.scale}function c(p,f,x,g){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.size.value=f.size*x,p.scale.value=g*.5,f.map&&(p.map.value=f.map,t(f.map,p.uvTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function l(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.rotation.value=f.rotation,f.map&&(p.map.value=f.map,t(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function d(p,f){p.specular.value.copy(f.specular),p.shininess.value=Math.max(f.shininess,1e-4)}function h(p,f){f.gradientMap&&(p.gradientMap.value=f.gradientMap)}function u(p,f){p.metalness.value=f.metalness,f.metalnessMap&&(p.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,p.metalnessMapTransform)),p.roughness.value=f.roughness,f.roughnessMap&&(p.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,p.roughnessMapTransform)),e.get(f).envMap&&(p.envMapIntensity.value=f.envMapIntensity)}function m(p,f,x){p.ior.value=f.ior,f.sheen>0&&(p.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),p.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(p.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,p.sheenColorMapTransform)),f.sheenRoughnessMap&&(p.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,p.sheenRoughnessMapTransform))),f.clearcoat>0&&(p.clearcoat.value=f.clearcoat,p.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(p.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,p.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(p.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Ft&&p.clearcoatNormalScale.value.negate())),f.iridescence>0&&(p.iridescence.value=f.iridescence,p.iridescenceIOR.value=f.iridescenceIOR,p.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(p.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,p.iridescenceMapTransform)),f.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),f.transmission>0&&(p.transmission.value=f.transmission,p.transmissionSamplerMap.value=x.texture,p.transmissionSamplerSize.value.set(x.width,x.height),f.transmissionMap&&(p.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,p.transmissionMapTransform)),p.thickness.value=f.thickness,f.thicknessMap&&(p.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=f.attenuationDistance,p.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(p.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(p.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=f.specularIntensity,p.specularColor.value.copy(f.specularColor),f.specularColorMap&&(p.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,p.specularColorMapTransform)),f.specularIntensityMap&&(p.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,p.specularIntensityMapTransform))}function M(p,f){f.matcap&&(p.matcap.value=f.matcap)}function _(p,f){const x=e.get(f).light;p.referencePosition.value.setFromMatrixPosition(x.matrixWorld),p.nearDistance.value=x.shadow.camera.near,p.farDistance.value=x.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function e0(n,e,t,i){let r={},s={},a=[];const o=t.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function c(x,g){const v=g.program;i.uniformBlockBinding(x,v)}function l(x,g){let v=r[x.id];v===void 0&&(M(x),v=d(x),r[x.id]=v,x.addEventListener("dispose",p));const C=g.program;i.updateUBOMapping(x,C);const P=e.render.frame;s[x.id]!==P&&(u(x),s[x.id]=P)}function d(x){const g=h();x.__bindingPointIndex=g;const v=n.createBuffer(),C=x.__size,P=x.usage;return n.bindBuffer(n.UNIFORM_BUFFER,v),n.bufferData(n.UNIFORM_BUFFER,C,P),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,g,v),v}function h(){for(let x=0;x<o;x++)if(a.indexOf(x)===-1)return a.push(x),x;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function u(x){const g=r[x.id],v=x.uniforms,C=x.__cache;n.bindBuffer(n.UNIFORM_BUFFER,g);for(let P=0,A=v.length;P<A;P++){const N=Array.isArray(v[P])?v[P]:[v[P]];for(let E=0,w=N.length;E<w;E++){const H=N[E];if(m(H,P,E,C)===!0){const U=H.__offset,W=Array.isArray(H.value)?H.value:[H.value];let L=0;for(let I=0;I<W.length;I++){const k=W[I],X=_(k);typeof k=="number"||typeof k=="boolean"?(H.__data[0]=k,n.bufferSubData(n.UNIFORM_BUFFER,U+L,H.__data)):k.isMatrix3?(H.__data[0]=k.elements[0],H.__data[1]=k.elements[1],H.__data[2]=k.elements[2],H.__data[3]=0,H.__data[4]=k.elements[3],H.__data[5]=k.elements[4],H.__data[6]=k.elements[5],H.__data[7]=0,H.__data[8]=k.elements[6],H.__data[9]=k.elements[7],H.__data[10]=k.elements[8],H.__data[11]=0):(k.toArray(H.__data,L),L+=X.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,U,H.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function m(x,g,v,C){const P=x.value,A=g+"_"+v;if(C[A]===void 0)return typeof P=="number"||typeof P=="boolean"?C[A]=P:C[A]=P.clone(),!0;{const N=C[A];if(typeof P=="number"||typeof P=="boolean"){if(N!==P)return C[A]=P,!0}else if(N.equals(P)===!1)return N.copy(P),!0}return!1}function M(x){const g=x.uniforms;let v=0;const C=16;for(let A=0,N=g.length;A<N;A++){const E=Array.isArray(g[A])?g[A]:[g[A]];for(let w=0,H=E.length;w<H;w++){const U=E[w],W=Array.isArray(U.value)?U.value:[U.value];for(let L=0,I=W.length;L<I;L++){const k=W[L],X=_(k),$=v%C;$!==0&&C-$<X.boundary&&(v+=C-$),U.__data=new Float32Array(X.storage/Float32Array.BYTES_PER_ELEMENT),U.__offset=v,v+=X.storage}}}const P=v%C;return P>0&&(v+=C-P),x.__size=v,x.__cache={},this}function _(x){const g={boundary:0,storage:0};return typeof x=="number"||typeof x=="boolean"?(g.boundary=4,g.storage=4):x.isVector2?(g.boundary=8,g.storage=8):x.isVector3||x.isColor?(g.boundary=16,g.storage=12):x.isVector4?(g.boundary=16,g.storage=16):x.isMatrix3?(g.boundary=48,g.storage=48):x.isMatrix4?(g.boundary=64,g.storage=64):x.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",x),g}function p(x){const g=x.target;g.removeEventListener("dispose",p);const v=a.indexOf(g.__bindingPointIndex);a.splice(v,1),n.deleteBuffer(r[g.id]),delete r[g.id],delete s[g.id]}function f(){for(const x in r)n.deleteBuffer(r[x]);a=[],r={},s={}}return{bind:c,update:l,dispose:f}}class Oa{constructor(e={}){const{canvas:t=jh(),context:i=null,depth:r=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:c=!0,preserveDrawingBuffer:l=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:h=!1}=e;this.isWebGLRenderer=!0;let u;i!==null?u=i.getContextAttributes().alpha:u=a;const m=new Uint32Array(4),M=new Int32Array(4);let _=null,p=null;const f=[],x=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=mt,this._useLegacyLights=!1,this.toneMapping=Pn,this.toneMappingExposure=1;const g=this;let v=!1,C=0,P=0,A=null,N=-1,E=null;const w=new wt,H=new wt;let U=null;const W=new je(0);let L=0,I=t.width,k=t.height,X=1,$=null,ie=null;const ne=new wt(0,0,I,k),ue=new wt(0,0,I,k);let de=!1;const J=new Na;let se=!1,ge=!1,Ae=null;const Ee=new Qe,Be=new Oe,ke=new z,De={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function S(){return A===null?X:1}let y=i;function G(R,B){for(let Y=0;Y<R.length;Y++){const K=R[Y],q=t.getContext(K,B);if(q!==null)return q}return null}try{const R={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:c,preserveDrawingBuffer:l,powerPreference:d,failIfMajorPerformanceCaveat:h};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Pa}`),t.addEventListener("webglcontextlost",j,!1),t.addEventListener("webglcontextrestored",D,!1),t.addEventListener("webglcontextcreationerror",he,!1),y===null){const B=["webgl2","webgl","experimental-webgl"];if(g.isWebGL1Renderer===!0&&B.shift(),y=G(B,R),y===null)throw G(B)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&y instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),y.getShaderPrecisionFormat===void 0&&(y.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(R){throw console.error("THREE.WebGLRenderer: "+R.message),R}let F,ae,oe,ee,me,T,b,O,Q,Z,te,ve,_e,Me,we,Ue,le,Ke,Ve,Ne,Ce,Se,ze,re;function ce(){F=new hp(y),ae=new rp(y,F,e),F.init(ae),Se=new jm(y,F,ae),oe=new Ym(y,F,ae),ee=new fp(y),me=new Um,T=new Zm(y,F,oe,me,ae,Se,ee),b=new ap(g),O=new lp(g),Q=new Mu(y,ae),ze=new np(y,F,Q,ae),Z=new up(y,Q,ee,ze),te=new _p(y,Z,Q,ee),Ve=new gp(y,ae,T),Ue=new sp(me),ve=new Dm(g,b,O,F,ae,ze,Ue),_e=new Qm(g,me),Me=new Nm,we=new Gm(F,ae),Ke=new tp(g,b,O,oe,te,u,c),le=new qm(g,te,ae),re=new e0(y,ee,ae,oe),Ne=new ip(y,F,ee,ae),Ce=new dp(y,F,ee,ae),ee.programs=ve.programs,g.capabilities=ae,g.extensions=F,g.properties=me,g.renderLists=Me,g.shadowMap=le,g.state=oe,g.info=ee}ce();const fe=new Jm(g,y);this.xr=fe,this.getContext=function(){return y},this.getContextAttributes=function(){return y.getContextAttributes()},this.forceContextLoss=function(){const R=F.get("WEBGL_lose_context");R&&R.loseContext()},this.forceContextRestore=function(){const R=F.get("WEBGL_lose_context");R&&R.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(R){R!==void 0&&(X=R,this.setSize(I,k,!1))},this.getSize=function(R){return R.set(I,k)},this.setSize=function(R,B,Y=!0){if(fe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}I=R,k=B,t.width=Math.floor(R*X),t.height=Math.floor(B*X),Y===!0&&(t.style.width=R+"px",t.style.height=B+"px"),this.setViewport(0,0,R,B)},this.getDrawingBufferSize=function(R){return R.set(I*X,k*X).floor()},this.setDrawingBufferSize=function(R,B,Y){I=R,k=B,X=Y,t.width=Math.floor(R*Y),t.height=Math.floor(B*Y),this.setViewport(0,0,R,B)},this.getCurrentViewport=function(R){return R.copy(w)},this.getViewport=function(R){return R.copy(ne)},this.setViewport=function(R,B,Y,K){R.isVector4?ne.set(R.x,R.y,R.z,R.w):ne.set(R,B,Y,K),oe.viewport(w.copy(ne).multiplyScalar(X).floor())},this.getScissor=function(R){return R.copy(ue)},this.setScissor=function(R,B,Y,K){R.isVector4?ue.set(R.x,R.y,R.z,R.w):ue.set(R,B,Y,K),oe.scissor(H.copy(ue).multiplyScalar(X).floor())},this.getScissorTest=function(){return de},this.setScissorTest=function(R){oe.setScissorTest(de=R)},this.setOpaqueSort=function(R){$=R},this.setTransparentSort=function(R){ie=R},this.getClearColor=function(R){return R.copy(Ke.getClearColor())},this.setClearColor=function(){Ke.setClearColor.apply(Ke,arguments)},this.getClearAlpha=function(){return Ke.getClearAlpha()},this.setClearAlpha=function(){Ke.setClearAlpha.apply(Ke,arguments)},this.clear=function(R=!0,B=!0,Y=!0){let K=0;if(R){let q=!1;if(A!==null){const ye=A.texture.format;q=ye===$c||ye===Kc||ye===jc}if(q){const ye=A.texture.type,Re=ye===Ln||ye===Tn||ye===Da||ye===jn||ye===Yc||ye===Zc,Le=Ke.getClearColor(),Fe=Ke.getClearAlpha(),qe=Le.r,Ge=Le.g,He=Le.b;Re?(m[0]=qe,m[1]=Ge,m[2]=He,m[3]=Fe,y.clearBufferuiv(y.COLOR,0,m)):(M[0]=qe,M[1]=Ge,M[2]=He,M[3]=Fe,y.clearBufferiv(y.COLOR,0,M))}else K|=y.COLOR_BUFFER_BIT}B&&(K|=y.DEPTH_BUFFER_BIT),Y&&(K|=y.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),y.clear(K)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",j,!1),t.removeEventListener("webglcontextrestored",D,!1),t.removeEventListener("webglcontextcreationerror",he,!1),Me.dispose(),we.dispose(),me.dispose(),b.dispose(),O.dispose(),te.dispose(),ze.dispose(),re.dispose(),ve.dispose(),fe.dispose(),fe.removeEventListener("sessionstart",Pt),fe.removeEventListener("sessionend",st),Ae&&(Ae.dispose(),Ae=null),Lt.stop()};function j(R){R.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),v=!0}function D(){console.log("THREE.WebGLRenderer: Context Restored."),v=!1;const R=ee.autoReset,B=le.enabled,Y=le.autoUpdate,K=le.needsUpdate,q=le.type;ce(),ee.autoReset=R,le.enabled=B,le.autoUpdate=Y,le.needsUpdate=K,le.type=q}function he(R){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",R.statusMessage)}function pe(R){const B=R.target;B.removeEventListener("dispose",pe),Te(B)}function Te(R){Pe(R),me.remove(R)}function Pe(R){const B=me.get(R).programs;B!==void 0&&(B.forEach(function(Y){ve.releaseProgram(Y)}),R.isShaderMaterial&&ve.releaseShaderCache(R))}this.renderBufferDirect=function(R,B,Y,K,q,ye){B===null&&(B=De);const Re=q.isMesh&&q.matrixWorld.determinant()<0,Le=Xl(R,B,Y,K,q);oe.setMaterial(K,Re);let Fe=Y.index,qe=1;if(K.wireframe===!0){if(Fe=Z.getWireframeAttribute(Y),Fe===void 0)return;qe=2}const Ge=Y.drawRange,He=Y.attributes.position;let ft=Ge.start*qe,Bt=(Ge.start+Ge.count)*qe;ye!==null&&(ft=Math.max(ft,ye.start*qe),Bt=Math.min(Bt,(ye.start+ye.count)*qe)),Fe!==null?(ft=Math.max(ft,0),Bt=Math.min(Bt,Fe.count)):He!=null&&(ft=Math.max(ft,0),Bt=Math.min(Bt,He.count));const bt=Bt-ft;if(bt<0||bt===1/0)return;ze.setup(q,K,Le,Y,Fe);let cn,ht=Ne;if(Fe!==null&&(cn=Q.get(Fe),ht=Ce,ht.setIndex(cn)),q.isMesh)K.wireframe===!0?(oe.setLineWidth(K.wireframeLinewidth*S()),ht.setMode(y.LINES)):ht.setMode(y.TRIANGLES);else if(q.isLine){let Ze=K.linewidth;Ze===void 0&&(Ze=1),oe.setLineWidth(Ze*S()),q.isLineSegments?ht.setMode(y.LINES):q.isLineLoop?ht.setMode(y.LINE_LOOP):ht.setMode(y.LINE_STRIP)}else q.isPoints?ht.setMode(y.POINTS):q.isSprite&&ht.setMode(y.TRIANGLES);if(q.isBatchedMesh)ht.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else if(q.isInstancedMesh)ht.renderInstances(ft,bt,q.count);else if(Y.isInstancedBufferGeometry){const Ze=Y._maxInstanceCount!==void 0?Y._maxInstanceCount:1/0,Es=Math.min(Y.instanceCount,Ze);ht.renderInstances(ft,bt,Es)}else ht.render(ft,bt)};function it(R,B,Y){R.transparent===!0&&R.side===xt&&R.forceSinglePass===!1?(R.side=Ft,R.needsUpdate=!0,fr(R,B,Y),R.side=_n,R.needsUpdate=!0,fr(R,B,Y),R.side=xt):fr(R,B,Y)}this.compile=function(R,B,Y=null){Y===null&&(Y=R),p=we.get(Y),p.init(),x.push(p),Y.traverseVisible(function(q){q.isLight&&q.layers.test(B.layers)&&(p.pushLight(q),q.castShadow&&p.pushShadow(q))}),R!==Y&&R.traverseVisible(function(q){q.isLight&&q.layers.test(B.layers)&&(p.pushLight(q),q.castShadow&&p.pushShadow(q))}),p.setupLights(g._useLegacyLights);const K=new Set;return R.traverse(function(q){const ye=q.material;if(ye)if(Array.isArray(ye))for(let Re=0;Re<ye.length;Re++){const Le=ye[Re];it(Le,Y,q),K.add(Le)}else it(ye,Y,q),K.add(ye)}),x.pop(),p=null,K},this.compileAsync=function(R,B,Y=null){const K=this.compile(R,B,Y);return new Promise(q=>{function ye(){if(K.forEach(function(Re){me.get(Re).currentProgram.isReady()&&K.delete(Re)}),K.size===0){q(R);return}setTimeout(ye,10)}F.get("KHR_parallel_shader_compile")!==null?ye():setTimeout(ye,10)})};let rt=null;function St(R){rt&&rt(R)}function Pt(){Lt.stop()}function st(){Lt.start()}const Lt=new dl;Lt.setAnimationLoop(St),typeof self<"u"&&Lt.setContext(self),this.setAnimationLoop=function(R){rt=R,fe.setAnimationLoop(R),R===null?Lt.stop():Lt.start()},fe.addEventListener("sessionstart",Pt),fe.addEventListener("sessionend",st),this.render=function(R,B){if(B!==void 0&&B.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(v===!0)return;R.matrixWorldAutoUpdate===!0&&R.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),fe.enabled===!0&&fe.isPresenting===!0&&(fe.cameraAutoUpdate===!0&&fe.updateCamera(B),B=fe.getCamera()),R.isScene===!0&&R.onBeforeRender(g,R,B,A),p=we.get(R,x.length),p.init(),x.push(p),Ee.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),J.setFromProjectionMatrix(Ee),ge=this.localClippingEnabled,se=Ue.init(this.clippingPlanes,ge),_=Me.get(R,f.length),_.init(),f.push(_),an(R,B,0,g.sortObjects),_.finish(),g.sortObjects===!0&&_.sort($,ie),this.info.render.frame++,se===!0&&Ue.beginShadows();const Y=p.state.shadowsArray;if(le.render(Y,R,B),se===!0&&Ue.endShadows(),this.info.autoReset===!0&&this.info.reset(),Ke.render(_,R),p.setupLights(g._useLegacyLights),B.isArrayCamera){const K=B.cameras;for(let q=0,ye=K.length;q<ye;q++){const Re=K[q];ja(_,R,Re,Re.viewport)}}else ja(_,R,B);A!==null&&(T.updateMultisampleRenderTarget(A),T.updateRenderTargetMipmap(A)),R.isScene===!0&&R.onAfterRender(g,R,B),ze.resetDefaultState(),N=-1,E=null,x.pop(),x.length>0?p=x[x.length-1]:p=null,f.pop(),f.length>0?_=f[f.length-1]:_=null};function an(R,B,Y,K){if(R.visible===!1)return;if(R.layers.test(B.layers)){if(R.isGroup)Y=R.renderOrder;else if(R.isLOD)R.autoUpdate===!0&&R.update(B);else if(R.isLight)p.pushLight(R),R.castShadow&&p.pushShadow(R);else if(R.isSprite){if(!R.frustumCulled||J.intersectsSprite(R)){K&&ke.setFromMatrixPosition(R.matrixWorld).applyMatrix4(Ee);const Re=te.update(R),Le=R.material;Le.visible&&_.push(R,Re,Le,Y,ke.z,null)}}else if((R.isMesh||R.isLine||R.isPoints)&&(!R.frustumCulled||J.intersectsObject(R))){const Re=te.update(R),Le=R.material;if(K&&(R.boundingSphere!==void 0?(R.boundingSphere===null&&R.computeBoundingSphere(),ke.copy(R.boundingSphere.center)):(Re.boundingSphere===null&&Re.computeBoundingSphere(),ke.copy(Re.boundingSphere.center)),ke.applyMatrix4(R.matrixWorld).applyMatrix4(Ee)),Array.isArray(Le)){const Fe=Re.groups;for(let qe=0,Ge=Fe.length;qe<Ge;qe++){const He=Fe[qe],ft=Le[He.materialIndex];ft&&ft.visible&&_.push(R,Re,ft,Y,ke.z,He)}}else Le.visible&&_.push(R,Re,Le,Y,ke.z,null)}}const ye=R.children;for(let Re=0,Le=ye.length;Re<Le;Re++)an(ye[Re],B,Y,K)}function ja(R,B,Y,K){const q=R.opaque,ye=R.transmissive,Re=R.transparent;p.setupLightsView(Y),se===!0&&Ue.setGlobalState(g.clippingPlanes,Y),ye.length>0&&Wl(q,ye,B,Y),K&&oe.viewport(w.copy(K)),q.length>0&&dr(q,B,Y),ye.length>0&&dr(ye,B,Y),Re.length>0&&dr(Re,B,Y),oe.buffers.depth.setTest(!0),oe.buffers.depth.setMask(!0),oe.buffers.color.setMask(!0),oe.setPolygonOffset(!1)}function Wl(R,B,Y,K){if((Y.isScene===!0?Y.overrideMaterial:null)!==null)return;const ye=ae.isWebGL2;Ae===null&&(Ae=new Jn(1,1,{generateMipmaps:!0,type:F.has("EXT_color_buffer_half_float")?rr:Ln,minFilter:ir,samples:ye?4:0})),g.getDrawingBufferSize(Be),ye?Ae.setSize(Be.x,Be.y):Ae.setSize(va(Be.x),va(Be.y));const Re=g.getRenderTarget();g.setRenderTarget(Ae),g.getClearColor(W),L=g.getClearAlpha(),L<1&&g.setClearColor(16777215,.5),g.clear();const Le=g.toneMapping;g.toneMapping=Pn,dr(R,Y,K),T.updateMultisampleRenderTarget(Ae),T.updateRenderTargetMipmap(Ae);let Fe=!1;for(let qe=0,Ge=B.length;qe<Ge;qe++){const He=B[qe],ft=He.object,Bt=He.geometry,bt=He.material,cn=He.group;if(bt.side===xt&&ft.layers.test(K.layers)){const ht=bt.side;bt.side=Ft,bt.needsUpdate=!0,Ka(ft,Y,K,Bt,bt,cn),bt.side=ht,bt.needsUpdate=!0,Fe=!0}}Fe===!0&&(T.updateMultisampleRenderTarget(Ae),T.updateRenderTargetMipmap(Ae)),g.setRenderTarget(Re),g.setClearColor(W,L),g.toneMapping=Le}function dr(R,B,Y){const K=B.isScene===!0?B.overrideMaterial:null;for(let q=0,ye=R.length;q<ye;q++){const Re=R[q],Le=Re.object,Fe=Re.geometry,qe=K===null?Re.material:K,Ge=Re.group;Le.layers.test(Y.layers)&&Ka(Le,B,Y,Fe,qe,Ge)}}function Ka(R,B,Y,K,q,ye){R.onBeforeRender(g,B,Y,K,q,ye),R.modelViewMatrix.multiplyMatrices(Y.matrixWorldInverse,R.matrixWorld),R.normalMatrix.getNormalMatrix(R.modelViewMatrix),q.onBeforeRender(g,B,Y,K,R,ye),q.transparent===!0&&q.side===xt&&q.forceSinglePass===!1?(q.side=Ft,q.needsUpdate=!0,g.renderBufferDirect(Y,B,K,q,R,ye),q.side=_n,q.needsUpdate=!0,g.renderBufferDirect(Y,B,K,q,R,ye),q.side=xt):g.renderBufferDirect(Y,B,K,q,R,ye),R.onAfterRender(g,B,Y,K,q,ye)}function fr(R,B,Y){B.isScene!==!0&&(B=De);const K=me.get(R),q=p.state.lights,ye=p.state.shadowsArray,Re=q.state.version,Le=ve.getParameters(R,q.state,ye,B,Y),Fe=ve.getProgramCacheKey(Le);let qe=K.programs;K.environment=R.isMeshStandardMaterial?B.environment:null,K.fog=B.fog,K.envMap=(R.isMeshStandardMaterial?O:b).get(R.envMap||K.environment),qe===void 0&&(R.addEventListener("dispose",pe),qe=new Map,K.programs=qe);let Ge=qe.get(Fe);if(Ge!==void 0){if(K.currentProgram===Ge&&K.lightsStateVersion===Re)return Ja(R,Le),Ge}else Le.uniforms=ve.getUniforms(R),R.onBuild(Y,Le,g),R.onBeforeCompile(Le,g),Ge=ve.acquireProgram(Le,Fe),qe.set(Fe,Ge),K.uniforms=Le.uniforms;const He=K.uniforms;return(!R.isShaderMaterial&&!R.isRawShaderMaterial||R.clipping===!0)&&(He.clippingPlanes=Ue.uniform),Ja(R,Le),K.needsLights=Yl(R),K.lightsStateVersion=Re,K.needsLights&&(He.ambientLightColor.value=q.state.ambient,He.lightProbe.value=q.state.probe,He.directionalLights.value=q.state.directional,He.directionalLightShadows.value=q.state.directionalShadow,He.spotLights.value=q.state.spot,He.spotLightShadows.value=q.state.spotShadow,He.rectAreaLights.value=q.state.rectArea,He.ltc_1.value=q.state.rectAreaLTC1,He.ltc_2.value=q.state.rectAreaLTC2,He.pointLights.value=q.state.point,He.pointLightShadows.value=q.state.pointShadow,He.hemisphereLights.value=q.state.hemi,He.directionalShadowMap.value=q.state.directionalShadowMap,He.directionalShadowMatrix.value=q.state.directionalShadowMatrix,He.spotShadowMap.value=q.state.spotShadowMap,He.spotLightMatrix.value=q.state.spotLightMatrix,He.spotLightMap.value=q.state.spotLightMap,He.pointShadowMap.value=q.state.pointShadowMap,He.pointShadowMatrix.value=q.state.pointShadowMatrix),K.currentProgram=Ge,K.uniformsList=null,Ge}function $a(R){if(R.uniformsList===null){const B=R.currentProgram.getUniforms();R.uniformsList=qr.seqWithValue(B.seq,R.uniforms)}return R.uniformsList}function Ja(R,B){const Y=me.get(R);Y.outputColorSpace=B.outputColorSpace,Y.batching=B.batching,Y.instancing=B.instancing,Y.instancingColor=B.instancingColor,Y.skinning=B.skinning,Y.morphTargets=B.morphTargets,Y.morphNormals=B.morphNormals,Y.morphColors=B.morphColors,Y.morphTargetsCount=B.morphTargetsCount,Y.numClippingPlanes=B.numClippingPlanes,Y.numIntersection=B.numClipIntersection,Y.vertexAlphas=B.vertexAlphas,Y.vertexTangents=B.vertexTangents,Y.toneMapping=B.toneMapping}function Xl(R,B,Y,K,q){B.isScene!==!0&&(B=De),T.resetTextureUnits();const ye=B.fog,Re=K.isMeshStandardMaterial?B.environment:null,Le=A===null?g.outputColorSpace:A.isXRRenderTarget===!0?A.texture.colorSpace:xn,Fe=(K.isMeshStandardMaterial?O:b).get(K.envMap||Re),qe=K.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,Ge=!!Y.attributes.tangent&&(!!K.normalMap||K.anisotropy>0),He=!!Y.morphAttributes.position,ft=!!Y.morphAttributes.normal,Bt=!!Y.morphAttributes.color;let bt=Pn;K.toneMapped&&(A===null||A.isXRRenderTarget===!0)&&(bt=g.toneMapping);const cn=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,ht=cn!==void 0?cn.length:0,Ze=me.get(K),Es=p.state.lights;if(se===!0&&(ge===!0||R!==E)){const Wt=R===E&&K.id===N;Ue.setState(K,R,Wt)}let dt=!1;K.version===Ze.__version?(Ze.needsLights&&Ze.lightsStateVersion!==Es.state.version||Ze.outputColorSpace!==Le||q.isBatchedMesh&&Ze.batching===!1||!q.isBatchedMesh&&Ze.batching===!0||q.isInstancedMesh&&Ze.instancing===!1||!q.isInstancedMesh&&Ze.instancing===!0||q.isSkinnedMesh&&Ze.skinning===!1||!q.isSkinnedMesh&&Ze.skinning===!0||q.isInstancedMesh&&Ze.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ze.instancingColor===!1&&q.instanceColor!==null||Ze.envMap!==Fe||K.fog===!0&&Ze.fog!==ye||Ze.numClippingPlanes!==void 0&&(Ze.numClippingPlanes!==Ue.numPlanes||Ze.numIntersection!==Ue.numIntersection)||Ze.vertexAlphas!==qe||Ze.vertexTangents!==Ge||Ze.morphTargets!==He||Ze.morphNormals!==ft||Ze.morphColors!==Bt||Ze.toneMapping!==bt||ae.isWebGL2===!0&&Ze.morphTargetsCount!==ht)&&(dt=!0):(dt=!0,Ze.__version=K.version);let Nn=Ze.currentProgram;dt===!0&&(Nn=fr(K,B,q));let Qa=!1,Wi=!1,ws=!1;const Tt=Nn.getUniforms(),zn=Ze.uniforms;if(oe.useProgram(Nn.program)&&(Qa=!0,Wi=!0,ws=!0),K.id!==N&&(N=K.id,Wi=!0),Qa||E!==R){Tt.setValue(y,"projectionMatrix",R.projectionMatrix),Tt.setValue(y,"viewMatrix",R.matrixWorldInverse);const Wt=Tt.map.cameraPosition;Wt!==void 0&&Wt.setValue(y,ke.setFromMatrixPosition(R.matrixWorld)),ae.logarithmicDepthBuffer&&Tt.setValue(y,"logDepthBufFC",2/(Math.log(R.far+1)/Math.LN2)),(K.isMeshPhongMaterial||K.isMeshToonMaterial||K.isMeshLambertMaterial||K.isMeshBasicMaterial||K.isMeshStandardMaterial||K.isShaderMaterial)&&Tt.setValue(y,"isOrthographic",R.isOrthographicCamera===!0),E!==R&&(E=R,Wi=!0,ws=!0)}if(q.isSkinnedMesh){Tt.setOptional(y,q,"bindMatrix"),Tt.setOptional(y,q,"bindMatrixInverse");const Wt=q.skeleton;Wt&&(ae.floatVertexTextures?(Wt.boneTexture===null&&Wt.computeBoneTexture(),Tt.setValue(y,"boneTexture",Wt.boneTexture,T)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}q.isBatchedMesh&&(Tt.setOptional(y,q,"batchingTexture"),Tt.setValue(y,"batchingTexture",q._matricesTexture,T));const Ts=Y.morphAttributes;if((Ts.position!==void 0||Ts.normal!==void 0||Ts.color!==void 0&&ae.isWebGL2===!0)&&Ve.update(q,Y,Nn),(Wi||Ze.receiveShadow!==q.receiveShadow)&&(Ze.receiveShadow=q.receiveShadow,Tt.setValue(y,"receiveShadow",q.receiveShadow)),K.isMeshGouraudMaterial&&K.envMap!==null&&(zn.envMap.value=Fe,zn.flipEnvMap.value=Fe.isCubeTexture&&Fe.isRenderTargetTexture===!1?-1:1),Wi&&(Tt.setValue(y,"toneMappingExposure",g.toneMappingExposure),Ze.needsLights&&ql(zn,ws),ye&&K.fog===!0&&_e.refreshFogUniforms(zn,ye),_e.refreshMaterialUniforms(zn,K,X,k,Ae),qr.upload(y,$a(Ze),zn,T)),K.isShaderMaterial&&K.uniformsNeedUpdate===!0&&(qr.upload(y,$a(Ze),zn,T),K.uniformsNeedUpdate=!1),K.isSpriteMaterial&&Tt.setValue(y,"center",q.center),Tt.setValue(y,"modelViewMatrix",q.modelViewMatrix),Tt.setValue(y,"normalMatrix",q.normalMatrix),Tt.setValue(y,"modelMatrix",q.matrixWorld),K.isShaderMaterial||K.isRawShaderMaterial){const Wt=K.uniformsGroups;for(let As=0,Zl=Wt.length;As<Zl;As++)if(ae.isWebGL2){const eo=Wt[As];re.update(eo,Nn),re.bind(eo,Nn)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return Nn}function ql(R,B){R.ambientLightColor.needsUpdate=B,R.lightProbe.needsUpdate=B,R.directionalLights.needsUpdate=B,R.directionalLightShadows.needsUpdate=B,R.pointLights.needsUpdate=B,R.pointLightShadows.needsUpdate=B,R.spotLights.needsUpdate=B,R.spotLightShadows.needsUpdate=B,R.rectAreaLights.needsUpdate=B,R.hemisphereLights.needsUpdate=B}function Yl(R){return R.isMeshLambertMaterial||R.isMeshToonMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isShadowMaterial||R.isShaderMaterial&&R.lights===!0}this.getActiveCubeFace=function(){return C},this.getActiveMipmapLevel=function(){return P},this.getRenderTarget=function(){return A},this.setRenderTargetTextures=function(R,B,Y){me.get(R.texture).__webglTexture=B,me.get(R.depthTexture).__webglTexture=Y;const K=me.get(R);K.__hasExternalTextures=!0,K.__hasExternalTextures&&(K.__autoAllocateDepthBuffer=Y===void 0,K.__autoAllocateDepthBuffer||F.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),K.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(R,B){const Y=me.get(R);Y.__webglFramebuffer=B,Y.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(R,B=0,Y=0){A=R,C=B,P=Y;let K=!0,q=null,ye=!1,Re=!1;if(R){const Fe=me.get(R);Fe.__useDefaultFramebuffer!==void 0?(oe.bindFramebuffer(y.FRAMEBUFFER,null),K=!1):Fe.__webglFramebuffer===void 0?T.setupRenderTarget(R):Fe.__hasExternalTextures&&T.rebindTextures(R,me.get(R.texture).__webglTexture,me.get(R.depthTexture).__webglTexture);const qe=R.texture;(qe.isData3DTexture||qe.isDataArrayTexture||qe.isCompressedArrayTexture)&&(Re=!0);const Ge=me.get(R).__webglFramebuffer;R.isWebGLCubeRenderTarget?(Array.isArray(Ge[B])?q=Ge[B][Y]:q=Ge[B],ye=!0):ae.isWebGL2&&R.samples>0&&T.useMultisampledRTT(R)===!1?q=me.get(R).__webglMultisampledFramebuffer:Array.isArray(Ge)?q=Ge[Y]:q=Ge,w.copy(R.viewport),H.copy(R.scissor),U=R.scissorTest}else w.copy(ne).multiplyScalar(X).floor(),H.copy(ue).multiplyScalar(X).floor(),U=de;if(oe.bindFramebuffer(y.FRAMEBUFFER,q)&&ae.drawBuffers&&K&&oe.drawBuffers(R,q),oe.viewport(w),oe.scissor(H),oe.setScissorTest(U),ye){const Fe=me.get(R.texture);y.framebufferTexture2D(y.FRAMEBUFFER,y.COLOR_ATTACHMENT0,y.TEXTURE_CUBE_MAP_POSITIVE_X+B,Fe.__webglTexture,Y)}else if(Re){const Fe=me.get(R.texture),qe=B||0;y.framebufferTextureLayer(y.FRAMEBUFFER,y.COLOR_ATTACHMENT0,Fe.__webglTexture,Y||0,qe)}N=-1},this.readRenderTargetPixels=function(R,B,Y,K,q,ye,Re){if(!(R&&R.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Le=me.get(R).__webglFramebuffer;if(R.isWebGLCubeRenderTarget&&Re!==void 0&&(Le=Le[Re]),Le){oe.bindFramebuffer(y.FRAMEBUFFER,Le);try{const Fe=R.texture,qe=Fe.format,Ge=Fe.type;if(qe!==sn&&Se.convert(qe)!==y.getParameter(y.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const He=Ge===rr&&(F.has("EXT_color_buffer_half_float")||ae.isWebGL2&&F.has("EXT_color_buffer_float"));if(Ge!==Ln&&Se.convert(Ge)!==y.getParameter(y.IMPLEMENTATION_COLOR_READ_TYPE)&&!(Ge===An&&(ae.isWebGL2||F.has("OES_texture_float")||F.has("WEBGL_color_buffer_float")))&&!He){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=R.width-K&&Y>=0&&Y<=R.height-q&&y.readPixels(B,Y,K,q,Se.convert(qe),Se.convert(Ge),ye)}finally{const Fe=A!==null?me.get(A).__webglFramebuffer:null;oe.bindFramebuffer(y.FRAMEBUFFER,Fe)}}},this.copyFramebufferToTexture=function(R,B,Y=0){const K=Math.pow(2,-Y),q=Math.floor(B.image.width*K),ye=Math.floor(B.image.height*K);T.setTexture2D(B,0),y.copyTexSubImage2D(y.TEXTURE_2D,Y,0,0,R.x,R.y,q,ye),oe.unbindTexture()},this.copyTextureToTexture=function(R,B,Y,K=0){const q=B.image.width,ye=B.image.height,Re=Se.convert(Y.format),Le=Se.convert(Y.type);T.setTexture2D(Y,0),y.pixelStorei(y.UNPACK_FLIP_Y_WEBGL,Y.flipY),y.pixelStorei(y.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),y.pixelStorei(y.UNPACK_ALIGNMENT,Y.unpackAlignment),B.isDataTexture?y.texSubImage2D(y.TEXTURE_2D,K,R.x,R.y,q,ye,Re,Le,B.image.data):B.isCompressedTexture?y.compressedTexSubImage2D(y.TEXTURE_2D,K,R.x,R.y,B.mipmaps[0].width,B.mipmaps[0].height,Re,B.mipmaps[0].data):y.texSubImage2D(y.TEXTURE_2D,K,R.x,R.y,Re,Le,B.image),K===0&&Y.generateMipmaps&&y.generateMipmap(y.TEXTURE_2D),oe.unbindTexture()},this.copyTextureToTexture3D=function(R,B,Y,K,q=0){if(g.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const ye=R.max.x-R.min.x+1,Re=R.max.y-R.min.y+1,Le=R.max.z-R.min.z+1,Fe=Se.convert(K.format),qe=Se.convert(K.type);let Ge;if(K.isData3DTexture)T.setTexture3D(K,0),Ge=y.TEXTURE_3D;else if(K.isDataArrayTexture||K.isCompressedArrayTexture)T.setTexture2DArray(K,0),Ge=y.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}y.pixelStorei(y.UNPACK_FLIP_Y_WEBGL,K.flipY),y.pixelStorei(y.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),y.pixelStorei(y.UNPACK_ALIGNMENT,K.unpackAlignment);const He=y.getParameter(y.UNPACK_ROW_LENGTH),ft=y.getParameter(y.UNPACK_IMAGE_HEIGHT),Bt=y.getParameter(y.UNPACK_SKIP_PIXELS),bt=y.getParameter(y.UNPACK_SKIP_ROWS),cn=y.getParameter(y.UNPACK_SKIP_IMAGES),ht=Y.isCompressedTexture?Y.mipmaps[q]:Y.image;y.pixelStorei(y.UNPACK_ROW_LENGTH,ht.width),y.pixelStorei(y.UNPACK_IMAGE_HEIGHT,ht.height),y.pixelStorei(y.UNPACK_SKIP_PIXELS,R.min.x),y.pixelStorei(y.UNPACK_SKIP_ROWS,R.min.y),y.pixelStorei(y.UNPACK_SKIP_IMAGES,R.min.z),Y.isDataTexture||Y.isData3DTexture?y.texSubImage3D(Ge,q,B.x,B.y,B.z,ye,Re,Le,Fe,qe,ht.data):Y.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),y.compressedTexSubImage3D(Ge,q,B.x,B.y,B.z,ye,Re,Le,Fe,ht.data)):y.texSubImage3D(Ge,q,B.x,B.y,B.z,ye,Re,Le,Fe,qe,ht),y.pixelStorei(y.UNPACK_ROW_LENGTH,He),y.pixelStorei(y.UNPACK_IMAGE_HEIGHT,ft),y.pixelStorei(y.UNPACK_SKIP_PIXELS,Bt),y.pixelStorei(y.UNPACK_SKIP_ROWS,bt),y.pixelStorei(y.UNPACK_SKIP_IMAGES,cn),q===0&&K.generateMipmaps&&y.generateMipmap(Ge),oe.unbindTexture()},this.initTexture=function(R){R.isCubeTexture?T.setTextureCube(R,0):R.isData3DTexture?T.setTexture3D(R,0):R.isDataArrayTexture||R.isCompressedArrayTexture?T.setTexture2DArray(R,0):T.setTexture2D(R,0),oe.unbindTexture()},this.resetState=function(){C=0,P=0,A=null,oe.reset(),ze.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return gn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=e===Ua?"display-p3":"srgb",t.unpackColorSpace=et.workingColorSpace===ds?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===mt?$n:Qc}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===$n?mt:xn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}}class t0 extends Oa{}t0.prototype.isWebGL1Renderer=!0;class Ba{constructor(e,t=1,i=1e3){this.isFog=!0,this.name="",this.color=new je(e),this.near=t,this.far=i}clone(){return new Ba(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class vl extends ut{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}}class n0{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=ga,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=Dn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[i+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Dn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=Dn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Dt=new z;class is{constructor(e,t,i,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)Dt.fromBufferAttribute(this,t),Dt.applyMatrix4(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Dt.fromBufferAttribute(this,t),Dt.applyNormalMatrix(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Dt.fromBufferAttribute(this,t),Dt.transformDirection(e),this.setXYZ(t,Dt.x,Dt.y,Dt.z);return this}setX(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=tt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=mn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=mn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=mn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=mn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),r=tt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=tt(t,this.array),i=tt(i,this.array),r=tt(r,this.array),s=tt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new Qt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new is(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class Ml extends Hi{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new je(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let gi;const ji=new z,_i=new z,xi=new z,vi=new Oe,Ki=new Oe,yl=new Qe,zr=new z,$i=new z,Fr=new z,yc=new Oe,sa=new Oe,Sc=new Oe;class i0 extends ut{constructor(e=new Ml){if(super(),this.isSprite=!0,this.type="Sprite",gi===void 0){gi=new at;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new n0(t,5);gi.setIndex([0,1,2,0,2,3]),gi.setAttribute("position",new is(i,3,0,!1)),gi.setAttribute("uv",new is(i,2,3,!1))}this.geometry=gi,this.material=e,this.center=new Oe(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),_i.setFromMatrixScale(this.matrixWorld),yl.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),xi.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&_i.multiplyScalar(-xi.z);const i=this.material.rotation;let r,s;i!==0&&(s=Math.cos(i),r=Math.sin(i));const a=this.center;Or(zr.set(-.5,-.5,0),xi,a,_i,r,s),Or($i.set(.5,-.5,0),xi,a,_i,r,s),Or(Fr.set(.5,.5,0),xi,a,_i,r,s),yc.set(0,0),sa.set(1,0),Sc.set(1,1);let o=e.ray.intersectTriangle(zr,$i,Fr,!1,ji);if(o===null&&(Or($i.set(-.5,.5,0),xi,a,_i,r,s),sa.set(0,1),o=e.ray.intersectTriangle(zr,Fr,$i,!1,ji),o===null))return;const c=e.ray.origin.distanceTo(ji);c<e.near||c>e.far||t.push({distance:c,point:ji.clone(),uv:jt.getInterpolation(ji,zr,$i,Fr,yc,sa,Sc,new Oe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function Or(n,e,t,i,r,s){vi.subVectors(n,t).addScalar(.5).multiply(i),r!==void 0?(Ki.x=s*vi.x-r*vi.y,Ki.y=r*vi.x+s*vi.y):Ki.copy(vi),n.copy(e),n.x+=Ki.x,n.y+=Ki.y,n.applyMatrix4(yl)}class bc extends Qt{constructor(e,t,i,r=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Mi=new Qe,Ec=new Qe,Br=[],wc=new vn,r0=new Qe,Ji=new Ie,Qi=new lr;class rs extends Ie{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new bc(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<i;r++)this.setMatrixAt(r,r0)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new vn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Mi),wc.copy(e.boundingBox).applyMatrix4(Mi),this.boundingBox.union(wc)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new lr),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Mi),Qi.copy(e.boundingSphere).applyMatrix4(Mi),this.boundingSphere.union(Qi)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){const i=this.matrixWorld,r=this.count;if(Ji.geometry=this.geometry,Ji.material=this.material,Ji.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Qi.copy(this.boundingSphere),Qi.applyMatrix4(i),e.ray.intersectsSphere(Qi)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,Mi),Ec.multiplyMatrices(i,Mi),Ji.matrixWorld=Ec,Ji.raycast(e,Br);for(let a=0,o=Br.length;a<o;a++){const c=Br[a];c.instanceId=s,c.object=this,t.push(c)}Br.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new bc(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}}class ss extends Ot{constructor(e,t,i,r,s,a,o,c,l){super(e,t,i,r,s,a,o,c,l),this.isCanvasTexture=!0,this.needsUpdate=!0}}class ka extends at{constructor(e=1,t=32,i=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:r},t=Math.max(3,t);const s=[],a=[],o=[],c=[],l=new z,d=new Oe;a.push(0,0,0),o.push(0,0,1),c.push(.5,.5);for(let h=0,u=3;h<=t;h++,u+=3){const m=i+h/t*r;l.x=e*Math.cos(m),l.y=e*Math.sin(m),a.push(l.x,l.y,l.z),o.push(0,0,1),d.x=(a[u]/e+1)/2,d.y=(a[u+1]/e+1)/2,c.push(d.x,d.y)}for(let h=1;h<=t;h++)s.push(h,h+1,0);this.setIndex(s),this.setAttribute("position",new Ye(a,3)),this.setAttribute("normal",new Ye(o,3)),this.setAttribute("uv",new Ye(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ka(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Ga extends at{constructor(e=1,t=1,i=1,r=32,s=1,a=!1,o=0,c=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:c};const l=this;r=Math.floor(r),s=Math.floor(s);const d=[],h=[],u=[],m=[];let M=0;const _=[],p=i/2;let f=0;x(),a===!1&&(e>0&&g(!0),t>0&&g(!1)),this.setIndex(d),this.setAttribute("position",new Ye(h,3)),this.setAttribute("normal",new Ye(u,3)),this.setAttribute("uv",new Ye(m,2));function x(){const v=new z,C=new z;let P=0;const A=(t-e)/i;for(let N=0;N<=s;N++){const E=[],w=N/s,H=w*(t-e)+e;for(let U=0;U<=r;U++){const W=U/r,L=W*c+o,I=Math.sin(L),k=Math.cos(L);C.x=H*I,C.y=-w*i+p,C.z=H*k,h.push(C.x,C.y,C.z),v.set(I,A,k).normalize(),u.push(v.x,v.y,v.z),m.push(W,1-w),E.push(M++)}_.push(E)}for(let N=0;N<r;N++)for(let E=0;E<s;E++){const w=_[E][N],H=_[E+1][N],U=_[E+1][N+1],W=_[E][N+1];d.push(w,H,W),d.push(H,U,W),P+=6}l.addGroup(f,P,0),f+=P}function g(v){const C=M,P=new Oe,A=new z;let N=0;const E=v===!0?e:t,w=v===!0?1:-1;for(let U=1;U<=r;U++)h.push(0,p*w,0),u.push(0,w,0),m.push(.5,.5),M++;const H=M;for(let U=0;U<=r;U++){const L=U/r*c+o,I=Math.cos(L),k=Math.sin(L);A.x=E*k,A.y=p*w,A.z=E*I,h.push(A.x,A.y,A.z),u.push(0,w,0),P.x=I*.5+.5,P.y=k*.5*w+.5,m.push(P.x,P.y),M++}for(let U=0;U<r;U++){const W=C+U,L=H+U;v===!0?d.push(L,L+1,W):d.push(L+1,L,W),N+=3}l.addGroup(f,N,v===!0?1:2),f+=N}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ga(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class sr extends Ga{constructor(e=1,t=1,i=32,r=1,s=!1,a=0,o=Math.PI*2){super(0,e,t,i,r,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:r,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new sr(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Ha extends at{constructor(e=[],t=[],i=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:r};const s=[],a=[];o(r),l(i),d(),this.setAttribute("position",new Ye(s,3)),this.setAttribute("normal",new Ye(s.slice(),3)),this.setAttribute("uv",new Ye(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(x){const g=new z,v=new z,C=new z;for(let P=0;P<t.length;P+=3)m(t[P+0],g),m(t[P+1],v),m(t[P+2],C),c(g,v,C,x)}function c(x,g,v,C){const P=C+1,A=[];for(let N=0;N<=P;N++){A[N]=[];const E=x.clone().lerp(v,N/P),w=g.clone().lerp(v,N/P),H=P-N;for(let U=0;U<=H;U++)U===0&&N===P?A[N][U]=E:A[N][U]=E.clone().lerp(w,U/H)}for(let N=0;N<P;N++)for(let E=0;E<2*(P-N)-1;E++){const w=Math.floor(E/2);E%2===0?(u(A[N][w+1]),u(A[N+1][w]),u(A[N][w])):(u(A[N][w+1]),u(A[N+1][w+1]),u(A[N+1][w]))}}function l(x){const g=new z;for(let v=0;v<s.length;v+=3)g.x=s[v+0],g.y=s[v+1],g.z=s[v+2],g.normalize().multiplyScalar(x),s[v+0]=g.x,s[v+1]=g.y,s[v+2]=g.z}function d(){const x=new z;for(let g=0;g<s.length;g+=3){x.x=s[g+0],x.y=s[g+1],x.z=s[g+2];const v=p(x)/2/Math.PI+.5,C=f(x)/Math.PI+.5;a.push(v,1-C)}M(),h()}function h(){for(let x=0;x<a.length;x+=6){const g=a[x+0],v=a[x+2],C=a[x+4],P=Math.max(g,v,C),A=Math.min(g,v,C);P>.9&&A<.1&&(g<.2&&(a[x+0]+=1),v<.2&&(a[x+2]+=1),C<.2&&(a[x+4]+=1))}}function u(x){s.push(x.x,x.y,x.z)}function m(x,g){const v=x*3;g.x=e[v+0],g.y=e[v+1],g.z=e[v+2]}function M(){const x=new z,g=new z,v=new z,C=new z,P=new Oe,A=new Oe,N=new Oe;for(let E=0,w=0;E<s.length;E+=9,w+=6){x.set(s[E+0],s[E+1],s[E+2]),g.set(s[E+3],s[E+4],s[E+5]),v.set(s[E+6],s[E+7],s[E+8]),P.set(a[w+0],a[w+1]),A.set(a[w+2],a[w+3]),N.set(a[w+4],a[w+5]),C.copy(x).add(g).add(v).divideScalar(3);const H=p(C);_(P,w+0,x,H),_(A,w+2,g,H),_(N,w+4,v,H)}}function _(x,g,v,C){C<0&&x.x===1&&(a[g]=x.x-1),v.x===0&&v.z===0&&(a[g]=C/2/Math.PI+.5)}function p(x){return Math.atan2(x.z,-x.x)}function f(x){return Math.atan2(-x.y,Math.sqrt(x.x*x.x+x.z*x.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ha(e.vertices,e.indices,e.radius,e.details)}}class ar extends Ha{constructor(e=1,t=0){const i=(1+Math.sqrt(5))/2,r=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new ar(e.radius,e.detail)}}class ms extends at{constructor(e=1,t=32,i=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const c=Math.min(a+o,Math.PI);let l=0;const d=[],h=new z,u=new z,m=[],M=[],_=[],p=[];for(let f=0;f<=i;f++){const x=[],g=f/i;let v=0;f===0&&a===0?v=.5/t:f===i&&c===Math.PI&&(v=-.5/t);for(let C=0;C<=t;C++){const P=C/t;h.x=-e*Math.cos(r+P*s)*Math.sin(a+g*o),h.y=e*Math.cos(a+g*o),h.z=e*Math.sin(r+P*s)*Math.sin(a+g*o),M.push(h.x,h.y,h.z),u.copy(h).normalize(),_.push(u.x,u.y,u.z),p.push(P+v,1-g),x.push(l++)}d.push(x)}for(let f=0;f<i;f++)for(let x=0;x<t;x++){const g=d[f][x+1],v=d[f][x],C=d[f+1][x],P=d[f+1][x+1];(f!==0||a>0)&&m.push(g,v,P),(f!==i-1||c<Math.PI)&&m.push(v,C,P)}this.setIndex(m),this.setAttribute("position",new Ye(M,3)),this.setAttribute("normal",new Ye(_,3)),this.setAttribute("uv",new Ye(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ms(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class Vt extends Hi{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new je(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new je(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=el,this.normalScale=new Oe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=La,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Sl extends ut{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new je(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}}class bl extends Sl{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(ut.DEFAULT_UP),this.updateMatrix(),this.groundColor=new je(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const aa=new Qe,Tc=new z,Ac=new z;class s0{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Oe(512,512),this.map=null,this.mapPass=null,this.matrix=new Qe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Na,this._frameExtents=new Oe(1,1),this._viewportCount=1,this._viewports=[new wt(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,i=this.matrix;Tc.setFromMatrixPosition(e.matrixWorld),t.position.copy(Tc),Ac.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ac),t.updateMatrixWorld(),aa.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(aa),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(aa)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class a0 extends s0{constructor(){super(new za(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class El extends Sl{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(ut.DEFAULT_UP),this.updateMatrix(),this.target=new ut,this.shadow=new a0}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class o0{constructor(e,t,i=0,r=1/0){this.ray=new hr(e,t),this.near=i,this.far=r,this.camera=null,this.layers=new Ia,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return ya(e,this,i,t),i.sort(Rc),i}intersectObjects(e,t=!0,i=[]){for(let r=0,s=e.length;r<s;r++)ya(e[r],this,i,t);return i.sort(Rc),i}}function Rc(n,e){return n.distance-e.distance}function ya(n,e,t,i){if(n.layers.test(e.layers)&&n.raycast(e,t),i===!0){const r=n.children;for(let s=0,a=r.length;s<a;s++)ya(r[s],e,t,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Pa}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Pa);const wl={flowers:[[.5,.16,.5,.6,.32,.6,11827792],[.5,.48,.5,.06,.64,.06,5671001],[.5,.78,.5,.46,.18,.46,14523267],[.5,.89,.5,.18,.06,.18,16110715]],lantern:[[.5,.06,.5,.55,.12,.55,6255726],[.5,.46,.5,.4,.7,.4,16174707],[.5,.87,.5,.6,.12,.6,6255726],...[.27,.73].flatMap(n=>[.27,.73].map(e=>[n,.46,e,.06,.75,.06,6255726]))],bench:[[.5,.47,.5,.94,.12,.64,11369552],[.5,.77,.77,.94,.4,.1,11369552],...[.12,.88].flatMap(n=>[.25,.72].map(e=>[n,.22,e,.1,.44,.1,6714986]))]},In=[],as=[],Sa=[15851437,15185051,12177332,14728124,14268559,11914194],Tl=[4488320,11365457,7042704,7108992];function gs(n,e,t,i,r){e.forEach((s,a)=>{const o=t+i*16,c=i<0?0:Math.PI;if(r.includes(a))as.push({id:`${n}-lot-${a}`,x:s,z:o,w:17,d:16,angle:c,street:n,roadZ:t,subtle:!0});else{const l=n==="north"?[1,5].includes(a)&&i<0:[2,5].includes(a)&&i>0;In.push({id:`${n}-${i<0?"n":"s"}-${a}`,name:`${n==="north"?"Linden":"Willow"} ${l?"family home":"cottage"} ${a+1}`,x:s,z:o,w:l?12:8+a%3,d:l?12:8+a%2*2,angle:c,wall:Sa[(a+(i+1)*2)%Sa.length],roof:Tl[(a+(i+1))%4],style:l?"gable":["hip","gable","shed"][a%3],storeys:l?2:1,rooms:l||a%3===0,designed:!0,garden:0,garage:a%4===0,street:n})}})}gs("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,-1,[2,6]);gs("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,1,[1,5,8]);gs("south",[-90,-66,-42,-18,6,30,54,78],128,-1,[0,3,6]);gs("south",[-90,-66,-42,-18,6,30,54,78],128,1,[1,4]);In.push({id:"linden-library",name:"Linden library",x:60,z:-195,w:12,d:12,angle:Math.PI,route:"trail",wall:15851437,roof:4488320,style:"hip",shop:!0,sign:"LIBRARY",rooms:!0,designed:!0},{id:"willow-workshop",name:"Willow motor workshop",x:-109,z:110,w:12,d:12,angle:0,street:"south",wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,designed:!0},{id:"manor",name:"Magnolia manor",x:103,z:16,w:22,d:18,angle:-Math.PI/2,route:"trail",wall:15851437,roof:7042704,style:"hip",storeys:2,rooms:!0,designed:!0,porch:5},{id:"garden-cafe",name:"Garden cafe",x:112,z:-26,w:10,d:9,angle:Math.PI,wall:14728124,roof:11365457,style:"gable",shop:!0,sign:"GARDEN CAFE",designed:!0});const ba=[[[-108,-143],[-64,-143],[-8,-143],[54,-143],[118,-143]],[[-112,128],[-66,128],[-6,128],[60,128],[119,128]],[[72,-28],[81,-16],[83,14],[83,39],[104,42]]];for(const[n,e]of[-28,-52,-76,-100,-122].entries())In.push({id:`elm-${n}`,name:`Elm lane ${n===2?"family house":"cottage"}`,x:-121,z:e,w:n===2?12:9,d:n===2?12:9,angle:-Math.PI/2,wall:Sa[n%6],roof:Tl[n%4],style:n%2?"hip":"gable",storeys:n===2?2:1,rooms:!0,designed:!0,street:"elm"});as.push({id:"elm-lot",x:-150,z:-98,w:12,d:14,angle:Math.PI/2,street:"elm",roadX:-137,subtle:!0});ba.push([[-137,-132],[-137,-90],[-137,-45],[-137,-9],[-146,10]]);const c0=[[[73,62],[80,66]],[[80,52],[84,52]],[[53,25],[53,36],[53,56],[65,62],[73,56],[80,52]],[[53,36],[61,34],[76,34],[80,41],[80,52]],[[65,62],[65,45]],[[197,98],[185,96],[181,82],[185,69],[197,65],[208,72],[210,86],[206,96],[197,98]],[[185,96],[197,84],[208,72]]],Al=[{id:"linden",name:"Linden street",icon:"⌂",x:-30,z:-143,color:"#b7a48a",signX:-113,signZ:-150},{id:"willow-street",name:"Willow street",icon:"⌂",x:-18,z:128,color:"#aebf90",signX:-118,signZ:136},{id:"manor",name:"Magnolia manor",icon:"♜",x:103,z:16,color:"#cfbc97",signX:88,signZ:29}],l0=In.findIndex(n=>n.id==="north-n-0");In.splice(l0,1);for(const n of["north-n-1","north-n-8"])In.find(e=>e.id===n).z=-154;In.find(n=>n.id==="south-s-0").x=-86;const lt=(n,e,t,i,r,s,a,o,c,l,d={})=>({id:n,name:e,x:t,z:i,w:r,d:s,angle:a,style:o,wall:c,roof:l,...d}),yi=0,Gn=Math.PI,kr=Math.PI/2,Hn=-Math.PI/2,h0=[lt("juniper","Juniper veranda",-160,-45,12,10,Hn,"hip",12177332,11365457,{porch:4.4,carport:!0,garden:2,bay:!0}),lt("birch","Birch twin cottage",-212,-40,8,11,kr,"gable",15851437,7042704,{wing:!0,garden:3,chimney:!0}),lt("copper","Copper longhouse",-161,-80,7,12,Hn,"shed",14268559,4488320,{porch:4,garden:1,bay:!0}),lt("lavender","Lavender bungalow",-215,5,10,8,kr,"hip",14728124,7108992,{garage:!0,garden:2}),lt("acacia","Acacia courtyard",-213,47,14,9,kr,"gable",15185051,4488320,{wing:!0,porch:4.6,garden:3}),lt("riverside","Riverside home",-151,45,9,9,Hn,"hip",11914194,11365457,{carport:!0,garden:1,bay:!0}),lt("north-house","North garden house",-42,-214,12,10,yi,"hip",14728124,7042704,{wing:!0,garden:3}),lt("north-bakery","Sunbeam bakery",-18,-214,9,8,yi,"gable",15851437,11365457,{shop:!0,sign:"SUNBEAM",approach:{x:-18,z:-202},chimney:!0}),lt("north-hall","North village hall",7,-214,14,10,yi,"gable",12177332,4488320,{shop:!0,sign:"VILLAGE HALL",approach:{x:7,z:-202},porch:4.2}),lt("north-clock","Clockmaker house",35,-214,8,8,yi,"hip",14268559,7108992,{tower:!0,porch:3.2,garden:2}),lt("weavers","Weavers studio",202,-132,9,10,Hn,"shed",14728124,7042704,{shop:!0,sign:"WEAVERS",bay:!0}),lt("clay-yard","Clay courtyard",206,-103,12,8,Hn,"hip",15185051,4488320,{shop:!0,sign:"CLAY YARD",wing:!0}),lt("makers","Makers long workshop",205,-75,8,14,Hn,"gable",14268559,11365457,{shop:!0,sign:"MAKERS",carport:!0,chimney:!0}),lt("greenhouse","Garden potting house",207,-45,7,7,Hn,"gable",12177332,4488320,{porch:3.4,garden:3,bay:!0}),lt("lake-house","Lakeview veranda",213,4,10,9,yi,"shed",11914194,7108992,{route:"trail",porch:4.6,garden:2,bay:!0}),lt("east-house","Eastern carport house",212,109,14,8,Gn,"hip",15851437,11365457,{route:"trail",carport:!0,garden:1}),lt("beacon-house","Beacon lodge",214,145,8,9,Gn,"gable",14728124,4488320,{route:"trail",tower:!0,garden:2}),lt("farm-home","Farmhouse porch",43,215,12,10,Gn,"gable",15851437,7042704,{route:"trail",porch:5,chimney:!0,garden:1}),lt("farm-shop","Farmyard store",12,216,10,8,Gn,"hip",12177332,11365457,{route:"trail",shop:!0,sign:"FARM STORE",approach:{x:12,z:204},carport:!0}),lt("red-barn","Red barn workshop",-18,214,14,12,Gn,"gambrel",13075044,7108992,{route:"trail",shop:!0,sign:"RED BARN",approach:{x:-18,z:202},chimney:!0}),lt("farm-cottage","Farm garden cottage",-47,213,8,9,Gn,"hip",15185051,4488320,{route:"trail",wing:!0,garden:3}),lt("orchard-barn","Orchard long barn",-96,211,14,12,Gn,"gambrel",14268559,11365457,{route:"trail",carport:!0,garden:1}),lt("pond-cabin","Reed pond cabin",-201,192,7,8,kr,"gable",12177332,7042704,{route:"trail",porch:3.5,garden:2}),lt("trail-hut","North trail cabin",152,-218,6,7,yi,"shed",14728124,4488320,{route:"trail",porch:3,garden:2})],u0=[[[-124,6],[-146,10],[-169,1],[-186,-22],[-193,-61],[-177,-100],[-147,-127],[-112,-151],[-68,-171],[-15,-183],[40,-182],[89,-166],[133,-136],[160,-100],[175,-55],[174,-12],[176,20],[157,57],[139,92],[122,129],[91,162],[50,184],[3,190],[-47,181],[-91,157],[-124,126],[-156,91],[-181,55],[-196,18],[-174,7],[-146,10]],[[115,-53],[139,-56],[175,-55]]],d0=[[[-65,-103],[-108,-120],[-123,-150],[-128,-182],[-127,-209],[-99,-225],[-60,-221],[-66,-202],[-42,-202],[-8,-197],[-8,-182]],[[89,-166],[117,-185],[152,-198],[184,-210],[215,-208],[234,-183],[222,-151],[202,-147],[160,-100]],[[108,62],[142,48],[166,45],[184,44],[193,24],[220,20],[239,45],[236,70],[216,95],[185,116],[144,148],[122,129]],[[50,184],[33,202],[-10,198],[-57,193],[-95,193],[-131,174],[-157,173],[-184,174],[-213,181],[-216,205],[-193,222],[-162,224],[-137,212],[-131,192],[-131,174],[-139,147],[-124,126]],[[91,162],[128,181],[151,209],[181,226],[217,212],[232,174],[234,148],[222,127],[185,116]],[[-193,-61],[-218,-88],[-214,-123],[-192,-145],[-157,-151],[-147,-127]],[[-8,-197],[17,-197],[43,-202],[72,-215],[111,-229],[152,-198]],[[-184,174],[-190,183],[-192,194],[-190,206],[-193,222]],[[216,95],[208,99],[197,98],[197,84]]],f0=[{x:-161,z:-218,w:36,d:28,subtle:!0},{x:214,z:-232,w:36,d:20,subtle:!0},{x:-234,z:-111,w:22,d:24,subtle:!0},{x:151,z:234,w:36,d:20,subtle:!0}],Yr=[{x:-167,z:197,rx:23,rz:14},{x:215,z:45,rx:18,rz:12}],Rl=[{id:"north-square",name:"Sunbeam village",icon:"☀",x:-8,z:-197,color:"#d7ae71"},{id:"artists",name:"Makers village",icon:"▤",x:190,z:-102,color:"#bd9583"},{id:"east-park",name:"Lake park",icon:"⚑",x:197,z:84,color:"#7aa276"},{id:"farm",name:"Red barn farm",icon:"♧",x:-18,z:197,color:"#bd7967"},{id:"reed-pond",name:"Reed pond",icon:"≈",x:-167,z:197,color:"#72aebc",signX:-141,signZ:216},{id:"beacon",name:"Beacon walk",icon:"♜",x:214,z:145,color:"#8eaaa1",signX:225,signZ:143},{id:"north-meadow",name:"North meadow",icon:"▦",x:-161,z:-218,color:"#a9b774",signX:-182,signZ:-218},{id:"east-meadow",name:"East meadow",icon:"▦",x:151,z:234,color:"#a9b774",signX:173,signZ:234}],nt=Object.freeze({id:"little-block-world-06",saveVersion:4,halfSize:250,buildHeight:24,maxBlocks:12e3,maxSaveBytes:4e6,chunkSize:24,fogNear:75,fogFar:155,cameraFar:190,saveKey:"blockworld.neighborhood.06",preferencesKey:"blockworld.neighborhood.controls.v6"}),oa=Object.freeze({normal:3.4,quick:5.1,fast:6.8}),Cl=n=>typeof oa[n]=="number"?oa[n]:oa.normal,p0=[{id:"home",name:"Home",icon:"⌂",x:-14.4,z:-1.2,color:"#cc9168"},{id:"village",name:"Village square",icon:"▥",x:49,z:-26,color:"#d9ac68"},{id:"park",name:"Play park",icon:"⚑",x:65,z:45,color:"#7aa276"},{id:"pond",name:"Willow pond",icon:"≈",x:18,z:-101,color:"#72aebc"},{id:"woods",name:"Woodland walk",icon:"♠",x:-65,z:-103,color:"#528969"},{id:"meadow",name:"Building meadow",icon:"▦",x:-59,z:61,color:"#a9b774"},{id:"orchard",name:"Orchard picnic",icon:"●",x:81,z:94,color:"#b89c78"},...Rl,...Al];class zi{constructor(e=12){this.size=e,this.cells=new Map,this.global=new Set,this.entries=new Map}keys(e){const t=[];for(let i=Math.floor(e.minX/this.size);i<=Math.floor(e.maxX/this.size);i++)for(let r=Math.floor(e.minZ/this.size);r<=Math.floor(e.maxZ/this.size);r++)t.push(`${i},${r}`);return t}add(e){const t=this.keys(e);if(this.entries.set(e,t),t.length>64){this.global.add(e);return}for(const i of t)this.cells.has(i)||this.cells.set(i,new Set),this.cells.get(i).add(e)}remove(e){for(const t of this.entries.get(e)||[]){const i=this.cells.get(t);i==null||i.delete(e),i!=null&&i.size||this.cells.delete(t)}this.global.delete(e),this.entries.delete(e)}query(e){const t=new Set(this.global);for(const i of this.keys(e))for(const r of this.cells.get(i)||[])t.add(r);return[...t].filter(i=>i.minX<=e.maxX&&i.maxX>=e.minX&&i.minZ<=e.maxZ&&i.maxZ>=e.minZ&&i.minY<=e.maxY&&i.maxY>=e.minY)}}const Gr=(n,e=2)=>({minX:n.x-e,maxX:n.x+e,minZ:n.z-e,maxZ:n.z+e,minY:-1,maxY:(n.y||0)+30}),Si=nt.halfSize,m0=nt.maxBlocks,Hr=.28,g0=1.65,Ea=["wood","brick","stone","glass"],os=["flowers","lantern","bench"],Cc=[...Ea,...os],Pl=(n,e,t)=>Math.max(e,Math.min(t,n)),cs=n=>`${n.x},${n.y},${n.z}`,Zn=n=>{const e=(n.rotation||0)*Math.PI/180,t=Math.abs(Math.cos(e)),i=Math.abs(Math.sin(e)),r=n.type==="bench"?Math.max(0,(.94*t+.64*i-1)/2):0,s=n.type==="bench"?Math.max(0,(.94*i+.64*t-1)/2):0;return{minX:n.x-r,minY:n.y,minZ:n.z-s,maxX:n.x+1+r,maxY:n.y+1,maxZ:n.z+1+s}},Ll=n=>({minX:n.x-Hr,minY:n.y+.001,minZ:n.z-Hr,maxX:n.x+Hr,maxY:n.y+g0,maxZ:n.z+Hr});function Pc(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function _0(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:Pl((i.length/2-o)/i.length,0,1)*i.rise}function Fi(n,e){if(e.ramp){const a=_0(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return Fi(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=Pc(n),i=Pc(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const c=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),l=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=c+l-1e-5)return!1}return!0}const x0=(n,e)=>e.some(t=>Fi(Ll(n),t)),Dl={x:-14.4,y:0,z:-1.2,yaw:0,pitch:0};function v0(){return{version:nt.saveVersion,world:nt.id,blocks:[],inventory:{flowers:0,lantern:0,bench:0},selected:"hand",player:{...Dl},doors:{},doorSwings:{}}}function M0(n,e=[]){var l,d,h;if(!n||![1,2,3,nt.saveVersion].includes(n.version)||n.version===nt.saveVersion&&n.world!==nt.id||n.version===2&&n.world!=="little-block-world-04"||n.version===3&&n.world!=="little-block-world-05"||!Array.isArray(n.blocks)||n.blocks.length>m0)throw Error("This is not a supported BlockWorld save");const t=n.version===1,i=n.version===2;if(t&&n.blocks.length>800)throw Error("Older saves support up to 800 pieces");const r=v0(),s=new Set,a=new zi(4),o=new zi;for(const u of e)o.add(u);for(const u of n.blocks){if(!u||!Cc.includes(u.type)||![u.x,u.y,u.z].every(Number.isInteger)||u.y<0||u.y>=nt.buildHeight||u.x<-Si||u.x>=Si||u.z<-Si||u.z>=Si||t&&(Math.abs(u.x)>31||u.x===31||Math.abs(u.z)>31||u.z===31||u.y>9)||i&&(u.x<-125||u.x>=125||u.z<-125||u.z>=125)||s.has(cs(u)))throw Error("The save contains an invalid piece");if(o.query(Zn(u)).some(_=>Fi(Zn(u),_.ramp?{..._,ramp:null}:_)))throw Error("A saved piece overlaps the neighborhood");const m=Zn(u);if(a.query(m).some(_=>Fi(m,_)))throw Error("Saved pieces overlap");a.add(m),s.add(cs(u));const M=u.rotation??0;if(!Number.isFinite(M)||Math.abs(M)>36e3)throw Error("The piece rotation is invalid");r.blocks.push({x:u.x,y:u.y,z:u.z,type:u.type,...os.includes(u.type)?{rotation:(M%360+360)%360}:{}})}for(const u of os){const m=((l=n.inventory)==null?void 0:l[u])??0;if(!Number.isInteger(m)||m<0||m>999)throw Error("The inventory is invalid");r.inventory[u]=m}const c=n.player;c&&["x","y","z","yaw","pitch"].every(u=>Number.isFinite(c[u]))&&Math.abs(c.x)<Si&&Math.abs(c.z)<Si&&c.y>=0&&c.y<=nt.buildHeight+2&&(r.player={x:c.x,y:c.y,z:c.z,yaw:c.yaw%(Math.PI*2),pitch:Pl(c.pitch,-1.3,1.3)}),(n.selected==="hand"||Cc.includes(n.selected))&&(r.selected=n.selected);for(const u of Object.keys(n.doors||{}).filter(m=>/^[a-z][a-z0-9-]{0,39}$/.test(m)&&!["constructor","prototype"].includes(m)))r.doors[u]=((d=n.doors)==null?void 0:d[u])===!0,r.doorSwings[u]=((h=n.doorSwings)==null?void 0:h[u])===1?1:-1;return x0(r.player,[...e,...r.blocks.map(Zn)])&&(r.player={...Dl}),r}const Zr=new Set(["wood","brick","stone","glass","flowers","lantern","bench"]),V=(n,e,t,i,r,s,a,o="box")=>({x:n,y:e,z:t,w:i,h:r,d:s,color:a,shape:o}),$e=11239513,ct=15852744,Je=5796718,Oi=10340302,ur=[];function be(n,e,t,i,r={}){var s;ur.push({id:n,label:e,category:t,parts:i,icon:t==="Garden"?"🌿":t==="Lighting"?"💡":t==="Openings"?"🚪":t==="Furniture"?"🪑":"▦",color:((s=i[0])==null?void 0:s.color)||$e,...r})}for(const[n,e,t]of[["wood","Wood",12424551],["brick","Brick",13075044],["stone","Stone",10267045],["glass","Glass",Oi]])be(n,e,"Materials",[V(0,.5,0,1,1,1,t)],{cube:!0,icon:n==="wood"?"▥":n==="brick"?"▦":n==="stone"?"▧":"◈"});for(const[n,e,t]of[["flowers","Flowers","🌷"],["lantern","Lantern","🏮"],["bench","Bench","🪑"]])be(n,e,n==="flowers"?"Garden":"Furniture",wl[n].map(([i,r,s,a,o,c,l])=>V(i-.5,r,s-.5,a,o,c,l)),{icon:t});for(const[n,e,t,i]of[["oak-planks","Oak planks",12423520,"wood"],["bamboo","Bamboo",12763001,"bamboo"],["log-end","Timber logs",10912340,"log"],["white-brick","White brick",14407359,"brick"],["cobble","Cobblestone",9607822,"cobble"],["sandstone","Sandstone",14468245,"stone"],["marble","Marble",14867920,"marble"],["slate","Slate",6912896,"stone"],["concrete","Concrete",11710880,"concrete"],["terracotta","Terracotta",12419166,"tile"],["mosaic","Mosaic tiles",8563103,"mosaic"],["checker-tile","Checker tiles",14274995,"checker"],["copper","Copper panels",12157540,"metal"],["steel","Steel plate",11123392,"metal"],["grass","Turf",8957292,"grass"],["sand","Sand",14930847,"sand"]])be(n,e,"Materials",[V(0,.5,0,1,1,1,t)],{cube:!0,surface:i});for(const[n,e,t,i,r,s]of[["slab","Half slab",1,.5,1,"box"],["floor-panel","Floor panel",1,.15,1,"box"],["wall-panel","Wall panel",1,2,.15,"box"],["half-wall","Half wall",1,1,.15,"box"],["pillar","Square pillar",.35,2.5,.35,"box"],["beam","Long beam",3,.25,.25,"box"],["post","Fence post",.18,1.2,.18,"box"],["roof-slope","Roof slope",1,1,1,"wedge"],["roof-slab","Roof sheet",2,.15,2,"box"],["ramp","Walking ramp",1,1,2,"wedge"],["wide-ramp","Wide ramp",2,1,2,"wedge"],["step","Low step",1,.25,.5,"box"],["foundation","Foundation plinth",2,.4,2,"box"]])be(n,e,"Shapes",[V(0,i/2,0,t,i,r,n.includes("roof")?9665388:$e,s)],{ramp:s==="wedge"});be("stairs","Timber stairs","Shapes",Array.from({length:4},(n,e)=>V(0,(e+1)*.125,.75-e*.5,1,(e+1)*.25,.5,$e)),{ramp:!0});be("arch","Wide arch","Shapes",[V(-.8,1,0,.3,2,.4,12627596),V(.8,1,0,.3,2,.4,12627596),V(0,2,0,1.9,.35,.4,12627596)]);be("corner-wall","Corner wall","Shapes",[V(-.42,1,0,.16,2,1,ct),V(0,1,-.42,1,2,.16,ct)]);for(const[n,e,t,i,r]of[["door","Timber door",1,2.2,$e],["glass-door","Glass door",1,2.2,Oi],["double-door","Double-width door",2,2.2,$e],["garden-gate","Garden gate",1.4,1.2,10268294]])be(n,e,"Openings",[V(-t/2,i/2,0,.1,i,.18,Je),V(t/2,i/2,0,.1,i,.18,Je),V(0,i,0,t+.1,.1,.18,Je),V(0,i/2,0,t-.16,i-.1,.1,r)],{interaction:"door"});for(const[n,e,t,i]of[["window","Window",1.2,1.2],["wide-window","Wide window",2,1.2],["tall-window","Tall window",.8,2],["skylight","Skylight",1.2,.35]])be(n,e,"Openings",[V(0,i/2,0,t,i,.09,Oi),V(-t/2,i/2,0,.08,i,.15,ct),V(t/2,i/2,0,.08,i,.15,ct),V(0,i,0,t+.08,.08,.15,ct),V(0,.04,0,t+.08,.08,.15,ct),V(0,i/2,0,.06,i,.16,ct)]);for(const[n,e,t]of[["picket-fence","Picket fence",ct],["rail-fence","Timber rail fence",$e],["metal-rail","Metal railing",Je]])be(n,e,"Openings",[...[-.48,.48].map(i=>V(i,.6,0,.1,1.2,.1,t)),V(0,.9,0,1,.1,.1,t),V(0,.4,0,1,.1,.1,t),...n==="picket-fence"?[-.25,0,.25].map(i=>V(i,.55,0,.09,1.1,.1,t)):[]]);const _s=(n=1.5,e=1,t=.75,i=$e)=>[V(0,t,0,n,.12,e,i),...[-n*.38,n*.38].flatMap(r=>[-e*.35,e*.35].map(s=>V(r,t/2,s,.1,t,.1,Je)))],xs=(n=1,e=9942176)=>[V(0,.4,0,n,.25,.8,e),V(0,.8,.34,n,.6,.16,e),...[-n*.36,n*.36].map(t=>V(t,.15,0,.1,.3,.6,$e))];be("chair","Dining chair","Furniture",xs(.6),{interaction:"seat"});be("armchair","Armchair","Furniture",[...xs(1),V(-.48,.55,0,.18,.4,.8,9942176),V(.48,.55,0,.18,.4,.8,9942176)],{interaction:"seat"});be("sofa","Two-seat sofa","Furniture",xs(1.9,9152434),{interaction:"seat"});be("corner-sofa","Corner sofa","Furniture",[...xs(1.8,11772084),V(-.6,.4,-.7,.6,.25,1.2,11772084)],{interaction:"seat"});be("stool","Stool","Furniture",[V(0,.55,0,.55,.12,.55,14003573),...[-.2,.2].flatMap(n=>[-.2,.2].map(e=>V(n,.25,e,.08,.5,.08,$e)))],{interaction:"seat"});be("dining-table","Dining table","Furniture",_s(1.8,1));be("coffee-table","Coffee table","Furniture",_s(1.2,.7,.4));be("desk","Writing desk","Furniture",[..._s(1.5,.8),V(.5,.5,0,.4,.5,.65,14272417)]);for(const[n,e,t,i]of[["single-bed","Single bed",.95,2],["double-bed","Double bed",1.75,2.1]])be(n,e,"Furniture",[V(0,.25,0,t,.5,i,$e),V(0,.55,0,t,.15,i,15186816),V(0,.68,-i*.33,t*.8,.18,.45,ct),V(0,.65,-i/2,t,.8,.12,$e)]);be("bunk-bed","Bunk beds","Furniture",[V(0,.5,0,1,.2,2,14663563),V(0,1.7,0,1,.2,2,14663563),...[-.47,.47].flatMap(n=>[-.95,.95].map(e=>V(n,1,e,.1,2,.1,$e))),...Array.from({length:5},(n,e)=>V(-.58,.2+e*.33,.6,.25,.08,.18,$e))]);be("crib","Crib","Furniture",[V(0,.4,0,.9,.15,1.5,ct),...[-.45,.45].flatMap(n=>[-.65,-.3,0,.3,.65].map(e=>V(n,.75,e,.06,.8,.06,$e)))]);be("wardrobe","Wardrobe","Furniture",[V(0,1,0,1.2,2,.6,$e),V(0,1,.32,.04,1.8,.05,ct)]);be("dresser","Dresser","Furniture",[V(0,.6,0,1.4,1.2,.65,$e),...Array.from({length:3},(n,e)=>V(0,.25+e*.35,.34,1.25,.04,.04,ct))]);be("nightstand","Nightstand","Furniture",[V(0,.3,0,.55,.6,.5,$e),V(0,.4,.27,.1,.06,.05,Je)]);be("bookcase","Bookcase","Furniture",[V(0,1,0,1.4,2,.35,$e),...Array.from({length:6},(n,e)=>V(-.55+e*.22,1.35,.2,.16,.55,.08,[13208431,8562842,13876601][e%3]))]);be("shelf","Wall shelf","Furniture",[V(0,.2,0,1.5,.12,.35,$e),V(-.55,.1,.08,.1,.2,.1,Je),V(.55,.1,.08,.1,.2,.1,Je)]);be("tv-cabinet","TV cabinet","Furniture",[V(0,.35,0,1.5,.7,.5,$e),V(0,1,.05,1.2,.65,.12,Je),V(0,.95,.13,1.05,.5,.03,10930105)]);be("rug","Woven rug","Furniture",[V(0,.025,0,1.8,.05,1.3,13216390),V(0,.055,0,1.5,.01,1,14994589)]);const vs=(n=12897715)=>[V(0,.5,0,.98,1,.6,n),V(0,1.04,0,1,.08,.68,ct),V(0,.75,.32,.25,.05,.06,Je)];be("kitchen-counter","Kitchen counter","Kitchen",vs());be("sink","Kitchen sink","Kitchen",[...vs(),V(0,1.09,0,.6,.04,.4,9218473),V(.28,1.3,-.2,.06,.45,.06,Je)]);be("stove","Cooker","Kitchen",[...vs(13949132),...[-.25,.25].flatMap(n=>[-.18,.18].map(e=>V(n,1.1,e,.25,.02,.22,Je))),V(0,.55,.32,.7,.45,.04,Je)]);be("fridge","Fridge","Kitchen",[V(0,1,0,.85,2,.8,14476243),V(.28,1,.42,.06,.6,.06,Je)]);be("oven","Oven","Kitchen",[...vs(11713718),V(0,.5,.32,.7,.5,.05,Je)]);be("kitchen-island","Kitchen island","Kitchen",[V(0,.5,0,2,1,.8,10860973),V(0,1.05,0,2.2,.12,1,ct)]);be("wall-cupboard","Wall cupboard","Kitchen",[V(0,.4,0,1,.8,.35,14081476),V(0,.4,.2,.04,.7,.03,Je)]);be("bin","Kitchen bin","Kitchen",[V(0,.4,0,.5,.8,.5,Je),V(0,.82,0,.55,.08,.55,11779249)]);be("toilet","Toilet","Bathroom",[V(0,.22,0,.4,.44,.5,ct),V(0,.48,-.05,.6,.15,.7,ct),V(0,.72,-.3,.6,.6,.18,ct)]);be("bath","Bath","Bathroom",[V(0,.25,0,.9,.5,1.8,ct),V(0,.52,0,.7,.03,1.5,10077642),V(.32,.7,-.55,.05,.35,.05,Je)]);be("shower","Shower","Bathroom",[V(0,.04,0,1,.08,1,ct),V(0,1,-.46,.9,2,.06,Oi),V(.44,1,0,.06,2,1,Oi),V(-.3,1.4,-.4,.05,1,.05,Je),V(-.3,1.95,-.2,.3,.07,.3,Je)]);be("washbasin","Washbasin","Bathroom",[V(0,.5,0,.7,1,.5,12306876),V(0,1.05,0,.8,.12,.6,ct),V(.2,1.2,-.2,.05,.3,.05,Je)]);be("mirror","Mirror","Bathroom",[V(0,.65,0,.8,1.3,.1,$e),V(0,.65,.06,.68,1.15,.04,Oi)]);be("towel-rail","Towel rail","Bathroom",[V(0,.6,0,.9,.08,.08,Je),V(0,.4,.04,.6,.45,.04,13939875)]);be("workbench","Workbench","Workshop",[..._s(2,.9,.9),V(0,1.4,-.35,2,.8,.1,$e)]);be("tool-cabinet","Tool cabinet","Workshop",[V(0,.7,0,1.1,1.4,.55,9153185),...Array.from({length:4},(n,e)=>V(0,.25+e*.3,.29,.8,.04,.05,Je))]);be("garage-shelf","Garage shelving","Workshop",[...[-.7,.7].flatMap(n=>[-.3,.3].map(e=>V(n,1,e,.08,2,.08,Je))),...Array.from({length:4},(n,e)=>V(0,.2+e*.55,0,1.5,.08,.7,$e))]);be("storage-crate","Storage crate","Workshop",[V(0,.4,0,.8,.8,.8,$e),V(0,.42,.41,.7,.1,.04,ct)]);be("traffic-cone","Traffic cone","Workshop",[V(0,.06,0,.6,.12,.6,6255729),V(0,.3,0,.35,.5,.35,13998948),V(0,.6,0,.2,.2,.2,16050123)]);be("tyre-stack","Tyre stack","Workshop",[V(0,.18,0,.7,.3,.7,Je),V(0,.52,0,.7,.3,.7,Je)]);for(const[n,e,t,i,r]of[["oak-tree","Oak tree",2.4,3.5,7444841],["pine-tree","Pine tree",1.6,4,6132863],["palm-tree","Palm tree",2.5,3.2,8890990],["fruit-tree","Fruit tree",2,2.8,9876856]])be(n,e,"Garden",[V(0,i*.35,0,.25,i*.7,.25,$e),...n==="pine-tree"?[0,1,2].map(s=>V(0,i*.48+s*.75,0,t*(1-s*.23),1,t*(1-s*.23),r)):n==="palm-tree"?[V(0,i*.86,0,t,.3,.45,r),V(0,i*.88,0,.45,.3,t,r),V(0,i*.95,0,.8,.5,.8,r)]:[V(0,i*.75,0,t*.75,i*.5,t*.75,r),...[-1,1].map(s=>V(s*t*.3,i*.71,0,t*.4,i*.33,t*.65,r))],...n==="fruit-tree"?[-.65,0,.65].map(s=>V(s,i*.75,.8,.2,.2,.2,14724205)):[]]);be("hedge","Hedge","Garden",[V(0,.5,0,1.5,1,.7,7840116)]);be("flower-bed","Flower bed","Garden",[V(0,.12,0,1.5,.24,.8,$e),...[-.5,0,.5].map(n=>V(n,.45,0,.3,.5,.3,14069921))]);be("planter","Square planter","Garden",[V(0,.25,0,.7,.5,.7,12555371),V(0,.65,0,.5,.5,.5,8956533)]);be("vegetable-patch","Vegetable patch","Garden",[V(0,.06,0,1.8,.12,1.5,10847589),...[-.5,0,.5].flatMap(n=>[-.45,0,.45].map(e=>V(n,.22,e,.2,.3,.2,9021805)))]);be("boulder","Boulder","Garden",[V(0,.35,0,1.3,.7,1.1,10398366),V(.2,.8,0,.8,.3,.8,10398366)]);be("birdhouse","Birdhouse","Garden",[V(0,.8,0,.1,1.6,.1,$e),V(0,1.65,0,.5,.5,.45,13939070),V(0,1.95,0,.65,.12,.6,9217434)]);be("pergola","Pergola","Garden",[...[-1,1].flatMap(n=>[-1,1].map(e=>V(n,1.25,e,.15,2.5,.15,$e))),...[-1,-.5,0,.5,1].map(n=>V(n,2.55,0,.15,.15,2.3,$e))]);for(const[n,e,t,i]of[["table-lamp","Table lamp",.65,.4],["floor-lamp","Floor lamp",1.8,.6],["street-lamp","Street lamp",3,.7],["garden-light","Garden light",.7,.35],["ceiling-light","Ceiling lamp",.3,.7],["wall-light","Wall light",.5,.3]])be(n,e,"Lighting",[V(0,t*.4,0,.08,t*.8,.08,Je),V(0,t*.85,0,i,t*.3,i,16768917),V(0,.04,0,i*.7,.08,i*.7,Je)],{interaction:"light"});be("toy-box","Toy box","Play",[V(0,.3,0,1.1,.6,.7,13874817),V(0,.65,0,1.15,.1,.75,9154209)]);be("dollhouse","Doll house","Play",[V(0,.25,0,.8,.5,.55,14529701),V(0,.6,0,.9,.25,.65,9348764,"wedge")]);be("sandpit","Sandpit","Play",[V(0,.08,0,2,.16,2,$e),V(0,.18,0,1.7,.08,1.7,14930335)]);be("play-slide","Play slide","Play",[V(0,.5,0,.6,1,1.7,14202233,"wedge"),V(-.4,1,.7,.12,2,.12,Je),V(.4,1,.7,.12,2,.12,Je)]);be("goal","Play goal","Play",[V(-1,.7,0,.1,1.4,.1,ct),V(1,.7,0,.1,1.4,.1,ct),V(0,1.4,0,2.1,.1,.1,ct)]);const Jt=new Map(ur.map(n=>[n.id,n]));function Va(n,e){const t=Jt.get(n.type);if(!t)throw Error("Unknown catalogue item");const i=t.parts.map(r=>({...r}));if(t.interaction==="door"&&(n.open||e!==void 0)){const r=i.at(-1),s=(e??(n.open?1:0))*Math.PI/2;r.x=-r.w/2+Math.cos(s)*r.w/2,r.z=-Math.sin(s)*r.w/2,r.yaw=s}if(t.interaction==="light"&&n.on===!1)for(const r of i)r.color===16768917&&(r.color=12960431);return i}function Ul(n,e){if(Zr.has(n.type))return[Zn(n)];const t=(n.rotation||0)*Math.PI/180,i=Math.cos(t),r=Math.sin(t),s=Jt.get(n.type);if(s.ramp){const a=Math.max(...s.parts.map(l=>l.w)),o=n.type==="stairs"?2:s.parts[0].d,c=Math.max(...s.parts.map(l=>l.y+l.h/2));return[{minX:n.x+.5-(Math.abs(i)*a+Math.abs(r)*o)/2,maxX:n.x+.5+(Math.abs(i)*a+Math.abs(r)*o)/2,minZ:n.z+.5-(Math.abs(r)*a+Math.abs(i)*o)/2,maxZ:n.z+.5+(Math.abs(r)*a+Math.abs(i)*o)/2,minY:n.y,maxY:n.y+c,ramp:{cx:n.x+.5,cz:n.z+.5,c:i,s:r,width:a,length:o,rise:c,baseY:n.y}}]}return Va(n,e).map(a=>{const o=t+(a.yaw||0),c=Math.cos(o),l=Math.sin(o),d=n.x+.5+a.x*i+a.z*r,h=n.z+.5-a.x*r+a.z*i,u=(Math.abs(c)*a.w+Math.abs(l)*a.d)/2,m=(Math.abs(l)*a.w+Math.abs(c)*a.d)/2;return{minX:d-u,maxX:d+u,minZ:h-m,maxZ:h+m,minY:n.y+a.y-a.h/2,maxY:n.y+a.y+a.h/2,obb:{cx:d,cz:h,c,s:l,halfW:a.w/2,halfD:a.d/2}}})}function pt(n){return Ul(n)}function y0(n,e){return Ul(n,e)}function Wa(n){const e=pt(n);return{minX:Math.min(...e.map(t=>t.minX)),maxX:Math.max(...e.map(t=>t.maxX)),minY:Math.min(...e.map(t=>t.minY)),maxY:Math.max(...e.map(t=>t.maxY)),minZ:Math.min(...e.map(t=>t.minZ)),maxZ:Math.max(...e.map(t=>t.maxZ))}}const Xa=[{id:"set-bedroom",label:"Bedroom set",category:"Presets",icon:"🛏",color:$e,blocks:[{x:0,y:0,z:0,type:"single-bed"},{x:2,y:0,z:0,type:"nightstand"},{x:2,y:0,z:2,type:"floor-lamp"}]},{id:"set-kitchen",label:"Kitchen run",category:"Presets",icon:"🍳",color:ct,blocks:[{x:0,y:0,z:0,type:"kitchen-counter"},{x:1,y:0,z:0,type:"sink"},{x:2,y:0,z:0,type:"stove"}]},{id:"set-garden",label:"Garden seating",category:"Presets",icon:"🌷",color:$e,blocks:[{x:0,y:0,z:0,type:"bench"},{x:-2,y:0,z:0,type:"planter"},{x:2,y:0,z:0,type:"planter"}]},{id:"set-workshop",label:"Workshop set",category:"Presets",icon:"🛠",color:Je,blocks:[{x:0,y:0,z:0,type:"workbench"},{x:3,y:0,z:0,type:"tool-cabinet"},{x:0,y:0,z:2,type:"storage-crate"}]}],or=[...ur,...Xa];function wa(n){const e=Xa.find(s=>s.id===n.type);if(!e)return[n];const t=(n.rotation||0)*Math.PI/180,i=Math.round(Math.cos(t)),r=Math.round(Math.sin(t));return e.blocks.map(s=>({x:n.x+s.x*i+s.z*r,y:n.y+s.y,z:n.z-s.x*r+s.z*i,type:s.type,rotation:n.rotation||0}))}const Vr=n=>`${Math.floor(n.x/nt.chunkSize)},${Math.floor(n.z/nt.chunkSize)}`;class S0{constructor(e,t,i,r){Object.assign(this,{parent:e,geometry:t,materials:i,decorMat:r}),this.cells=new Map,this.groups=new Map,this.rebuilt=0}clear(){for(const e of this.groups.values())this.dispose(e);this.cells.clear(),this.groups.clear()}dispose(e){e.traverse(t=>{t.isInstancedMesh&&t.dispose(),t.userData.ownedGeometry&&t.geometry.dispose()}),e.removeFromParent()}reset(e){this.clear();for(const t of e)this.store(t);for(const t of this.cells.keys())this.rebuild(t)}store(e){const t=Vr(e);this.cells.has(t)||this.cells.set(t,new Map),this.cells.get(t).set(cs(e),e)}update(e,t){var s;const i=Vr(e);t?this.store(e):(s=this.cells.get(i))==null||s.delete(cs(e));const r=new Set([i]);nt.chunkSize;for(const[a,o]of[[1,0],[-1,0],[0,1],[0,-1]]){const c=Vr({x:e.x+a,z:e.z+o});c!==i&&this.cells.has(c)&&r.add(c)}for(const a of r)this.rebuild(a)}opaque(e,t,i){var r,s;return Ea.includes((s=(r=this.cells.get(Vr({x:e,z:i})))==null?void 0:r.get(`${e},${t},${i}`))==null?void 0:s.type)}rebuild(e){var d;const t=this.groups.get(e);t&&this.dispose(t);const i=new gt,r=[...((d=this.cells.get(e))==null?void 0:d.values())||[]],s=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],a=this.geometry;for(const h of Ea){const u=[],m=[],M=[],_=[],p=[];for(const g of r.filter(v=>v.type===h))for(let v=0;v<6;v++){const[C,P,A]=s[v];if(this.opaque(g.x+C,g.y+P,g.z+A))continue;const N=u.length/3;for(let E=0;E<4;E++){const w=v*4+E;u.push(a.attributes.position.getX(w)+g.x+.5,a.attributes.position.getY(w)+g.y+.5,a.attributes.position.getZ(w)+g.z+.5),m.push(a.attributes.normal.getX(w),a.attributes.normal.getY(w),a.attributes.normal.getZ(w)),M.push(a.attributes.uv.getX(w),a.attributes.uv.getY(w))}for(let E=0;E<6;E++)_.push(N+a.index.array[v*6+E]-v*4);p.push(g,g)}if(!u.length)continue;const f=new at;f.setAttribute("position",new Ye(u,3)),f.setAttribute("normal",new Ye(m,3)),f.setAttribute("uv",new Ye(M,2)),f.setIndex(_),f.computeBoundingSphere(),f.computeBoundingBox();const x=new Ie(f,this.materials[h]);x.userData.faceBlocks=p,x.userData.ownedGeometry=!0,i.add(x)}const o=new Map,c=new ut,l=new ut;for(const h of r.filter(u=>os.includes(u.type))){c.position.set(h.x+.5,h.y,h.z+.5),c.rotation.y=(h.rotation||0)*Math.PI/180,c.updateMatrix();for(const[u,m,M,_,p,f,x]of wl[h.type])l.position.set(u-.5,m,M-.5),l.scale.set(_,p,f),l.updateMatrix(),o.has(x)||o.set(x,[]),o.get(x).push({b:h,m:new Qe().multiplyMatrices(c.matrix,l.matrix)})}for(const[h,u]of o){const m=new rs(this.geometry,this.decorMat(h),u.length);u.forEach((M,_)=>m.setMatrixAt(_,M.m)),m.userData.blocks=u.map(M=>M.b),m.computeBoundingSphere(),i.add(m)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i),this.rebuilt++}rayMeshes(){const e=[];return this.parent.traverse(t=>{t.isMesh&&e.push(t)}),e}}const b0=new vt(1,1,1),Ms=new at;Ms.setAttribute("position",new Ye([-.5,-.5,-.5,.5,-.5,-.5,-.5,-.5,.5,.5,-.5,.5,-.5,.5,-.5,.5,.5,-.5],3));Ms.setIndex([0,2,1,1,2,3,0,1,4,1,5,4,0,4,2,1,3,5,2,4,3,3,4,5]);Ms.computeVertexNormals();const ca=new Map;function Il(n,e){if(ca.has(n))return ca.get(n);if(typeof document>"u")return;const t=document.createElement("canvas");t.width=t.height=128;const i=t.getContext("2d");if(i.fillStyle="#ffffff",i.fillRect(0,0,128,128),i.strokeStyle="#c7c7c7",i.lineWidth=3,["brick","tile","checker","mosaic","metal"].includes(e)){const s=e==="mosaic"?16:e==="metal"?64:32;for(let a=0;a<128;a+=s)for(let o=0;o<128;o+=s){const c=o-(e==="brick"&&a/s%2?s/2:0);e==="checker"&&(o+a)/s%2===0&&(i.fillStyle="#aaaaaa",i.fillRect(c,a,s,s)),i.strokeRect(c,a,s,s)}}else if(["wood","bamboo","log"].includes(e)){for(let s=0;s<8;s++)i.beginPath(),i.moveTo(s*18,0),i.lineTo(s*18,128),i.stroke();if(e==="log")for(let s=12;s<64;s+=12)i.beginPath(),i.arc(64,64,s,0,Math.PI*2),i.stroke()}else for(let s=0;s<110;s++){const a=s*37%128,o=s*67%128;i.fillStyle=s%3?"#e1e1e1":"#bdbdbd",i.fillRect(a,o,e==="cobble"?15:e==="marble"?22:3,e==="cobble"?12:2)}const r=new ss(t);return r.colorSpace=mt,r.magFilter=Ct,ca.set(n,r),r}const Nl=n=>n.shape==="wedge"?Ms:b0;function ys(n,e=!1){const t=new gt;t.position.set(n.x+.5,n.y,n.z+.5),t.rotation.y=(n.rotation||0)*Math.PI/180;const i=Jt.get(n.type);if(!i){for(const r of wa(n))t.add(ys({...r,x:r.x-n.x-.5,y:r.y-n.y,z:r.z-n.z-.5},e));return t.rotation.y=0,t.position.set(n.x+.5,n.y,n.z+.5),t}for(const r of Va(n)){const s=new Ie(Nl(r),new Vt({color:r.color,map:i.surface&&Il(i.id,i.surface)||null,transparent:e,opacity:e?.55:1}));s.position.set(r.x,r.y,r.z),s.scale.set(r.w,r.h,r.d),s.rotation.y=r.yaw||0,s.userData.block=n,t.add(s)}return t}class E0{constructor(e,t,i,r){this.parent=e,e.add(this.legacyGroup),this.legacy=new S0(this.legacyGroup,t,i,r)}legacy;legacyGroup=new gt;cells=new Map;groups=new Map;materials=new Map;key(e){return`${Math.floor(e.x/16)},${Math.floor(e.z/16)}`}anchor(e){return`${e.x},${e.y},${e.z}`}clear(){this.legacy.clear();for(const e of this.groups.values())e.traverse(t=>{t.isInstancedMesh&&t.dispose()}),e.removeFromParent();this.groups.clear(),this.cells.clear()}reset(e){this.clear(),this.legacy.reset(e.filter(t=>Zr.has(t.type)));for(const t of e.filter(i=>!Zr.has(i.type))){const i=this.key(t);this.cells.has(i)||this.cells.set(i,new Map),this.cells.get(i).set(this.anchor(t),t)}for(const t of this.cells.keys())this.rebuild(t)}update(e,t){if(Zr.has(e.type)){this.legacy.update(e,t);return}const i=this.key(e);this.cells.has(i)||this.cells.set(i,new Map),t?this.cells.get(i).set(this.anchor(e),e):this.cells.get(i).delete(this.anchor(e)),this.rebuild(i)}rebuild(e){var o;const t=this.groups.get(e);t&&(t.traverse(c=>{c.isInstancedMesh&&c.dispose()}),t.removeFromParent());const i=new gt,r=new Map,s=new ut,a=new ut;for(const c of((o=this.cells.get(e))==null?void 0:o.values())||[]){s.position.set(c.x+.5,c.y,c.z+.5),s.rotation.y=(c.rotation||0)*Math.PI/180,s.updateMatrix();for(const l of Va(c)){a.position.set(l.x,l.y,l.z),a.scale.set(l.w,l.h,l.d),a.rotation.y=l.yaw||0,a.updateMatrix();const d=Jt.get(c.type),h=(l.shape||"box")+":"+(d.surface?d.id:"plain");r.has(h)||r.set(h,[]),r.get(h).push({b:c,p:l,matrix:new Qe().multiplyMatrices(s.matrix,a.matrix)})}}for(const[c,l]of r){const d=Jt.get(l[0].b.type);this.materials.has(c)||this.materials.set(c,new Vt({color:16777215,map:d.surface&&Il(d.id,d.surface)||null}));const h=new rs(Nl(l[0].p),this.materials.get(c),l.length);l.forEach((u,m)=>{h.setMatrixAt(m,u.matrix),h.setColorAt(m,new je(u.p.color))}),h.userData.blocks=l.map(u=>u.b),h.computeBoundingSphere(),i.add(h)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i)}rayMeshes(){return[...this.legacy.rayMeshes(),...[...this.groups.values()].flatMap(e=>e.children)]}}let bi;const la=new Map;function w0(n){if(la.has(n))return la.get(n);bi||(bi=new Oa({alpha:!0,antialias:!1}),bi.setSize(112,96),bi.setPixelRatio(1));const e=new vl,t=ys({x:0,y:0,z:0,type:n}),i=new vn().setFromObject(t),r=i.getCenter(new z),s=i.getSize(new z),a=Math.max(s.x,s.y,s.z)*.8+.25,o=new za(-a*1.17,a*1.17,a,-a,.01,100);o.position.copy(r).add(new z(a*2,a*1.5,a*2.4)),o.lookAt(r),e.add(new bl(16777215,8624771,2),new El(16777215,1),t),bi.render(e,o);const c=bi.domElement.toDataURL();return t.traverse(l=>{l.isMesh&&l.material.dispose()}),la.set(n,c),c}function Ta(n){const e=[...n.recent.filter(i=>or.some(r=>r.id===i)),...ur.slice(0,7).map(i=>i.id)],t=[...new Set(e)].slice(0,8);document.querySelector("#palette").innerHTML=t.map(i=>{const r=or.find(s=>s.id===i);return`<button data-item="${r.id}" aria-label="Choose ${r.label}" title="${r.label}" aria-pressed="${n.selected===i}"><span>${r.icon}</span><small>${r.label}</small></button>`}).join("")}function T0(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section class="cataloguePanel"><h1>▦ Build anything</h1><input id="catalogueSearch" aria-label="Search catalogue" placeholder="Search (optional)"><div id="categories"></div><div id="catalogueGrid"></div><div class="cataloguePages"><button id="previousPage" aria-label="Previous catalogue page">◀</button><output id="catalogueCount"></output><button id="nextPage" aria-label="Next catalogue page">▶</button><button id="closeCatalogue">▶ Play</button></div></section>';let t="All",i=0,r=0;const s=()=>{r++,e.hidden=!0,n.paused=!1,n.controls.clear()},a=()=>{r++;const o=r,c=document.querySelector("#catalogueSearch").value.toLowerCase(),l=or.filter(M=>(t==="All"||t==="Favourites"&&n.favourites.includes(M.id)||t==="Recent"&&n.recent.includes(M.id)||M.category===t)&&M.label.toLowerCase().includes(c));i=Math.min(i,Math.max(0,Math.ceil(l.length/24)-1));const d=l.slice(i*24,i*24+24),h=document.querySelector("#catalogueGrid");h.replaceChildren();const u=[];for(const M of d){const _=document.createElement("article");_.className="catalogueCard";const p=document.createElement("button");p.dataset.catalogue=M.id,p.setAttribute("aria-label","Choose "+M.label);const f=document.createElement("img");f.alt=M.label,f.width=112,f.height=96;const x=document.createElement("span");x.textContent=M.label,p.append(f,x),p.onclick=()=>{n.choose(M.id),s()};const g=document.createElement("button");g.className="favourite",g.textContent=n.favourites.includes(M.id)?"★":"☆",g.setAttribute("aria-label","Favourite "+M.label),g.setAttribute("aria-pressed",String(n.favourites.includes(M.id))),g.onclick=()=>{n.favourites=n.favourites.includes(M.id)?n.favourites.filter(v=>v!==M.id):[M.id,...n.favourites].slice(0,32),n.onEdit(),a()},_.append(p,g),h.append(_),u.push(()=>{o===r&&f.isConnected&&(f.src=w0(M.id))})}const m=()=>{var M;o!==r||e.hidden||((M=u.shift())==null||M(),u.length&&requestAnimationFrame(m))};requestAnimationFrame(m),document.querySelector("#catalogueCount").textContent=`${l.length} choices · ${i+1}/${Math.max(1,Math.ceil(l.length/24))}`,document.querySelector("#previousPage").disabled=i===0,document.querySelector("#nextPage").disabled=(i+1)*24>=l.length};for(const o of["All","Favourites","Recent",...new Set(or.map(c=>c.category))]){const c=document.createElement("button");c.textContent=o==="Favourites"?"★ Favourites":o==="Recent"?"◷ Recent":o,c.dataset.category=o,c.onclick=()=>{t=o,i=0,a()},document.querySelector("#categories").append(c)}document.querySelector("#catalogueSearch").oninput=()=>{i=0,a()},document.querySelector("#nextPage").onclick=()=>{i++,a()},document.querySelector("#previousPage").onclick=()=>{i--,a()},document.querySelector("#closeCatalogue").onclick=s,a()}const Lc=nt.halfSize;nt.maxBlocks;const Rn=.28,zl=1.65,jr=(n,e,t)=>Math.max(e,Math.min(t,n)),Bi=n=>({minX:n.x-Rn,minY:n.y+.001,minZ:n.z-Rn,maxX:n.x+Rn,maxY:n.y+zl,maxZ:n.z+Rn});function Dc(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function Ci(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:(i.baseY||0)+jr((i.length/2-o)/i.length,0,1)*i.rise}function It(n,e){if(e.ramp){const a=Ci(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return It(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=Dc(n),i=Dc(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const c=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),l=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=c+l-1e-5)return!1}return!0}const Pi=(n,e)=>e.some(t=>It(Bi(n),t));function Uc(n,e){let t=0;for(const i of e){const r=Ci(i,n.x,n.z),s=r===null?i:{...i,maxY:r};i.ramp&&r===null||s.maxY<=n.y+.02&&s.maxY>t&&n.x+Rn>s.minX+.01&&n.x-Rn<s.maxX-.01&&n.z+Rn>s.minZ+.01&&n.z-Rn<s.maxZ-.01&&(t=s.maxY)}return t}function Ic(n,e){return n.y<=.35?!0:[-.12,.12].every(t=>[-.12,.12].every(i=>e.some(r=>{const s=Ci(r,n.x+t,n.z+i);if(r.ramp)return s!==null&&Math.abs(s-n.y)<.3;if(r.maxY>n.y+.025||r.maxY<n.y-.3)return!1;const a={minX:n.x+t-.001,maxX:n.x+t+.001,minZ:n.z+i-.001,maxZ:n.z+i+.001,minY:r.maxY-.003,maxY:r.maxY+.003};return It(a,r)})))}function Nc(n,e){let t=1/0;for(const i of e){if(i.maxY>n.y+.025||i.maxY<n.y-.3)continue;const r=Math.max(i.minX+.12-n.x,0,n.x-(i.maxX-.12)),s=Math.max(i.minZ+.12-n.z,0,n.z-(i.maxZ-.12));t=Math.min(t,r*r+s*s)}return t}function A0(n,e,t,i){const r=Math.ceil(Math.min(t,.1)/.012),s=Math.min(t,.1)/r,a=Cl(e.walkSpeed);let o=jr(e.forward||0,-1,1),c=jr(e.right||0,-1,1),l=Math.max(1,Math.hypot(o,c));const d=(-Math.sin(n.yaw)*o+Math.cos(n.yaw)*c)*a/l,h=(-Math.cos(n.yaw)*o-Math.sin(n.yaw)*c)*a/l;for(let u=0;u<r;u++){const m=Uc(n,i);(n.vy||0)<=0&&n.y>=m-.002&&n.y-m<.035&&(n.y=m,n.vy=0,n.grounded=!0);for(const[p,f]of[["x",d],["z",h]]){const x=n[p];n[p]=jr(x+f*s,-Lc+.4,Lc-.4);const g=n.y;if(n.grounded)for(const v of i){const C=Ci(v,n.x,n.z),P=Ci(v,p==="x"?x:n.x,p==="z"?x:n.z);C!==null&&C-n.y<=.09&&C-n.y>=-.12&&(P!==null||Math.abs(n.y-(v.ramp.baseY||0))<.1||Math.abs(n.y-v.maxY)<.1)&&(n.y=C)}if(Pi(n,i)&&(n[p]=x,n.y=g),e.edgeProtection&&n.grounded&&!e.allowDrop&&n.y>.35&&!Ic(n,i)){const v={...n,[p]:x};(Ic(v,i)||Nc(n,i)>=Nc(v,i)-1e-6)&&(n[p]=x)}}n.vy=(n.vy||0)-16*s;const M=n.y;if(n.y+=n.vy*s,n.y<=0)n.y=0,n.vy=0,n.grounded=!0;else if(Pi(n,i)){const p=i.filter(f=>It(Bi(n),f));n.vy<0?(n.y=Math.max(...p.map(f=>Ci(f,n.x,n.z)??f.maxY)),n.grounded=!0):(n.y=Math.min(...p.map(f=>f.minY))-zl-.002,n.grounded=!1),(n.y<0||Pi(n,i))&&(n.y=M),n.vy=0}else n.grounded=!1;const _=Uc(n,i);n.vy<=0&&n.y>=_-.002&&n.y-_<.035&&(n.y=_,n.vy=0,n.grounded=!0)}}const Fl=n=>Number.isInteger(n.x)&&Number.isInteger(n.z)&&Number.isFinite(n.y)&&Math.abs(n.y*100-Math.round(n.y*100))<1e-7;function R0(n){if(!Array.isArray(n)||n.length>12e3)throw Error("Unsupported build capacity");const e=new Set,t=new zi(4);for(const i of n){if(!i||!Jt.has(i.type)||!Fl(i)||i.x<-250||i.x>=250||i.z<-250||i.z>=250||i.y<0||i.y>=24||i.rotation!==void 0&&!Number.isFinite(i.rotation)||Math.abs(i.rotation||0)>36e3||i.open!==void 0&&typeof i.open!="boolean"||i.on!==void 0&&typeof i.on!="boolean")throw Error("Invalid catalogue object");const r=`${i.x},${i.y},${i.z}`;if(e.has(r))throw Error("Duplicate build anchor");if(e.add(r),Wa(i).maxY>24.001)throw Error("Object exceeds build ceiling");for(const a of pt(i))if(t.query(a).some(o=>It(a,o)))throw Error("Saved objects overlap");for(const a of pt(i))t.add(a)}}function zc(n,e,t,i,r=!0){if(!n||!Jt.has(n.type))return"Choose a building piece";if(!Fl(n)||n.x<-250||n.x>=250||n.z<-250||n.z>=250||n.y<0||n.y>=24)return"Build inside the world";if(e.length>=12e3)return"World geometry capacity reached";if(Wa(n).maxY>24.001)return"That is above the build ceiling";if(r&&Math.hypot(n.x+.5-i.x,n.y+.5-i.y,n.z+.5-i.z)>6)return"Move a little closer";if(e.some(c=>c.x===n.x&&c.y===n.y&&c.z===n.z))return"Find a clear space";const a=pt(n),o=[...t,...e.flatMap(pt)];return a.some(c=>It(c,Bi(i)))?"Take a little step back":a.some(c=>o.some(l=>It(c,l.ramp?{...l,ramp:null}:l)))?"Find a clear space":n.y>0&&!e.some(c=>Math.abs(c.x-n.x)+Math.abs(c.y-n.y)+Math.abs(c.z-n.z)<=1)&&!o.some(c=>Math.abs(c.maxY-n.y)<.02&&c.minX<=n.x+.5&&c.maxX>=n.x+.5&&c.minZ<=n.z+.5&&c.maxZ>=n.z+.5)?"Join this piece to a surface":""}function qa({scene:n,material:e,doors:t,h:i,local:r,id:s=i.id,x:a=-1.4,z:o=i.d/2,width:c=1.26,height:l=2.3}){const d=r(a-c/2,o+.03),h=r(a,o),u=new gt;u.position.set(d.x,0,d.z),u.rotation.y=i.angle;const m=new Ie(new vt(c,l,.1),e(9726028));m.position.set(c/2,l/2,0),u.add(m);const M=new Ie(new vt(c*.62,.65,.112),e(11980733));M.position.set(c/2,1.65,0),u.add(M);const _=new Ie(new ms(.055,6,5),e(16768118));_.position.set(c-.16,1,.09),u.add(_),n.add(u),t.push({id:s,pivot:u,baseAngle:i.angle,open:!1,center:h,hinge:d,width:c,height:l})}function Ss({scene:n,material:e,doors:t,h:i,put:r,local:s}){const a=-i.w/2-2.1,o=i.d/2,c=o-2.7;r(a,.007,c,4.2,.014,5.4,12959399);for(const m of[-2.1,2.1])r(a+m,1.4,c,.2,2.8,5.4,i.wall,!0);r(a,1.4,o-5.4,4.2,2.8,.2,i.wall,!0),r(a,2.72,o,4.2,.16,.2,i.wall,!0);for(const m of[-1.92,1.92])r(a+m,1.32,o,.36,2.64,.2,i.wall,!0);r(a,2.88,c,4.6,.18,5.8,i.roof,!0);const l=s(a,o),d=new gt;d.position.set(l.x,0,l.z),d.rotation.y=i.angle;const h=new gt,u=new Ie(new vt(3.46,2.6,.1),e(14144708));u.position.y=1.3,h.add(u);for(let m=.25;m<2.6;m+=.32){const M=new Ie(new vt(3.42,.035,.12),e(10989475));M.position.y=m,h.add(M)}d.add(h),n.add(d),t.push({id:i.id+"-garage",kind:"roller",pivot:d,leaf:h,baseAngle:i.angle,center:l,hinge:l,width:3.46,height:2.6,open:!1})}function C0({h:n,put:e,local:t,scene:i,material:r,doors:s,solids:a,label:o,rooms:c}){const l=n.w,d=n.d,h=d/2,u=n.storeys===2,m=3.2,M=u?6.4:3,_=16774617,p=9725511,f=8501706;e(0,.007,0,l,.014,d,14006419);for(const U of[-h,h]){const W=U>0,L=l/2-2,I=2.1,k=W?[[-l/2,-2.1],[-.7,L-I/2],[L+I/2,l/2]]:[[-l/2,L-I/2],[L+I/2,l/2]];for(const[X,$]of k)$>X&&e((X+$)/2,1.5,U,$-X,3,.22,n.wall,!0);W&&e(-1.4,2.68,U,1.4,.64,.22,n.wall,!0),e(L,.5,U,I,1,.22,n.wall,!0),e(L,2.65,U,I,.7,.22,n.wall,!0),e(L,1.65,U,I,1.3,.1,f,!0);for(const X of[L-I/2,L,L+I/2])e(X,1.65,U,.065,1.42,.3,_);for(const X of[1,2.3])e(L,X,U,I+.15,.07,.3,_);if(u){e(0,3.22,U,l,.44,.22,n.wall,!0);const X=1.6,$=n.id==="manor"?[-l/2+2,-1.4,l/2-2]:[-l/2+2,l/2-2];let ie=-l/2;for(const ne of $){e((ie+ne-X/2)/2,4.8,U,ne-X/2-ie,3.2,.22,n.wall,!0),e(ne,3.7,U,X,1,.22,n.wall,!0),e(ne,5.98,U,X,.84,.22,n.wall,!0),e(ne,4.88,U,X,1.36,.1,f,!0);for(const ue of[ne-X/2,ne,ne+X/2])e(ue,4.88,U,.065,1.5,.3,_);for(const ue of[4.2,5.56])e(ne,ue,U,X+.15,.07,.3,_);ie=ne+X/2}e((ie+l/2)/2,4.8,U,l/2-ie,3.2,.22,n.wall,!0)}}for(const U of[-l/2,l/2])for(const W of u?[0,m]:[0]){const L=d>10?[-d/2+2.5,d/2-2.5]:[0],I=1.6;let k=-h;for(const X of L){e(U,W+1.5,(k+X-I/2)/2,.22,3,X-I/2-k,n.wall,!0),e(U,W+.5,X,.22,1,I,n.wall,!0),e(U,W+2.65,X,.22,.7,I,n.wall,!0),e(U,W+1.65,X,.1,1.3,I,f,!0);for(const $ of[X-.8,X,X+.8])e(U,W+1.65,$,.3,1.42,.065,_);for(const $ of[1,2.3])e(U,W+$,X,.3,.07,I+.15,_);k=X+I/2}e(U,W+1.5,(k+h)/2,.22,3,h-k,n.wall,!0),u&&(e(U,3.1,0,.22,.2,d,n.wall,!0),e(U,M-.1,0,.22,.2,d,n.wall,!0))}qa({scene:i,material:r,doors:s,h:n,local:t});const x=M+.06,g=x+(n.id==="manor"?3.3:1.8),v=l/2+.4,C=h+.4,P=[],A=(U,W,L,I)=>P.push(...U,...W,...L,...U,...L,...I);if(n.style==="hip")A([-v,x,C],[v,x,C],[0,g,1],[0,g,1]),A([v,x,C],[v,x,-C],[0,g,-1],[0,g,1]),A([v,x,-C],[-v,x,-C],[0,g,-1],[0,g,-1]),A([-v,x,-C],[-v,x,C],[0,g,1],[0,g,-1]);else if(n.style==="shed"){const U=x+1.4;A([-v,x,C],[v,x,C],[v,U,-C],[-v,U,-C]);for(const W of[-l/2,l/2]){const L=new at;L.setAttribute("position",new Ye([W,M,-h,W,U,-h,W,x,h,W,M,-h,W,x,h,W,M,h],3)),L.computeVertexNormals();const I=r(n.wall).clone();I.side=xt;const k=new Ie(L,I);k.position.set(n.x,0,n.z),k.rotation.y=n.angle,i.add(k)}e(0,(M+U)/2,-h,l,U-M,.22,n.wall,!0)}else{A([-v,x,C],[0,g,C],[0,g,-C],[-v,x,-C]),A([0,g,C],[v,x,C],[v,x,-C],[0,g,-C]);for(const U of[-h,h]){const W=new at;W.setAttribute("position",new Ye([-l/2,M,U,l/2,M,U,0,g,U],3)),W.computeVertexNormals();const L=r(n.wall).clone();L.side=xt;const I=new Ie(W,L);I.position.set(n.x,0,n.z),I.rotation.y=n.angle,i.add(I)}}const N=new at;N.setAttribute("position",new Ye(P,3)),N.computeVertexNormals();const E=r(n.roof).clone();E.side=xt;const w=new Ie(N,E);w.position.set(n.x,0,n.z),w.rotation.y=n.angle,i.add(w),e(0,M+.015,0,l,.09,d,_,!0),e(-1.4,2.64,h+.7,n.porch||2.4,.12,1.5,n.roof,!0);for(const U of[-2.45,-.35])e(U,1.27,h+1.3,.12,2.54,.12,_,!0);if(n.id==="manor"){for(const I of[-4.9,2.1]){e(I,3.15,h+2,.32,6.3,.32,_,!0);for(const k of[.12,6.25])e(I,k,h+2,.65,.24,.65,_,!0)}e(-1.4,6.5,h+1.1,7.9,.24,2.8,_,!0);const U=new at;U.setAttribute("position",new Ye([-5.35,6.65,h+2.55,2.55,6.65,h+2.55,-1.4,8.15,h+2.55],3)),U.computeVertexNormals();const W=r(_).clone();W.side=xt;const L=new Ie(U,W);L.position.set(n.x,0,n.z),L.rotation.y=n.angle,i.add(L),e(3,.34,h-2.5,3.4,.68,1,7183771,!0),e(3,.88,h-2.96,3.4,.72,.18,7183771,!0);for(const I of[1.4,4.6])e(I,.65,h-2.5,.2,.5,1,p,!0);e(3,.36,h-4.2,1.8,.72,.8,p,!0),e(-l/2+3.3,.79,h-3,2.6,.15,1.6,p,!0);for(const I of[-1,1])for(const k of[-.55,.55])e(-l/2+3.3+I,.36,h-3+k,.12,.72,.12,p,!0)}const H=(U,W,L=l/2-.2)=>{e((-l/2+-1.4-1.7/2)/2,U+1.5,W,-1.4-1.7/2+l/2,3,.16,n.wall,!0),e((-1.4+1.7/2+L)/2,U+1.5,W,L- -1.4-1.7/2,3,.16,n.wall,!0),e(-1.4,U+2.72,W,1.7,.56,.16,_,!0)};if(n.rooms&&(H(0,-.4,u?l/2-2.2:l/2-.2),c.push({house:n.id,name:"Back room",...t(-1.4,-h+1.7),y:0})),u){const U=l/2-1.2,W=1.65,L=h-1.4,I=-h+1.4,k=L-I,X=-l/2,$=U-W/2-.12;e((X+$)/2,m-.09,0,$-X,.18,d,14006419,!0);for(const[se,ge]of[[-h+.6,1.2],[h-.6,1.2]])e(($+l/2)/2,m-.09,se,l/2-$,.18,ge,14006419,!0);const ie=t(U,(L+I)/2),ne=Math.cos(n.angle),ue=Math.sin(n.angle),de=(W*Math.abs(ne)+k*Math.abs(ue))/2,J=(W*Math.abs(ue)+k*Math.abs(ne))/2;a.push({minX:ie.x-de,maxX:ie.x+de,minZ:ie.z-J,maxZ:ie.z+J,minY:0,maxY:m,ramp:{cx:ie.x,cz:ie.z,c:ne,s:ue,width:W,length:k,rise:m}});for(let se=0;se<16;se++){const ge=m*(se+1)/16;e(U,ge/2,L-(se+.5)*k/16,W,ge,k/16,p)}e($-.04,m+.48,(L+I)/2,.1,.96,k,p,!0);for(const se of[L-.15,I+.15])e($-.04,m+.48,se,.12,.96,.12,_,!0);H(m,-.4,$-.25),c.push({house:n.id,name:"Upper landing",...t(U,-h+.55),y:m},{house:n.id,name:"Upstairs bedroom",...t(-1.4,-h+1.7),y:m})}for(const U of u?[0,m]:[0])e(-l/2+1.3,U+.28,-h+1.6,1.8,.56,2.4,p,!0),e(-l/2+1.3,U+.62,-h+1.6,1.75,.13,2.3,n.roof),e(-l/2+1.3,U+.73,-h+.8,1.5,.16,.5,_),e(-l/2+1.1,U+.45,h-1.1,1.5,.9,.7,p,!0);if(n.shop){e(l/2-1.5,.5,-h+1.2,2,1,1,p,!0);const U=t(0,h+.2);o(n.sign,U.x,2.9,U.z,n.angle,Math.min(l-1,5))}if(n.street){const U=l/2+1.2;e(U,.22,0,1.1,.44,d+3,5933922,!0),e(0,.38,-h-1.6,l+2,.12,.12,p,!0);for(const W of[-l/2-1,0,l/2+1])e(W,.35,-h-1.6,.1,.7,.1,_,!0);e(l/2-1,.18,h+1.5,2,.36,1,5933922,!0);for(const W of[-.6,0,.6])e(l/2-1+W,.43,h+1.5,.3,.18,.3,15118451)}n.garage&&Ss({scene:i,material:r,doors:s,h:n,put:e,local:t}),c.push({house:n.id,name:"Entrance",...t(-1.4,h-1.1),y:0})}function Ya(n,e){const t=new Map,i=new Qe,r=new Qe,s=new z,a=new z,o=new Xe,c=[...n.children].filter(_=>_.isMesh&&!e.has(_)),l=new Set,d=new Set;for(const _ of c){_.updateMatrixWorld(!0);const p=_.geometry.index?_.geometry.toNonIndexed():_.geometry,f=p.attributes.position,x=p.attributes.normal,g=_.material.color,v=_.isInstancedMesh?_.count:1;for(let C=0;C<v;C++){_.isInstancedMesh?(_.getMatrixAt(C,i),r.multiplyMatrices(_.matrixWorld,i)):r.copy(_.matrixWorld);const P=r.elements[12],A=r.elements[14],N=`${Math.floor(P/nt.chunkSize)},${Math.floor(A/nt.chunkSize)}`;t.has(N)||t.set(N,{positions:[],normals:[],colors:[]});const E=t.get(N);o.getNormalMatrix(r);for(let w=0;w<f.count;w++)s.fromBufferAttribute(f,w).applyMatrix4(r),a.fromBufferAttribute(x,w).applyMatrix3(o).normalize(),E.positions.push(s.x,s.y,s.z),E.normals.push(a.x,a.y,a.z),E.colors.push(g.r,g.g,g.b);if(_.material.side===xt)for(let w=0;w<f.count;w+=3)for(const H of[w+2,w+1,w])s.fromBufferAttribute(f,H).applyMatrix4(r),a.fromBufferAttribute(x,H).applyMatrix3(o).normalize().negate(),E.positions.push(s.x,s.y,s.z),E.normals.push(a.x,a.y,a.z),E.colors.push(g.r,g.g,g.b)}p!==_.geometry&&p.dispose(),l.add(_.geometry),d.add(_.material),_.isInstancedMesh&&_.dispose(),n.remove(_)}const h=new Vt({vertexColors:!0,side:_n}),u=[];let m=0;for(const[_,p]of t){const f=new at;f.setAttribute("position",new Ye(p.positions,3)),f.setAttribute("normal",new Ye(p.normals,3)),f.setAttribute("color",new Ye(p.colors,3)),f.computeBoundingSphere();const x=new Ie(f,h);x.name=`scenery ${_}`,n.add(x),u.push(x),m+=p.positions.length/9}const M=new Set;n.traverse(_=>{_.isMesh&&M.add(_.material)});for(const _ of l)_.dispose();for(const _ of d)M.has(_)||_.dispose();return{chunks:t.size,triangles:m,hidden:0,updateVisibility(_,p,f=!0){const x=_.matrixWorldInverse.elements;let g=0;for(const v of u){const C=v.geometry.boundingSphere,P=C.center,A=-(x[2]*P.x+x[6]*P.y+x[10]*P.z+x[14])-C.radius;v.visible=!f||A<=p+.1,v.visible||g++}return this.hidden=g,g},showAll(){for(const _ of u)_.visible=!0;this.hidden=0}}}function Za(n){const e=new Map,t=new Vt({vertexColors:!0}),i=new Qe,r=new z,s=new z,a=new Xe;let o=0;for(const c of n){const l=c.leaf||c.pivot,d=[...l.children].filter(_=>_.isMesh);o+=d.length;const h=JSON.stringify(d.map(_=>[_.geometry.parameters,_.position.toArray(),_.rotation.toArray(),_.scale.toArray(),_.material.color.getHex()]));let u=e.get(h),m=0;if(!u){const _=[],p=[],f=[];for(const[x,g]of d.entries()){g.updateMatrix(),i.copy(g.matrix),a.getNormalMatrix(i);const v=g.geometry.index?g.geometry.toNonIndexed():g.geometry,C=v.attributes.position,P=v.attributes.normal,A=g.material.color;x===0&&(m=C.count);for(let N=0;N<C.count;N++)r.fromBufferAttribute(C,N).applyMatrix4(i),s.fromBufferAttribute(P,N).applyMatrix3(a).normalize(),_.push(r.x,r.y,r.z),p.push(s.x,s.y,s.z),f.push(A.r,A.g,A.b);v!==g.geometry&&v.dispose()}u=new at,u.setAttribute("position",new Ye(_,3)),u.setAttribute("normal",new Ye(p,3)),u.setAttribute("color",new Ye(f,3)),u.computeBoundingSphere(),u.userData.panelVertices=m,e.set(h,u)}for(const _ of d)l.remove(_),_.geometry.dispose();const M=new Ie(u,t);M.name=c.id+" leaf",l.add(M)}return{partsBefore:o,meshesAfter:n.length,sharedGeometries:e.size}}function Ol(n){const e=[],t=[],i=[],r=[],s=new vt(1,1,1),a=new Map,o=u=>(a.has(u)||a.set(u,new Vt({color:u})),a.get(u));function c(u,m,M,_,p,f,x,g=!1){const v=new Ie(s,o(x));return v.position.set(u,m,M),v.scale.set(_,p,f),n.add(v),g&&e.push({minX:u-_/2,maxX:u+_/2,minY:m-p/2,maxY:m+p/2,minZ:M-f/2,maxZ:M+f/2}),v}c(0,-.1,0,500,.2,500,10864267);for(const u of[-36,4,36])c(0,.012,u,84,.024,6,8558487);for(const u of[-40,8,40])c(u,.014,0,6,.028,78,8558487);for(let u=-36;u<=36;u+=5)c(u,.03,4,2,.02,.14,16772533);for(const[u,m]of[[-20,-12],[-5,-21],[24,-20],[-22,21]]){const M={id:r.length===0?"home":["cafe","library","workshop"][r.length-1],x:u,z:m,w:12,d:10,angle:r.length===3?Math.PI:0,wall:[15780251,15251368,12111037,13944996][r.length],roof:5209465};r.push(M);const _=Math.cos(M.angle),p=Math.sin(M.angle),f=(v,C)=>({x:u+v*_+C*p,z:m-v*p+C*_}),x=(v,C,P,A,N,E,w,H=!1)=>{const U=f(v,P);return c(U.x,C,U.z,A,N,E,w,H)};x(0,.025,0,12,.05,10,15127212),x(-6,1.6,0,.22,3.2,10,M.wall,!0),x(6,1.6,0,.22,3.2,10,M.wall,!0),x(0,1.6,-5,12,3.2,.22,M.wall,!0),x(-4.05,1.6,5,3.9,3.2,.22,M.wall,!0),x(2.65,1.6,5,6.7,3.2,.22,M.wall,!0),x(-1.4,2.77,5,1.4,.86,.22,M.wall,!0),x(0,3.27,0,12.8,.2,10.8,M.roof,!0);for(const v of[1.5,4])x(v,1.75,5.15,1.6,1.2,.08,9486022),x(v,1.75,5.21,.06,1.3,.08,16773589),x(v,2.35,5.21,1.7,.08,.08,16773589);qa({scene:n,material:o,doors:t,h:M,local:f}),i.push({id:M.id,x:u,z:m,y:0});const g=(v,C)=>{x(v,.72,C,1.6,.14,1,11501653,!0);for(const P of[-.65,.65])for(const A of[-.35,.35])x(v+P,.34,C+A,.1,.68,.1,8743505)};if(g(2,0),x(2,.36,1.3,1,.72,.65,9942170,!0),x(2,.8,1.6,1,.3,.12,9942170),M.id==="home"&&(x(-3,.32,-2,2.4,.64,3,12029801,!0),x(-3,.72,-2,2.3,.2,2.9,15846028),x(-3,.88,-3,1.8,.25,.6,16774879),x(3,.7,-3,3,1.4,.7,8496284,!0)),M.id==="cafe"&&(x(-3,.7,-2,3.5,1.4,1,12553574,!0),x(-3,1.45,-2,3.7,.1,1.1,16772304),g(2,-3)),M.id==="library")for(const v of[-4,0,4]){x(v,1.1,-3,2.3,2.2,.5,11766370,!0);for(let C=0;C<5;C++)x(v-.8+C*.38,1.45,-2.69,.25,.7,.12,[14588270,7905945,14730099][C%3])}M.id==="workshop"&&(x(-3,.85,-2,3,1.7,1.2,11055526,!0),x(3,.5,-3,2,1,1.5,14923112,!0)),M.id==="home"&&Ss({scene:n,material:o,doors:t,h:M,put:x,local:f})}for(const[u,m]of[[-34,15],[-10,30],[28,7],[30,31],[-32,-27],[13,-32],[34,-7],[-3,15]])c(u,1,m,.35,2,.35,10123350,!0),c(u,2.5,m,3.1,2.5,3.1,6790008);for(const[u,m]of[[17,12],[25,12]])c(u,.42,m,2.5,.16,.8,11701090,!0),c(u,.75,m+.36,2.5,.55,.12,11701090);c(30,.03,25,10,.04,8,8568778),c(15,.3,22,2,.6,2,13872254,!0),c(15,.7,22,1.8,.3,1.8,9678199);const l=new Ie(new Un(500,500),new Ri({visible:!1}));l.rotation.x=-Math.PI/2,n.add(l),l.updateMatrixWorld();const d=Za(t),h=Ya(n,new Set([...t.map(u=>u.pivot),l]));return{ground:l,solids:e,doors:t,houses:r,rooms:i,roads:[],doorRender:d,staticRender:h,landmarks:[{name:"Home",icon:"⌂",x:-20,z:0},{name:"Square",icon:"☀",x:18,z:7},{name:"Library",icon:"📚",x:22.6,z:-10},{name:"Workshop",icon:"🛠",x:-20.6,z:13},{name:"Garden",icon:"🌷",x:22,z:20},{name:"Garage",icon:"🚗",x:-28,z:1}]}}const Fc=[{id:"sunbeam-cottage",name:"Sunbeam cottage",icon:"🏡",x:-21,z:-46,w:12,d:10,angle:0,wall:15123870,roof:10256756,garage:!0,kind:"home"},{id:"bluebell-house",name:"Bluebell house",icon:"🏠",x:22,z:-46,w:14,d:10,angle:0,wall:11847630,roof:7243909,garage:!0,kind:"home"},{id:"orchard-home",name:"Orchard home",icon:"🍎",x:-51,z:-13,w:12,d:10,angle:Math.PI/2,wall:13879200,roof:10454885,kind:"home"},{id:"school",name:"Sunbeam school",icon:"🎨",x:50,z:-22,w:16,d:10,angle:Math.PI/2,wall:14076320,roof:6852491,kind:"school"},{id:"clinic",name:"Friendly clinic",icon:"✚",x:50,z:4,w:12,d:10,angle:Math.PI/2,wall:13819347,roof:9349276,kind:"clinic"},{id:"bakery",name:"Little bakery",icon:"🥐",x:22,z:25,w:12,d:10,angle:0,wall:15055525,roof:10782067,kind:"bakery"},{id:"garden-studio",name:"Garden studio",icon:"🌿",x:-7,z:47,w:12,d:10,angle:Math.PI,wall:12110250,roof:7771788,kind:"garden"},{id:"stable",name:"Orchard stables",icon:"🐴",x:-51,z:29,w:16,d:10,angle:Math.PI/2,wall:12950905,roof:9205610,kind:"stable"}];function P0(n){const e=Ol(n),t=new gt;n.add(t);const i=[],r=[],s=[],a=[],o=[],c=[],l=new vt(1,1,1),d=new Map,h=g=>(d.has(g)||d.set(g,new Vt({color:g})),d.get(g));function u(g,v,C,P,A,N,E,w=!1,H=0){const U=new Ie(l,h(E));if(U.position.set(g,v,C),U.rotation.y=H,U.scale.set(P,A,N),t.add(U),w){const W=Math.cos(H),L=Math.sin(H),I=(Math.abs(W)*P+Math.abs(L)*N)/2,k=(Math.abs(L)*P+Math.abs(W)*N)/2;i.push({minX:g-I,maxX:g+I,minY:v-A/2,maxY:v+A/2,minZ:C-k,maxZ:C+k,obb:{cx:g,cz:C,c:W,s:L,halfW:P/2,halfD:N/2}})}return U}function m(g,v,C,P=0,A=0){const N={x:v-.5,y:A,z:C-.5,type:g,rotation:P},E=ys(N);E.updateMatrixWorld(!0),E.traverse(w=>{if(w.isMesh){const H=new Ie(w.geometry.clone().applyMatrix4(w.matrixWorld),w.material);t.add(H)}}),i.push(...pt(N)),["chair","armchair","sofa","bench","stool"].includes(g)&&c.push({x:v,y:A,z:C,rotation:P})}function M(g,v,C,P){if(typeof document>"u")return;const A=document.createElement("canvas");A.width=512,A.height=96;const N=A.getContext("2d");N.fillStyle="#fff2d4",N.fillRect(0,0,512,96),N.fillStyle="#315f54",N.textAlign="center",N.font="bold 36px sans-serif",N.fillText(g,256,62);const E=new i0(new Ml({map:new ss(A),depthTest:!0}));E.position.set(v,C,P),E.scale.set(5.5,1,1),t.add(E),o.push(E)}const _=[{x:0,z:-56,w:126,d:6},{x:0,z:56,w:126,d:6},{x:-60,z:0,w:6,d:118},{x:60,z:0,w:6,d:118},{x:8,z:0,w:6,d:118}];for(const g of _)u(g.x,.014,g.z,g.w,.028,g.d,8689812);for(const g of Fc){a.push(g);const v=Math.cos(g.angle),C=Math.sin(g.angle),P=(L,I)=>({x:g.x+L*v+I*C,z:g.z-L*C+I*v}),A=(L,I,k,X,$,ie,ne,ue=!1)=>{const de=P(L,k);return u(de.x,I,de.z,X,$,ie,ne,ue,g.angle)},N=g.d/2,E=g.w/2-2;A(0,.025,0,g.w,.05,g.d,14667178);for(const L of[-g.w/2,g.w/2])A(L,1.6,0,.22,3.2,g.d,g.wall,!0);A(0,1.6,-N,g.w,3.2,.22,g.wall,!0);for(const[L,I]of[[-g.w/2,-2.1],[-.7,E-.9],[E+.9,g.w/2]])I>L&&A((L+I)/2,1.6,N,I-L,3.2,.22,g.wall,!0);A(-1.4,2.76,N,1.4,.88,.22,g.wall,!0),A(E,.45,N,1.8,.9,.22,g.wall,!0),A(E,2.75,N,1.8,.9,.22,g.wall,!0),A(E,1.6,N,1.8,1.4,.08,10471628,!0);for(const L of[E-.9,E,E+.9])A(L,1.6,N+.07,.06,1.5,.16,16772555);A(0,3.25,0,g.w+.6,.18,g.d+.6,g.roof,!0),(g.kind==="home"||g.kind==="stable")&&(A(0,3.6,0,g.w+.2,.5,g.d-.2,g.roof,!0),A(0,4,0,g.w-.8,.3,g.d-2,g.roof,!0)),qa({scene:t,material:h,doors:r,h:g,local:P}),g.garage&&Ss({scene:t,material:h,doors:r,h:g,put:A,local:P}),s.push({id:g.id,x:g.x,y:0,z:g.z});const w=(L,I,k,X=0)=>{const $=P(I,k);m(L,$.x,$.z,g.angle*180/Math.PI+X)};if(g.kind==="home"&&(w("double-bed",-3,-2),w("wardrobe",3,-3),w("sofa",2,1),w("coffee-table",2,-.3),w("floor-lamp",4,1),w("kitchen-counter",-4,1),w("sink",-3,1)),g.kind==="school"){for(const L of[-5,-2,2,5])w("desk",L,-1.5),w("chair",L,.2);w("bookcase",4,-4),w("toy-box",-5,-4)}if(g.kind==="clinic"&&(w("single-bed",-3,-1),w("washbasin",4,-3),w("desk",3,.5),w("chair",3,2),w("wall-cupboard",4,3.5)),g.kind==="bakery"){for(const L of[-4,-3,-2])w("kitchen-counter",L,-3);w("oven",1,-3),w("fridge",3,-3),w("dining-table",3,1),w("chair",3,2.5)}if(g.kind==="garden"){for(const L of[-4,0,4])w("planter",L,-3);w("workbench",3,0),w("garage-shelf",-4,0)}if(g.kind==="stable"){for(const L of[-5,4])w("rail-fence",L,-2),w("storage-crate",L,1);w("workbench",5,3)}const H=P(-1.4,N),U=P(-1.4,N+3);u((H.x+U.x)/2,.008,(H.z+U.z)/2,2.2,.012,3,15127469,!1,g.angle);const W=P(0,N+.2);M(g.name,W.x,2.8,W.z)}const p=[{x:-51,z:8,w:12,d:12},{x:51,z:37,w:12,d:14},{x:-5,z:-47,w:10,d:10},{x:22,z:47,w:12,d:10}];for(const g of p)u(g.x,.005,g.z,g.w,.008,g.d,11914902),M("BUILD HERE",g.x,1.2,g.z+g.d/2);m("play-slide",-1,22),m("sandpit",-6,25),m("goal",1,31),m("bench",0,17),m("bench",18,18),m("flower-bed",-12,6),m("flower-bed",31,9),m("pergola",17,44),m("dining-table",17,44),m("chair",17,46),m("street-lamp",13,0),m("street-lamp",-10,8);for(const g of[-55,-43,-4,8,40,55])for(const v of[-64,64])m("oak-tree",g,v);for(const g of[-68,68])for(const v of[-40,-12,16,40])m("pine-tree",g,v);for(const g of[-12,-8,-4])for(const v of[28,31])m("fruit-tree",g,v);const f=Za(r),x=Ya(t,new Set([...r.map(g=>g.pivot),...o]));return{...e,houses:[...e.houses,...a],rooms:[...e.rooms,...s],doors:[...e.doors,...r],solids:[...e.solids,...i],plots:p,seats:c,mapRoads:[...[-36,4,36].map(g=>({x:0,z:g,w:84,d:6})),...[-40,8,40].map(g=>({x:g,z:0,w:6,d:78})),..._],activityRange:70,landmarks:[...e.landmarks,...Fc.map(g=>{const v=Math.cos(g.angle),C=Math.sin(g.angle);return{name:g.name,icon:g.icon,x:g.x-1.4*v+(g.d/2+3)*C,z:g.z+1.4*C+(g.d/2+3)*v}}),{name:"Play park",icon:"🛝",x:0,z:20},{name:"Orchard plots",icon:"🧱",x:-51,z:8}],staticRender:{updateVisibility(g,v){e.staticRender.updateVisibility(g,v),x.updateVisibility(g,v)}},extraDoorRender:f}}function L0({box:n,bench:e,scene:t,material:i,reserved:r}){const l=(h,u)=>{n(h,.76,u,2.5,.15,1.2,9725511,!0);for(const m of[-.95,.95]){n(h,.43,u+m,2.5,.13,.45,9725511,!0);for(const M of[-.85,.85])n(h+M,.22,u+m,.12,.44,.35,5992562,!0)}for(const m of[-.8,.8])n(h+m,.36,u,.16,.72,.9,5992562,!0)},d=(h,u)=>{for(const m of[-3.3,3.3])for(const M of[-2.5,2.5])n(h+m,1.5,u+M,.18,3,.18,9725511,!0);n(h,3.08,u,7.3,.18,5.8,4488320,!0),l(h,u)};n(66,.006,46,29,.012,29,10993279),n(67,.012,43,22,.018,17,14995099);for(const h of[58,64])n(h,1.8,38,.2,3.6,.2,9725511,!0);n(61,3.55,38,6.5,.2,.22,4488320,!0);for(const h of[60,62]){for(const u of[-.3,.3])n(h+u,2.18,38,.035,2.4,.035,5992562);n(h,1,38,.85,.15,.5,11365457,!0)}for(const h of[-1,1])for(const u of[-1,1])n(73+h,1.15,39+u,.15,2.3,.15,9725511,!0);n(73,1.25,39,2.2,.15,2.2,4488320,!0);for(const h of[72,74])n(h,2,38,.12,1.4,.12,9725511,!0);n(73,2.68,39,2.6,.15,2.6,4488320,!0);for(let h=.22;h<1.3;h+=.22)n(73,h,40.1,1.5,.09,.18,16774617);if(!r({minX:74,maxX:79,minZ:38,maxZ:40,minY:0,maxY:2})){const h=new at;h.setAttribute("position",new Ye([74,1.32,38.4,74,1.32,39.6,77.8,.12,39.6,74,1.32,38.4,77.8,.12,39.6,77.8,.12,38.4],3)),h.computeVertexNormals();const u=i(15118451).clone();u.side=xt,t.add(new Ie(h,u))}n(60,.06,48,5,.12,4.2,9725511),n(60,.13,48,4.6,.14,3.8,14995099),n(69,.22,49,.6,.44,1.2,4488320,!0),n(69,.5,49,4.4,.14,.5,11365457,!0);for(const h of[67.2,70.8])n(h,.7,49,.1,.5,.1,16774617),n(h,.79,49,.4,.08,.08,16774617);e(56,44,-Math.PI/2),e(61,55,0),d(82,66);for(const h of[51,81])for(const u of[40,49])n(h,.45,u,.12,.9,.12,9725511,!0),n(h,.65,u,.12,.1,5,9725511,!0);d(195,82),l(204,91),e(204,64,0),e(178,77,-Math.PI/2),e(179,91,-Math.PI/2);for(const h of[190,202]){n(h,.18,64,3.5,.36,1.4,5933922,!0);for(const u of[-1,0,1])n(h+u,.42,64,.4,.2,.4,14728124)}l(-67,-111),n(-74,.5,-113,1.4,1,.14,9725511,!0),n(-74,1.2,-113,2.2,.6,.12,4488320)}const Bl=[{id:"orchid",name:"Orchid family house",x:-55,z:-14,w:11,d:9,angle:0,wall:14728124,roof:7042704,style:"hip",garage:!0,garden:1},{id:"cedar",name:"Cedar lodge",x:-78,z:-16,w:7,d:11,angle:0,wall:14268559,roof:4488320,style:"gable",porch:3.6,garden:2},{id:"sunflower",name:"Sunflower courtyard",x:-59,z:24,w:12,d:7,angle:Math.PI,wall:15851437,roof:11365457,style:"shed",garage:!0,garden:3},{id:"bluebell",name:"Bluebell cottage",x:-84,z:-44,w:6,d:7,angle:-Math.PI/2,wall:11914194,roof:7108992,style:"gable",garden:2},{id:"maple",name:"Maple garden house",x:-54,z:-61,w:10,d:10,angle:Math.PI,wall:15185051,roof:7042704,style:"hip",garage:!0,garden:1},{id:"fern",name:"Fern studio",x:-23,z:-62,w:6,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"shed",porch:3.2,garden:3},{id:"bakery",name:"Sunrise bakery",x:44,z:-42,w:10,d:8,angle:0,wall:15851437,roof:11365457,style:"gable",shop:!0,sign:"BAKERY",garden:0},{id:"market",name:"Village market",x:60,z:-43,w:10,d:10,angle:0,wall:12177332,roof:4488320,style:"hip",shop:!0,sign:"MARKET",garden:0},{id:"pottery",name:"Clay corner",x:32,z:-25,w:8,d:9,angle:Math.PI/2,wall:14728124,roof:7042704,style:"shed",shop:!0,sign:"POTTERY",garden:0},{id:"workshop",name:"Oak workshop",x:92,z:-17,w:11,d:10,angle:-Math.PI/2,wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,garden:0},{id:"willow",name:"Willow retreat",x:-10,z:-94,w:7,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"hip",porch:3.4,garden:2},{id:"pavilion",name:"Orchard shelter",x:103,z:90,w:8,d:6,angle:-Math.PI/2,wall:15851437,roof:11365457,style:"gable",porch:4,garden:2},...h0],D0=[[[-124,6],[-103,6],[-85,6],[-66,3],[-49,3],[-35,6],[-20,6],[-6,6],[6,8.6],[17,9],[26,4],[35,3],[50,2],[65,-8],[72,-28],[70,-55],[52,-68],[25,-66],[-10,-77],[-45,-78],[-80,-69],[-98,-48],[-99,-18],[-85,6]],[[72,-28],[92,-52],[115,-53]],...u0],U0=[[[-35,6],[-36,40],[-45,61],[-41,80],[-15,87],[15,86],[45,86],[66,67],[50,60],[50,33],[53,25],[50,2]],[[45,86],[66,98],[81,94],[94,91],[95,77],[108,62],[104,42],[82,30],[84,41],[84,54],[73,62],[66,67]],[[-80,-69],[-86,-90],[-65,-103],[-45,-108],[-21,-112],[-3,-105],[18,-117],[44,-109],[47,-90],[25,-66]],[[-10,-77],[-18,-89],[-14,-102],[-3,-105]],[[41,-33],[41,-18],[49,-12],[65,-8]],[[18,-117],[18,-104],[37,-103],[47,-90]],...d0];function Ht(n,e,t){let i=1/0,r=null;for(let s=1;s<t.length;s++){const a=t[s-1],o=t[s],c=o[0]-a[0],l=o[1]-a[1],d=Math.max(0,Math.min(1,((n-a[0])*c+(e-a[1])*l)/(c*c+l*l))),h={x:a[0]+c*d,z:a[1]+l*d},u=Math.hypot(n-h.x,e-h.z);u<i&&(i=u,r=h)}return{distance:i,point:r}}function er(n){let e=n;for(let t=0;t<2;t++){const i=[e[0]];for(let r=1;r<e.length;r++){const s=e[r-1],a=e[r];i.push([s[0]*.75+a[0]*.25,s[1]*.75+a[1]*.25],[s[0]*.25+a[0]*.75,s[1]*.25+a[1]*.75])}i.push(e.at(-1)),e=i}return e}function I0({scene:n,box:e,material:t,bench:i,disk:r,roads:s,trails:a,drives:o,houses:c,clearings:l,treeAllowed:d,treePositions:h}){e(-8,.006,-197,70,.012,18,14141609);for(const x of[-32,-8,16])e(x,.25,-205.5,3,.5,3,11906454,!0),e(x,.54,-205.5,2.6,.08,2.6,7052647),i(x===-8?-16:x,-190,0);for(const x of[-5,5])for(const g of[-204,-199])e(x,1.5,g,.18,3,.18,9725511,!0);for(const x of[-204,-199])e(0,2.98,x,10.4,.18,.22,9725511,!0);for(let x=-5;x<=5;x+=1)e(x,3.08,-201.5,.15,.16,6,9725511);e(188,.006,-103,14,.012,21,14141609);for(const x of[-116,-104,-92])i(187,x,Math.PI/2);for(const x of[199,203,207,211])for(const g of[-27,-34]){e(x,.2,g,2.5,.4,4,9725511,!0),e(x,.43,g,2.2,.06,3.7,7052647);for(let v=0;v<4;v++)e(x,.65,g-1.2+v*.8,.4,.38,.4,v%2?15118451:14728124)}for(const x of Yr){r(x.x,x.z,x.rx+1.6,x.rz+1.6,14141609,.008),r(x.x,x.z,x.rx,x.rz,7515836,.026);for(let g=0;g<30;g++){const v=g*Math.PI*2/30,C=x.x+Math.cos(v)*(x.rx+.7),P=x.z+Math.sin(v)*(x.rz+.7);Math.abs(C-x.x)<2||(e(C,.4,P,.055,.8,.055,5474391),e(C,.85,P,.11,.18,.11,9725511))}}e(-18,.006,200,20,.012,9,14141609);for(const x of[-76,-70,-64])for(let g=216;g<=234;g+=2)e(x,.12,g,3,.24,1.6,9725511),e(x,.38,g,2.6,.3,1.3,g%4?7052647:15118451);const m=[];for(let x=0;x<20;x++){const g=x*.56;m.push({x:-110+Math.cos(g)*(9+Math.floor(x/7)*4),z:232+Math.sin(g)*(7+Math.floor(x/7)*2),fruit:!0})}const M=[[-210,-190,26,29],[-71,-225,26,10],[181,-185,44,24],[-214,111,19,34],[66,232,43,10],[220,164,17,32],[-220,214,14,22]];let _=19052;const p=()=>(_=Math.imul(_,1664525)+1013904223>>>0,_/4294967296),f=(x,g)=>!!(Math.abs(x)<128&&Math.abs(g)<128||c.some(v=>{const C=Math.abs(Math.cos(v.angle)),P=Math.abs(Math.sin(v.angle));return Math.abs(x-v.x)<(v.w*C+v.d*P)/2+10&&Math.abs(g-v.z)<(v.w*P+v.d*C)/2+10})||[...s,...a].some(v=>Ht(x,g,v).distance<5.3)||o.some(v=>Ht(x,g,v.points).distance<4)||l.some(v=>Math.abs(x-v.x)<v.w/2+4&&Math.abs(g-v.z)<v.d/2+4)||Yr.some(v=>((x-v.x)/(v.rx+5))**2+((g-v.z)/(v.rz+5))**2<1)||Rl.some(v=>Math.hypot(x-(v.signX??v.x+4),g-(v.signZ??v.z+4))<5)||Math.abs(x-197)<18&&Math.abs(g-84)<15||Math.abs(x+8)<39&&Math.abs(g+197)<14||x>-85&&x<-55&&g>208);for(let x=0;x<2100;x++){const g=M[x%M.length],v=p()*Math.PI*2,C=Math.sqrt(p()),P=g[0]+Math.cos(v)*g[2]*C,A=g[1]+Math.sin(v)*g[3]*C;f(P,A)||m.some(N=>Math.hypot(P-N.x,A-N.z)<4.1)||m.push({x:P,z:A})}for(const[x,g]of[[-223,-73],[-143,12],[-205,76],[-143,82],[91,-202],[120,-169],[199,-8],[178,123],[113,222],[-50,235],[-231,159]])for(const[v,C]of[[0,0],[5,4],[-4,6]])f(x+v,g+C)||m.push({x:x+v,z:g+C});for(const[x,g]of m.entries()){if(!d(g.x,g.z))continue;h.push({x:g.x,z:g.z});const v=g.fruit?2.2:2.8+x%4*.4;e(g.x,v/2,g.z,.4,v,.4,9725511,!0);const C=!g.fruit&&x%3===0,P=C?new sr(2.2,4.8,7):new ar(1,1);C||P.scale(2.2,2.05,2.2);const A=new Ie(P,t(C?5082472:x%2?7052647:5933922));if(A.position.set(g.x,v+.7,g.z),n.add(A),g.fruit)for(const N of[-1,1])e(g.x+N,v+.5,g.z+.4,.22,.22,.22,13075044)}return{trees:m.length,groves:M.length,ponds:Yr.length}}function kl(n,e){if(n.kind==="roller"){const h=Math.cos(n.baseAngle),u=Math.sin(n.baseAngle),m=n.width/2,M=.055,_=n.center.x,p=n.center.z,f=Math.abs(h)*m+Math.abs(u)*M,x=Math.abs(u)*m+Math.abs(h)*M,g=Math.min(1,Math.max(0,e/(Math.PI/2)));return{minX:_-f,maxX:_+f,minZ:p-x,maxZ:p+x,minY:n.height*g,maxY:n.height,obb:{cx:_,cz:p,c:h,s:u,halfW:m,halfD:M},door:!0}}const t=n.baseAngle+e,i=Math.cos(t),r=Math.sin(t),s=n.width/2,a=.055,o=n.hinge.x+i*s,c=n.hinge.z-r*s,l=Math.abs(i)*s+Math.abs(r)*a,d=Math.abs(r)*s+Math.abs(i)*a;return{minX:o-l,maxX:o+l,minZ:c-d,maxZ:c+d,minY:0,maxY:n.height??2.3,obb:{cx:o,cz:c,c:i,s:r,halfW:s,halfD:a},door:!0}}function tr(n,e,t=n.swing??-1){const i=n.angle??(n.open?t*Math.PI/2:0);return kl(n,i)}const Oc=[{id:"home",name:"Your home",x:-13,z:-9,w:8,d:7,angle:0,wall:15851437,roof:4488320,style:"gable"},{id:"peach",name:"Peach cottage",x:6,z:-10,w:7,d:8,angle:0,wall:15185051,roof:7042704,style:"hip"},{id:"sage",name:"Sage bungalow",x:-17,z:20,w:9,d:6,angle:Math.PI,wall:12177332,roof:11365457,style:"gable"},{id:"rose",name:"Rose cabin",x:17,z:20,w:6,d:8,angle:Math.PI,wall:14728124,roof:7108992,style:"shed"},...Bl,...In];function Nt(n,e,t){const i=Math.cos(n.angle),r=Math.sin(n.angle);return{x:n.x+e*i+t*r,z:n.z-e*r+t*i}}function N0(n,e=[]){const t=new zi(8);for(const S of e)t.add(Zn(S));const i=S=>t.query(S).some(y=>Fi(y,S)),r=[],s=Oc.filter(S=>{if(!S.designed)return!0;const y=Math.max(S.w,S.d)/2+(S.garage?6:2),G=i({minX:S.x-y,maxX:S.x+y,minZ:S.z-y,maxZ:S.z+y,minY:0,maxY:10});return G&&r.push(S.id),!G}),a=[],o=[];let c=!1;const l=[],d=[],h=new Map,u=new vt(1,1,1),m=new Map,M=S=>(m.has(S)||m.set(S,new Vt({color:S})),m.get(S)),_=new ut;function p(S,y,G,F,ae,oe,ee,me=!1,T=0){const b=(Math.abs(Math.cos(T))*F+Math.abs(Math.sin(T))*oe)/2+.1,O=(Math.abs(Math.sin(T))*F+Math.abs(Math.cos(T))*oe)/2+.1;if(!(c&&ae>.03&&i({minX:S-b,maxX:S+b,minZ:G-O,maxZ:G+O,minY:y-ae/2,maxY:y+ae/2}))&&(h.has(ee)||h.set(ee,[]),h.get(ee).push({x:S,y,z:G,w:F,h:ae,d:oe,angle:T}),me)){const Q=Math.abs(Math.cos(T)),Z=Math.abs(Math.sin(T)),te=(F*Q+oe*Z)/2,ve=(F*Z+oe*Q)/2;l.push({...Math.abs(Math.sin(T*2))>1e-6?{obb:{cx:S,cz:G,c:Math.cos(T),s:Math.sin(T),halfW:F/2,halfD:oe/2}}:{},minX:S-te,maxX:S+te,minY:y-ae/2,maxY:y+ae/2,minZ:G-ve,maxZ:G+ve})}}const f=[];function x(S,y,G,F,ae=0,oe=4){if(typeof document>"u")return;const ee=document.createElement("canvas");ee.width=512,ee.height=96;const me=ee.getContext("2d");me.fillStyle="#fff5d9",me.fillRect(0,0,512,96),me.fillStyle="#496c61",me.font="bold 48px sans-serif",me.textAlign="center",me.textBaseline="middle",me.fillText(S,256,50,480);const T=new ss(ee);T.colorSpace=mt;const b=new Ie(new Un(oe,oe*96/512),new Ri({map:T,side:xt}));b.position.set(y,G,F),b.rotation.y=ae,n.add(b),f.push(b)}const g=9418861,v=9725511,C=16774617,P=8501706;p(0,-.18,0,nt.halfSize*2+2,.36,nt.halfSize*2+2,g,!0);const A=D0.map(er),N=U0.map(er);for(const S of ba.filter((y,G)=>G!==2)){const y=er(S);for(const G of[0,y.length-1]){const F=y[G],ae=Ht(F[0],F[1],A[2]).point;G===0?y.unshift([ae.x,ae.z]):y.push([ae.x,ae.z])}A.push(y)}N.push(...c0.map(er),er(ba[2]));const E=A[0];function w(S,y,G,F){const ae=[],oe=[];S.forEach((T,b)=>{const O=S[Math.max(0,b-1)],Q=S[Math.min(S.length-1,b+1)],Z=Q[0]-O[0],te=Q[1]-O[1],ve=Math.hypot(Z,te),_e=-te/ve*y/2,Me=Z/ve*y/2;if(ae.push(T[0]+_e,F,T[1]+Me,T[0]-_e,F,T[1]-Me),b){let we=b*2;oe.push(we-2,we,we-1,we-1,we,we+1)}});const ee=new at;ee.setAttribute("position",new Ye(ae,3)),ee.setIndex(oe),ee.computeVertexNormals();const me=new Ie(ee,M(G));return n.add(me),me}for(const S of A)w(S,7.4,14601641,.014),w(S,5,6845816,.024);for(const S of N)w(S,2.4,14008212,.019);const H=[];for(const S of A)for(const y of[0,S.length-1]){const G=S[y],F=y===0?S.slice(5):S.slice(0,-5);F.length>1&&Ht(G[0],G[1],F).distance<2.5&&H.push({x:G[0],z:G[1]})}for(const S of A){let y=0,G=1;for(let F=1;F<S.length;F++){const ae=S[F-1],oe=S[F],ee=oe[0]-ae[0],me=oe[1]-ae[1],T=Math.hypot(ee,me);for(;G<y+T;){const b=(G-y)/T,O=ae[0]+ee*b,Q=ae[1]+me*b;!H.some(Z=>Math.hypot(O-Z.x,Q-Z.z)<5.5)&&!A.some(Z=>Z!==S&&Ht(O,Q,Z).distance<5.5)&&p(ae[0]+ee*b,.031,ae[1]+me*b,.1,.012,1.1,15984318,!1,Math.atan2(ee,me)),G+=3.5}y+=T}}const U=s.map(S=>{const y=Nt(S,-1.4,S.d/2),G=Nt(S,-1.4,S.d/2+2.5),ae=(S.street?[A[{north:4,south:5,elm:6}[S.street]]]:S.route==="trail"?N:S.shop?[...A,N[4]]:S.id==="willow"||S.id==="pavilion"?N:A).map(me=>({...Ht(G.x,G.z,me),isRoad:A.includes(me)})).sort((me,T)=>me.distance-T.distance)[0];let oe=S.approach||{bakery:{x:44,z:-34},market:{x:60,z:-34},pottery:{x:39,z:-25}}[S.id]||ae.point;if(ae.isRoad&&!["bakery","market","pottery"].includes(S.id)){const me=G.x-oe.x,T=G.z-oe.z,b=Math.hypot(me,T);b>3.3&&(oe={x:oe.x+me/b*3.3,z:oe.z+T/b*3.3})}const ee=[[y.x,y.z],[G.x,G.z],[oe.x,oe.z]];if(w(ee,S.shop?2.8:2.4,12959399,.032),S.garage||S.carport){const me=Nt(S,-S.w/2-2.1,S.d/2+.15);let T=A.map(Z=>Ht(me.x,me.z,Z)).sort((Z,te)=>Z.distance-te.distance)[0].point;const b=me.x-T.x,O=me.z-T.z,Q=Math.hypot(b,O);Q>3.3&&(T={x:T.x+b/Q*3.3,z:T.z+O/Q*3.3}),w([[me.x,me.z],[T.x,T.z]],3.6,12959399,.033)}return{entry:y,end:oe,points:ee,w:S.shop?2.8:2.4}});for(const S of s){let me=function(re){const ce=S.w>9?2.4:1.8,fe=S.shop?2.6:S.w>9?2.2:1.5,j=1.05,D=1.2,he=re>0?[[-y/2,ae-oe/2],[ae+oe/2,ce-fe/2],[ce+fe/2,y/2]]:[[-y/2,ce-fe/2],[ce+fe/2,y/2]];for(const[pe,Te]of he)Te>pe&&ee((pe+Te)/2,1.5,re,Te-pe,3,.22,S.wall,!0);re>0&&ee(ae,2.675,re,oe,.65,.22,S.wall,!0),ee(ce,j/2,re,fe,j,.22,S.wall,!0),ee(ce,(j+D+3)/2,re,fe,3-j-D,.22,S.wall,!0),ee(ce,j+D/2,re,fe,D,.1,P,!0);for(const pe of[ce-fe/2,ce,ce+fe/2])ee(pe,j+D/2,re+.01,.065,D+.12,.29,C);for(const pe of[j,j+D/2,j+D])ee(ce,pe,re+.01,fe+.12,.065,.29,C);ee(ce,j-.06,re,fe+.27,.12,.42,C)};var De=me;const{w:y,d:G}=S,F=G/2,ae=-1.4,oe=1.4,ee=(re,ce,fe,j,D,he,pe,Te=!1)=>{const Pe=Nt(S,re,fe);p(Pe.x,ce,Pe.z,j,D,he,pe,Te,S.angle)};if(c=!!S.designed,S.designed){C0({h:S,put:ee,local:(re,ce)=>Nt(S,re,ce),scene:n,material:M,doors:d,solids:l,label:x,rooms:a}),c=!1;continue}if(ee(0,.006,0,y,.012,G,14006419),me(F),me(-F),S.wing){const re=-F+2.75;for(const[ce,fe]of[[-F,re-.9],[re+.9,F]])fe>ce&&ee(-y/2,1.5,(ce+fe)/2,.22,3,fe-ce,S.wall,!0);ee(-y/2,2.72,re,.22,.56,1.8,S.wall,!0),a.push({house:S.id,name:"Side room",...Nt(S,-y/2-2.25,re),y:0})}else ee(-y/2,1.5,0,.22,3,G,S.wall,!0);if((S.d>8||S.bay)&&Bl.some(re=>re.id===S.id)){const re=S.d>10?[-2.6,2.6]:[0],ce=.8;let fe=-F;for(const j of re){const D=j-ce;ee(y/2,1.5,(fe+D)/2,.22,3,D-fe,S.wall,!0),ee(y/2,.525,j,.22,1.05,1.6,S.wall,!0),ee(y/2,2.625,j,.22,.75,1.6,S.wall,!0),S.bay||ee(y/2,1.65,j,.1,1.2,1.6,P,!0);for(const he of[j-ce,j,j+ce])ee(y/2+.01,1.65,he,.29,1.32,.065,C);for(const he of[1.05,1.65,2.25])ee(y/2+.01,he,j,.29,.065,1.72,C);fe=j+ce}ee(y/2,1.5,(fe+F)/2,.22,3,F-fe,S.wall,!0)}else ee(y/2,1.5,0,.22,3,G,S.wall,!0);const T=[],b=[],O=(re,ce,fe,j)=>{const D=T.length/3;T.push(...re,...ce,...fe,...j),b.push(D,D+1,D+2,D,D+2,D+3)},Q=y/2+.4,Z=F+.4,te=3.06,ve=4.7;if(S.style==="gable"){O([-Q,te,Z],[0,ve,Z],[0,ve,-Z],[-Q,te,-Z]),O([0,ve,Z],[Q,te,Z],[Q,te,-Z],[0,ve,-Z]);for(const re of[-F,F]){const ce=te+(ve-te)*.4/Q,fe=new at;fe.setAttribute("position",new Ye([-y/2,3,re,y/2,3,re,y/2,ce,re,0,ve,re,-y/2,ce,re],3)),fe.setIndex([0,1,2,0,2,3,0,3,4]),fe.computeVertexNormals();const j=M(S.wall).clone();j.side=xt;const D=new Ie(fe,j);D.position.set(S.x,0,S.z),D.rotation.y=S.angle,n.add(D)}}else if(S.style==="gambrel"){const re=[-Q,-Q*.56,0,Q*.56,Q],ce=[te,4.45,5.4,4.45,te];for(let j=1;j<re.length;j++)O([re[j-1],ce[j-1],Z],[re[j],ce[j],Z],[re[j],ce[j],-Z],[re[j-1],ce[j-1],-Z]);const fe=te+(4.45-te)*.4/(Q*.44);for(const j of[-F,F]){const D=[[-y/2,3,j],[y/2,3,j],[y/2,fe,j],[Q*.56,4.45,j],[0,5.4,j],[-Q*.56,4.45,j],[-y/2,fe,j]],he=new at;he.setAttribute("position",new Ye(D.flat(),3)),he.setIndex([0,1,2,0,2,3,0,3,4,0,4,5,0,5,6]),he.computeVertexNormals();const pe=M(S.wall).clone();pe.side=xt;const Te=new Ie(he,pe);Te.position.set(S.x,0,S.z),Te.rotation.y=S.angle,n.add(Te)}}else if(S.style==="hip")O([-Q,te,Z],[Q,te,Z],[0,ve,1.5],[0,ve,1.5]),O([Q,te,Z],[Q,te,-Z],[0,ve,-1.5],[0,ve,1.5]),O([Q,te,-Z],[-Q,te,-Z],[0,ve,-1.5],[0,ve,-1.5]),O([-Q,te,-Z],[-Q,te,Z],[0,ve,1.5],[0,ve,-1.5]);else{O([-Q,te,Z],[Q,te,Z],[Q,4.1,-Z],[-Q,4.1,-Z]);const re=te+(4.1-te)*.4/(G+.8),ce=4.1-(4.1-te)*.4/(G+.8);ee(0,(3+ce)/2,-F,y,ce-3,.22,S.wall),ee(0,(3+re)/2,F,y,re-3,.22,S.wall);for(const fe of[-y/2,y/2]){const j=new at;j.setAttribute("position",new Ye([fe,3,-F,fe,ce,-F,fe,re,F,fe,3,F],3)),j.setIndex([0,1,2,0,2,3]),j.computeVertexNormals();const D=M(S.wall).clone();D.side=xt;const he=new Ie(j,D);he.position.set(S.x,0,S.z),he.rotation.y=S.angle,n.add(he)}}const _e=new at;_e.setAttribute("position",new Ye(T,3)),_e.setIndex(b),_e.computeVertexNormals();const Me=M(S.roof).clone();Me.side=xt;const we=new Ie(_e,Me);we.position.set(S.x,0,S.z),we.rotation.y=S.angle,n.add(we),ee(0,3.015,0,S.style==="shed"?y:y+.8,.09,S.style==="shed"?G:G+.8,C,!0);for(const re of[-y/2,y/2])ee(re,1.5,F+.08,.13,3,.14,C);ee(ae,2.62,F+.7,S.porch||2.2,.15,1.5,S.roof,!0);for(const re of[ae-(S.porch||2.2)/2+.14,ae+(S.porch||2.2)/2-.14])ee(re,1.27,F+1.28,.12,2.54,.12,C,!0);const Ue=new gt,le=Nt(S,ae-oe/2+.07,F+.03),Ke=oe-.14;Ue.position.set(le.x,0,le.z),Ue.rotation.y=S.angle;const Ve=new Ie(new vt(Ke,2.3,.1),M(9726028));Ve.position.set(Ke/2,1.15,0),Ue.add(Ve);const Ne=new Ie(new vt(.78,.7,.11),M(11980733));Ne.position.set(Ke/2,1.66,0),Ue.add(Ne);const Ce=new Ie(new ms(.055,6,5),M(16768118));Ce.position.set(Ke-.18,1,.09),Ue.add(Ce),n.add(Ue);const Se=Nt(S,ae,F);if(d.push({id:S.id,pivot:Ue,baseAngle:S.angle,open:!1,center:Se,hinge:le,width:Ke,height:2.3}),S.shop){ee(y/2-1,.45,-F+1,1.4,.9,1.3,v,!0),ee(y/2-1,.95,-F+1,1.6,.12,1.5,C);for(let ce=0;ce<3;ce++)ee(-y/2+1.2+ce*1.6,.6,-F+.7,1.2,1.2,.65,v,!0),ee(-y/2+1.2+ce*1.6,1.28,-F+.7,.8,.16,.4,[15118451,12177332,14728124][ce]);ee(1,2.6,F+.19,y-1,.25,.6,S.roof);for(let ce=0;ce<8;ce++)ee(-y/2+.5+ce*(y-1)/8,2.7,F+.8,(y-1)/8,.12,1.4,ce%2?C:S.roof);ee(0,3.28,F+.2,4.05,.82,.12,v);for(const ce of[-1.65,1.65])ee(ce,2.96,F+.18,.1,.7,.12,v);const re=Nt(S,0,F+.28);x(S.sign,re.x,3.28,re.z,S.angle,3.8)}else ee(-y/2+1.15,.29,-F+1.6,1.7,.58,2.4,v,!0),ee(-y/2+1.15,.65,-F+1.45,1.65,.16,2.1,S.id==="home"?7183771:13214055),ee(-y/2+1.15,.78,-F+.65,1.4,.17,.48,C),ee(y/2-.9,.45,-F+.9,1.1,.9,.7,v,!0);if(S.garage&&Ss({scene:n,material:M,doors:d,h:S,put:ee,local:(re,ce)=>Nt(S,re,ce)}),S.carport){const re=-y/2-2.1,ce=F-2.7;ee(re,2.55,ce,4.6,.18,5.8,S.roof,!0);for(const fe of[-1.9,1.9])for(const j of[-2.35,2.35])ee(re+fe,1.22,ce+j,.16,2.44,.16,v,!0);ee(re,.008,ce,4.2,.016,5.4,12959399)}if(S.wing){const re=-y/2-2.25,ce=-F+2.75;ee(re,.007,ce,4.5,.014,5.5,14006419),ee(re-2.25,1.65,ce,.22,3.3,5.5,S.wall,!0);for(const fe of[ce-2.75,ce+2.75])ee(re,1.65,fe,4.5,3.3,.22,S.wall,!0);ee(re,3.4,ce,4.9,.2,5.9,S.roof,!0),ee(re,1.7,ce+2.78,2.6,1.25,.08,P);for(const fe of[re-1.33,re,re+1.33])ee(fe,1.7,ce+2.84,.065,1.38,.1,C);for(const fe of[1.05,2.35])ee(re,fe,ce+2.84,2.73,.065,.1,C)}if(S.bay){c=!0,ee(y/2+.32,.525,0,.64,1.05,1.9,S.wall,!0),ee(y/2+.64,1.65,0,.08,1.2,1.8,P,!0);for(const re of[-.87,.87])ee(y/2+.32,1.65,re,.64,1.2,.08,P,!0);ee(y/2+.34,3.015,0,.9,.09,2.15,C,!0),ee(y/2+.64,2.625,0,.1,.75,1.8,S.wall,!0);for(const re of[-.87,.87])ee(y/2+.32,2.625,re,.64,.75,.1,S.wall,!0);for(const re of[-.9,0,.9])ee(y/2+.7,1.65,re,.1,1.35,.065,C)}if(c=!1,S.chimney&&ee(y/2-1,4.2,-F*.3,.8,2.4,.8,13075044,!0),S.tower){const re=y/2+1.8,ce=-F+1.8;ee(re,3.4,ce,3.6,6.8,3.6,S.wall,!0);for(const he of[ce-1.83,ce+1.83]){ee(re,5.1,he,1.5,1.5,.08,C),ee(re,5.3,he+(he>ce?.06:-.06),.08,.58,.1,v),ee(re+.22,5.1,he+(he>ce?.06:-.06),.48,.08,.1,v);for(const pe of[re-.58,re+.58])ee(pe,5.1,he,.08,1.65,.12,C)}const fe=Nt(S,re,ce),j=new sr(2.7,1.8,4),D=new Ie(j,M(S.roof));D.position.set(fe.x,7.7,fe.z),D.rotation.y=S.angle+Math.PI/4,n.add(D)}if(S.garden){c=!!S.wing;const re=S.garage||S.wing?y/2+2:-y/2-2;ee(re,.18,0,2.3,.36,G*.75,5933922,!0);for(let ce=0;ce<4;ce++)ee(re,.42,-G*.25+ce*G/6,.4,.2,.4,[15118451,14728124,15851437][S.garden-1]);S.garden===3&&(ee(0,.3,-F-2.2,y*.7,.6,1.2,v,!0),ee(0,.64,-F-2.2,y*.65,.12,1,7052647))}c=!1,ee(.55,.05,F+.5,.8,.09,.6,S.roof);const ze=Nt(S,2.15,F+2.1);p(ze.x,.5,ze.z,.11,1,.11,v,!0),p(ze.x,1.05,ze.z,.55,.34,.4,S.roof)}const W={x:-10.8,z:-8.1};p(W.x,.88,W.z,1.4,.22,1.1,11368266,!0);for(const S of[-.5,.5])for(const y of[-.35,.35])p(W.x+S,.39,W.z+y,.14,.78,.14,v,!0);for(let S=0;S<3;S++)for(let y=0;y<3;y++)p(W.x-.36+S*.36,1.001,W.z-.32+y*.32,.29,.014,.26,(S+y)%2?15718563:7687734);p(-4,.004,-.5,8,.008,6,10993279);for(const S of[-8,0])for(const y of[-3.5,2.5])p(S,.16,y,.2,.32,.2,v);const L=[[-27,-18],[-23,-7],[-28,17],[-6,-22],[18,-17],[26,-7],[28,20],[2,25],[-28,28],[27,-25],[13,29],[-2,19]];function I(S,y){return A.some(G=>Ht(S,y,G).distance<4.8)||N.some(G=>Ht(S,y,G).distance<2.1)||U.some(G=>Ht(S,y,G.points).distance<2.2)||s.some(G=>{const F=Nt({...G,angle:-G.angle,x:0,z:0},S-G.x,y-G.z);return Math.abs(F.x)<G.w/2+(G.garage||G.wing?6:2.8)&&Math.abs(F.z)<G.d/2+3})||[...as].some(G=>Math.abs(S-G.x)<G.w/2+2&&Math.abs(y-G.z)<G.d/2+2)?!1:!i({minX:S-2,maxX:S+2,minZ:y-2,maxZ:y+2,minY:0,maxY:7})}const k=[];for(const[S,[y,G]]of L.entries()){if(!I(y,G))continue;o.push({x:y,z:G});const F=2.5+S%3*.25;p(y,F/2,G,.42,F,.42,8675908,!0),k.push({x:y,y:F+.7,z:G,scale:1.9+S%2*.3,color:S%2?7052647:5082472})}for(const S of new Set(k.map(y=>y.color))){const y=k.filter(ae=>ae.color===S),G=new ar(1,1),F=new rs(G,M(S),y.length);y.forEach((ae,oe)=>{_.position.set(ae.x,ae.y,ae.z),_.scale.set(ae.scale,ae.scale*.85,ae.scale),_.rotation.set(0,oe,.2),_.updateMatrix(),F.setMatrixAt(oe,_.matrix)}),n.add(F)}for(let S=-nt.halfSize+1;S<=nt.halfSize-1;S+=4){for(const y of[-nt.halfSize,nt.halfSize])p(S,.7,y,4,1.4,1.4,5933922);for(const y of[-nt.halfSize,nt.halfSize])p(y,.7,S,1.4,1.4,4,5933922)}p(1,.48,15,2,.15,.65,v,!0),p(1,.94,15.28,2,.8,.12,v,!0);for(const S of[.25,1.75])p(S,.23,15,.12,.46,.5,5992562,!0);for(const[S,y]of[[-8,-14],[-18,-14],[10,-16],[20,15],[-21,17],[0,16]])p(S,.18,y,.07,.36,.07,5474391),p(S,.4,y,.32,.16,.32,15118451);if(p(49,.006,-26,23,.012,23,14141609),p(49,.2,-26,3,.4,3,11906454,!0),p(49,.44,-26,2.6,.08,2.6,7052647),p(49,2,-26,.32,4,.32,v,!0),p(49,4.1,-26,1.4,1.4,.4,15851437),typeof document<"u"){const S=document.createElement("canvas");S.width=S.height=192;const y=S.getContext("2d");y.fillStyle="#fff5d9",y.fillRect(0,0,192,192),y.strokeStyle="#496c61",y.lineWidth=5,y.beginPath(),y.arc(96,96,84,0,Math.PI*2),y.stroke(),y.font="bold 23px sans-serif",y.textAlign="center",y.textBaseline="middle",y.fillStyle="#496c61";for(const[ae,oe,ee]of[["12",96,34],["3",160,98],["6",96,160],["9",34,98]])y.fillText(ae,oe,ee);y.lineCap="round",y.lineWidth=8,y.beginPath(),y.moveTo(96,96),y.lineTo(65,77),y.moveTo(96,96),y.lineTo(132,60),y.stroke();const G=new ss(S);G.colorSpace=mt;const F=new Ie(new Un(1.14,1.14),new Ri({map:G}));F.position.set(49,4.1,-25.79),n.add(F),f.push(F)}function X(S,y,G=0){if(i({minX:S-1.4,maxX:S+1.4,minZ:y-1.4,maxZ:y+1.4,minY:0,maxY:1.5}))return;const F=(ae,oe,ee,me,T,b,O,Q=!0)=>{const Z=Nt({x:S,z:y,angle:G},ae,ee);p(Z.x,oe,Z.z,me,T,b,O,Q,G)};F(0,.48,0,2,.15,.65,v),F(0,.94,.28,2,.8,.12,v);for(const ae of[-.75,.75])F(ae,.23,0,.12,.46,.5,5992562)}for(const S of[40,58])X(S,-26,Math.PI/2);const $=[{x:-70,z:61,w:36,d:30,subtle:!0},{x:8,z:61,w:27,d:27},...f0];for(const S of $){const y=N.map(oe=>Ht(S.x,S.z,oe)).sort((oe,ee)=>oe.distance-ee.distance)[0].point,G=y.x-S.x,F=y.z-S.z,ae=Math.min(Math.abs(G)>1e-6?S.w/2/Math.abs(G):1/0,Math.abs(F)>1e-6?S.d/2/Math.abs(F):1/0);if(ae<1){const oe=[[y.x,y.z],[S.x+G*ae,S.z+F*ae]];N.push(oe),w(oe,2.4,14008212,.019)}p(S.x,.004,S.z,S.w,.008,S.d,S.subtle?9878134:10993279);for(const oe of[-S.w/2,S.w/2])for(const ee of[-S.d/2,S.d/2])p(S.x+oe,.18,S.z+ee,.22,.36,.22,v)}for(const S of as){$.push(S);const y=S.roadZ??S.z,G=S.roadX?S.z-6:S.z+(y-S.z)*.45;p(S.x,.005,S.z,S.w,.01,S.d,9878134),w(S.roadX?[[S.x+S.w/2,S.z],[S.roadX-3.3,S.z]]:[[S.x,S.z+(y>S.z?S.d/2:-S.d/2)],[S.x,y+(y>S.z?-3.3:3.3)]],2.4,12959399,.032),p(S.x-S.w/2+.4,.45,G,.12,.9,.12,v),p(S.x-S.w/2+.4,.82,G,1.2,.5,.08,4488320),x("BUILD",S.x-S.w/2+.4,.83,G+.05,0,1.1)}c=!0,L0({box:p,bench:X,material:M,scene:n,reserved:i}),c=!1;const ie={x:18,z:-101,rx:16,rz:10},ne=(S,y,G,F,ae,oe=.02)=>{const ee=new ka(1,48);ee.rotateX(-Math.PI/2),ee.scale(G,1,F);const me=new Ie(ee,M(ae));me.position.set(S,oe,y),n.add(me)};ne(18,-101,18,12,14141609,.006),ne(18,-101,16,10,7515836,.022);for(let S=0;S<9;S++)p(18+(S%2?.3:-.3),.035,-110+S*2.25,1.25,.018,1.45,11906454,!1);X(38,-103,Math.PI/2),X(10,-116,Math.PI);const ue=[];for(let S=0;S<18;S++){const y=S*.67;ue.push([81+Math.cos(y)*(7+Math.floor(S/6)*4),94+Math.sin(y)*(7+Math.floor(S/6)*4)])}X(81,100),p(81,.015,97,3,.03,2,14728124);const de=(S,y)=>!!(Math.abs(S)<32&&Math.abs(y)<32||Oc.slice(0,16).some(G=>{const F=Math.abs(Math.cos(G.angle)),ae=Math.abs(Math.sin(G.angle));return Math.abs(S-G.x)<(G.w*F+G.d*ae)/2+8&&Math.abs(y-G.z)<(G.w*ae+G.d*F)/2+6})||[...A.slice(0,2),...N.slice(0,6)].some(G=>Ht(S,y,G).distance<5.2)||U.slice(0,16).some(G=>Ht(S,y,G.points).distance<3)||$.slice(0,2).some(G=>Math.abs(S-G.x)<G.w/2+3&&Math.abs(y-G.z)<G.d/2+3)||Math.abs(S-65)<18&&Math.abs(y-46)<18||Math.abs(S-49)<17&&Math.abs(y+26)<17||Math.abs(S-18)<22&&Math.abs(y+101)<16||Math.hypot(S-81,y-94)<24);let J=73419;const se=()=>(J=Math.imul(J,1664525)+1013904223>>>0,J/4294967296),ge=[];for(let S=0;S<650;S++){const y=-118+se()*236,G=-118+se()*236;de(y,G)||ge.some(F=>Math.hypot(F[0]-y,F[1]-G)<5)||G>-80&&se()<.42||ge.push([y,G])}for(let S=0;S<600;S++){const y=-95+se()*63,G=-121+se()*36;de(y,G)||ge.some(F=>Math.hypot(F[0]-y,F[1]-G)<3.8)||ge.push([y,G])}for(let S=0;S<24;S++){const y=S*Math.PI*2/24,G=18+Math.cos(y)*16.8,F=-101+Math.sin(y)*10.8;Math.abs(G-18)<2||(p(G,.35,F,.055,.7,.055,5474391),p(G,.74,F,.12,.17,.12,9725511))}for(const[S,[y,G]]of[...ge,...ue].entries()){if(!I(y,G))continue;o.push({x:y,z:G});const F=S>=ge.length,ae=F?2.2:2.6+S%4*.35;p(y,ae/2,G,.38,ae,.38,v,!0);const oe=!F&&G<-80&&S%3===0,ee=oe?new sr(2.1,4.6,7):new ar(1,1);oe||ee.scale(2.2,1.9,2.2);const me=new Ie(ee,M(oe?5082472:S%2?7052647:5933922));if(me.position.set(y,ae+.7,G),n.add(me),F)for(const T of[-1,1])p(y+T,ae+.5,G+.5,.22,.22,.22,13075044)}c=!0;const Ae=I0({scene:n,box:p,material:M,bench:X,disk:ne,roads:A,trails:N,drives:U,houses:s,treeAllowed:I,treePositions:o,clearings:$});c=!1;for(const S of p0.filter(y=>y.id!=="home")){c=Al.some(F=>F.id===S.id);const y=S.signX??(S.id==="pond"?39:S.x+4),G=S.signZ??(S.id==="pond"?-94:S.z+4);i({minX:y-2,maxX:y+2,minZ:G-1,maxZ:G+1,minY:0,maxY:2.2})||(p(y,.9,G,.14,1.8,.14,v,!0),p(y,1.7,G,3.8,.8,.12,4488320),x(S.name.toUpperCase(),y,1.72,G+.075,0,3.6))}c=!1;for(const[S,y]of h){const G=new rs(u,M(S),y.length);y.forEach((F,ae)=>{_.position.set(F.x,F.y,F.z),_.rotation.set(0,F.angle,0),_.scale.set(F.w,F.h,F.d),_.updateMatrix(),G.setMatrixAt(ae,_.matrix)}),G.computeBoundingSphere(),n.add(G)}const Ee=new Ie(new Un(nt.halfSize*2,nt.halfSize*2),new Ri({visible:!1}));Ee.rotation.x=-Math.PI/2,Ee.updateMatrixWorld(),n.add(Ee);const Be=Za(d),ke=Ya(n,new Set([...d.map(S=>S.pivot),Ee,...f]));return{config:nt,roads:A,selfJunctions:H,trails:N,clearings:$,pond:ie,ponds:[ie,...Yr],outerScenery:Ae,staticRender:ke,doorRender:Be,treeCount:o.length,treePositions:o,rooms:a,omitted:r,solids:l,doors:d,table:W,ground:Ee,road:E,drives:U,houses:s,treeAllowed:I,batches:h}}const wn=[{id:"sunbeam-town",name:"Sunbeam Town",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"home-square",name:"Home & Square",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"legacy-06",name:"Legacy neighbourhood",icon:"🏡",spawn:{x:-14.4,y:0,z:-1.2,yaw:0,pitch:0}},{id:"blank",name:"Blank creative",icon:"🧱",spawn:{x:0,y:0,z:8,yaw:0,pitch:0}}];function z0(n,e,t=[]){if(e==="sunbeam-town")return P0(n);if(e==="home-square")return Ol(n);if(e==="legacy-06")return N0(n,t);const i=new Ie(new Un(500,500),new Vt({color:11127178}));return i.rotation.x=-Math.PI/2,n.add(i),i.updateMatrixWorld(),{ground:i,solids:[],doors:[],houses:[],rooms:[],roads:[],staticRender:{updateVisibility(){}}}}function Gl(n){let e=2166136261;for(let t=0;t<n.length;t++)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return(e>>>0).toString(16).padStart(8,"0")}function bs(n){const e=n;if(!e||![1,2].includes(e.schema)||!wn.some(i=>i.id===e.template)||!e.world||!e.player||!e.preferences)throw Error("Unsupported world schema or template");for(const i of["x","y","z","yaw","pitch"])if(!Number.isFinite(e.player[i]))throw Error("Invalid player position");if(Math.abs(e.player.x)>=250||Math.abs(e.player.z)>=250||e.player.y<0||e.player.y>26)throw Error("Player outside supported bounds");if(R0(e.world.blocks),!["hand",...or.map(i=>i.id)].includes(e.preferences.selected))throw Error("Invalid selected item");if(!e.world.doors||Array.isArray(e.world.doors)||typeof e.world.doors!="object"||Object.values(e.world.doors).some(i=>typeof i!="boolean"))throw Error("Invalid doors");const t=e.world.activity;if(t!==void 0&&(!t||!t.car||![t.car.x,t.car.z,t.car.yaw].every(Number.isFinite)||Math.abs(t.car.x)>249||Math.abs(t.car.z)>249))throw Error("Invalid vehicle checkpoint");return{...structuredClone(e),schema:2}}function Li(n){const e=JSON.stringify(bs(n));return{json:e,checksum:Gl(e)}}function Kr(n){if(!n||typeof n.json!="string"||n.json.length>8e6||Gl(n.json)!==n.checksum)throw Error("Checkpoint checksum failed");return bs(JSON.parse(n.json))}function Vn(n){return bs({schema:2,template:n.template,world:{blocks:n.blocks,doors:n.doors,...n.activity?{activity:n.activity}:{}},player:n.player,preferences:{selected:n.selected,favourites:n.favourites||[],recent:n.recent||[],camera:n.camera||"first",flying:!!n.flying}})}function F0(n){if(n.length>12e6)throw Error("Backup is too large");const e=JSON.parse(n);if(e.format==="blockworld2"&&e.version===1)return{snapshot:Kr(e.checkpoint),...typeof e.legacySource=="string"&&e.legacySource.length<=4e6?{source:e.legacySource}:{},name:typeof e.name=="string"?e.name.slice(0,60):"Imported world"};if(n.length>4e6)throw Error("Legacy backup exceeds 4 MB");const t=M0(e);return{snapshot:bs({schema:2,template:"legacy-06",world:{blocks:t.blocks,doors:t.doors},player:t.player,preferences:{selected:t.selected}}),source:n,name:"Imported legacy neighbourhood"}}class Bc extends Error{constructor(){super("This world changed in another tab. Your unsaved work is still here; export or save a new copy.")}}const Wr=n=>new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error||Error("Storage request failed"))}),Xr=n=>new Promise((e,t)=>{n.oncomplete=()=>e(),n.onabort=()=>t(n.error||Error("Storage transaction aborted")),n.onerror=()=>{}});class ls{constructor(e){this.db=e}static open(e="blockworld2-development"){return new Promise((t,i)=>{const r=indexedDB.open(e,1);r.onupgradeneeded=()=>{for(const s of["worlds","meta"])r.result.objectStoreNames.contains(s)||r.result.createObjectStore(s,{keyPath:s==="worlds"?"id":"key"})},r.onsuccess=()=>{r.result.onversionchange=()=>r.result.close(),t(new ls(r.result))},r.onerror=()=>i(r.error),r.onblocked=()=>i(Error("Close another BlockWorld tab to open saves"))})}async read(e,t){const i=this.db.transaction(e,"readonly");return Wr(i.objectStore(e).get(t))}async list(){const e=this.db.transaction("worlds","readonly");return Wr(e.objectStore("worlds").getAll())}async last(){var e;return(e=await this.read("meta","last"))==null?void 0:e.value}async select(e){const t=this.db.transaction("meta","readwrite"),i=Xr(t);t.objectStore("meta").put({key:"last",value:e}),await i}async create(e,t,i){const r=Li(t),s={id:crypto.randomUUID(),name:e.trim().slice(0,60)||"My world",template:t.template,revision:0,updated:Date.now(),current:r,previous:[],...i?{importSource:i}:{}},a=this.db.transaction("worlds","readwrite"),o=Xr(a);return a.objectStore("worlds").add(s),await o,s}async load(e){const t=await this.read("worlds",e);if(!t)throw Error("World was not found");try{return{record:t,snapshot:Kr(t.current),recovered:!1}}catch{for(const r of t.previous||[])try{return{record:t,snapshot:Kr(r),recovered:!0}}catch{}throw Error("No valid checkpoint. Original data is retained; import a backup or choose another world.")}}async save(e,t,i){const r=Li(i),s=this.db.transaction("worlds","readwrite"),a=Xr(s);try{const o=s.objectStore("worlds"),c=await Wr(o.get(e));if(!c)throw Error("World no longer exists");if(c.revision!==t)throw new Bc;Kr(c.current);const l={...c,revision:t+1,current:r,previous:[c.current,...c.previous].slice(0,3),updated:Date.now()};return o.put(l),await a,l}catch(o){try{s.abort()}catch{}throw await a.catch(()=>{}),o}}async rename(e,t,i){const r=this.db.transaction("worlds","readwrite"),s=Xr(r);try{const a=r.objectStore("worlds"),o=await Wr(a.get(e));if(!o||o.revision!==t)throw new Bc;const c={...o,name:i.trim().slice(0,60)||o.name,revision:t+1,updated:Date.now()};return a.put(c),await s,c}catch(a){try{r.abort()}catch{}throw await s.catch(()=>{}),a}}async duplicate(e){const{record:t,snapshot:i,recovered:r}=await this.load(e);if(r)throw Error("Recover this world to a new copy before duplicating");return this.create(t.name+" copy",i,t.importSource)}async import(e){const t=F0(e);return this.create(t.name,t.snapshot,t.source)}export(e,t){return JSON.stringify({format:"blockworld2",version:1,name:e.name,...e.importSource?{legacySource:e.importSource}:{},checkpoint:t?Li(t):e.current},null,2)}}class O0{constructor(e){this.game=e,e.paused=!0,document.querySelector("#worlds").onclick=()=>void this.menu(),e.onEdit=()=>{this.ready&&this.save().catch(()=>{})},this.init()}store;current=null;blocked=!1;ready=!1;flight=null;last="";async init(){try{this.store=await ls.open();const e=await this.store.list(),t=await this.store.last(),i=e.find(r=>r.id===t)||e[0]||await this.store.create("My neighbourhood",Vn(this.game.snapshot()));await this.open(i.id),this.ready=!0,setInterval(()=>{!this.game.paused&&!document.hidden&&this.save().catch(()=>{})},1500),addEventListener("blur",()=>{this.save().catch(()=>{})}),document.addEventListener("visibilitychange",()=>{document.hidden&&this.save().catch(()=>{})})}catch(e){this.ready=!1,this.game.paused=!1,this.failure(e)}}async open(e){this.flight&&await this.flight;const t=await this.store.load(e),i=t.snapshot;this.game.load(i.template,i.world.blocks,i.player,i.world.doors,i.world.activity),this.game.selected=i.preferences.selected,this.game.favourites=Array.isArray(i.preferences.favourites)?i.preferences.favourites:[],this.game.recent=Array.isArray(i.preferences.recent)?i.preferences.recent:[],Ta(this.game),this.game.cameraMode=i.preferences.camera==="third"?"third":"first",this.game.flying=!!i.preferences.flying,document.querySelector("#flightControls").hidden=!this.game.flying,this.game.refreshModes(),this.current=t.record,this.last=Li(Vn(this.game.snapshot())).json,this.blocked=t.recovered,await this.store.select(e),this.game.paused=!1,t.recovered?this.failure(Error("An older checkpoint was recovered. The damaged original is retained. Save a new copy before continuing.")):this.game.notice("✓ World ready · saved on this device")}async save(){if(!this.current||!this.store)return;if(this.flight)return await this.flight,this.save();if(this.blocked)throw Error("Save blocked; export or save a new copy");let e,t;try{e=Vn(this.game.snapshot()),t=Li(e).json}catch(r){throw this.failure(r),r}if(t===this.last)return;const i=this.current;this.flight=(async()=>{try{this.current=await this.store.save(i.id,i.revision,e),this.last=t}catch(r){throw this.failure(r),r}})();try{await this.flight}finally{this.flight=null}}async newWorld(e){await this.save();const t=wn.find(s=>s.id===e),i=Vn({template:e,blocks:[],doors:{},player:t.spawn,selected:"hand"}),r=await this.store.create(t.name,i);return await this.open(r.id),this.close(),r}exportCurrent(){const e=this.current||{name:"Unsaved recovered world"},t=this.store?this.store.export(e,Vn(this.game.snapshot())):JSON.stringify({format:"blockworld2",version:1,name:e.name,checkpoint:Li(Vn(this.game.snapshot()))},null,2),i=URL.createObjectURL(new Blob([t],{type:"application/json"})),r=document.createElement("a");return r.href=i,r.download="BlockWorld2-backup.bw2",r.click(),setTimeout(()=>URL.revokeObjectURL(i),6e4),t}failure(e){this.blocked=!0;let t=document.querySelector("#saveAlert");t||(t=document.createElement("aside"),t.id="saveAlert",t.setAttribute("role","alert"),document.body.append(t)),t.replaceChildren();const i=document.createElement("p");i.textContent="Progress remains in memory. "+String(e),t.append(i);const r=(s,a)=>{const o=document.createElement("button");o.textContent=s,o.onclick=a,t.append(o)};r("Export unsaved work",()=>{try{this.exportCurrent()}catch(s){i.textContent=String(s)}}),r("Save as new copy",()=>{(async()=>{var s;try{this.store||(this.store=await ls.open());const a=await this.store.create((((s=this.current)==null?void 0:s.name)||"Recovered world")+" recovered",Vn(this.game.snapshot()));this.current=a,await this.store.select(a.id),this.last=a.current.json,this.blocked=!1,this.ready=!0,t.remove(),this.game.notice("✓ Recovered copy saved")}catch(a){i.textContent=String(a)}})()})}close(){document.querySelector("#modal").hidden=!0,this.game.paused=!1,this.game.controls.clear()}async menu(){var e;try{await this.save(),this.game.paused=!0,this.game.controls.clear();const t=document.querySelector("#modal");t.hidden=!1,t.innerHTML='<section><h1>🌍 Your worlds</h1><div id="worldList"></div><h2>Create another</h2><div id="templates"></div><div class="backupActions"><button id="export">⇩ Backup</button><label class="fileButton">⇧ Import<input id="import" type="file" accept=".bw2,.json,application/json"></label><button id="resume">▶ Play</button></div><p id="worldError" role="alert"></p></section>';const i=r=>{r().catch(s=>{document.querySelector("#worldError").textContent=String(s)})};for(const r of await this.store.list()){const s=document.createElement("div");s.className="worldRow";const a=document.createElement("button");a.textContent=(r.id===((e=this.current)==null?void 0:e.id)?"▶ ":"")+r.name,a.dataset.world=r.id,a.onclick=()=>i(async()=>{await this.open(r.id),this.close()});const o=document.createElement("input");o.value=r.name,o.setAttribute("aria-label","World name");const c=document.createElement("button");c.textContent="✎",c.setAttribute("aria-label","Rename "+r.name),c.onclick=()=>i(async()=>{var h;const d=await this.store.rename(r.id,r.revision,o.value);((h=this.current)==null?void 0:h.id)===r.id&&(this.current=d),await this.menu()});const l=document.createElement("button");l.textContent="⧉",l.setAttribute("aria-label","Duplicate "+r.name),l.onclick=()=>i(async()=>{await this.store.duplicate(r.id),await this.menu()}),s.append(a,o,c,l),document.querySelector("#worldList").append(s)}for(const r of wn){const s=document.createElement("button");s.dataset.template=r.id,s.textContent=r.icon+" "+r.name,s.onclick=()=>i(()=>this.newWorld(r.id)),document.querySelector("#templates").append(s)}document.querySelector("#resume").onclick=()=>this.close(),document.querySelector("#export").onclick=()=>this.exportCurrent(),document.querySelector("#import").onchange=r=>i(async()=>{var o;const s=(o=r.target.files)==null?void 0:o[0];if(!s)return;if(s.size>12e6)throw Error("Backup exceeds 12 MB");const a=await this.store.import(await s.text());await this.open(a.id),this.close()})}catch(t){this.failure(t)}}}function B0(n,e,t,i,r){if(!e.length)return!1;if(n.wait>0)return n.wait=Math.max(0,n.wait-t),!1;const s=e[n.target%e.length],a=s.x-n.x,o=s.z-n.z,c=Math.hypot(a,o);if(c<.15)return n.target=(n.target+1)%e.length,n.wait=.6,!1;const l=Math.min(c,i*Math.min(t,.1)),d=n.x+a/c*l,h=n.z+o/c*l;return r(d,h)?(n.stuck+=t,n.stuck>2&&(n.target=(n.target+1)%e.length,n.stuck=0,n.wait=.5),!1):(n.x=d,n.z=h,n.stuck=0,!0)}function kc(n){const e=(n%304+304)%304;return e<80?{x:-40+e,z:-36,yaw:-Math.PI/2}:e<152?{x:40,z:-36+e-80,yaw:Math.PI}:e<232?{x:40-(e-152),z:36,yaw:Math.PI/2}:{x:-40,z:36-(e-232),yaw:0}}function k0(n){const e=new gt,t=new vt(1,1,1),i=[],r=n==="dog"?13019779:n==="cat"?12104869:n==="duck"?16113568:12159848,s=(a,o,c,l,d,h,u=r)=>{const m=new Ie(t,new Vt({color:u}));return m.position.set(a,o,c),m.scale.set(l,d,h),e.add(m),m};if(n==="duck"){s(0,.35,0,.6,.45,.7),s(0,.65,-.35,.34,.35,.35),s(0,.61,-.58,.3,.12,.24,14261592);for(const a of[-.2,.2])i.push(s(a,.1,0,.13,.2,.25,14261592));s(-.34,.4,0,.12,.2,.4),s(.34,.4,0,.12,.2,.4)}else{const a=n==="horse",o=a?.95:.36,c=a?1.35:.75;s(0,o,0,a?.7:.5,a?.6:.35,c),s(0,a?1.55:.68,-c*.48,a?.4:.32,a?.6:.32,a?.65:.35);for(const l of[a?-.24:-.16,a?.24:.16])for(const d of[-c*.33,c*.33])i.push(s(l,a?.42:.15,d,.12,a?.85:.3,.12));for(const l of[-.13,.13])s(l,a?1.94:.94,-c*.48,.1,n==="dog"?.23:.18,.12,n==="dog"?9402207:r);s(0,a?1.05:.55,c*.65,.1,a?.65:.55,.12,n==="horse"?7756615:r)}return e.userData.species=n,{group:e,limbs:i}}function Aa(n,e){const t=new vn,i=new z;if(e.obb){const s=e.obb,a=n.origin.x-s.cx,o=n.origin.z-s.cz,c=new hr(new z(a*s.c-o*s.s,n.origin.y,a*s.s+o*s.c),new z(n.direction.x*s.c-n.direction.z*s.s,n.direction.y,n.direction.x*s.s+n.direction.z*s.c));t.min.set(-s.halfW,e.minY,-s.halfD),t.max.set(s.halfW,e.maxY,s.halfD);const l=c.intersectBox(t,i);return l?c.origin.distanceTo(l):1/0}t.min.set(e.minX,e.minY,e.minZ),t.max.set(e.maxX,e.maxY,e.maxZ);const r=n.intersectBox(t,i);return r?n.origin.distanceTo(r):1/0}function G0(n,e,t,i,r){const s=Math.max(1,Math.hypot(e.forward,e.right)),a=(-Math.sin(n.yaw)*e.forward+Math.cos(n.yaw)*e.right)*6/s,o=(-Math.cos(n.yaw)*e.forward-Math.sin(n.yaw)*e.right)*6/s,c=Math.max(1,Math.ceil(i/.01));for(let l=0;l<c;l++)for(const[d,h]of[["x",a],["z",o],["y",t*5]]){const u=n[d];n[d]=Math.max(d==="y"?0:-249,Math.min(d==="y"?24:249,u+h*i/c)),Pi(n,r)&&(n[d]=u)}n.vy=0,n.grounded=n.y===0}function Hl(n=14987622){const e=new gt,t=new vt(1,1,1),i=(a,o,c,l,d,h,u)=>{const m=new Ie(t,new Vt({color:u}));return m.position.set(a,o,c),m.scale.set(l,d,h),e.add(m),m};i(0,1.43,0,.4,.4,.38,15778974),i(0,1.66,.02,.43,.12,.4,7493190),i(0,.93,0,.48,.55,.3,n);const r=i(-.14,.35,0,.2,.65,.24,5602691),s=i(.14,.35,0,.2,.65,.24,5602691);return i(-.34,.92,0,.16,.5,.2,15778974),i(.34,.92,0,.16,.5,.2,15778974),{group:e,left:r,right:s}}function H0(n,e,t){const i=new z(e.x,e.y+1.3,e.z),r=new z(e.x+Math.sin(e.yaw)*4.5,e.y+3,e.z+Math.cos(e.yaw)*4.5),s=r.clone().sub(i).normalize(),a=new hr(i,s);let o=r.distanceTo(i);for(const c of t){const l={...c,minX:c.minX-.2,maxX:c.maxX+.2,minY:c.minY-.2,maxY:c.maxY+.2,minZ:c.minZ-.2,maxZ:c.maxZ+.2,...c.obb?{obb:{...c.obb,halfW:c.obb.halfW+.2,halfD:c.obb.halfD+.2}}:{}};o=Math.min(o,Aa(a,l)-.2)}return o=Math.max(.15,o),n.position.copy(i.addScaledVector(s,o)),n.lookAt(e.x,e.y+1.3,e.z),n.updateMatrixWorld(),o>.7}function hs(n,e){for(let t=0;t<=12;t++)for(let i=-t;i<=t;i++)for(let r=-t;r<=t;r++){if(t&&Math.abs(i)!==t&&Math.abs(r)!==t)continue;const s={x:n.x+i,y:0,z:n.z+r,yaw:n.yaw||0,pitch:0,vy:0,grounded:!0};if(Math.abs(s.x)<249&&Math.abs(s.z)<249&&!Pi(s,e))return s}throw Error("No clear arrival space. Your current position is retained.")}function Gc(n){const e=new gt,t=new vt(1,1,1),i=(r,s,a,o,c,l,d)=>{const h=new Ie(t,new Vt({color:d}));h.position.set(r,s,a),h.scale.set(o,c,l),e.add(h)};i(0,.65,0,1.5,.65,3,n),i(0,1.2,0,1.25,.6,1.4,13165276),i(0,1.56,0,1.4,.12,1.6,n);for(const r of[-.78,.78])for(const s of[-.95,.95])i(r,.32,s,.22,.58,.58,4149581);return i(0,.65,-1.52,.9,.2,.06,16772278),e}function Yt(n){const e=Math.cos(n.yaw),t=Math.sin(n.yaw),i=Math.abs(e)*.8+Math.abs(t)*1.6,r=Math.abs(t)*.8+Math.abs(e)*1.6;return{minX:n.x-i,maxX:n.x+i,minY:0,maxY:1.7,minZ:n.z-r,maxZ:n.z+r,obb:{cx:n.x,cz:n.z,c:e,s:t,halfW:.8,halfD:1.6}}}class V0{constructor(e,t=47){this.range=t,e.add(this.group),this.group.add(this.vehicle);const i=[[[26,8],[22,10],[12,10],[12,6],[22,6]],[[12,6],[17,6],[24,9],[17,10]],[[56,-12],[56,-20.6],[58,-20.6],[56,-12]],[[56,0],[56,9],[58,5.4]],[[14,32],[29,32],[25,31]],[[-9,16],[-9,22],[-2,22],[3,16]]],r=(o,c,l,d,h)=>{const u=c.map(([M,_])=>({x:M,z:_})),m={...u[0],target:1,wait:0,stuck:0};o.position.set(m.x,0,m.z),this.group.add(o),this.agents.push({model:o,route:u,state:m,phase:this.agents.length*.4,animal:l,limbs:d,greetUntil:0,species:h})};for(let o=0;o<(t>47?6:4);o++){const c=Hl([14260858,9088931,14139254,9545917,11705009,12171142][o]);r(c.group,i[t>47?o:o%2],!1,[c.left,c.right])}const s=t>47?["dog","cat","duck","horse"]:["cat","duck"],a={dog:[[14,17],[22,17],[22,20],[14,20]],cat:[[-12,-5],[-8,-5],[-8,0],[-12,0]],duck:[[28,24],[32,24],[32,27],[28,27]],horse:[[-54,42],[-48,42],[-48,47],[-54,47]]};for(const o of s){const c=k0(o);r(c.group,a[o],!0,c.limbs,o)}for(let o=0;o<2;o++){const c=Gc([12156781,8628132][o]);this.traffic.push(c);const l=kc(this.progress[o]);c.position.set(l.x,0,l.z),c.rotation.y=l.yaw,this.group.add(c)}this.sync()}group=new gt;car={x:-28,z:-2,yaw:0};vehicle=Gc(15119462);driving=!1;time=0;agents=[];traffic=[];progress=[0,152];sync(){this.vehicle.position.set(this.car.x,0,this.car.z),this.vehicle.rotation.y=this.car.yaw}load(e){if(e!=null&&e.car){const t=e.car;if(![t.x,t.z,t.yaw].every(Number.isFinite)||Math.abs(t.x)>249||Math.abs(t.z)>249)throw Error("Invalid saved car");this.car={...t}}this.driving=!1,this.sync()}snapshot(){return{car:{...this.car}}}use(e,t){if(this.driving){const r=hs({x:this.car.x+Math.cos(this.car.yaw)*2,z:this.car.z-Math.sin(this.car.yaw)*2,yaw:this.car.yaw},[...t,Yt(this.car)]);return Object.assign(e,r),this.driving=!1,"✓ Parked — ready to walk"}if(Math.abs(e.y)<2&&Math.hypot(e.x-this.car.x,e.z-this.car.z)<3)return this.driving=!0,e.y=0,this.sync(),"🚗 Drive with the stick · tap Use to leave";const i=this.agents.find(r=>Math.hypot(r.model.position.x-e.x,r.model.position.z-e.z)<2.5);return i&&Math.abs(e.y)<2?(i.greetUntil=this.time+2,i.model.rotation.y=Math.atan2(e.x-i.state.x,e.z-i.state.z),i.animal?`♡ Hello, ${i.species}!`:"👋 Hello, neighbour!"):null}update(e,t,i,r){if(this.time+=e,this.driving){const a={...this.car,yaw:this.car.yaw-i.right*e*1.3*Math.sign(i.forward||1)},o=i.forward*6;a.x-=Math.sin(a.yaw)*o*e,a.z-=Math.cos(a.yaw)*o*e,Math.abs(a.x)<this.range&&Math.abs(a.z)<this.range&&![...r,...this.traffic.map(c=>Yt({x:c.position.x,z:c.position.z,yaw:c.rotation.y}))].some(c=>It(Yt(a),c))&&(this.car=a),Object.assign(t,{x:this.car.x,y:0,z:this.car.z,yaw:this.car.yaw,vy:0,grounded:!0}),this.sync()}const s=Yt(this.car);for(const a of this.agents){if(Math.hypot(a.state.x-t.x,a.state.z-t.z)>80)continue;const o={x:a.state.x,z:a.state.z};let c=!1;this.time>=a.greetUntil&&(c=B0(a.state,a.route,e,a.animal?.65:1,(l,d)=>Math.hypot(l-t.x,d-t.z)<1||[...r,s,...this.traffic.map(h=>Yt({x:h.position.x,z:h.position.z,yaw:h.rotation.y}))].some(h=>It(Bi({x:l,y:0,z:d}),h)))),a.model.position.set(a.state.x,0,a.state.z),c&&(a.model.rotation.y=Math.atan2(-(a.state.x-o.x),-(a.state.z-o.z))),a.limbs.forEach((l,d)=>l.rotation.x=c?Math.sin(this.time*5+a.phase+(d%2?Math.PI:0))*.2:0)}for(let a=0;a<this.traffic.length;a++){const o=(this.progress[a]+e*2)%304,c=kc(o),l=Yt(c),d=this.traffic.filter((u,m)=>m!==a).map(u=>Yt({x:u.position.x,z:u.position.z,yaw:u.rotation.y}));!this.progress.some((u,m)=>m!==a&&(u-o+304)%304<6)&&Math.hypot(c.x-t.x,c.z-t.z)>3&&!this.agents.some(u=>Math.hypot(u.state.x-c.x,u.state.z-c.z)<2.5)&&![...r,s,...d].some(u=>It(l,u))&&(this.progress[a]=o,this.traffic[a].position.set(c.x,0,c.z),this.traffic[a].rotation.y=c.yaw)}}dispose(){const e=new Set,t=new Set;this.group.traverse(i=>{i.isMesh&&(e.add(i.geometry),t.add(i.material))}),e.forEach(i=>i.dispose()),t.forEach(i=>i.dispose()),this.group.removeFromParent()}}function W0(n){const e=document.querySelector("#modal");n.paused=!0,n.controls.clear(),e.hidden=!1,e.innerHTML='<section><h1>🗺 Let’s explore</h1><canvas id="mapCanvas" width="560" height="420" aria-label="Drag map; choose a landmark to travel"></canvas><div id="mapPlaces"></div><div><button id="zoomIn" aria-label="Zoom in">＋</button><button id="zoomOut" aria-label="Zoom out">−</button><button id="closeMap">▶ Play</button></div><p id="mapMessage">Drag to look around. Choose a picture to travel.</p></section>';const t=document.querySelector("#mapCanvas"),i=t.getContext("2d");let r=n.template==="sunbeam-town"?2.7:n.template==="home-square"?4:.8,s=280,a=210,o=null;const c=()=>{if(i.fillStyle="#c4d39e",i.fillRect(0,0,560,420),i.save(),i.translate(s,a),i.scale(r,r),i.fillStyle="#859995",n.world.mapRoads)for(const h of n.world.mapRoads)i.fillRect(h.x-h.w/2,h.z-h.d/2,h.w,h.d);else if(n.template==="home-square"){for(const h of[-36,4,36])i.fillRect(-43,h-3,86,6);for(const h of[-40,8,40])i.fillRect(h-3,-39,6,78)}for(const h of n.world.houses)i.fillStyle="#b88361",i.fillRect(h.x-h.w/2,h.z-h.d/2,h.w,h.d);i.fillStyle="#edb447",i.beginPath(),i.arc(n.player.x,n.player.z,2,0,Math.PI*2),i.fill(),i.restore()};c(),t.onpointerdown=h=>{t.setPointerCapture(h.pointerId),o={x:h.clientX,y:h.clientY}},t.onpointermove=h=>{if(!o)return;const u=t.getBoundingClientRect();s+=(h.clientX-o.x)*560/u.width,a+=(h.clientY-o.y)*420/u.height,o={x:h.clientX,y:h.clientY},c()},t.onpointerup=t.onpointercancel=()=>{o=null},document.querySelector("#zoomIn").onclick=()=>{r=Math.min(10,r*1.3),c()},document.querySelector("#zoomOut").onclick=()=>{r=Math.max(.3,r/1.3),c()};const l=()=>{e.hidden=!0,n.paused=!1,n.controls.clear()};document.querySelector("#closeMap").onclick=l;const d=n.world.landmarks||[{name:"Home",icon:"⌂",x:n.template==="blank"?0:-14.4,z:n.template==="blank"?8:-1.2}];for(const h of d){const u=document.createElement("button");u.textContent=h.icon+" "+h.name,u.dataset.place=h.name,u.onclick=()=>{try{const m=hs(h,[...n.obstacles(),...n.commands.blocks.flatMap(pt)]);Object.assign(n.player,m),n.seated=null,n.flying=!1,n.activity&&(n.activity.driving=!1),n.vertical=0,n.refreshModes(),n.cancel(),n.onEdit(),l()}catch(m){document.querySelector("#mapMessage").textContent=String(m)}},document.querySelector("#mapPlaces").append(u)}}function X0(n){const e=new Oa({canvas:n,antialias:!1,powerPreference:"low-power"});e.setPixelRatio(Math.min(devicePixelRatio,1.25)),e.outputColorSpace=mt;const t=new vl;t.background=new je("#badbdc"),t.fog=new Ba("#badbdc",70,155),t.add(new bl(16774620,6720624,2.2));const i=new El(16770744,1.8);i.position.set(-30,50,20),t.add(i);const r=new Kt(67,1,.06,180);r.rotation.order="YXZ";function s(){e.setSize(innerWidth,innerHeight),r.aspect=innerWidth/innerHeight,r.updateProjectionMatrix()}return s(),addEventListener("resize",s),{renderer:e,scene:t,camera:r,dispose(){removeEventListener("resize",s),e.dispose()}}}class q0{constructor(e=1/60,t=5){this.step=e,this.maxSteps=t}previous=0;accumulator=0;reset(e){this.previous=e,this.accumulator=0}tick(e,t){const i=Math.max(0,Math.min(.1,(e-this.previous)/1e3));this.previous=e,this.accumulator=Math.min(this.accumulator+i,this.step*this.maxSteps);let r=0;for(;this.accumulator+1e-9>=this.step&&r<this.maxSteps;)t(this.step),this.accumulator-=this.step,r++;return r}}function Y0(n,e){let t=null,i=null;const r=()=>{clearTimeout(i),i=null};function s(){var a;r(),t=null,(a=e.onIndicator)==null||a.call(e,null)}n.addEventListener("pointerdown",a=>{var o;if(t){s();return}e.canStart()&&(a.preventDefault(),n.setPointerCapture(a.pointerId),t={id:a.pointerId,x:a.clientX,y:a.clientY,lastX:a.clientX,lastY:a.clientY,drag:!1,held:!1},(o=e.onStart)==null||o.call(e,t),i=setTimeout(()=>{var c;!t||t.drag||(t.held=!0,(c=e.onIndicator)==null||c.call(e,null),e.onHold(t.x,t.y))},550))}),n.addEventListener("pointermove",a=>{var l;if(!t||a.pointerId!==t.id)return;const o=a.clientX-t.lastX,c=a.clientY-t.lastY;!t.drag&&Math.hypot(a.clientX-t.x,a.clientY-t.y)>10?(t.drag=!0,r(),(l=e.onIndicator)==null||l.call(e,null),e.onLook(a.clientX-t.x,a.clientY-t.y)):t.drag&&e.onLook(o,c),t.lastX=a.clientX,t.lastY=a.clientY}),n.addEventListener("pointerup",a=>{var c;if(!t||a.pointerId!==t.id)return;const o=t;s(),!o.drag&&!o.held&&e.onTap(o.x,o.y),(c=e.onEnd)==null||c.call(e)});for(const a of["pointercancel","lostpointercapture"])n.addEventListener(a,o=>{(t==null?void 0:t.id)===o.pointerId&&s()});return n.addEventListener("contextmenu",a=>a.preventDefault()),{cancel:s}}function Z0(n=document){const e=new Map;let t=!1,i=0;n.addEventListener("pointerdown",r=>{var a,o;i=0;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button");(r.pointerType==="touch"||r.pointerType==="pen")&&s&&!s.disabled&&e.set(r.pointerId,{button:s,x:r.clientX,y:r.clientY,moved:!1})},!0),n.addEventListener("keydown",()=>{i=0},!0),n.addEventListener("pointermove",r=>{const s=e.get(r.pointerId);s&&Math.hypot(r.clientX-s.x,r.clientY-s.y)>10&&(s.moved=!0)},!0),n.addEventListener("pointercancel",r=>{e.has(r.pointerId)&&(i=performance.now()+900),e.delete(r.pointerId)},!0),n.addEventListener("pointerup",r=>{var a,o;const s=e.get(r.pointerId);if(e.delete(r.pointerId),(r.pointerType==="touch"||r.pointerType==="pen")&&((o=(a=r.target).closest)!=null&&o.call(a,"#world"))&&(i=performance.now()+900),!!s&&(i=performance.now()+900,!s.moved&&!s.button.disabled&&s.button.isConnected!==!1)){r.preventDefault(),t=!0;try{s.button.click()}finally{t=!1}}},!0),n.addEventListener("click",r=>{var a,o;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button,summary,.file-button");!t&&s&&performance.now()<i&&(r.preventDefault(),r.stopImmediatePropagation())},!0)}class j0{stick={x:0,y:0};keys=new Set;pointer=null;gestures;constructor(e,t,i){Z0();let r=null;this.gestures=Y0(e,{canStart:t,onStart:()=>{r=i.pose?{...i.pose()}:null},onTap:i.tap,onHold:(o,c)=>{var d;const l=(d=i.pose)==null?void 0:d.call(i);r&&l&&(Math.hypot(l.x-r.x,l.y-r.y,l.z-r.z)>.08||Math.abs(l.yaw-r.yaw)+Math.abs(l.pitch-r.pitch)>.01)||i.hold(o,c)},onLook:i.look});const s=document.querySelector("#joystick"),a=o=>{const c=s.getBoundingClientRect(),l=o.clientX-c.left-c.width/2,d=o.clientY-c.top-c.height/2,h=Math.max(1,Math.hypot(l,d)/40);this.stick={x:l/h/40,y:d/h/40},document.querySelector("#knob").style.transform=`translate(${this.stick.x*36}px,${this.stick.y*36}px)`};s.addEventListener("pointerdown",o=>{!t()||this.pointer!==null||(o.preventDefault(),this.pointer=o.pointerId,s.setPointerCapture(o.pointerId),a(o))}),s.addEventListener("pointermove",o=>{this.pointer===o.pointerId&&a(o)});for(const o of["pointerup","pointercancel","lostpointercapture"])s.addEventListener(o,c=>{this.pointer===c.pointerId&&this.clear()});addEventListener("keydown",o=>{var c;(c=o.target)!=null&&c.matches("input,textarea,select")||!t()&&o.code!=="Escape"||(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(o.code)&&o.preventDefault(),this.keys.add(o.code),o.repeat||i.action(o.code))}),addEventListener("keyup",o=>this.keys.delete(o.code)),addEventListener("blur",()=>this.clear()),document.addEventListener("visibilitychange",()=>this.clear())}clear(){var t;this.keys.clear(),this.pointer=null,this.stick={x:0,y:0},(t=this.gestures)==null||t.cancel();const e=document.querySelector("#knob");e&&(e.style.transform="")}movement(){return{forward:+(this.keys.has("KeyW")||this.keys.has("ArrowUp"))-+(this.keys.has("KeyS")||this.keys.has("ArrowDown"))-this.stick.y,right:+(this.keys.has("KeyD")||this.keys.has("ArrowRight"))-+(this.keys.has("KeyA")||this.keys.has("ArrowLeft"))+this.stick.x}}}const qt=n=>`${n.x},${n.y},${n.z}`;class Hc{constructor(e,t,i){this.obstacles=e,this.player=t,this.changed=i}blocks=[];past=[];future=[];reason(e,t=!0,i){return zc(e,this.blocks.filter(r=>!i||qt(r)!==qt(i)),this.obstacles(),this.player(),t)}apply(e,t,i=!1,r=!1){const s=t?e.before:e.after,a=t?e.after:e.before,o=new Set(s.map(qt));if(s.some(l=>!this.blocks.some(d=>qt(d)===qt(l))))return"The original object changed";const c=this.blocks.filter(l=>!o.has(qt(l)));for(const l of a){if(c.some(d=>qt(d)===qt(l)))return"Find a clear space";if(i){const d=zc(l,c,this.obstacles(),this.player(),r);if(d)return d}else if(pt(l).some(d=>It(d,Bi(this.player()))||[...this.obstacles(),...c.flatMap(pt)].some(h=>It(d,h))))return"That space is occupied";c.push({...l})}return this.blocks.splice(0,this.blocks.length,...c),""}notify(e,t){for(const i of t?e.before:e.after)this.changed(i,!1);for(const i of t?e.after:e.before)this.changed(i,!0)}execute(e,t){const i=this.apply(e,!0,!0,t);return i||(this.past.push(structuredClone(e)),this.past.length>100&&this.past.shift(),this.future=[],this.notify(e,!0),"")}place(e,t=!0){return this.execute({before:[],after:[{...e}]},t)}placeMany(e,t=!0){return this.execute({before:[],after:e.map(i=>({...i}))},t)}move(e,t,i=!0){return this.execute({before:[{...e}],after:[{...t}]},i)}toggle(e){const t=Jt.get(e.type);if((t==null?void 0:t.interaction)==="door"){const i=[...this.obstacles(),...this.blocks.filter(r=>qt(r)!==qt(e)).flatMap(r=>pt(r)),Bi(this.player())];for(let r=0;r<=12;r++){const s=(e.open?1:0)+(e.open?-1:1)*r/12;if(y0(e,s).some(a=>i.some(o=>It(a,o))))return"Door swing blocked — make a little room"}}return this.execute({before:[{...e}],after:[{...e,...(t==null?void 0:t.interaction)==="light"?{on:e.on===!1}:{open:!e.open}}]},!1)}remove(e){const t=this.blocks.find(i=>qt(i)===qt(e));return!!t&&this.execute({before:[{...t}],after:[]},!1)===""}undo(){const e=this.past.at(-1);return!e||this.apply(e,!1)?!1:(this.past.pop(),this.future.push(e),this.notify(e,!1),!0)}redo(){const e=this.future.at(-1);return!e||this.apply(e,!0)?!1:(this.future.pop(),this.past.push(e),this.notify(e,!0),!0)}reset(e){this.blocks.splice(0,this.blocks.length,...e.map(t=>({...t}))),this.past=[],this.future=[]}get canUndo(){return!!this.past.length}get canRedo(){return!!this.future.length}}const ki=Math.PI/2,K0=ki/.65,$0=2.25,J0=3.1,Q0=1.2;function Vl(n){if(n.kind==="roller"){const e=Math.max(0,Math.min(1,n.angle/ki));n.leaf.scale.y=Math.max(.001,1-e),n.leaf.position.y=e*n.height,n.pivot.rotation.y=n.baseAngle}else n.pivot.rotation.y=n.baseAngle+n.angle}function eg(n,e=!1,t=-1){n.kind==="roller"&&(t=1),Object.assign(n,{open:e,targetOpen:e,swing:t,angle:e?t*ki:0,leaveSince:null,manualHold:!1,lastAttempt:-1/0,blocked:!1}),Vl(n)}function Vc(n,e,t){return Math.abs(e.y)<2.3&&Math.hypot(e.x-n.center.x,e.z-n.center.z)<t}function Ra(n,e,t,i,r,s){const a=Math.max(1,Math.ceil(Math.abs(t-e)/.02)),o=[Ll(i),...r.map(Zn),...s];for(let c=0;c<=a;c++){const l=kl(n,e+(t-e)*c/a);if(o.some(d=>Fi(l,d)))return!1}return!0}function Ca(n,e,t,i,r=[],s=!1){const a=n.angle??(n.open?(n.swing??-1)*ki:0);if(e){const o=(t.x-n.center.x)*Math.sin(n.baseAngle)+(t.z-n.center.z)*Math.cos(n.baseAngle),c=n.kind==="roller"?1:Math.abs(a)>.01?n.swing??-1:o>=0?1:-1;for(const l of Math.abs(a)>.01?[c]:[c,-c])if(Ra(n,a,l*ki,t,i,r))return n.swing=l,n.targetOpen=n.open=!0,n.manualHold=s,n.blocked=!1,{ok:!0}}else if(Ra(n,a,0,t,i,r))return n.targetOpen=n.open=!1,n.manualHold=s,n.blocked=!1,{ok:!0};return{ok:!1,message:e?"There is something in the door’s swing. Make room beside it.":"The door stays open while someone or something is in its way."}}function tg(n,e,t,i,r,s,a,o=null,c="normal"){const l=$0*Cl(c)/3.4,d=Math.max(J0,l+.85);let h=!1;for(const u of n){let m;const M=()=>m??=(o==null?void 0:o(u))??{blocks:t,solids:i},_=Vc(u,e,d);_?u.leaveSince=null:(u.leaveSince??=s,u.manualHold=!1),r&&!u.manualHold&&s-u.lastAttempt>.3&&(Vc(u,e,l)&&!u.targetOpen?(u.lastAttempt=s,Ca(u,!0,e,M().blocks,M().solids)):!_&&u.targetOpen&&s-u.leaveSince>Q0&&(u.lastAttempt=s,Ca(u,!1,e,M().blocks,M().solids)));let f=(u.targetOpen?u.swing*ki:0)-u.angle;const x=Math.sign(f)*Math.min(Math.abs(f),Math.max(0,a)*K0),g=Math.max(1,Math.ceil(Math.abs(x)/.02));for(let v=0;v<g&&Math.abs(x)>1e-8;v++){const C=u.angle+x/g;if(!Ra(u,u.angle,C,e,M().blocks,M().solids)){u.blocked=!0,u.targetOpen||(u.targetOpen=u.open=!0,u.manualHold=!1,u.leaveSince=null);break}u.angle=C,u.blocked=!1,h=!0}Vl(u)}return h}const ng=tg;class ig{activity=null;seated=null;body=Hl();cameraMode="first";flying=!1;vertical=0;view;world;worldGroup=new gt;buildGroup=new gt;preview=new gt;player={...wn[0].spawn,vy:0,grounded:!0};selected="hand";favourites=[];recent=[];pending=null;moving=null;pickingMove=!1;automatic=!0;guard=!0;paused=!1;template="legacy-06";controls;commands;chunks;index=new zi;clock=new q0;ray=new o0;geometry=new vt(1,1,1);materials={};decor=new Map;noticeTimer=0;onEdit=()=>{};constructor(){document.querySelector("#app").innerHTML='<canvas id="world" tabindex="-1" aria-label="Drag to look; tap to build; hold to remove"></canvas><div class="brand">BLOCKWORLD <b>2.0</b><small>Sunbeam Town · Development preview</small></div><nav id="top"><button id="home" aria-label="Return home">⌂</button><button id="doorMode" aria-label="Automatic doors" aria-pressed="true">🚪 Auto</button><button id="guard" aria-label="Edge protection" aria-pressed="true">🛡</button><button id="cameraMode" aria-label="Switch camera">👤</button><button id="flyMode" aria-label="Creative flight" aria-pressed="false">🪽</button><button id="mapButton" aria-label="World map">🗺</button><button id="catalogueButton" aria-label="Building catalogue">▦</button><button id="worlds" aria-label="Worlds">🌍</button></nav><output id="status" role="status" aria-live="polite">Starting…</output><div id="crosshair">+</div><div id="joystick" aria-label="Move joystick"><div id="knob"></div></div><div id="actions"><button id="use" aria-label="Use nearby object">🚪</button><button id="undo" aria-label="Undo">↶</button><button id="redo" aria-label="Redo">↷</button><button id="jump" aria-label="Jump">↑</button></div><div id="palette" aria-label="Building hotbar"></div><button id="moveObject" aria-label="Move a built object">✥ Move</button><div id="flightControls" hidden><button id="flyUp" aria-label="Fly up">⇧</button><button id="flyDown" aria-label="Fly down">⇩</button></div><div id="previewControls" hidden><button id="cancel" aria-label="Cancel placement">✕</button><button id="rotate" aria-label="Rotate preview">↻</button><button id="confirm" aria-label="Confirm placement">✓</button></div><div id="modal" hidden></div>',this.view=X0(document.querySelector("#world")),this.view.scene.add(this.worldGroup,this.buildGroup,this.preview,this.body.group);for(const e of ur)this.materials[e.id]=new Vt({color:e.color});this.chunks=new E0(this.buildGroup,this.geometry,this.materials,e=>(this.decor.has(e)||this.decor.set(e,new Vt({color:e})),this.decor.get(e))),this.commands=new Hc(()=>this.obstacles(),()=>this.player,(e,t)=>{this.chunks.update(e,t),this.refreshHistory(),this.onEdit()}),this.load("sunbeam-town"),this.controls=new j0(document.querySelector("#world"),()=>!this.paused,{tap:(e,t)=>this.tap(e,t),hold:(e,t)=>this.removeAt(e,t),look:(e,t)=>{this.player.yaw-=e*.004,this.player.pitch=Math.max(-1.3,Math.min(1.3,this.player.pitch-t*.0035))},action:e=>this.key(e),pose:()=>this.player}),this.ui(),this.clock.reset(performance.now()),requestAnimationFrame(e=>this.frame(e)),this.notice("Ready · choose a picture to build")}load(e,t=[],i,r={},s){var l,d;const a=new gt,o=z0(a,e,t),c=new zi;for(const h of o.solids)c.add(h);if(t.some(h=>c.query(Wa(h)).some(u=>pt(h).some(m=>It(m,u.ramp?{...u,ramp:null}:u)))))throw this.clearGroup(a),Error("Saved objects overlap permanent structures; active progress is unchanged");if((e==="home-square"||e==="sunbeam-town")&&(s!=null&&s.car)&&[...o.solids,...t.flatMap(pt)].some(h=>It(Yt(s.car),h)))throw this.clearGroup(a),Error("Saved vehicle overlaps structures; active world is retained");this.seated=null,(l=this.activity)==null||l.dispose(),this.activity=null,this.flying=!1,this.vertical=0,this.clearGroup(this.worldGroup);for(const h of[...a.children])this.worldGroup.add(h);this.chunks.clear(),this.template=e,this.world=o,this.index=c,(e==="home-square"||e==="sunbeam-town")&&(this.activity=new V0(this.view.scene,this.world.activityRange||47),this.activity.load(s));for(const h of this.world.doors)eg(h,r[h.id]===!0,-1);this.player={...((d=wn.find(h=>h.id===e))==null?void 0:d.spawn)||wn[0].spawn,...i,vy:0,grounded:!0},this.commands.reset(t),this.chunks.reset(t),this.cancel(),Pi(this.player,this.nearbySolids())&&this.home(),this.refreshHistory(),this.updateCamera()}clearGroup(e){const t=new Set,i=new Set,r=new Set;e.traverse(s=>{if(s.isSprite&&(i.add(s.material),s.material.map&&r.add(s.material.map)),s.isMesh){t.add(s.geometry);for(const a of Array.isArray(s.material)?s.material:[s.material])i.add(a),a.map&&r.add(a.map);s.isInstancedMesh&&s.dispose()}}),t.forEach(s=>s.dispose()),i.forEach(s=>s.dispose()),r.forEach(s=>s.dispose()),e.clear()}obstacles(){return[...this.world.solids,...this.world.doors.map(e=>tr(e)),...this.activity?[Yt(this.activity.car)]:[]]}nearbySolids(){return[...this.activity&&!this.activity.driving?[Yt(this.activity.car)]:[],...this.index.query(Gr(this.player,3)),...this.commands.blocks.filter(e=>Math.abs(e.x-this.player.x)<4&&Math.abs(e.z-this.player.z)<4).flatMap(pt),...this.world.doors.filter(e=>Math.hypot(e.center.x-this.player.x,e.center.z-this.player.z)<6).map(e=>tr(e))]}update(e){var s,a;ng(this.world.doors,this.player,this.commands.blocks,this.world.solids,this.automatic,performance.now()/1e3,e,o=>({solids:[...this.index.query(Gr({...o.center,y:0},4)),...this.activity?[Yt(this.activity.car)]:[],...this.commands.blocks.filter(c=>Math.hypot(c.x-o.center.x,c.z-o.center.z)<6).flatMap(pt).map(c=>c.ramp?{...c,ramp:null}:c)],blocks:[]}));const t=this.controls.movement(),i=this.nearbySolids(),r=[...this.world.solids,...this.world.doors.map(o=>tr(o)),...this.commands.blocks.flatMap(pt)];this.seated&&Math.abs(t.forward)+Math.abs(t.right)>.2&&this.stand(),!((s=this.activity)!=null&&s.driving)&&!this.seated&&(this.flying?G0(this.player,t,this.vertical+ +this.controls.keys.has("Space")-+(this.controls.keys.has("ShiftLeft")||this.controls.keys.has("ShiftRight")),e,i):A0(this.player,{...t,edgeProtection:this.guard,walkSpeed:"normal"},e,i)),(a=this.activity)==null||a.update(e,this.player,t,r)}frame(e){requestAnimationFrame(t=>this.frame(t)),this.paused||document.hidden?this.clock.reset(e):this.clock.tick(e,t=>this.update(t)),this.updateCamera(),this.world.staticRender.updateVisibility(this.view.camera,155),this.view.renderer.render(this.view.scene,this.view.camera)}updateCamera(){var e;this.body.group.position.set(this.player.x,this.seated?this.seated.height-.65:this.player.y,this.player.z),this.body.left.rotation.x=this.body.right.rotation.x=this.seated?-1.2:0,this.body.group.rotation.y=this.player.yaw,this.body.group.visible=!1,this.cameraMode==="third"?this.body.group.visible=H0(this.view.camera,this.player,[...this.index.query(Gr(this.player,8)),...this.world.doors.map(t=>tr(t)),...this.commands.blocks.filter(t=>Math.abs(t.x-this.player.x)<8&&Math.abs(t.z-this.player.z)<8).flatMap(pt)])&&!((e=this.activity)!=null&&e.driving):(this.view.camera.position.set(this.player.x,this.seated?this.seated.height+.9:this.player.y+1.53,this.player.z),this.view.camera.rotation.set(this.player.pitch,this.player.yaw,0),this.view.camera.updateMatrixWorld())}hit(e=innerWidth/2,t=innerHeight/2){var o,c,l;this.updateCamera(),this.view.scene.updateMatrixWorld(!0),this.ray.setFromCamera(new Oe(e/innerWidth*2-1,1-t/innerHeight*2),this.view.camera);const i=this.ray.intersectObjects([...this.chunks.rayMeshes(),this.world.ground],!1)[0];if(!i||i.distance>8)return null;for(const d of[...this.index.query(Gr(this.player,9)),...this.world.doors.map(h=>tr(h))])if(Aa(this.ray.ray,d)<i.distance-.02)return null;const r=i.object.userData,s=((o=r.faceBlocks)==null?void 0:o[i.faceIndex])||((c=r.blocks)==null?void 0:c[i.instanceId])||r.block;let a;if(s){const d=i.face.normal.clone().transformDirection(i.object.matrixWorld);if(i.object.isInstancedMesh){const u=new Qe;i.object.getMatrixAt(i.instanceId,u),d.copy(i.face.normal).transformDirection(u).transformDirection(i.object.matrixWorld)}const h=i.point.clone().addScaledVector(d,.015);if(a={x:Math.floor(h.x),y:d.y>.9?Math.ceil(i.point.y*100-1e-5)/100:d.y<-.9?Math.floor(i.point.y)-1:s.y,z:Math.floor(h.z),type:this.selected},!((l=Jt.get(s.type))!=null&&l.cube)){const u=["x","y","z"].sort((m,M)=>Math.abs(d[M])-Math.abs(d[m]))[0];u!=="y"?(a={...s,type:this.selected},a[u]+=Math.sign(d[u])):d.y<0&&(a.y=Math.floor(i.point.y)-1)}}else a={x:Math.floor(i.point.x),y:0,z:Math.floor(i.point.z),type:this.selected};return{target:s,aim:a}}tap(e,t){var a,o,c;if(this.paused)return;if((a=this.activity)!=null&&a.driving){this.notice("Park before building");return}const i=this.hit(e,t);if(this.pickingMove){if(!(i!=null&&i.target)){this.notice("Tap an object you built");return}this.moving={...i.target},this.pending={...i.target},this.pickingMove=!1,this.showPreview(),this.notice("Tap its new spot, turn it, then confirm");return}if(this.moving&&i){this.pending={...i.aim,type:this.moving.type,rotation:((o=this.pending)==null?void 0:o.rotation)||0},this.showPreview();return}if(this.selected==="hand"){this.use();return}const r=i;if(!r){this.notice("Move closer to a clear space");return}const s=this.placementReason(r.aim);if(s){this.notice(s);return}(c=Jt.get(this.selected))!=null&&c.cube?this.notice(this.commands.place(r.aim)||"✓ Placed"):(this.pending={...r.aim,rotation:0},this.showPreview())}removeAt(e,t){if(this.paused)return;const i=this.hit(e,t);i!=null&&i.target&&(this.cancel(),this.commands.remove(i.target),this.notice("↶ Removed — Undo brings it back"))}showPreview(){this.preview.traverse(e=>{e.isMesh&&e.material.dispose()}),this.preview.clear(),this.pending&&(this.preview.add(ys(this.pending,!0)),document.querySelector("#previewControls").hidden=!1,document.querySelector("#confirm").disabled=!!this.placementReason(this.pending))}cancel(){this.pending=null,this.moving=null,this.pickingMove=!1,this.preview.traverse(t=>{t.isMesh&&t.material.dispose()}),this.preview.clear();const e=document.querySelector("#previewControls");e&&(e.hidden=!0)}confirm(){if(!this.pending)return;const e=this.moving?this.commands.move(this.moving,this.pending):this.commands.placeMany(wa(this.pending));e?this.notice(e):(this.cancel(),this.notice("✓ Placed"))}stand(){if(!this.seated)return!0;try{return Object.assign(this.player,hs(this.seated.entry,[...this.obstacles(),...this.commands.blocks.flatMap(pt)])),this.seated=null,this.refreshModes(),this.onEdit(),!0}catch(e){return this.notice(String(e)),!1}}use(){if(this.seated){this.stand();return}const e=this.commands.blocks.filter(a=>{var o;return["door","light"].includes(((o=Jt.get(a.type))==null?void 0:o.interaction)||"")&&Math.hypot(a.x+.5-this.player.x,a.z+.5-this.player.z)<2.4&&Math.abs(a.y-this.player.y)<2}).sort((a,o)=>Math.hypot(a.x-this.player.x,a.z-this.player.z)-Math.hypot(o.x-this.player.x,o.z-this.player.z))[0];if(e){this.notice(this.commands.toggle(e)||"✓ Used");return}const i=[...this.world.seats||[],...this.commands.blocks.filter(a=>{var o;return((o=Jt.get(a.type))==null?void 0:o.interaction)==="seat"}).map(a=>({x:a.x+.5,z:a.z+.5,y:a.y,rotation:a.rotation||0}))].filter(a=>Math.abs((a.y||0)-this.player.y)<1.2&&Math.hypot(a.x-this.player.x,a.z-this.player.z)<2).sort((a,o)=>Math.hypot(a.x-this.player.x,a.z-this.player.z)-Math.hypot(o.x-this.player.x,o.z-this.player.z))[0];if(i){const a=new z(this.player.x,this.player.y+1.3,this.player.z),o=new z(i.x,(i.y||0)+1.2,i.z),c=a.distanceTo(o),l=new hr(a,o.sub(a).normalize());if(![...this.obstacles(),...this.commands.blocks.flatMap(pt)].some(d=>Aa(l,d)<c-.2)){this.seated={entry:{x:this.player.x,z:this.player.z,yaw:this.player.yaw},height:(i.y||0)+.4},Object.assign(this.player,{x:i.x,y:i.y||0,z:i.z,yaw:(i.rotation||0)*Math.PI/180,vy:0,grounded:!0}),this.flying=!1,this.vertical=0,this.controls.clear(),this.refreshModes(),this.notice("🪑 Sitting · move or tap Use to stand"),this.onEdit();return}}if(this.activity)try{const a=this.activity.use(this.player,[...this.obstacles(),...this.commands.blocks.flatMap(pt)]);if(a){this.flying=!1,this.vertical=0,this.refreshModes(),this.controls.clear(),this.notice(a),this.onEdit();return}}catch(a){this.notice(String(a));return}const r=this.world.doors.filter(a=>Math.abs(this.player.y)<2.3&&Math.hypot(a.center.x-this.player.x,a.center.z-this.player.z)<3.2).sort((a,o)=>Math.hypot(a.center.x-this.player.x,a.center.z-this.player.z)-Math.hypot(o.center.x-this.player.x,o.center.z-this.player.z))[0];if(!r){this.notice("Walk closer to a door");return}const s=Ca(r,!r.targetOpen,this.player,[],[...this.world.solids,...this.activity?[Yt(this.activity.car)]:[],...this.commands.blocks.flatMap(pt).map(a=>a.ramp?{...a,ramp:null}:a)],!0);this.notice(s.ok?"🚪 Door":s.message||"Clear the doorway"),this.onEdit()}home(){var e,t;Object.assign(this.player,hs(((e=wn.find(i=>i.id===this.template))==null?void 0:e.spawn)||wn[0].spawn,[...this.obstacles(),...this.commands.blocks.flatMap(pt)])),this.seated=null,this.flying=!1,this.activity&&(this.activity.driving=!1),this.vertical=0,this.refreshModes(),(t=this.controls)==null||t.clear(),this.cancel()}jump(){var e;if(this.seated){this.stand();return}!this.paused&&!this.flying&&!((e=this.activity)!=null&&e.driving)&&this.player.grounded&&(this.player.vy=6,this.player.grounded=!1)}key(e){e==="Space"&&this.jump(),e==="KeyE"&&this.use(),e==="KeyF"&&this.tap(innerWidth/2,innerHeight/2),e==="KeyR"&&(this.pending?(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview()):this.removeAt(innerWidth/2,innerHeight/2)),e==="Enter"&&this.confirm(),e==="KeyZ"&&this.commands.undo(),e==="KeyY"&&this.commands.redo(),e==="Escape"&&this.cancel()}ui(){const e=(t,i)=>document.querySelector("#"+t).onclick=i;e("cameraMode",()=>{this.cameraMode=this.cameraMode==="first"?"third":"first",this.refreshModes(),this.onEdit()}),e("flyMode",()=>{var t;if(!(this.seated&&!this.stand())){if((t=this.activity)!=null&&t.driving){this.notice("Leave the car before flying");return}this.flying=!this.flying,this.player.vy=0,document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),this.onEdit()}}),e("mapButton",()=>W0(this)),e("catalogueButton",()=>this.catalogue());for(const[t,i]of[["flyUp",1],["flyDown",-1]]){const r=document.querySelector("#"+t);r.onpointerdown=s=>{s.preventDefault(),r.setPointerCapture(s.pointerId),this.vertical=i};for(const s of["pointerup","pointercancel","lostpointercapture"])r.addEventListener(s,()=>this.vertical=0)}addEventListener("blur",()=>this.vertical=0),e("moveObject",()=>{this.paused||(this.cancel(),this.pickingMove=!0,this.notice("Tap an object you built to move it"))}),document.addEventListener("visibilitychange",()=>this.vertical=0),e("home",()=>this.home()),e("jump",()=>this.jump()),e("use",()=>this.use()),e("undo",()=>this.commands.undo()),e("redo",()=>this.commands.redo()),e("cancel",()=>this.cancel()),e("rotate",()=>{this.pending&&(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview())}),e("confirm",()=>this.confirm()),e("doorMode",()=>{this.automatic=!this.automatic,document.querySelector("#doorMode").setAttribute("aria-pressed",String(this.automatic))}),e("guard",()=>{this.guard=!this.guard,document.querySelector("#guard").setAttribute("aria-pressed",String(this.guard))}),Ta(this),document.querySelector("#palette").addEventListener("click",t=>{const i=t.target.closest("[data-item]");!i||this.paused||this.choose(i.dataset.item,!0)})}catalogue(){T0(this)}choose(e,t=!1){this.selected=t&&this.selected===e?"hand":e,this.recent=[e,...this.recent.filter(i=>i!==e)].slice(0,8),this.cancel(),Ta(this),this.refreshSelection(),this.onEdit()}placementReason(e){if(this.moving)return this.commands.reason(e,!0,this.moving);if(!Xa.some(i=>i.id===e.type))return this.commands.reason(e);const t=new Hc(()=>this.obstacles(),()=>this.player,()=>{});return t.reset(this.commands.blocks),t.placeMany(wa(e))}refreshSelection(){document.querySelectorAll("[data-item]").forEach(e=>e.setAttribute("aria-pressed",String(e.dataset.item===this.selected)))}refreshModes(){var e;this.refreshSelection(),document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),document.querySelector("#cameraMode").setAttribute("aria-pressed",String(this.cameraMode==="third")),document.querySelector("#use").textContent=this.seated?"🪑":(e=this.activity)!=null&&e.driving?"🚶":"✋"}refreshHistory(){const e=document.querySelector("#undo"),t=document.querySelector("#redo");e&&(e.disabled=!this.commands.canUndo),t&&(t.disabled=!this.commands.canRedo)}notice(e){const t=document.querySelector("#status");t.textContent=e,clearTimeout(this.noticeTimer),this.noticeTimer=window.setTimeout(()=>t.textContent="",5e3)}snapshot(){var e;return{favourites:this.favourites,recent:this.recent,camera:this.cameraMode,flying:this.flying,activity:(e=this.activity)==null?void 0:e.snapshot(),template:this.template,player:{...this.player},blocks:this.commands.blocks.map(t=>({...t})),doors:Object.fromEntries(this.world.doors.map(t=>[t.id,t.targetOpen])),selected:this.selected}}}try{const n=new ig,e=new O0(n);new URLSearchParams(location.search).get("test")==="1"&&Object.assign(window,{bw2:{session:e,game:n,snapshot:()=>n.snapshot(),setPlayer:t=>Object.assign(n.player,t),simulate:(t,i)=>{const r=n.controls.movement;n.controls.movement=()=>t;for(let s=0;s<i;s+=1/60)n.update(1/60);n.controls.movement=r},add:t=>n.commands.place(t,!1)}}),"serviceWorker"in navigator&&navigator.serviceWorker.register("./sw.js",{scope:"./"}).catch(()=>n.notice("Offline preparation unavailable; export a backup before closing."))}catch(n){const e=document.createElement("p");e.textContent=`Could not start: ${String(n)}`,document.querySelector("#app").append(e),console.error(n)}
