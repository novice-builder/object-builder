(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))i(r);new MutationObserver(r=>{for(const s of r)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&i(a)}).observe(document,{childList:!0,subtree:!0});function t(r){const s={};return r.integrity&&(s.integrity=r.integrity),r.referrerPolicy&&(s.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?s.credentials="include":r.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(r){if(r.ep)return;r.ep=!0;const s=t(r);fetch(r.href,s)}})();/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const Wa="160",gh=0,po=1,xh=2,ac=1,_h=2,pn=3,yn=0,Bt=1,yt=2,Dn=0,Ni=1,mo=2,go=3,xo=4,vh=5,$n=100,yh=101,Mh=102,_o=103,vo=104,Sh=200,bh=201,wh=202,Eh=203,ba=204,wa=205,Th=206,Ah=207,Rh=208,Ch=209,Ph=210,Lh=211,Dh=212,Ih=213,Uh=214,zh=0,Nh=1,Fh=2,ns=3,Oh=4,kh=5,Bh=6,Gh=7,Xa=0,Hh=1,Vh=2,In=0,Wh=1,Xh=2,qh=3,Yh=4,jh=5,Zh=6,oc=300,Bi=301,Gi=302,Ea=303,Ta=304,_s=306,Aa=1e3,rn=1001,Ra=1002,Pt=1003,yo=1004,Fs=1005,$t=1006,$h=1007,ur=1008,Un=1009,Kh=1010,Jh=1011,qa=1012,lc=1013,Cn=1014,Pn=1015,dr=1016,cc=1017,hc=1018,ei=1020,Qh=1021,sn=1023,eu=1024,tu=1025,ti=1026,Hi=1027,nu=1028,uc=1029,iu=1030,dc=1031,fc=1033,Os=33776,ks=33777,Bs=33778,Gs=33779,Mo=35840,So=35841,bo=35842,wo=35843,pc=36196,Eo=37492,To=37496,Ao=37808,Ro=37809,Co=37810,Po=37811,Lo=37812,Do=37813,Io=37814,Uo=37815,zo=37816,No=37817,Fo=37818,Oo=37819,ko=37820,Bo=37821,Hs=36492,Go=36494,Ho=36495,ru=36283,Vo=36284,Wo=36285,Xo=36286,mc=3e3,ni=3001,su=3200,au=3201,gc=0,ou=1,Jt="",xt="srgb",Mn="srgb-linear",Ya="display-p3",vs="display-p3-linear",is="linear",ct="srgb",rs="rec709",ss="p3",li=7680,qo=519,lu=512,cu=513,hu=514,xc=515,uu=516,du=517,fu=518,pu=519,Ca=35044,Yo="300 es",Pa=1035,xn=2e3,as=2001;class Zi{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const r=this._listeners[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const i=this._listeners[e.type];if(i!==void 0){e.target=this;const r=i.slice(0);for(let s=0,a=r.length;s<a;s++)r[s].call(this,e);e.target=null}}}const At=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Vs=Math.PI/180,La=180/Math.PI;function zn(){const n=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0;return(At[n&255]+At[n>>8&255]+At[n>>16&255]+At[n>>24&255]+"-"+At[e&255]+At[e>>8&255]+"-"+At[e>>16&15|64]+At[e>>24&255]+"-"+At[t&63|128]+At[t>>8&255]+"-"+At[t>>16&255]+At[t>>24&255]+At[i&255]+At[i>>8&255]+At[i>>16&255]+At[i>>24&255]).toLowerCase()}function kt(n,e,t){return Math.max(e,Math.min(t,n))}function mu(n,e){return(n%e+e)%e}function Ws(n,e,t){return(1-t)*n+t*e}function jo(n){return(n&n-1)===0&&n!==0}function Da(n){return Math.pow(2,Math.floor(Math.log(n)/Math.LN2))}function gn(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return n/4294967295;case Uint16Array:return n/65535;case Uint8Array:return n/255;case Int32Array:return Math.max(n/2147483647,-1);case Int16Array:return Math.max(n/32767,-1);case Int8Array:return Math.max(n/127,-1);default:throw new Error("Invalid component type.")}}function nt(n,e){switch(e.constructor){case Float32Array:return n;case Uint32Array:return Math.round(n*4294967295);case Uint16Array:return Math.round(n*65535);case Uint8Array:return Math.round(n*255);case Int32Array:return Math.round(n*2147483647);case Int16Array:return Math.round(n*32767);case Int8Array:return Math.round(n*127);default:throw new Error("Invalid component type.")}}class Oe{constructor(e=0,t=0){Oe.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,i=this.y,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6],this.y=r[1]*t+r[4]*i+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(kt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const i=Math.cos(t),r=Math.sin(t),s=this.x-e.x,a=this.y-e.y;return this.x=s*i-a*r+e.x,this.y=s*r+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Xe{constructor(e,t,i,r,s,a,o,l,c){Xe.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,l,c)}set(e,t,i,r,s,a,o,l,c){const d=this.elements;return d[0]=e,d[1]=r,d[2]=o,d[3]=t,d[4]=s,d[5]=l,d[6]=i,d[7]=a,d[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[3],l=i[6],c=i[1],d=i[4],u=i[7],h=i[2],m=i[5],_=i[8],x=r[0],p=r[3],f=r[6],v=r[1],g=r[4],y=r[7],R=r[2],T=r[5],C=r[8];return s[0]=a*x+o*v+l*R,s[3]=a*p+o*g+l*T,s[6]=a*f+o*y+l*C,s[1]=c*x+d*v+u*R,s[4]=c*p+d*g+u*T,s[7]=c*f+d*y+u*C,s[2]=h*x+m*v+_*R,s[5]=h*p+m*g+_*T,s[8]=h*f+m*y+_*C,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8];return t*a*d-t*o*c-i*s*d+i*o*l+r*s*c-r*a*l}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=d*a-o*c,h=o*l-d*s,m=c*s-a*l,_=t*u+i*h+r*m;if(_===0)return this.set(0,0,0,0,0,0,0,0,0);const x=1/_;return e[0]=u*x,e[1]=(r*c-d*i)*x,e[2]=(o*i-r*a)*x,e[3]=h*x,e[4]=(d*t-r*l)*x,e[5]=(r*s-o*t)*x,e[6]=m*x,e[7]=(i*l-c*t)*x,e[8]=(a*t-i*s)*x,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,r,s,a,o){const l=Math.cos(s),c=Math.sin(s);return this.set(i*l,i*c,-i*(l*a+c*o)+a+e,-r*c,r*l,-r*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(Xs.makeScale(e,t)),this}rotate(e){return this.premultiply(Xs.makeRotation(-e)),this}translate(e,t){return this.premultiply(Xs.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<9;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Xs=new Xe;function _c(n){for(let e=n.length-1;e>=0;--e)if(n[e]>=65535)return!0;return!1}function os(n){return document.createElementNS("http://www.w3.org/1999/xhtml",n)}function gu(){const n=os("canvas");return n.style.display="block",n}const Zo={};function hr(n){n in Zo||(Zo[n]=!0,console.warn(n))}const $o=new Xe().set(.8224621,.177538,0,.0331941,.9668058,0,.0170827,.0723974,.9105199),Ko=new Xe().set(1.2249401,-.2249404,0,-.0420569,1.0420571,0,-.0196376,-.0786361,1.0982735),Mr={[Mn]:{transfer:is,primaries:rs,toReference:n=>n,fromReference:n=>n},[xt]:{transfer:ct,primaries:rs,toReference:n=>n.convertSRGBToLinear(),fromReference:n=>n.convertLinearToSRGB()},[vs]:{transfer:is,primaries:ss,toReference:n=>n.applyMatrix3(Ko),fromReference:n=>n.applyMatrix3($o)},[Ya]:{transfer:ct,primaries:ss,toReference:n=>n.convertSRGBToLinear().applyMatrix3(Ko),fromReference:n=>n.applyMatrix3($o).convertLinearToSRGB()}},xu=new Set([Mn,vs]),tt={enabled:!0,_workingColorSpace:Mn,get workingColorSpace(){return this._workingColorSpace},set workingColorSpace(n){if(!xu.has(n))throw new Error(`Unsupported working color space, "${n}".`);this._workingColorSpace=n},convert:function(n,e,t){if(this.enabled===!1||e===t||!e||!t)return n;const i=Mr[e].toReference,r=Mr[t].fromReference;return r(i(n))},fromWorkingColorSpace:function(n,e){return this.convert(n,this._workingColorSpace,e)},toWorkingColorSpace:function(n,e){return this.convert(n,e,this._workingColorSpace)},getPrimaries:function(n){return Mr[n].primaries},getTransfer:function(n){return n===Jt?is:Mr[n].transfer}};function Fi(n){return n<.04045?n*.0773993808:Math.pow(n*.9478672986+.0521327014,2.4)}function qs(n){return n<.0031308?n*12.92:1.055*Math.pow(n,.41666)-.055}let ci;class vc{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{ci===void 0&&(ci=os("canvas")),ci.width=e.width,ci.height=e.height;const i=ci.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=ci}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=os("canvas");t.width=e.width,t.height=e.height;const i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);const r=i.getImageData(0,0,e.width,e.height),s=r.data;for(let a=0;a<s.length;a++)s[a]=Fi(s[a]/255)*255;return i.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(Fi(t[i]/255)*255):t[i]=Fi(t[i]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let _u=0;class yc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:_u++}),this.uuid=zn(),this.data=e,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const i={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let a=0,o=r.length;a<o;a++)r[a].isDataTexture?s.push(Ys(r[a].image)):s.push(Ys(r[a]))}else s=Ys(r);i.url=s}return t||(e.images[this.uuid]=i),i}}function Ys(n){return typeof HTMLImageElement<"u"&&n instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&n instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&n instanceof ImageBitmap?vc.getDataURL(n):n.data?{data:Array.from(n.data),width:n.width,height:n.height,type:n.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let vu=0;class Gt extends Zi{constructor(e=Gt.DEFAULT_IMAGE,t=Gt.DEFAULT_MAPPING,i=rn,r=rn,s=$t,a=ur,o=sn,l=Un,c=Gt.DEFAULT_ANISOTROPY,d=Jt){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:vu++}),this.uuid=zn(),this.name="",this.source=new yc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=r,this.magFilter=s,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new Oe(0,0),this.repeat=new Oe(1,1),this.center=new Oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Xe,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,typeof d=="string"?this.colorSpace=d:(hr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=d===ni?xt:Jt),this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.needsPMREMUpdate=!1}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==oc)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Aa:e.x=e.x-Math.floor(e.x);break;case rn:e.x=e.x<0?0:1;break;case Ra:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Aa:e.y=e.y-Math.floor(e.y);break;case rn:e.y=e.y<0?0:1;break;case Ra:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}get encoding(){return hr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace===xt?ni:mc}set encoding(e){hr("THREE.Texture: Property .encoding has been replaced by .colorSpace."),this.colorSpace=e===ni?xt:Jt}}Gt.DEFAULT_IMAGE=null;Gt.DEFAULT_MAPPING=oc;Gt.DEFAULT_ANISOTROPY=1;class ut{constructor(e=0,t=0,i=0,r=1){ut.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,r){return this.x=e,this.y=t,this.z=i,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*r+a[12]*s,this.y=a[1]*t+a[5]*i+a[9]*r+a[13]*s,this.z=a[2]*t+a[6]*i+a[10]*r+a[14]*s,this.w=a[3]*t+a[7]*i+a[11]*r+a[15]*s,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,r,s;const l=e.elements,c=l[0],d=l[4],u=l[8],h=l[1],m=l[5],_=l[9],x=l[2],p=l[6],f=l[10];if(Math.abs(d-h)<.01&&Math.abs(u-x)<.01&&Math.abs(_-p)<.01){if(Math.abs(d+h)<.1&&Math.abs(u+x)<.1&&Math.abs(_+p)<.1&&Math.abs(c+m+f-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const g=(c+1)/2,y=(m+1)/2,R=(f+1)/2,T=(d+h)/4,C=(u+x)/4,z=(_+p)/4;return g>y&&g>R?g<.01?(i=0,r=.707106781,s=.707106781):(i=Math.sqrt(g),r=T/i,s=C/i):y>R?y<.01?(i=.707106781,r=0,s=.707106781):(r=Math.sqrt(y),i=T/r,s=z/r):R<.01?(i=.707106781,r=.707106781,s=0):(s=Math.sqrt(R),i=C/s,r=z/s),this.set(i,r,s,t),this}let v=Math.sqrt((p-_)*(p-_)+(u-x)*(u-x)+(h-d)*(h-d));return Math.abs(v)<.001&&(v=1),this.x=(p-_)/v,this.y=(u-x)/v,this.z=(h-d)/v,this.w=Math.acos((c+m+f-1)/2),this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class yu extends Zi{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new ut(0,0,e,t),this.scissorTest=!1,this.viewport=new ut(0,0,e,t);const r={width:e,height:t,depth:1};i.encoding!==void 0&&(hr("THREE.WebGLRenderTarget: option.encoding has been replaced by option.colorSpace."),i.colorSpace=i.encoding===ni?xt:Jt),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:$t,depthBuffer:!0,stencilBuffer:!1,depthTexture:null,samples:0},i),this.texture=new Gt(r,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.flipY=!1,this.texture.generateMipmaps=i.generateMipmaps,this.texture.internalFormat=i.internalFormat,this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}setSize(e,t,i=1){(this.width!==e||this.height!==t||this.depth!==i)&&(this.width=e,this.height=t,this.depth=i,this.texture.image.width=e,this.texture.image.height=t,this.texture.image.depth=i,this.dispose()),this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.texture=e.texture.clone(),this.texture.isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new yc(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ri extends yu{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}}class Mc extends Gt{constructor(e=null,t=1,i=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Pt,this.minFilter=Pt,this.wrapR=rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Mu extends Gt{constructor(e=null,t=1,i=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:r},this.magFilter=Pt,this.minFilter=Pt,this.wrapR=rn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class gr{constructor(e=0,t=0,i=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=r}static slerpFlat(e,t,i,r,s,a,o){let l=i[r+0],c=i[r+1],d=i[r+2],u=i[r+3];const h=s[a+0],m=s[a+1],_=s[a+2],x=s[a+3];if(o===0){e[t+0]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u;return}if(o===1){e[t+0]=h,e[t+1]=m,e[t+2]=_,e[t+3]=x;return}if(u!==x||l!==h||c!==m||d!==_){let p=1-o;const f=l*h+c*m+d*_+u*x,v=f>=0?1:-1,g=1-f*f;if(g>Number.EPSILON){const R=Math.sqrt(g),T=Math.atan2(R,f*v);p=Math.sin(p*T)/R,o=Math.sin(o*T)/R}const y=o*v;if(l=l*p+h*y,c=c*p+m*y,d=d*p+_*y,u=u*p+x*y,p===1-o){const R=1/Math.sqrt(l*l+c*c+d*d+u*u);l*=R,c*=R,d*=R,u*=R}}e[t]=l,e[t+1]=c,e[t+2]=d,e[t+3]=u}static multiplyQuaternionsFlat(e,t,i,r,s,a){const o=i[r],l=i[r+1],c=i[r+2],d=i[r+3],u=s[a],h=s[a+1],m=s[a+2],_=s[a+3];return e[t]=o*_+d*u+l*m-c*h,e[t+1]=l*_+d*h+c*u-o*m,e[t+2]=c*_+d*m+o*h-l*u,e[t+3]=d*_-o*u-l*h-c*m,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,r){return this._x=e,this._y=t,this._z=i,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const i=e._x,r=e._y,s=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(i/2),d=o(r/2),u=o(s/2),h=l(i/2),m=l(r/2),_=l(s/2);switch(a){case"XYZ":this._x=h*d*u+c*m*_,this._y=c*m*u-h*d*_,this._z=c*d*_+h*m*u,this._w=c*d*u-h*m*_;break;case"YXZ":this._x=h*d*u+c*m*_,this._y=c*m*u-h*d*_,this._z=c*d*_-h*m*u,this._w=c*d*u+h*m*_;break;case"ZXY":this._x=h*d*u-c*m*_,this._y=c*m*u+h*d*_,this._z=c*d*_+h*m*u,this._w=c*d*u-h*m*_;break;case"ZYX":this._x=h*d*u-c*m*_,this._y=c*m*u+h*d*_,this._z=c*d*_-h*m*u,this._w=c*d*u+h*m*_;break;case"YZX":this._x=h*d*u+c*m*_,this._y=c*m*u+h*d*_,this._z=c*d*_-h*m*u,this._w=c*d*u-h*m*_;break;case"XZY":this._x=h*d*u-c*m*_,this._y=c*m*u-h*d*_,this._z=c*d*_+h*m*u,this._w=c*d*u+h*m*_;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const i=t/2,r=Math.sin(i);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,i=t[0],r=t[4],s=t[8],a=t[1],o=t[5],l=t[9],c=t[2],d=t[6],u=t[10],h=i+o+u;if(h>0){const m=.5/Math.sqrt(h+1);this._w=.25/m,this._x=(d-l)*m,this._y=(s-c)*m,this._z=(a-r)*m}else if(i>o&&i>u){const m=2*Math.sqrt(1+i-o-u);this._w=(d-l)/m,this._x=.25*m,this._y=(r+a)/m,this._z=(s+c)/m}else if(o>u){const m=2*Math.sqrt(1+o-i-u);this._w=(s-c)/m,this._x=(r+a)/m,this._y=.25*m,this._z=(l+d)/m}else{const m=2*Math.sqrt(1+u-i-o);this._w=(a-r)/m,this._x=(s+c)/m,this._y=(l+d)/m,this._z=.25*m}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(kt(this.dot(e),-1,1)))}rotateTowards(e,t){const i=this.angleTo(e);if(i===0)return this;const r=Math.min(1,t/i);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const i=e._x,r=e._y,s=e._z,a=e._w,o=t._x,l=t._y,c=t._z,d=t._w;return this._x=i*d+a*o+r*c-s*l,this._y=r*d+a*l+s*o-i*c,this._z=s*d+a*c+i*l-r*o,this._w=a*d-i*o-r*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const i=this._x,r=this._y,s=this._z,a=this._w;let o=a*e._w+i*e._x+r*e._y+s*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=r,this._z=s,this;const l=1-o*o;if(l<=Number.EPSILON){const m=1-t;return this._w=m*a+t*this._w,this._x=m*i+t*this._x,this._y=m*r+t*this._y,this._z=m*s+t*this._z,this.normalize(),this}const c=Math.sqrt(l),d=Math.atan2(c,o),u=Math.sin((1-t)*d)/c,h=Math.sin(t*d)/c;return this._w=a*u+this._w*h,this._x=i*u+this._x*h,this._y=r*u+this._y*h,this._z=s*u+this._z*h,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){const e=Math.random(),t=Math.sqrt(1-e),i=Math.sqrt(e),r=2*Math.PI*Math.random(),s=2*Math.PI*Math.random();return this.set(t*Math.cos(r),i*Math.sin(s),i*Math.cos(s),t*Math.sin(r))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class N{constructor(e=0,t=0,i=0){N.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Jo.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Jo.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*i+s[6]*r,this.y=s[1]*t+s[4]*i+s[7]*r,this.z=s[2]*t+s[5]*i+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,i=this.y,r=this.z,s=e.elements,a=1/(s[3]*t+s[7]*i+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*i+s[8]*r+s[12])*a,this.y=(s[1]*t+s[5]*i+s[9]*r+s[13])*a,this.z=(s[2]*t+s[6]*i+s[10]*r+s[14])*a,this}applyQuaternion(e){const t=this.x,i=this.y,r=this.z,s=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*r-o*i),d=2*(o*t-s*r),u=2*(s*i-a*t);return this.x=t+l*c+a*u-o*d,this.y=i+l*d+o*c-s*u,this.z=r+l*u+s*d-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,i=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*i+s[8]*r,this.y=s[1]*t+s[5]*i+s[9]*r,this.z=s[2]*t+s[6]*i+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const i=e.x,r=e.y,s=e.z,a=t.x,o=t.y,l=t.z;return this.x=r*l-s*o,this.y=s*a-i*l,this.z=i*o-r*a,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return js.copy(this).projectOnVector(e),this.sub(js)}reflect(e){return this.sub(js.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const i=this.dot(e)/t;return Math.acos(kt(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,i=this.y-e.y,r=this.z-e.z;return t*t+i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){const r=Math.sin(t)*e;return this.x=r*Math.sin(i),this.y=Math.cos(t)*e,this.z=r*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=(Math.random()-.5)*2,t=Math.random()*Math.PI*2,i=Math.sqrt(1-e**2);return this.x=i*Math.cos(t),this.y=i*Math.sin(t),this.z=e,this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const js=new N,Jo=new gr;class Sn{constructor(e=new N(1/0,1/0,1/0),t=new N(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(en.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(en.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const i=en.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const i=e.geometry;if(i!==void 0){const s=i.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=s.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,en):en.fromBufferAttribute(s,a),en.applyMatrix4(e.matrixWorld),this.expandByPoint(en);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Sr.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Sr.copy(i.boundingBox)),Sr.applyMatrix4(e.matrixWorld),this.union(Sr)}const r=e.children;for(let s=0,a=r.length;s<a;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return!(e.x<this.min.x||e.x>this.max.x||e.y<this.min.y||e.y>this.max.y||e.z<this.min.z||e.z>this.max.z)}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return!(e.max.x<this.min.x||e.min.x>this.max.x||e.max.y<this.min.y||e.min.y>this.max.y||e.max.z<this.min.z||e.min.z>this.max.z)}intersectsSphere(e){return this.clampPoint(e.center,en),en.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Qi),br.subVectors(this.max,Qi),hi.subVectors(e.a,Qi),ui.subVectors(e.b,Qi),di.subVectors(e.c,Qi),bn.subVectors(ui,hi),wn.subVectors(di,ui),Bn.subVectors(hi,di);let t=[0,-bn.z,bn.y,0,-wn.z,wn.y,0,-Bn.z,Bn.y,bn.z,0,-bn.x,wn.z,0,-wn.x,Bn.z,0,-Bn.x,-bn.y,bn.x,0,-wn.y,wn.x,0,-Bn.y,Bn.x,0];return!Zs(t,hi,ui,di,br)||(t=[1,0,0,0,1,0,0,0,1],!Zs(t,hi,ui,di,br))?!1:(wr.crossVectors(bn,wn),t=[wr.x,wr.y,wr.z],Zs(t,hi,ui,di,br))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,en).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(en).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(cn[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),cn[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),cn[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),cn[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),cn[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),cn[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),cn[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),cn[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(cn),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const cn=[new N,new N,new N,new N,new N,new N,new N,new N],en=new N,Sr=new Sn,hi=new N,ui=new N,di=new N,bn=new N,wn=new N,Bn=new N,Qi=new N,br=new N,wr=new N,Gn=new N;function Zs(n,e,t,i,r){for(let s=0,a=n.length-3;s<=a;s+=3){Gn.fromArray(n,s);const o=r.x*Math.abs(Gn.x)+r.y*Math.abs(Gn.y)+r.z*Math.abs(Gn.z),l=e.dot(Gn),c=t.dot(Gn),d=i.dot(Gn);if(Math.max(-Math.max(l,c,d),Math.min(l,c,d))>o)return!1}return!0}const Su=new Sn,er=new N,$s=new N;class xr{constructor(e=new N,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const i=this.center;t!==void 0?i.copy(t):Su.setFromPoints(e).getCenter(i);let r=0;for(let s=0,a=e.length;s<a;s++)r=Math.max(r,i.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;er.subVectors(e,this.center);const t=er.lengthSq();if(t>this.radius*this.radius){const i=Math.sqrt(t),r=(i-this.radius)*.5;this.center.addScaledVector(er,r/i),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):($s.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(er.copy(e.center).add($s)),this.expandByPoint(er.copy(e.center).sub($s))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const hn=new N,Ks=new N,Er=new N,En=new N,Js=new N,Tr=new N,Qs=new N;class _r{constructor(e=new N,t=new N(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,hn)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=hn.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(hn.copy(this.origin).addScaledVector(this.direction,t),hn.distanceToSquared(e))}distanceSqToSegment(e,t,i,r){Ks.copy(e).add(t).multiplyScalar(.5),Er.copy(t).sub(e).normalize(),En.copy(this.origin).sub(Ks);const s=e.distanceTo(t)*.5,a=-this.direction.dot(Er),o=En.dot(this.direction),l=-En.dot(Er),c=En.lengthSq(),d=Math.abs(1-a*a);let u,h,m,_;if(d>0)if(u=a*l-o,h=a*o-l,_=s*d,u>=0)if(h>=-_)if(h<=_){const x=1/d;u*=x,h*=x,m=u*(u+a*h+2*o)+h*(a*u+h+2*l)+c}else h=s,u=Math.max(0,-(a*h+o)),m=-u*u+h*(h+2*l)+c;else h=-s,u=Math.max(0,-(a*h+o)),m=-u*u+h*(h+2*l)+c;else h<=-_?(u=Math.max(0,-(-a*s+o)),h=u>0?-s:Math.min(Math.max(-s,-l),s),m=-u*u+h*(h+2*l)+c):h<=_?(u=0,h=Math.min(Math.max(-s,-l),s),m=h*(h+2*l)+c):(u=Math.max(0,-(a*s+o)),h=u>0?s:Math.min(Math.max(-s,-l),s),m=-u*u+h*(h+2*l)+c);else h=a>0?-s:s,u=Math.max(0,-(a*h+o)),m=-u*u+h*(h+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(Ks).addScaledVector(Er,h),m}intersectSphere(e,t){hn.subVectors(e.center,this.origin);const i=hn.dot(this.direction),r=hn.dot(hn)-i*i,s=e.radius*e.radius;if(r>s)return null;const a=Math.sqrt(s-r),o=i-a,l=i+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){const i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,r,s,a,o,l;const c=1/this.direction.x,d=1/this.direction.y,u=1/this.direction.z,h=this.origin;return c>=0?(i=(e.min.x-h.x)*c,r=(e.max.x-h.x)*c):(i=(e.max.x-h.x)*c,r=(e.min.x-h.x)*c),d>=0?(s=(e.min.y-h.y)*d,a=(e.max.y-h.y)*d):(s=(e.max.y-h.y)*d,a=(e.min.y-h.y)*d),i>a||s>r||((s>i||isNaN(i))&&(i=s),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-h.z)*u,l=(e.max.z-h.z)*u):(o=(e.max.z-h.z)*u,l=(e.min.z-h.z)*u),i>l||o>r)||((o>i||i!==i)&&(i=o),(l<r||r!==r)&&(r=l),r<0)?null:this.at(i>=0?i:r,t)}intersectsBox(e){return this.intersectBox(e,hn)!==null}intersectTriangle(e,t,i,r,s){Js.subVectors(t,e),Tr.subVectors(i,e),Qs.crossVectors(Js,Tr);let a=this.direction.dot(Qs),o;if(a>0){if(r)return null;o=1}else if(a<0)o=-1,a=-a;else return null;En.subVectors(this.origin,e);const l=o*this.direction.dot(Tr.crossVectors(En,Tr));if(l<0)return null;const c=o*this.direction.dot(Js.cross(En));if(c<0||l+c>a)return null;const d=-o*En.dot(Qs);return d<0?null:this.at(d/a,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Qe{constructor(e,t,i,r,s,a,o,l,c,d,u,h,m,_,x,p){Qe.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,r,s,a,o,l,c,d,u,h,m,_,x,p)}set(e,t,i,r,s,a,o,l,c,d,u,h,m,_,x,p){const f=this.elements;return f[0]=e,f[4]=t,f[8]=i,f[12]=r,f[1]=s,f[5]=a,f[9]=o,f[13]=l,f[2]=c,f[6]=d,f[10]=u,f[14]=h,f[3]=m,f[7]=_,f[11]=x,f[15]=p,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Qe().fromArray(this.elements)}copy(e){const t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){const t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,i=e.elements,r=1/fi.setFromMatrixColumn(e,0).length(),s=1/fi.setFromMatrixColumn(e,1).length(),a=1/fi.setFromMatrixColumn(e,2).length();return t[0]=i[0]*r,t[1]=i[1]*r,t[2]=i[2]*r,t[3]=0,t[4]=i[4]*s,t[5]=i[5]*s,t[6]=i[6]*s,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,i=e.x,r=e.y,s=e.z,a=Math.cos(i),o=Math.sin(i),l=Math.cos(r),c=Math.sin(r),d=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const h=a*d,m=a*u,_=o*d,x=o*u;t[0]=l*d,t[4]=-l*u,t[8]=c,t[1]=m+_*c,t[5]=h-x*c,t[9]=-o*l,t[2]=x-h*c,t[6]=_+m*c,t[10]=a*l}else if(e.order==="YXZ"){const h=l*d,m=l*u,_=c*d,x=c*u;t[0]=h+x*o,t[4]=_*o-m,t[8]=a*c,t[1]=a*u,t[5]=a*d,t[9]=-o,t[2]=m*o-_,t[6]=x+h*o,t[10]=a*l}else if(e.order==="ZXY"){const h=l*d,m=l*u,_=c*d,x=c*u;t[0]=h-x*o,t[4]=-a*u,t[8]=_+m*o,t[1]=m+_*o,t[5]=a*d,t[9]=x-h*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){const h=a*d,m=a*u,_=o*d,x=o*u;t[0]=l*d,t[4]=_*c-m,t[8]=h*c+x,t[1]=l*u,t[5]=x*c+h,t[9]=m*c-_,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){const h=a*l,m=a*c,_=o*l,x=o*c;t[0]=l*d,t[4]=x-h*u,t[8]=_*u+m,t[1]=u,t[5]=a*d,t[9]=-o*d,t[2]=-c*d,t[6]=m*u+_,t[10]=h-x*u}else if(e.order==="XZY"){const h=a*l,m=a*c,_=o*l,x=o*c;t[0]=l*d,t[4]=-u,t[8]=c*d,t[1]=h*u+x,t[5]=a*d,t[9]=m*u-_,t[2]=_*u-m,t[6]=o*d,t[10]=x*u+h}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(bu,e,wu)}lookAt(e,t,i){const r=this.elements;return Vt.subVectors(e,t),Vt.lengthSq()===0&&(Vt.z=1),Vt.normalize(),Tn.crossVectors(i,Vt),Tn.lengthSq()===0&&(Math.abs(i.z)===1?Vt.x+=1e-4:Vt.z+=1e-4,Vt.normalize(),Tn.crossVectors(i,Vt)),Tn.normalize(),Ar.crossVectors(Vt,Tn),r[0]=Tn.x,r[4]=Ar.x,r[8]=Vt.x,r[1]=Tn.y,r[5]=Ar.y,r[9]=Vt.y,r[2]=Tn.z,r[6]=Ar.z,r[10]=Vt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const i=e.elements,r=t.elements,s=this.elements,a=i[0],o=i[4],l=i[8],c=i[12],d=i[1],u=i[5],h=i[9],m=i[13],_=i[2],x=i[6],p=i[10],f=i[14],v=i[3],g=i[7],y=i[11],R=i[15],T=r[0],C=r[4],z=r[8],M=r[12],S=r[1],G=r[5],I=r[9],W=r[13],L=r[2],U=r[6],B=r[10],X=r[14],K=r[3],ie=r[7],ne=r[11],ue=r[15];return s[0]=a*T+o*S+l*L+c*K,s[4]=a*C+o*G+l*U+c*ie,s[8]=a*z+o*I+l*B+c*ne,s[12]=a*M+o*W+l*X+c*ue,s[1]=d*T+u*S+h*L+m*K,s[5]=d*C+u*G+h*U+m*ie,s[9]=d*z+u*I+h*B+m*ne,s[13]=d*M+u*W+h*X+m*ue,s[2]=_*T+x*S+p*L+f*K,s[6]=_*C+x*G+p*U+f*ie,s[10]=_*z+x*I+p*B+f*ne,s[14]=_*M+x*W+p*X+f*ue,s[3]=v*T+g*S+y*L+R*K,s[7]=v*C+g*G+y*U+R*ie,s[11]=v*z+g*I+y*B+R*ne,s[15]=v*M+g*W+y*X+R*ue,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],i=e[4],r=e[8],s=e[12],a=e[1],o=e[5],l=e[9],c=e[13],d=e[2],u=e[6],h=e[10],m=e[14],_=e[3],x=e[7],p=e[11],f=e[15];return _*(+s*l*u-r*c*u-s*o*h+i*c*h+r*o*m-i*l*m)+x*(+t*l*m-t*c*h+s*a*h-r*a*m+r*c*d-s*l*d)+p*(+t*c*u-t*o*m-s*a*u+i*a*m+s*o*d-i*c*d)+f*(-r*o*d-t*l*u+t*o*h+r*a*u-i*a*h+i*l*d)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=i),this}invert(){const e=this.elements,t=e[0],i=e[1],r=e[2],s=e[3],a=e[4],o=e[5],l=e[6],c=e[7],d=e[8],u=e[9],h=e[10],m=e[11],_=e[12],x=e[13],p=e[14],f=e[15],v=u*p*c-x*h*c+x*l*m-o*p*m-u*l*f+o*h*f,g=_*h*c-d*p*c-_*l*m+a*p*m+d*l*f-a*h*f,y=d*x*c-_*u*c+_*o*m-a*x*m-d*o*f+a*u*f,R=_*u*l-d*x*l-_*o*h+a*x*h+d*o*p-a*u*p,T=t*v+i*g+r*y+s*R;if(T===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const C=1/T;return e[0]=v*C,e[1]=(x*h*s-u*p*s-x*r*m+i*p*m+u*r*f-i*h*f)*C,e[2]=(o*p*s-x*l*s+x*r*c-i*p*c-o*r*f+i*l*f)*C,e[3]=(u*l*s-o*h*s-u*r*c+i*h*c+o*r*m-i*l*m)*C,e[4]=g*C,e[5]=(d*p*s-_*h*s+_*r*m-t*p*m-d*r*f+t*h*f)*C,e[6]=(_*l*s-a*p*s-_*r*c+t*p*c+a*r*f-t*l*f)*C,e[7]=(a*h*s-d*l*s+d*r*c-t*h*c-a*r*m+t*l*m)*C,e[8]=y*C,e[9]=(_*u*s-d*x*s-_*i*m+t*x*m+d*i*f-t*u*f)*C,e[10]=(a*x*s-_*o*s+_*i*c-t*x*c-a*i*f+t*o*f)*C,e[11]=(d*o*s-a*u*s-d*i*c+t*u*c+a*i*m-t*o*m)*C,e[12]=R*C,e[13]=(d*x*r-_*u*r+_*i*h-t*x*h-d*i*p+t*u*p)*C,e[14]=(_*o*r-a*x*r-_*i*l+t*x*l+a*i*p-t*o*p)*C,e[15]=(a*u*r-d*o*r+d*i*l-t*u*l-a*i*h+t*o*h)*C,this}scale(e){const t=this.elements,i=e.x,r=e.y,s=e.z;return t[0]*=i,t[4]*=r,t[8]*=s,t[1]*=i,t[5]*=r,t[9]*=s,t[2]*=i,t[6]*=r,t[10]*=s,t[3]*=i,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,r))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const i=Math.cos(t),r=Math.sin(t),s=1-i,a=e.x,o=e.y,l=e.z,c=s*a,d=s*o;return this.set(c*a+i,c*o-r*l,c*l+r*o,0,c*o+r*l,d*o+i,d*l-r*a,0,c*l-r*o,d*l+r*a,s*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,r,s,a){return this.set(1,i,s,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,i){const r=this.elements,s=t._x,a=t._y,o=t._z,l=t._w,c=s+s,d=a+a,u=o+o,h=s*c,m=s*d,_=s*u,x=a*d,p=a*u,f=o*u,v=l*c,g=l*d,y=l*u,R=i.x,T=i.y,C=i.z;return r[0]=(1-(x+f))*R,r[1]=(m+y)*R,r[2]=(_-g)*R,r[3]=0,r[4]=(m-y)*T,r[5]=(1-(h+f))*T,r[6]=(p+v)*T,r[7]=0,r[8]=(_+g)*C,r[9]=(p-v)*C,r[10]=(1-(h+x))*C,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,i){const r=this.elements;let s=fi.set(r[0],r[1],r[2]).length();const a=fi.set(r[4],r[5],r[6]).length(),o=fi.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],tn.copy(this);const c=1/s,d=1/a,u=1/o;return tn.elements[0]*=c,tn.elements[1]*=c,tn.elements[2]*=c,tn.elements[4]*=d,tn.elements[5]*=d,tn.elements[6]*=d,tn.elements[8]*=u,tn.elements[9]*=u,tn.elements[10]*=u,t.setFromRotationMatrix(tn),i.x=s,i.y=a,i.z=o,this}makePerspective(e,t,i,r,s,a,o=xn){const l=this.elements,c=2*s/(t-e),d=2*s/(i-r),u=(t+e)/(t-e),h=(i+r)/(i-r);let m,_;if(o===xn)m=-(a+s)/(a-s),_=-2*a*s/(a-s);else if(o===as)m=-a/(a-s),_=-a*s/(a-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=d,l[9]=h,l[13]=0,l[2]=0,l[6]=0,l[10]=m,l[14]=_,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,r,s,a,o=xn){const l=this.elements,c=1/(t-e),d=1/(i-r),u=1/(a-s),h=(t+e)*c,m=(i+r)*d;let _,x;if(o===xn)_=(a+s)*u,x=-2*u;else if(o===as)_=s*u,x=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-h,l[1]=0,l[5]=2*d,l[9]=0,l[13]=-m,l[2]=0,l[6]=0,l[10]=x,l[14]=-_,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,i=e.elements;for(let r=0;r<16;r++)if(t[r]!==i[r])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){const i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}}const fi=new N,tn=new Qe,bu=new N(0,0,0),wu=new N(1,1,1),Tn=new N,Ar=new N,Vt=new N,Qo=new Qe,el=new gr;class ys{constructor(e=0,t=0,i=0,r=ys.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,r=this._order){return this._x=e,this._y=t,this._z=i,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){const r=e.elements,s=r[0],a=r[4],o=r[8],l=r[1],c=r[5],d=r[9],u=r[2],h=r[6],m=r[10];switch(t){case"XYZ":this._y=Math.asin(kt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-d,m),this._z=Math.atan2(-a,s)):(this._x=Math.atan2(h,c),this._z=0);break;case"YXZ":this._x=Math.asin(-kt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(o,m),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(kt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(-u,m),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-kt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(h,m),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(kt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-d,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(o,m));break;case"XZY":this._z=Math.asin(-kt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(h,c),this._y=Math.atan2(o,s)):(this._x=Math.atan2(-d,m),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return Qo.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Qo,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return el.setFromEuler(this),this.setFromQuaternion(el,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}ys.DEFAULT_ORDER="XYZ";class ja{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Eu=0;const tl=new N,pi=new gr,un=new Qe,Rr=new N,tr=new N,Tu=new N,Au=new gr,nl=new N(1,0,0),il=new N(0,1,0),rl=new N(0,0,1),Ru={type:"added"},Cu={type:"removed"};class pt extends Zi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Eu++}),this.uuid=zn(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=pt.DEFAULT_UP.clone();const e=new N,t=new ys,i=new gr,r=new N(1,1,1);function s(){i.setFromEuler(t,!1)}function a(){t.setFromQuaternion(i,void 0,!1)}t._onChange(s),i._onChange(a),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new Qe},normalMatrix:{value:new Xe}}),this.matrix=new Qe,this.matrixWorld=new Qe,this.matrixAutoUpdate=pt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=pt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new ja,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return pi.setFromAxisAngle(e,t),this.quaternion.multiply(pi),this}rotateOnWorldAxis(e,t){return pi.setFromAxisAngle(e,t),this.quaternion.premultiply(pi),this}rotateX(e){return this.rotateOnAxis(nl,e)}rotateY(e){return this.rotateOnAxis(il,e)}rotateZ(e){return this.rotateOnAxis(rl,e)}translateOnAxis(e,t){return tl.copy(e).applyQuaternion(this.quaternion),this.position.add(tl.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(nl,e)}translateY(e){return this.translateOnAxis(il,e)}translateZ(e){return this.translateOnAxis(rl,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(un.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Rr.copy(e):Rr.set(e,t,i);const r=this.parent;this.updateWorldMatrix(!0,!1),tr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?un.lookAt(tr,Rr,this.up):un.lookAt(Rr,tr,this.up),this.quaternion.setFromRotationMatrix(un),r&&(un.extractRotation(r.matrixWorld),pi.setFromRotationMatrix(un),this.quaternion.premultiply(pi.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.parent!==null&&e.parent.remove(e),e.parent=this,this.children.push(e),e.dispatchEvent(Ru)):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(Cu)),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),un.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),un.multiply(e.parent.matrixWorld)),e.applyMatrix4(un),this.add(e),e.updateWorldMatrix(!1,!0),this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,r=this.children.length;i<r;i++){const a=this.children[i].getObjectByProperty(e,t);if(a!==void 0)return a}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);const r=this.children;for(let s=0,a=r.length;s<a;s++)r[s].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(tr,e,Tu),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(tr,Au,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let i=0,r=t.length;i<r;i++)t[i].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let i=0,r=t.length;i<r;i++){const s=t[i];(s.matrixWorldAutoUpdate===!0||e===!0)&&s.updateMatrixWorld(e)}}updateWorldMatrix(e,t){const i=this.parent;if(e===!0&&i!==null&&i.matrixWorldAutoUpdate===!0&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix),t===!0){const r=this.children;for(let s=0,a=r.length;s<a;s++){const o=r[s];o.matrixWorldAutoUpdate===!0&&o.updateWorldMatrix(!1,!0)}}}toJSON(e){const t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.visibility=this._visibility,r.active=this._active,r.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),r.maxGeometryCount=this._maxGeometryCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.geometryCount=this._geometryCount,r.matricesTexture=this._matricesTexture.toJSON(e),this.boundingSphere!==null&&(r.boundingSphere={center:r.boundingSphere.center.toArray(),radius:r.boundingSphere.radius}),this.boundingBox!==null&&(r.boundingBox={min:r.boundingBox.min.toArray(),max:r.boundingBox.max.toArray()}));function s(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){const l=o.shapes;if(Array.isArray(l))for(let c=0,d=l.length;c<d;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(s(e.materials,this.material[l]));r.material=o}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let o=0;o<this.children.length;o++)r.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let o=0;o<this.animations.length;o++){const l=this.animations[o];r.animations.push(s(e.animations,l))}}if(t){const o=a(e.geometries),l=a(e.materials),c=a(e.textures),d=a(e.images),u=a(e.shapes),h=a(e.skeletons),m=a(e.animations),_=a(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),d.length>0&&(i.images=d),u.length>0&&(i.shapes=u),h.length>0&&(i.skeletons=h),m.length>0&&(i.animations=m),_.length>0&&(i.nodes=_)}return i.object=r,i;function a(o){const l=[];for(const c in o){const d=o[c];delete d.metadata,l.push(d)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){const r=e.children[i];this.add(r.clone())}return this}}pt.DEFAULT_UP=new N(0,1,0);pt.DEFAULT_MATRIX_AUTO_UPDATE=!0;pt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const nn=new N,dn=new N,ea=new N,fn=new N,mi=new N,gi=new N,sl=new N,ta=new N,na=new N,ia=new N;let Cr=!1;class Kt{constructor(e=new N,t=new N,i=new N){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,r){r.subVectors(i,t),nn.subVectors(e,t),r.cross(nn);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,i,r,s){nn.subVectors(r,t),dn.subVectors(i,t),ea.subVectors(e,t);const a=nn.dot(nn),o=nn.dot(dn),l=nn.dot(ea),c=dn.dot(dn),d=dn.dot(ea),u=a*c-o*o;if(u===0)return s.set(0,0,0),null;const h=1/u,m=(c*l-o*d)*h,_=(a*d-o*l)*h;return s.set(1-m-_,_,m)}static containsPoint(e,t,i,r){return this.getBarycoord(e,t,i,r,fn)===null?!1:fn.x>=0&&fn.y>=0&&fn.x+fn.y<=1}static getUV(e,t,i,r,s,a,o,l){return Cr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Cr=!0),this.getInterpolation(e,t,i,r,s,a,o,l)}static getInterpolation(e,t,i,r,s,a,o,l){return this.getBarycoord(e,t,i,r,fn)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,fn.x),l.addScaledVector(a,fn.y),l.addScaledVector(o,fn.z),l)}static isFrontFacing(e,t,i,r){return nn.subVectors(i,t),dn.subVectors(e,t),nn.cross(dn).dot(r)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,r){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,i,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return nn.subVectors(this.c,this.b),dn.subVectors(this.a,this.b),nn.cross(dn).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Kt.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return Kt.getBarycoord(e,this.a,this.b,this.c,t)}getUV(e,t,i,r,s){return Cr===!1&&(console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."),Cr=!0),Kt.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}getInterpolation(e,t,i,r,s){return Kt.getInterpolation(e,this.a,this.b,this.c,t,i,r,s)}containsPoint(e){return Kt.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Kt.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const i=this.a,r=this.b,s=this.c;let a,o;mi.subVectors(r,i),gi.subVectors(s,i),ta.subVectors(e,i);const l=mi.dot(ta),c=gi.dot(ta);if(l<=0&&c<=0)return t.copy(i);na.subVectors(e,r);const d=mi.dot(na),u=gi.dot(na);if(d>=0&&u<=d)return t.copy(r);const h=l*u-d*c;if(h<=0&&l>=0&&d<=0)return a=l/(l-d),t.copy(i).addScaledVector(mi,a);ia.subVectors(e,s);const m=mi.dot(ia),_=gi.dot(ia);if(_>=0&&m<=_)return t.copy(s);const x=m*c-l*_;if(x<=0&&c>=0&&_<=0)return o=c/(c-_),t.copy(i).addScaledVector(gi,o);const p=d*_-m*u;if(p<=0&&u-d>=0&&m-_>=0)return sl.subVectors(s,r),o=(u-d)/(u-d+(m-_)),t.copy(r).addScaledVector(sl,o);const f=1/(p+x+h);return a=x*f,o=h*f,t.copy(i).addScaledVector(mi,a).addScaledVector(gi,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Sc={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},An={h:0,s:0,l:0},Pr={h:0,s:0,l:0};function ra(n,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?n+(e-n)*6*t:t<1/2?e:t<2/3?n+(e-n)*6*(2/3-t):n}class $e{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=xt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,tt.toWorkingColorSpace(this,t),this}setRGB(e,t,i,r=tt.workingColorSpace){return this.r=e,this.g=t,this.b=i,tt.toWorkingColorSpace(this,r),this}setHSL(e,t,i,r=tt.workingColorSpace){if(e=mu(e,1),t=kt(t,0,1),i=kt(i,0,1),t===0)this.r=this.g=this.b=i;else{const s=i<=.5?i*(1+t):i+t-i*t,a=2*i-s;this.r=ra(a,s,e+1/3),this.g=ra(a,s,e),this.b=ra(a,s,e-1/3)}return tt.toWorkingColorSpace(this,r),this}setStyle(e,t=xt){function i(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const a=r[1],o=r[2];switch(a){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],a=s.length;if(a===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=xt){const i=Sc[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Fi(e.r),this.g=Fi(e.g),this.b=Fi(e.b),this}copyLinearToSRGB(e){return this.r=qs(e.r),this.g=qs(e.g),this.b=qs(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=xt){return tt.fromWorkingColorSpace(Rt.copy(this),e),Math.round(kt(Rt.r*255,0,255))*65536+Math.round(kt(Rt.g*255,0,255))*256+Math.round(kt(Rt.b*255,0,255))}getHexString(e=xt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=tt.workingColorSpace){tt.fromWorkingColorSpace(Rt.copy(this),t);const i=Rt.r,r=Rt.g,s=Rt.b,a=Math.max(i,r,s),o=Math.min(i,r,s);let l,c;const d=(o+a)/2;if(o===a)l=0,c=0;else{const u=a-o;switch(c=d<=.5?u/(a+o):u/(2-a-o),a){case i:l=(r-s)/u+(r<s?6:0);break;case r:l=(s-i)/u+2;break;case s:l=(i-r)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=d,e}getRGB(e,t=tt.workingColorSpace){return tt.fromWorkingColorSpace(Rt.copy(this),t),e.r=Rt.r,e.g=Rt.g,e.b=Rt.b,e}getStyle(e=xt){tt.fromWorkingColorSpace(Rt.copy(this),e);const t=Rt.r,i=Rt.g,r=Rt.b;return e!==xt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(i*255)},${Math.round(r*255)})`}offsetHSL(e,t,i){return this.getHSL(An),this.setHSL(An.h+e,An.s+t,An.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(An),e.getHSL(Pr);const i=Ws(An.h,Pr.h,t),r=Ws(An.s,Pr.s,t),s=Ws(An.l,Pr.l,t);return this.setHSL(i,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,i=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*i+s[6]*r,this.g=s[1]*t+s[4]*i+s[7]*r,this.b=s[2]*t+s[5]*i+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Rt=new $e;$e.NAMES=Sc;let Pu=0;class $i extends Zi{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Pu++}),this.uuid=zn(),this.name="",this.type="Material",this.blending=Ni,this.side=yn,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ba,this.blendDst=wa,this.blendEquation=$n,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new $e(0,0,0),this.blendAlpha=0,this.depthFunc=ns,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=qo,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=li,this.stencilZFail=li,this.stencilZPass=li,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBuild(){}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(i):r&&r.isVector3&&i&&i.isVector3?r.copy(i):this[t]=i}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==Ni&&(i.blending=this.blending),this.side!==yn&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==ba&&(i.blendSrc=this.blendSrc),this.blendDst!==wa&&(i.blendDst=this.blendDst),this.blendEquation!==$n&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==ns&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==qo&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==li&&(i.stencilFail=this.stencilFail),this.stencilZFail!==li&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==li&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData);function r(s){const a=[];for(const o in s){const l=s[o];delete l.metadata,a.push(l)}return a}if(t){const s=r(e.textures),a=r(e.images);s.length>0&&(i.textures=s),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let i=null;if(t!==null){const r=t.length;i=new Array(r);for(let s=0;s!==r;++s)i[s]=t[s].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class Oi extends $i{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new $e(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Xa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const vt=new N,Lr=new Oe;class Qt{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Ca,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.gpuType=Pn,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.BufferAttribute: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[i+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Lr.fromBufferAttribute(this,t),Lr.applyMatrix3(e),this.setXY(t,Lr.x,Lr.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)vt.fromBufferAttribute(this,t),vt.applyMatrix3(e),this.setXYZ(t,vt.x,vt.y,vt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)vt.fromBufferAttribute(this,t),vt.applyMatrix4(e),this.setXYZ(t,vt.x,vt.y,vt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)vt.fromBufferAttribute(this,t),vt.applyNormalMatrix(e),this.setXYZ(t,vt.x,vt.y,vt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)vt.fromBufferAttribute(this,t),vt.transformDirection(e),this.setXYZ(t,vt.x,vt.y,vt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=gn(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=nt(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=gn(t,this.array)),t}setX(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=gn(t,this.array)),t}setY(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=gn(t,this.array)),t}setZ(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=gn(t,this.array)),t}setW(e,t){return this.normalized&&(t=nt(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,r){return e*=this.itemSize,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),r=nt(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e*=this.itemSize,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),r=nt(r,this.array),s=nt(s,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Ca&&(e.usage=this.usage),e}}class bc extends Qt{constructor(e,t,i){super(new Uint16Array(e),t,i)}}class wc extends Qt{constructor(e,t,i){super(new Uint32Array(e),t,i)}}class Ve extends Qt{constructor(e,t,i){super(new Float32Array(e),t,i)}}let Lu=0;const jt=new Qe,sa=new pt,xi=new N,Wt=new Sn,nr=new Sn,Et=new N;class rt extends Zi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:Lu++}),this.uuid=zn(),this.name="",this.type="BufferGeometry",this.index=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(_c(e)?wc:bc)(e,1):this.index=e,this}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const i=this.attributes.normal;if(i!==void 0){const s=new Xe().getNormalMatrix(e);i.applyNormalMatrix(s),i.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return jt.makeRotationFromQuaternion(e),this.applyMatrix4(jt),this}rotateX(e){return jt.makeRotationX(e),this.applyMatrix4(jt),this}rotateY(e){return jt.makeRotationY(e),this.applyMatrix4(jt),this}rotateZ(e){return jt.makeRotationZ(e),this.applyMatrix4(jt),this}translate(e,t,i){return jt.makeTranslation(e,t,i),this.applyMatrix4(jt),this}scale(e,t,i){return jt.makeScale(e,t,i),this.applyMatrix4(jt),this}lookAt(e){return sa.lookAt(e),sa.updateMatrix(),this.applyMatrix4(sa.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(xi).negate(),this.translate(xi.x,xi.y,xi.z),this}setFromPoints(e){const t=[];for(let i=0,r=e.length;i<r;i++){const s=e[i];t.push(s.x,s.y,s.z||0)}return this.setAttribute("position",new Ve(t,3)),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Sn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingBox.set(new N(-1/0,-1/0,-1/0),new N(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,r=t.length;i<r;i++){const s=t[i];Wt.setFromBufferAttribute(s),this.morphTargetsRelative?(Et.addVectors(this.boundingBox.min,Wt.min),this.boundingBox.expandByPoint(Et),Et.addVectors(this.boundingBox.max,Wt.max),this.boundingBox.expandByPoint(Et)):(this.boundingBox.expandByPoint(Wt.min),this.boundingBox.expandByPoint(Wt.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new xr);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".',this),this.boundingSphere.set(new N,1/0);return}if(e){const i=this.boundingSphere.center;if(Wt.setFromBufferAttribute(e),t)for(let s=0,a=t.length;s<a;s++){const o=t[s];nr.setFromBufferAttribute(o),this.morphTargetsRelative?(Et.addVectors(Wt.min,nr.min),Wt.expandByPoint(Et),Et.addVectors(Wt.max,nr.max),Wt.expandByPoint(Et)):(Wt.expandByPoint(nr.min),Wt.expandByPoint(nr.max))}Wt.getCenter(i);let r=0;for(let s=0,a=e.count;s<a;s++)Et.fromBufferAttribute(e,s),r=Math.max(r,i.distanceToSquared(Et));if(t)for(let s=0,a=t.length;s<a;s++){const o=t[s],l=this.morphTargetsRelative;for(let c=0,d=o.count;c<d;c++)Et.fromBufferAttribute(o,c),l&&(xi.fromBufferAttribute(e,c),Et.add(xi)),r=Math.max(r,i.distanceToSquared(Et))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const i=e.array,r=t.position.array,s=t.normal.array,a=t.uv.array,o=r.length/3;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Qt(new Float32Array(4*o),4));const l=this.getAttribute("tangent").array,c=[],d=[];for(let S=0;S<o;S++)c[S]=new N,d[S]=new N;const u=new N,h=new N,m=new N,_=new Oe,x=new Oe,p=new Oe,f=new N,v=new N;function g(S,G,I){u.fromArray(r,S*3),h.fromArray(r,G*3),m.fromArray(r,I*3),_.fromArray(a,S*2),x.fromArray(a,G*2),p.fromArray(a,I*2),h.sub(u),m.sub(u),x.sub(_),p.sub(_);const W=1/(x.x*p.y-p.x*x.y);isFinite(W)&&(f.copy(h).multiplyScalar(p.y).addScaledVector(m,-x.y).multiplyScalar(W),v.copy(m).multiplyScalar(x.x).addScaledVector(h,-p.x).multiplyScalar(W),c[S].add(f),c[G].add(f),c[I].add(f),d[S].add(v),d[G].add(v),d[I].add(v))}let y=this.groups;y.length===0&&(y=[{start:0,count:i.length}]);for(let S=0,G=y.length;S<G;++S){const I=y[S],W=I.start,L=I.count;for(let U=W,B=W+L;U<B;U+=3)g(i[U+0],i[U+1],i[U+2])}const R=new N,T=new N,C=new N,z=new N;function M(S){C.fromArray(s,S*3),z.copy(C);const G=c[S];R.copy(G),R.sub(C.multiplyScalar(C.dot(G))).normalize(),T.crossVectors(z,G);const W=T.dot(d[S])<0?-1:1;l[S*4]=R.x,l[S*4+1]=R.y,l[S*4+2]=R.z,l[S*4+3]=W}for(let S=0,G=y.length;S<G;++S){const I=y[S],W=I.start,L=I.count;for(let U=W,B=W+L;U<B;U+=3)M(i[U+0]),M(i[U+1]),M(i[U+2])}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new Qt(new Float32Array(t.count*3),3),this.setAttribute("normal",i);else for(let h=0,m=i.count;h<m;h++)i.setXYZ(h,0,0,0);const r=new N,s=new N,a=new N,o=new N,l=new N,c=new N,d=new N,u=new N;if(e)for(let h=0,m=e.count;h<m;h+=3){const _=e.getX(h+0),x=e.getX(h+1),p=e.getX(h+2);r.fromBufferAttribute(t,_),s.fromBufferAttribute(t,x),a.fromBufferAttribute(t,p),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),o.fromBufferAttribute(i,_),l.fromBufferAttribute(i,x),c.fromBufferAttribute(i,p),o.add(d),l.add(d),c.add(d),i.setXYZ(_,o.x,o.y,o.z),i.setXYZ(x,l.x,l.y,l.z),i.setXYZ(p,c.x,c.y,c.z)}else for(let h=0,m=t.count;h<m;h+=3)r.fromBufferAttribute(t,h+0),s.fromBufferAttribute(t,h+1),a.fromBufferAttribute(t,h+2),d.subVectors(a,s),u.subVectors(r,s),d.cross(u),i.setXYZ(h+0,d.x,d.y,d.z),i.setXYZ(h+1,d.x,d.y,d.z),i.setXYZ(h+2,d.x,d.y,d.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)Et.fromBufferAttribute(e,t),Et.normalize(),e.setXYZ(t,Et.x,Et.y,Et.z)}toNonIndexed(){function e(o,l){const c=o.array,d=o.itemSize,u=o.normalized,h=new c.constructor(l.length*d);let m=0,_=0;for(let x=0,p=l.length;x<p;x++){o.isInterleavedBufferAttribute?m=l[x]*o.data.stride+o.offset:m=l[x]*d;for(let f=0;f<d;f++)h[_++]=c[m++]}return new Qt(h,d,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new rt,i=this.index.array,r=this.attributes;for(const o in r){const l=r[o],c=e(l,i);t.setAttribute(o,c)}const s=this.morphAttributes;for(const o in s){const l=[],c=s[o];for(let d=0,u=c.length;d<u;d++){const h=c[d],m=e(h,i);l.push(m)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;const a=this.groups;for(let o=0,l=a.length;o<l;o++){const c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const i=this.attributes;for(const l in i){const c=i[l];e.data.attributes[l]=c.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],d=[];for(let u=0,h=c.length;u<h;u++){const m=c[u];d.push(m.toJSON(e.data))}d.length>0&&(r[l]=d,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));const o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const i=e.index;i!==null&&this.setIndex(i.clone(t));const r=e.attributes;for(const c in r){const d=r[c];this.setAttribute(c,d.clone(t))}const s=e.morphAttributes;for(const c in s){const d=[],u=s[c];for(let h=0,m=u.length;h<m;h++)d.push(u[h].clone(t));this.morphAttributes[c]=d}this.morphTargetsRelative=e.morphTargetsRelative;const a=e.groups;for(let c=0,d=a.length;c<d;c++){const u=a[c];this.addGroup(u.start,u.count,u.materialIndex)}const o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const al=new Qe,Hn=new _r,Dr=new xr,ol=new N,_i=new N,vi=new N,yi=new N,aa=new N,Ir=new N,Ur=new Oe,zr=new Oe,Nr=new Oe,ll=new N,cl=new N,hl=new N,Fr=new N,Or=new N;class Le extends pt{constructor(e=new rt,t=new Oi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,i=Object.keys(t);if(i.length>0){const r=t[i[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,a=r.length;s<a;s++){const o=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[o]=s}}}}getVertexPosition(e,t){const i=this.geometry,r=i.attributes.position,s=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(r,e);const o=this.morphTargetInfluences;if(s&&o){Ir.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const d=o[l],u=s[l];d!==0&&(aa.fromBufferAttribute(u,e),a?Ir.addScaledVector(aa,d):Ir.addScaledVector(aa.sub(t),d))}t.add(Ir)}return t}raycast(e,t){const i=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(i.boundingSphere===null&&i.computeBoundingSphere(),Dr.copy(i.boundingSphere),Dr.applyMatrix4(s),Hn.copy(e.ray).recast(e.near),!(Dr.containsPoint(Hn.origin)===!1&&(Hn.intersectSphere(Dr,ol)===null||Hn.origin.distanceToSquared(ol)>(e.far-e.near)**2))&&(al.copy(s).invert(),Hn.copy(e.ray).applyMatrix4(al),!(i.boundingBox!==null&&Hn.intersectsBox(i.boundingBox)===!1)&&this._computeIntersections(e,t,Hn)))}_computeIntersections(e,t,i){let r;const s=this.geometry,a=this.material,o=s.index,l=s.attributes.position,c=s.attributes.uv,d=s.attributes.uv1,u=s.attributes.normal,h=s.groups,m=s.drawRange;if(o!==null)if(Array.isArray(a))for(let _=0,x=h.length;_<x;_++){const p=h[_],f=a[p.materialIndex],v=Math.max(p.start,m.start),g=Math.min(o.count,Math.min(p.start+p.count,m.start+m.count));for(let y=v,R=g;y<R;y+=3){const T=o.getX(y),C=o.getX(y+1),z=o.getX(y+2);r=kr(this,f,e,i,c,d,u,T,C,z),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const _=Math.max(0,m.start),x=Math.min(o.count,m.start+m.count);for(let p=_,f=x;p<f;p+=3){const v=o.getX(p),g=o.getX(p+1),y=o.getX(p+2);r=kr(this,a,e,i,c,d,u,v,g,y),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(a))for(let _=0,x=h.length;_<x;_++){const p=h[_],f=a[p.materialIndex],v=Math.max(p.start,m.start),g=Math.min(l.count,Math.min(p.start+p.count,m.start+m.count));for(let y=v,R=g;y<R;y+=3){const T=y,C=y+1,z=y+2;r=kr(this,f,e,i,c,d,u,T,C,z),r&&(r.faceIndex=Math.floor(y/3),r.face.materialIndex=p.materialIndex,t.push(r))}}else{const _=Math.max(0,m.start),x=Math.min(l.count,m.start+m.count);for(let p=_,f=x;p<f;p+=3){const v=p,g=p+1,y=p+2;r=kr(this,a,e,i,c,d,u,v,g,y),r&&(r.faceIndex=Math.floor(p/3),t.push(r))}}}}function Du(n,e,t,i,r,s,a,o){let l;if(e.side===Bt?l=i.intersectTriangle(a,s,r,!0,o):l=i.intersectTriangle(r,s,a,e.side===yn,o),l===null)return null;Or.copy(o),Or.applyMatrix4(n.matrixWorld);const c=t.ray.origin.distanceTo(Or);return c<t.near||c>t.far?null:{distance:c,point:Or.clone(),object:n}}function kr(n,e,t,i,r,s,a,o,l,c){n.getVertexPosition(o,_i),n.getVertexPosition(l,vi),n.getVertexPosition(c,yi);const d=Du(n,e,t,i,_i,vi,yi,Fr);if(d){r&&(Ur.fromBufferAttribute(r,o),zr.fromBufferAttribute(r,l),Nr.fromBufferAttribute(r,c),d.uv=Kt.getInterpolation(Fr,_i,vi,yi,Ur,zr,Nr,new Oe)),s&&(Ur.fromBufferAttribute(s,o),zr.fromBufferAttribute(s,l),Nr.fromBufferAttribute(s,c),d.uv1=Kt.getInterpolation(Fr,_i,vi,yi,Ur,zr,Nr,new Oe),d.uv2=d.uv1),a&&(ll.fromBufferAttribute(a,o),cl.fromBufferAttribute(a,l),hl.fromBufferAttribute(a,c),d.normal=Kt.getInterpolation(Fr,_i,vi,yi,ll,cl,hl,new N),d.normal.dot(i.direction)>0&&d.normal.multiplyScalar(-1));const u={a:o,b:l,c,normal:new N,materialIndex:0};Kt.getNormal(_i,vi,yi,u.normal),d.face=u}return d}class _t extends rt{constructor(e=1,t=1,i=1,r=1,s=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:r,heightSegments:s,depthSegments:a};const o=this;r=Math.floor(r),s=Math.floor(s),a=Math.floor(a);const l=[],c=[],d=[],u=[];let h=0,m=0;_("z","y","x",-1,-1,i,t,e,a,s,0),_("z","y","x",1,-1,i,t,-e,a,s,1),_("x","z","y",1,1,e,i,t,r,a,2),_("x","z","y",1,-1,e,i,-t,r,a,3),_("x","y","z",1,-1,e,t,i,r,s,4),_("x","y","z",-1,-1,e,t,-i,r,s,5),this.setIndex(l),this.setAttribute("position",new Ve(c,3)),this.setAttribute("normal",new Ve(d,3)),this.setAttribute("uv",new Ve(u,2));function _(x,p,f,v,g,y,R,T,C,z,M){const S=y/C,G=R/z,I=y/2,W=R/2,L=T/2,U=C+1,B=z+1;let X=0,K=0;const ie=new N;for(let ne=0;ne<B;ne++){const ue=ne*G-W;for(let de=0;de<U;de++){const J=de*S-I;ie[x]=J*v,ie[p]=ue*g,ie[f]=L,c.push(ie.x,ie.y,ie.z),ie[x]=0,ie[p]=0,ie[f]=T>0?1:-1,d.push(ie.x,ie.y,ie.z),u.push(de/C),u.push(1-ne/z),X+=1}}for(let ne=0;ne<z;ne++)for(let ue=0;ue<C;ue++){const de=h+ue+U*ne,J=h+ue+U*(ne+1),se=h+(ue+1)+U*(ne+1),ge=h+(ue+1)+U*ne;l.push(de,J,ge),l.push(J,se,ge),K+=6}o.addGroup(m,K,M),m+=K,h+=X}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new _t(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Vi(n){const e={};for(const t in n){e[t]={};for(const i in n[t]){const r=n[t][i];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=r.clone():Array.isArray(r)?e[t][i]=r.slice():e[t][i]=r}}return e}function Ft(n){const e={};for(let t=0;t<n.length;t++){const i=Vi(n[t]);for(const r in i)e[r]=i[r]}return e}function Iu(n){const e=[];for(let t=0;t<n.length;t++)e.push(n[t].clone());return e}function Ec(n){return n.getRenderTarget()===null?n.outputColorSpace:tt.workingColorSpace}const Uu={clone:Vi,merge:Ft};var zu=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Nu=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class si extends $i{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=zu,this.fragmentShader=Nu,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={derivatives:!1,fragDepth:!1,drawBuffers:!1,shaderTextureLOD:!1,clipCullDistance:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Vi(e.uniforms),this.uniformsGroups=Iu(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const a=this.uniforms[r].value;a&&a.isTexture?t.uniforms[r]={type:"t",value:a.toJSON(e).uuid}:a&&a.isColor?t.uniforms[r]={type:"c",value:a.getHex()}:a&&a.isVector2?t.uniforms[r]={type:"v2",value:a.toArray()}:a&&a.isVector3?t.uniforms[r]={type:"v3",value:a.toArray()}:a&&a.isVector4?t.uniforms[r]={type:"v4",value:a.toArray()}:a&&a.isMatrix3?t.uniforms[r]={type:"m3",value:a.toArray()}:a&&a.isMatrix4?t.uniforms[r]={type:"m4",value:a.toArray()}:t.uniforms[r]={value:a}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const i={};for(const r in this.extensions)this.extensions[r]===!0&&(i[r]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}}class Tc extends pt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Qe,this.projectionMatrix=new Qe,this.projectionMatrixInverse=new Qe,this.coordinateSystem=xn}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}class qt extends Tc{constructor(e=50,t=1,i=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=La*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Vs*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return La*2*Math.atan(Math.tan(Vs*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}setViewOffset(e,t,i,r,s,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Vs*.5*this.fov)/this.zoom,i=2*t,r=this.aspect*i,s=-.5*r;const a=this.view;if(this.view!==null&&this.view.enabled){const l=a.fullWidth,c=a.fullHeight;s+=a.offsetX*r/l,t-=a.offsetY*i/c,r*=a.width/l,i*=a.height/c}const o=this.filmOffset;o!==0&&(s+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Mi=-90,Si=1;class Fu extends pt{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new qt(Mi,Si,e,t);r.layers=this.layers,this.add(r);const s=new qt(Mi,Si,e,t);s.layers=this.layers,this.add(s);const a=new qt(Mi,Si,e,t);a.layers=this.layers,this.add(a);const o=new qt(Mi,Si,e,t);o.layers=this.layers,this.add(o);const l=new qt(Mi,Si,e,t);l.layers=this.layers,this.add(l);const c=new qt(Mi,Si,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[i,r,s,a,o,l]=t;for(const c of t)this.remove(c);if(e===xn)i.up.set(0,1,0),i.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===as)i.up.set(0,-1,0),i.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:i,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,a,o,l,c,d]=this.children,u=e.getRenderTarget(),h=e.getActiveCubeFace(),m=e.getActiveMipmapLevel(),_=e.xr.enabled;e.xr.enabled=!1;const x=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,r),e.render(t,s),e.setRenderTarget(i,1,r),e.render(t,a),e.setRenderTarget(i,2,r),e.render(t,o),e.setRenderTarget(i,3,r),e.render(t,l),e.setRenderTarget(i,4,r),e.render(t,c),i.texture.generateMipmaps=x,e.setRenderTarget(i,5,r),e.render(t,d),e.setRenderTarget(u,h,m),e.xr.enabled=_,i.texture.needsPMREMUpdate=!0}}class Ac extends Gt{constructor(e,t,i,r,s,a,o,l,c,d){e=e!==void 0?e:[],t=t!==void 0?t:Bi,super(e,t,i,r,s,a,o,l,c,d),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Ou extends ri{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const i={width:e,height:e,depth:1},r=[i,i,i,i,i,i];t.encoding!==void 0&&(hr("THREE.WebGLCubeRenderTarget: option.encoding has been replaced by option.colorSpace."),t.colorSpace=t.encoding===ni?xt:Jt),this.texture=new Ac(r,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:$t}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new _t(5,5,5),s=new si({name:"CubemapFromEquirect",uniforms:Vi(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:Bt,blending:Dn});s.uniforms.tEquirect.value=t;const a=new Le(r,s),o=t.minFilter;return t.minFilter===ur&&(t.minFilter=$t),new Fu(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,r){const s=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,r);e.setRenderTarget(s)}}const oa=new N,ku=new N,Bu=new Xe;class Yn{constructor(e=new N(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,r){return this.normal.set(e,t,i),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){const r=oa.subVectors(i,t).cross(ku.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const i=e.delta(oa),r=this.normal.dot(i);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(i,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const i=t||Bu.getNormalMatrix(e),r=this.coplanarPoint(oa).applyMatrix4(e),s=this.normal.applyMatrix3(i).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Vn=new xr,Br=new N;class Za{constructor(e=new Yn,t=new Yn,i=new Yn,r=new Yn,s=new Yn,a=new Yn){this.planes=[e,t,i,r,s,a]}set(e,t,i,r,s,a){const o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(r),o[4].copy(s),o[5].copy(a),this}copy(e){const t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=xn){const i=this.planes,r=e.elements,s=r[0],a=r[1],o=r[2],l=r[3],c=r[4],d=r[5],u=r[6],h=r[7],m=r[8],_=r[9],x=r[10],p=r[11],f=r[12],v=r[13],g=r[14],y=r[15];if(i[0].setComponents(l-s,h-c,p-m,y-f).normalize(),i[1].setComponents(l+s,h+c,p+m,y+f).normalize(),i[2].setComponents(l+a,h+d,p+_,y+v).normalize(),i[3].setComponents(l-a,h-d,p-_,y-v).normalize(),i[4].setComponents(l-o,h-u,p-x,y-g).normalize(),t===xn)i[5].setComponents(l+o,h+u,p+x,y+g).normalize();else if(t===as)i[5].setComponents(o,u,x,g).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Vn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),Vn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Vn)}intersectsSprite(e){return Vn.center.set(0,0,0),Vn.radius=.7071067811865476,Vn.applyMatrix4(e.matrixWorld),this.intersectsSphere(Vn)}intersectsSphere(e){const t=this.planes,i=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(i)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let i=0;i<6;i++){const r=t[i];if(Br.x=r.normal.x>0?e.max.x:e.min.x,Br.y=r.normal.y>0?e.max.y:e.min.y,Br.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Br)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function Rc(){let n=null,e=!1,t=null,i=null;function r(s,a){t(s,a),i=n.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(i=n.requestAnimationFrame(r),e=!0)},stop:function(){n.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){n=s}}}function Gu(n,e){const t=e.isWebGL2,i=new WeakMap;function r(c,d){const u=c.array,h=c.usage,m=u.byteLength,_=n.createBuffer();n.bindBuffer(d,_),n.bufferData(d,u,h),c.onUploadCallback();let x;if(u instanceof Float32Array)x=n.FLOAT;else if(u instanceof Uint16Array)if(c.isFloat16BufferAttribute)if(t)x=n.HALF_FLOAT;else throw new Error("THREE.WebGLAttributes: Usage of Float16BufferAttribute requires WebGL2.");else x=n.UNSIGNED_SHORT;else if(u instanceof Int16Array)x=n.SHORT;else if(u instanceof Uint32Array)x=n.UNSIGNED_INT;else if(u instanceof Int32Array)x=n.INT;else if(u instanceof Int8Array)x=n.BYTE;else if(u instanceof Uint8Array)x=n.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)x=n.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:_,type:x,bytesPerElement:u.BYTES_PER_ELEMENT,version:c.version,size:m}}function s(c,d,u){const h=d.array,m=d._updateRange,_=d.updateRanges;if(n.bindBuffer(u,c),m.count===-1&&_.length===0&&n.bufferSubData(u,0,h),_.length!==0){for(let x=0,p=_.length;x<p;x++){const f=_[x];t?n.bufferSubData(u,f.start*h.BYTES_PER_ELEMENT,h,f.start,f.count):n.bufferSubData(u,f.start*h.BYTES_PER_ELEMENT,h.subarray(f.start,f.start+f.count))}d.clearUpdateRanges()}m.count!==-1&&(t?n.bufferSubData(u,m.offset*h.BYTES_PER_ELEMENT,h,m.offset,m.count):n.bufferSubData(u,m.offset*h.BYTES_PER_ELEMENT,h.subarray(m.offset,m.offset+m.count)),m.count=-1),d.onUploadCallback()}function a(c){return c.isInterleavedBufferAttribute&&(c=c.data),i.get(c)}function o(c){c.isInterleavedBufferAttribute&&(c=c.data);const d=i.get(c);d&&(n.deleteBuffer(d.buffer),i.delete(c))}function l(c,d){if(c.isGLBufferAttribute){const h=i.get(c);(!h||h.version<c.version)&&i.set(c,{buffer:c.buffer,type:c.type,bytesPerElement:c.elementSize,version:c.version});return}c.isInterleavedBufferAttribute&&(c=c.data);const u=i.get(c);if(u===void 0)i.set(c,r(c,d));else if(u.version<c.version){if(u.size!==c.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(u.buffer,c,d),u.version=c.version}}return{get:a,remove:o,update:l}}class Nn extends rt{constructor(e=1,t=1,i=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:r};const s=e/2,a=t/2,o=Math.floor(i),l=Math.floor(r),c=o+1,d=l+1,u=e/o,h=t/l,m=[],_=[],x=[],p=[];for(let f=0;f<d;f++){const v=f*h-a;for(let g=0;g<c;g++){const y=g*u-s;_.push(y,-v,0),x.push(0,0,1),p.push(g/o),p.push(1-f/l)}}for(let f=0;f<l;f++)for(let v=0;v<o;v++){const g=v+c*f,y=v+c*(f+1),R=v+1+c*(f+1),T=v+1+c*f;m.push(g,y,T),m.push(y,R,T)}this.setIndex(m),this.setAttribute("position",new Ve(_,3)),this.setAttribute("normal",new Ve(x,3)),this.setAttribute("uv",new Ve(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Nn(e.width,e.height,e.widthSegments,e.heightSegments)}}var Hu=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Vu=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Wu=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Xu=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,qu=`#ifdef USE_ALPHATEST
	if ( diffuseColor.a < alphaTest ) discard;
#endif`,Yu=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,ju=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Zu=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,$u=`#ifdef USE_BATCHING
	attribute float batchId;
	uniform highp sampler2D batchingTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Ku=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( batchId );
#endif`,Ju=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Qu=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,ed=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,td=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,nd=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,id=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#pragma unroll_loop_start
	for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
		plane = clippingPlanes[ i ];
		if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
	}
	#pragma unroll_loop_end
	#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
		bool clipped = true;
		#pragma unroll_loop_start
		for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
		}
		#pragma unroll_loop_end
		if ( clipped ) discard;
	#endif
#endif`,rd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,sd=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,ad=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,od=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,ld=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,cd=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	varying vec3 vColor;
#endif`,hd=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif`,ud=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( 0.2126729, 0.7151522, 0.0721750 );
	return dot( weights, rgb );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,dd=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,fd=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,pd=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,md=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,gd=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,xd=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,_d="gl_FragColor = linearToOutputTexel( gl_FragColor );",vd=`
const mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(
	vec3( 0.8224621, 0.177538, 0.0 ),
	vec3( 0.0331941, 0.9668058, 0.0 ),
	vec3( 0.0170827, 0.0723974, 0.9105199 )
);
const mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(
	vec3( 1.2249401, - 0.2249404, 0.0 ),
	vec3( - 0.0420569, 1.0420571, 0.0 ),
	vec3( - 0.0196376, - 0.0786361, 1.0982735 )
);
vec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {
	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );
}
vec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {
	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );
}
vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}
vec4 LinearToLinear( in vec4 value ) {
	return value;
}
vec4 LinearTosRGB( in vec4 value ) {
	return sRGBTransferOETF( value );
}`,yd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Md=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Sd=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,bd=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,wd=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,Ed=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Td=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Ad=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Rd=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Cd=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,Pd=`#ifdef USE_LIGHTMAP
	vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
	vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
	reflectedLight.indirectDiffuse += lightMapIrradiance;
#endif`,Ld=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Dd=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Id=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Ud=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	#if defined ( LEGACY_LIGHTS )
		if ( cutoffDistance > 0.0 && decayExponent > 0.0 ) {
			return pow( saturate( - lightDistance / cutoffDistance + 1.0 ), decayExponent );
		}
		return 1.0;
	#else
		float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
		if ( cutoffDistance > 0.0 ) {
			distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
		}
		return distanceFalloff;
	#endif
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,zd=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Nd=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Fd=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Od=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,kd=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Bd=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Gd=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Hd=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Vd=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Wd=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Xd=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	gl_FragDepthEXT = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,qd=`#if defined( USE_LOGDEPTHBUF ) && defined( USE_LOGDEPTHBUF_EXT )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Yd=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		varying float vFragDepth;
		varying float vIsPerspective;
	#else
		uniform float logDepthBufFC;
	#endif
#endif`,jd=`#ifdef USE_LOGDEPTHBUF
	#ifdef USE_LOGDEPTHBUF_EXT
		vFragDepth = 1.0 + gl_Position.w;
		vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
	#else
		if ( isPerspectiveMatrix( projectionMatrix ) ) {
			gl_Position.z = log2( max( EPSILON, gl_Position.w + 1.0 ) ) * logDepthBufFC - 1.0;
			gl_Position.z *= gl_Position.w;
		}
	#endif
#endif`,Zd=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );
	
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,$d=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Kd=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Jd=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Qd=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,ef=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,tf=`#if defined( USE_MORPHCOLORS ) && defined( MORPHTARGETS_TEXTURE )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,nf=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		objectNormal += morphNormal0 * morphTargetInfluences[ 0 ];
		objectNormal += morphNormal1 * morphTargetInfluences[ 1 ];
		objectNormal += morphNormal2 * morphTargetInfluences[ 2 ];
		objectNormal += morphNormal3 * morphTargetInfluences[ 3 ];
	#endif
#endif`,rf=`#ifdef USE_MORPHTARGETS
	uniform float morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
		uniform sampler2DArray morphTargetsTexture;
		uniform ivec2 morphTargetsTextureSize;
		vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
			int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
			int y = texelIndex / morphTargetsTextureSize.x;
			int x = texelIndex - y * morphTargetsTextureSize.x;
			ivec3 morphUV = ivec3( x, y, morphTargetIndex );
			return texelFetch( morphTargetsTexture, morphUV, 0 );
		}
	#else
		#ifndef USE_MORPHNORMALS
			uniform float morphTargetInfluences[ 8 ];
		#else
			uniform float morphTargetInfluences[ 4 ];
		#endif
	#endif
#endif`,sf=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	#ifdef MORPHTARGETS_TEXTURE
		for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
			if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
		}
	#else
		transformed += morphTarget0 * morphTargetInfluences[ 0 ];
		transformed += morphTarget1 * morphTargetInfluences[ 1 ];
		transformed += morphTarget2 * morphTargetInfluences[ 2 ];
		transformed += morphTarget3 * morphTargetInfluences[ 3 ];
		#ifndef USE_MORPHNORMALS
			transformed += morphTarget4 * morphTargetInfluences[ 4 ];
			transformed += morphTarget5 * morphTargetInfluences[ 5 ];
			transformed += morphTarget6 * morphTargetInfluences[ 6 ];
			transformed += morphTarget7 * morphTargetInfluences[ 7 ];
		#endif
	#endif
#endif`,af=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,of=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,lf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,cf=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,hf=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,uf=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,df=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,ff=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,pf=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,mf=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,gf=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,xf=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;
const vec3 PackFactors = vec3( 256. * 256. * 256., 256. * 256., 256. );
const vec4 UnpackFactors = UnpackDownscale / vec4( PackFactors, 1. );
const float ShiftRight8 = 1. / 256.;
vec4 packDepthToRGBA( const in float v ) {
	vec4 r = vec4( fract( v * PackFactors ), v );
	r.yzw -= r.xyz * ShiftRight8;	return r * PackUpscale;
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors );
}
vec2 packDepthToRG( in highp float v ) {
	return packDepthToRGBA( v ).yx;
}
float unpackRGToDepth( const in highp vec2 v ) {
	return unpackRGBAToDepth( vec4( v.xy, 0.0, 0.0 ) );
}
vec4 pack2HalfToRGBA( vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,_f=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,vf=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,yf=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Mf=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Sf=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,bf=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,wf=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return shadow;
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
		vec3 lightToPosition = shadowCoord.xyz;
		float dp = ( length( lightToPosition ) - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );		dp += shadowBias;
		vec3 bd3D = normalize( lightToPosition );
		#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
			vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
			return (
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
				texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
			) * ( 1.0 / 9.0 );
		#else
			return texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
		#endif
	}
#endif`,Ef=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,Tf=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,Af=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Rf=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,Cf=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Pf=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,Lf=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Df=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,If=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Uf=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,zf=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 OptimizedCineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color *= toneMappingExposure;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	return color;
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Nf=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Ff=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
		vec3 refractedRayExit = position + transmissionRay;
		vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
		vec2 refractionCoords = ndcPos.xy / ndcPos.w;
		refractionCoords += 1.0;
		refractionCoords /= 2.0;
		vec4 transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
		vec3 transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Of=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,kf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Bf=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Gf=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Hf=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Vf=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Wf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Xf=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,qf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Yf=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,jf=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Zf=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#endif
}`,$f=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Kf=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( 1.0 );
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,Jf=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Qf=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,e0=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,t0=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,n0=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,i0=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,r0=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,s0=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,a0=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,o0=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,l0=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,c0=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), opacity );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,h0=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,u0=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,d0=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,f0=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,p0=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,m0=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec4 diffuseColor = vec4( diffuse, opacity );
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,g0=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,x0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,_0=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,v0=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,y0=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix * vec4( 0.0, 0.0, 0.0, 1.0 );
	vec2 scale;
	scale.x = length( vec3( modelMatrix[ 0 ].x, modelMatrix[ 0 ].y, modelMatrix[ 0 ].z ) );
	scale.y = length( vec3( modelMatrix[ 1 ].x, modelMatrix[ 1 ].y, modelMatrix[ 1 ].z ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,M0=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Ye={alphahash_fragment:Hu,alphahash_pars_fragment:Vu,alphamap_fragment:Wu,alphamap_pars_fragment:Xu,alphatest_fragment:qu,alphatest_pars_fragment:Yu,aomap_fragment:ju,aomap_pars_fragment:Zu,batching_pars_vertex:$u,batching_vertex:Ku,begin_vertex:Ju,beginnormal_vertex:Qu,bsdfs:ed,iridescence_fragment:td,bumpmap_pars_fragment:nd,clipping_planes_fragment:id,clipping_planes_pars_fragment:rd,clipping_planes_pars_vertex:sd,clipping_planes_vertex:ad,color_fragment:od,color_pars_fragment:ld,color_pars_vertex:cd,color_vertex:hd,common:ud,cube_uv_reflection_fragment:dd,defaultnormal_vertex:fd,displacementmap_pars_vertex:pd,displacementmap_vertex:md,emissivemap_fragment:gd,emissivemap_pars_fragment:xd,colorspace_fragment:_d,colorspace_pars_fragment:vd,envmap_fragment:yd,envmap_common_pars_fragment:Md,envmap_pars_fragment:Sd,envmap_pars_vertex:bd,envmap_physical_pars_fragment:zd,envmap_vertex:wd,fog_vertex:Ed,fog_pars_vertex:Td,fog_fragment:Ad,fog_pars_fragment:Rd,gradientmap_pars_fragment:Cd,lightmap_fragment:Pd,lightmap_pars_fragment:Ld,lights_lambert_fragment:Dd,lights_lambert_pars_fragment:Id,lights_pars_begin:Ud,lights_toon_fragment:Nd,lights_toon_pars_fragment:Fd,lights_phong_fragment:Od,lights_phong_pars_fragment:kd,lights_physical_fragment:Bd,lights_physical_pars_fragment:Gd,lights_fragment_begin:Hd,lights_fragment_maps:Vd,lights_fragment_end:Wd,logdepthbuf_fragment:Xd,logdepthbuf_pars_fragment:qd,logdepthbuf_pars_vertex:Yd,logdepthbuf_vertex:jd,map_fragment:Zd,map_pars_fragment:$d,map_particle_fragment:Kd,map_particle_pars_fragment:Jd,metalnessmap_fragment:Qd,metalnessmap_pars_fragment:ef,morphcolor_vertex:tf,morphnormal_vertex:nf,morphtarget_pars_vertex:rf,morphtarget_vertex:sf,normal_fragment_begin:af,normal_fragment_maps:of,normal_pars_fragment:lf,normal_pars_vertex:cf,normal_vertex:hf,normalmap_pars_fragment:uf,clearcoat_normal_fragment_begin:df,clearcoat_normal_fragment_maps:ff,clearcoat_pars_fragment:pf,iridescence_pars_fragment:mf,opaque_fragment:gf,packing:xf,premultiplied_alpha_fragment:_f,project_vertex:vf,dithering_fragment:yf,dithering_pars_fragment:Mf,roughnessmap_fragment:Sf,roughnessmap_pars_fragment:bf,shadowmap_pars_fragment:wf,shadowmap_pars_vertex:Ef,shadowmap_vertex:Tf,shadowmask_pars_fragment:Af,skinbase_vertex:Rf,skinning_pars_vertex:Cf,skinning_vertex:Pf,skinnormal_vertex:Lf,specularmap_fragment:Df,specularmap_pars_fragment:If,tonemapping_fragment:Uf,tonemapping_pars_fragment:zf,transmission_fragment:Nf,transmission_pars_fragment:Ff,uv_pars_fragment:Of,uv_pars_vertex:kf,uv_vertex:Bf,worldpos_vertex:Gf,background_vert:Hf,background_frag:Vf,backgroundCube_vert:Wf,backgroundCube_frag:Xf,cube_vert:qf,cube_frag:Yf,depth_vert:jf,depth_frag:Zf,distanceRGBA_vert:$f,distanceRGBA_frag:Kf,equirect_vert:Jf,equirect_frag:Qf,linedashed_vert:e0,linedashed_frag:t0,meshbasic_vert:n0,meshbasic_frag:i0,meshlambert_vert:r0,meshlambert_frag:s0,meshmatcap_vert:a0,meshmatcap_frag:o0,meshnormal_vert:l0,meshnormal_frag:c0,meshphong_vert:h0,meshphong_frag:u0,meshphysical_vert:d0,meshphysical_frag:f0,meshtoon_vert:p0,meshtoon_frag:m0,points_vert:g0,points_frag:x0,shadow_vert:_0,shadow_frag:v0,sprite_vert:y0,sprite_frag:M0},_e={common:{diffuse:{value:new $e(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Xe},alphaMap:{value:null},alphaMapTransform:{value:new Xe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Xe}},envmap:{envMap:{value:null},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Xe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Xe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Xe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Xe},normalScale:{value:new Oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Xe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Xe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Xe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Xe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new $e(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new $e(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Xe},alphaTest:{value:0},uvTransform:{value:new Xe}},sprite:{diffuse:{value:new $e(16777215)},opacity:{value:1},center:{value:new Oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Xe},alphaMap:{value:null},alphaMapTransform:{value:new Xe},alphaTest:{value:0}}},on={basic:{uniforms:Ft([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.fog]),vertexShader:Ye.meshbasic_vert,fragmentShader:Ye.meshbasic_frag},lambert:{uniforms:Ft([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,_e.lights,{emissive:{value:new $e(0)}}]),vertexShader:Ye.meshlambert_vert,fragmentShader:Ye.meshlambert_frag},phong:{uniforms:Ft([_e.common,_e.specularmap,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,_e.lights,{emissive:{value:new $e(0)},specular:{value:new $e(1118481)},shininess:{value:30}}]),vertexShader:Ye.meshphong_vert,fragmentShader:Ye.meshphong_frag},standard:{uniforms:Ft([_e.common,_e.envmap,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.roughnessmap,_e.metalnessmap,_e.fog,_e.lights,{emissive:{value:new $e(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ye.meshphysical_vert,fragmentShader:Ye.meshphysical_frag},toon:{uniforms:Ft([_e.common,_e.aomap,_e.lightmap,_e.emissivemap,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.gradientmap,_e.fog,_e.lights,{emissive:{value:new $e(0)}}]),vertexShader:Ye.meshtoon_vert,fragmentShader:Ye.meshtoon_frag},matcap:{uniforms:Ft([_e.common,_e.bumpmap,_e.normalmap,_e.displacementmap,_e.fog,{matcap:{value:null}}]),vertexShader:Ye.meshmatcap_vert,fragmentShader:Ye.meshmatcap_frag},points:{uniforms:Ft([_e.points,_e.fog]),vertexShader:Ye.points_vert,fragmentShader:Ye.points_frag},dashed:{uniforms:Ft([_e.common,_e.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ye.linedashed_vert,fragmentShader:Ye.linedashed_frag},depth:{uniforms:Ft([_e.common,_e.displacementmap]),vertexShader:Ye.depth_vert,fragmentShader:Ye.depth_frag},normal:{uniforms:Ft([_e.common,_e.bumpmap,_e.normalmap,_e.displacementmap,{opacity:{value:1}}]),vertexShader:Ye.meshnormal_vert,fragmentShader:Ye.meshnormal_frag},sprite:{uniforms:Ft([_e.sprite,_e.fog]),vertexShader:Ye.sprite_vert,fragmentShader:Ye.sprite_frag},background:{uniforms:{uvTransform:{value:new Xe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ye.background_vert,fragmentShader:Ye.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1}},vertexShader:Ye.backgroundCube_vert,fragmentShader:Ye.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ye.cube_vert,fragmentShader:Ye.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ye.equirect_vert,fragmentShader:Ye.equirect_frag},distanceRGBA:{uniforms:Ft([_e.common,_e.displacementmap,{referencePosition:{value:new N},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ye.distanceRGBA_vert,fragmentShader:Ye.distanceRGBA_frag},shadow:{uniforms:Ft([_e.lights,_e.fog,{color:{value:new $e(0)},opacity:{value:1}}]),vertexShader:Ye.shadow_vert,fragmentShader:Ye.shadow_frag}};on.physical={uniforms:Ft([on.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Xe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Xe},clearcoatNormalScale:{value:new Oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Xe},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Xe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Xe},sheen:{value:0},sheenColor:{value:new $e(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Xe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Xe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Xe},transmissionSamplerSize:{value:new Oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Xe},attenuationDistance:{value:0},attenuationColor:{value:new $e(0)},specularColor:{value:new $e(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Xe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Xe},anisotropyVector:{value:new Oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Xe}}]),vertexShader:Ye.meshphysical_vert,fragmentShader:Ye.meshphysical_frag};const Gr={r:0,b:0,g:0};function S0(n,e,t,i,r,s,a){const o=new $e(0);let l=s===!0?0:1,c,d,u=null,h=0,m=null;function _(p,f){let v=!1,g=f.isScene===!0?f.background:null;g&&g.isTexture&&(g=(f.backgroundBlurriness>0?t:e).get(g)),g===null?x(o,l):g&&g.isColor&&(x(g,1),v=!0);const y=n.xr.getEnvironmentBlendMode();y==="additive"?i.buffers.color.setClear(0,0,0,1,a):y==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(n.autoClear||v)&&n.clear(n.autoClearColor,n.autoClearDepth,n.autoClearStencil),g&&(g.isCubeTexture||g.mapping===_s)?(d===void 0&&(d=new Le(new _t(1,1,1),new si({name:"BackgroundCubeMaterial",uniforms:Vi(on.backgroundCube.uniforms),vertexShader:on.backgroundCube.vertexShader,fragmentShader:on.backgroundCube.fragmentShader,side:Bt,depthTest:!1,depthWrite:!1,fog:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(R,T,C){this.matrixWorld.copyPosition(C.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(d)),d.material.uniforms.envMap.value=g,d.material.uniforms.flipEnvMap.value=g.isCubeTexture&&g.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=f.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,d.material.toneMapped=tt.getTransfer(g.colorSpace)!==ct,(u!==g||h!==g.version||m!==n.toneMapping)&&(d.material.needsUpdate=!0,u=g,h=g.version,m=n.toneMapping),d.layers.enableAll(),p.unshift(d,d.geometry,d.material,0,0,null)):g&&g.isTexture&&(c===void 0&&(c=new Le(new Nn(2,2),new si({name:"BackgroundMaterial",uniforms:Vi(on.background.uniforms),vertexShader:on.background.vertexShader,fragmentShader:on.background.fragmentShader,side:yn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=g,c.material.uniforms.backgroundIntensity.value=f.backgroundIntensity,c.material.toneMapped=tt.getTransfer(g.colorSpace)!==ct,g.matrixAutoUpdate===!0&&g.updateMatrix(),c.material.uniforms.uvTransform.value.copy(g.matrix),(u!==g||h!==g.version||m!==n.toneMapping)&&(c.material.needsUpdate=!0,u=g,h=g.version,m=n.toneMapping),c.layers.enableAll(),p.unshift(c,c.geometry,c.material,0,0,null))}function x(p,f){p.getRGB(Gr,Ec(n)),i.buffers.color.setClear(Gr.r,Gr.g,Gr.b,f,a)}return{getClearColor:function(){return o},setClearColor:function(p,f=1){o.set(p),l=f,x(o,l)},getClearAlpha:function(){return l},setClearAlpha:function(p){l=p,x(o,l)},render:_}}function b0(n,e,t,i){const r=n.getParameter(n.MAX_VERTEX_ATTRIBS),s=i.isWebGL2?null:e.get("OES_vertex_array_object"),a=i.isWebGL2||s!==null,o={},l=p(null);let c=l,d=!1;function u(L,U,B,X,K){let ie=!1;if(a){const ne=x(X,B,U);c!==ne&&(c=ne,m(c.object)),ie=f(L,X,B,K),ie&&v(L,X,B,K)}else{const ne=U.wireframe===!0;(c.geometry!==X.id||c.program!==B.id||c.wireframe!==ne)&&(c.geometry=X.id,c.program=B.id,c.wireframe=ne,ie=!0)}K!==null&&t.update(K,n.ELEMENT_ARRAY_BUFFER),(ie||d)&&(d=!1,z(L,U,B,X),K!==null&&n.bindBuffer(n.ELEMENT_ARRAY_BUFFER,t.get(K).buffer))}function h(){return i.isWebGL2?n.createVertexArray():s.createVertexArrayOES()}function m(L){return i.isWebGL2?n.bindVertexArray(L):s.bindVertexArrayOES(L)}function _(L){return i.isWebGL2?n.deleteVertexArray(L):s.deleteVertexArrayOES(L)}function x(L,U,B){const X=B.wireframe===!0;let K=o[L.id];K===void 0&&(K={},o[L.id]=K);let ie=K[U.id];ie===void 0&&(ie={},K[U.id]=ie);let ne=ie[X];return ne===void 0&&(ne=p(h()),ie[X]=ne),ne}function p(L){const U=[],B=[],X=[];for(let K=0;K<r;K++)U[K]=0,B[K]=0,X[K]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:U,enabledAttributes:B,attributeDivisors:X,object:L,attributes:{},index:null}}function f(L,U,B,X){const K=c.attributes,ie=U.attributes;let ne=0;const ue=B.getAttributes();for(const de in ue)if(ue[de].location>=0){const se=K[de];let ge=ie[de];if(ge===void 0&&(de==="instanceMatrix"&&L.instanceMatrix&&(ge=L.instanceMatrix),de==="instanceColor"&&L.instanceColor&&(ge=L.instanceColor)),se===void 0||se.attribute!==ge||ge&&se.data!==ge.data)return!0;ne++}return c.attributesNum!==ne||c.index!==X}function v(L,U,B,X){const K={},ie=U.attributes;let ne=0;const ue=B.getAttributes();for(const de in ue)if(ue[de].location>=0){let se=ie[de];se===void 0&&(de==="instanceMatrix"&&L.instanceMatrix&&(se=L.instanceMatrix),de==="instanceColor"&&L.instanceColor&&(se=L.instanceColor));const ge={};ge.attribute=se,se&&se.data&&(ge.data=se.data),K[de]=ge,ne++}c.attributes=K,c.attributesNum=ne,c.index=X}function g(){const L=c.newAttributes;for(let U=0,B=L.length;U<B;U++)L[U]=0}function y(L){R(L,0)}function R(L,U){const B=c.newAttributes,X=c.enabledAttributes,K=c.attributeDivisors;B[L]=1,X[L]===0&&(n.enableVertexAttribArray(L),X[L]=1),K[L]!==U&&((i.isWebGL2?n:e.get("ANGLE_instanced_arrays"))[i.isWebGL2?"vertexAttribDivisor":"vertexAttribDivisorANGLE"](L,U),K[L]=U)}function T(){const L=c.newAttributes,U=c.enabledAttributes;for(let B=0,X=U.length;B<X;B++)U[B]!==L[B]&&(n.disableVertexAttribArray(B),U[B]=0)}function C(L,U,B,X,K,ie,ne){ne===!0?n.vertexAttribIPointer(L,U,B,K,ie):n.vertexAttribPointer(L,U,B,X,K,ie)}function z(L,U,B,X){if(i.isWebGL2===!1&&(L.isInstancedMesh||X.isInstancedBufferGeometry)&&e.get("ANGLE_instanced_arrays")===null)return;g();const K=X.attributes,ie=B.getAttributes(),ne=U.defaultAttributeValues;for(const ue in ie){const de=ie[ue];if(de.location>=0){let J=K[ue];if(J===void 0&&(ue==="instanceMatrix"&&L.instanceMatrix&&(J=L.instanceMatrix),ue==="instanceColor"&&L.instanceColor&&(J=L.instanceColor)),J!==void 0){const se=J.normalized,ge=J.itemSize,Ae=t.get(J);if(Ae===void 0)continue;const we=Ae.buffer,ke=Ae.type,Ge=Ae.bytesPerElement,Ie=i.isWebGL2===!0&&(ke===n.INT||ke===n.UNSIGNED_INT||J.gpuType===lc);if(J.isInterleavedBufferAttribute){const w=J.data,b=w.stride,H=J.offset;if(w.isInstancedInterleavedBuffer){for(let F=0;F<de.locationSize;F++)R(de.location+F,w.meshPerAttribute);L.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=w.meshPerAttribute*w.count)}else for(let F=0;F<de.locationSize;F++)y(de.location+F);n.bindBuffer(n.ARRAY_BUFFER,we);for(let F=0;F<de.locationSize;F++)C(de.location+F,ge/de.locationSize,ke,se,b*Ge,(H+ge/de.locationSize*F)*Ge,Ie)}else{if(J.isInstancedBufferAttribute){for(let w=0;w<de.locationSize;w++)R(de.location+w,J.meshPerAttribute);L.isInstancedMesh!==!0&&X._maxInstanceCount===void 0&&(X._maxInstanceCount=J.meshPerAttribute*J.count)}else for(let w=0;w<de.locationSize;w++)y(de.location+w);n.bindBuffer(n.ARRAY_BUFFER,we);for(let w=0;w<de.locationSize;w++)C(de.location+w,ge/de.locationSize,ke,se,ge*Ge,ge/de.locationSize*w*Ge,Ie)}}else if(ne!==void 0){const se=ne[ue];if(se!==void 0)switch(se.length){case 2:n.vertexAttrib2fv(de.location,se);break;case 3:n.vertexAttrib3fv(de.location,se);break;case 4:n.vertexAttrib4fv(de.location,se);break;default:n.vertexAttrib1fv(de.location,se)}}}}T()}function M(){I();for(const L in o){const U=o[L];for(const B in U){const X=U[B];for(const K in X)_(X[K].object),delete X[K];delete U[B]}delete o[L]}}function S(L){if(o[L.id]===void 0)return;const U=o[L.id];for(const B in U){const X=U[B];for(const K in X)_(X[K].object),delete X[K];delete U[B]}delete o[L.id]}function G(L){for(const U in o){const B=o[U];if(B[L.id]===void 0)continue;const X=B[L.id];for(const K in X)_(X[K].object),delete X[K];delete B[L.id]}}function I(){W(),d=!0,c!==l&&(c=l,m(c.object))}function W(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:u,reset:I,resetDefaultState:W,dispose:M,releaseStatesOfGeometry:S,releaseStatesOfProgram:G,initAttributes:g,enableAttribute:y,disableUnusedAttributes:T}}function w0(n,e,t,i){const r=i.isWebGL2;let s;function a(d){s=d}function o(d,u){n.drawArrays(s,d,u),t.update(u,s,1)}function l(d,u,h){if(h===0)return;let m,_;if(r)m=n,_="drawArraysInstanced";else if(m=e.get("ANGLE_instanced_arrays"),_="drawArraysInstancedANGLE",m===null){console.error("THREE.WebGLBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}m[_](s,d,u,h),t.update(u,s,h)}function c(d,u,h){if(h===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let _=0;_<h;_++)this.render(d[_],u[_]);else{m.multiDrawArraysWEBGL(s,d,0,u,0,h);let _=0;for(let x=0;x<h;x++)_+=u[x];t.update(_,s,1)}}this.setMode=a,this.render=o,this.renderInstances=l,this.renderMultiDraw=c}function E0(n,e,t){let i;function r(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const C=e.get("EXT_texture_filter_anisotropic");i=n.getParameter(C.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function s(C){if(C==="highp"){if(n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.HIGH_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.HIGH_FLOAT).precision>0)return"highp";C="mediump"}return C==="mediump"&&n.getShaderPrecisionFormat(n.VERTEX_SHADER,n.MEDIUM_FLOAT).precision>0&&n.getShaderPrecisionFormat(n.FRAGMENT_SHADER,n.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}const a=typeof WebGL2RenderingContext<"u"&&n.constructor.name==="WebGL2RenderingContext";let o=t.precision!==void 0?t.precision:"highp";const l=s(o);l!==o&&(console.warn("THREE.WebGLRenderer:",o,"not supported, using",l,"instead."),o=l);const c=a||e.has("WEBGL_draw_buffers"),d=t.logarithmicDepthBuffer===!0,u=n.getParameter(n.MAX_TEXTURE_IMAGE_UNITS),h=n.getParameter(n.MAX_VERTEX_TEXTURE_IMAGE_UNITS),m=n.getParameter(n.MAX_TEXTURE_SIZE),_=n.getParameter(n.MAX_CUBE_MAP_TEXTURE_SIZE),x=n.getParameter(n.MAX_VERTEX_ATTRIBS),p=n.getParameter(n.MAX_VERTEX_UNIFORM_VECTORS),f=n.getParameter(n.MAX_VARYING_VECTORS),v=n.getParameter(n.MAX_FRAGMENT_UNIFORM_VECTORS),g=h>0,y=a||e.has("OES_texture_float"),R=g&&y,T=a?n.getParameter(n.MAX_SAMPLES):0;return{isWebGL2:a,drawBuffers:c,getMaxAnisotropy:r,getMaxPrecision:s,precision:o,logarithmicDepthBuffer:d,maxTextures:u,maxVertexTextures:h,maxTextureSize:m,maxCubemapSize:_,maxAttributes:x,maxVertexUniforms:p,maxVaryings:f,maxFragmentUniforms:v,vertexTextures:g,floatFragmentTextures:y,floatVertexTextures:R,maxSamples:T}}function T0(n){const e=this;let t=null,i=0,r=!1,s=!1;const a=new Yn,o=new Xe,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,h){const m=u.length!==0||h||i!==0||r;return r=h,i=u.length,m},this.beginShadows=function(){s=!0,d(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,h){t=d(u,h,0)},this.setState=function(u,h,m){const _=u.clippingPlanes,x=u.clipIntersection,p=u.clipShadows,f=n.get(u);if(!r||_===null||_.length===0||s&&!p)s?d(null):c();else{const v=s?0:i,g=v*4;let y=f.clippingState||null;l.value=y,y=d(_,h,g,m);for(let R=0;R!==g;++R)y[R]=t[R];f.clippingState=y,this.numIntersection=x?this.numPlanes:0,this.numPlanes+=v}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}function d(u,h,m,_){const x=u!==null?u.length:0;let p=null;if(x!==0){if(p=l.value,_!==!0||p===null){const f=m+x*4,v=h.matrixWorldInverse;o.getNormalMatrix(v),(p===null||p.length<f)&&(p=new Float32Array(f));for(let g=0,y=m;g!==x;++g,y+=4)a.copy(u[g]).applyMatrix4(v,o),a.normal.toArray(p,y),p[y+3]=a.constant}l.value=p,l.needsUpdate=!0}return e.numPlanes=x,e.numIntersection=0,p}}function A0(n){let e=new WeakMap;function t(a,o){return o===Ea?a.mapping=Bi:o===Ta&&(a.mapping=Gi),a}function i(a){if(a&&a.isTexture){const o=a.mapping;if(o===Ea||o===Ta)if(e.has(a)){const l=e.get(a).texture;return t(l,a.mapping)}else{const l=a.image;if(l&&l.height>0){const c=new Ou(l.height/2);return c.fromEquirectangularTexture(n,a),e.set(a,c),a.addEventListener("dispose",r),t(c.texture,a.mapping)}else return null}}return a}function r(a){const o=a.target;o.removeEventListener("dispose",r);const l=e.get(o);l!==void 0&&(e.delete(o),l.dispose())}function s(){e=new WeakMap}return{get:i,dispose:s}}class $a extends Tc{constructor(e=-1,t=1,i=1,r=-1,s=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=r,this.near=s,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,r,s,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=r,this.view.width=s,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=i-e,a=i+e,o=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,d=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,a=s+c*this.view.width,o-=d*this.view.offsetY,l=o-d*this.view.height}this.projectionMatrix.makeOrthographic(s,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const Ii=4,ul=[.125,.215,.35,.446,.526,.582],Kn=20,la=new $a,dl=new $e;let ca=null,ha=0,ua=0;const jn=(1+Math.sqrt(5))/2,bi=1/jn,fl=[new N(1,1,1),new N(-1,1,1),new N(1,1,-1),new N(-1,1,-1),new N(0,jn,bi),new N(0,jn,-bi),new N(bi,0,jn),new N(-bi,0,jn),new N(jn,bi,0),new N(-jn,bi,0)];class pl{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,r=100){ca=this._renderer.getRenderTarget(),ha=this._renderer.getActiveCubeFace(),ua=this._renderer.getActiveMipmapLevel(),this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,i,r,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=xl(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=gl(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(ca,ha,ua),e.scissorTest=!1,Hr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Bi||e.mapping===Gi?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ca=this._renderer.getRenderTarget(),ha=this._renderer.getActiveCubeFace(),ua=this._renderer.getActiveMipmapLevel();const i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:$t,minFilter:$t,generateMipmaps:!1,type:dr,format:sn,colorSpace:Mn,depthBuffer:!1},r=ml(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=ml(e,t,i);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=R0(s)),this._blurMaterial=C0(s,e,t)}return r}_compileMaterial(e){const t=new Le(this._lodPlanes[0],e);this._renderer.compile(t,la)}_sceneToCubeUV(e,t,i,r){const o=new qt(90,1,t,i),l=[1,-1,1,1,1,1],c=[1,1,1,-1,-1,-1],d=this._renderer,u=d.autoClear,h=d.toneMapping;d.getClearColor(dl),d.toneMapping=In,d.autoClear=!1;const m=new Oi({name:"PMREM.Background",side:Bt,depthWrite:!1,depthTest:!1}),_=new Le(new _t,m);let x=!1;const p=e.background;p?p.isColor&&(m.color.copy(p),e.background=null,x=!0):(m.color.copy(dl),x=!0);for(let f=0;f<6;f++){const v=f%3;v===0?(o.up.set(0,l[f],0),o.lookAt(c[f],0,0)):v===1?(o.up.set(0,0,l[f]),o.lookAt(0,c[f],0)):(o.up.set(0,l[f],0),o.lookAt(0,0,c[f]));const g=this._cubeSize;Hr(r,v*g,f>2?g:0,g,g),d.setRenderTarget(r),x&&d.render(_,o),d.render(e,o)}_.geometry.dispose(),_.material.dispose(),d.toneMapping=h,d.autoClear=u,e.background=p}_textureToCubeUV(e,t){const i=this._renderer,r=e.mapping===Bi||e.mapping===Gi;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=xl()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=gl());const s=r?this._cubemapMaterial:this._equirectMaterial,a=new Le(this._lodPlanes[0],s),o=s.uniforms;o.envMap.value=e;const l=this._cubeSize;Hr(t,0,0,3*l,2*l),i.setRenderTarget(t),i.render(a,la)}_applyPMREM(e){const t=this._renderer,i=t.autoClear;t.autoClear=!1;for(let r=1;r<this._lodPlanes.length;r++){const s=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),a=fl[(r-1)%fl.length];this._blur(e,r-1,r,s,a)}t.autoClear=i}_blur(e,t,i,r,s){const a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,r,"latitudinal",s),this._halfBlur(a,e,i,i,r,"longitudinal",s)}_halfBlur(e,t,i,r,s,a,o){const l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const d=3,u=new Le(this._lodPlanes[r],c),h=c.uniforms,m=this._sizeLods[i]-1,_=isFinite(s)?Math.PI/(2*m):2*Math.PI/(2*Kn-1),x=s/_,p=isFinite(s)?1+Math.floor(d*x):Kn;p>Kn&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${p} samples when the maximum is set to ${Kn}`);const f=[];let v=0;for(let C=0;C<Kn;++C){const z=C/x,M=Math.exp(-z*z/2);f.push(M),C===0?v+=M:C<p&&(v+=2*M)}for(let C=0;C<f.length;C++)f[C]=f[C]/v;h.envMap.value=e.texture,h.samples.value=p,h.weights.value=f,h.latitudinal.value=a==="latitudinal",o&&(h.poleAxis.value=o);const{_lodMax:g}=this;h.dTheta.value=_,h.mipInt.value=g-i;const y=this._sizeLods[r],R=3*y*(r>g-Ii?r-g+Ii:0),T=4*(this._cubeSize-y);Hr(t,R,T,3*y,2*y),l.setRenderTarget(t),l.render(u,la)}}function R0(n){const e=[],t=[],i=[];let r=n;const s=n-Ii+1+ul.length;for(let a=0;a<s;a++){const o=Math.pow(2,r);t.push(o);let l=1/o;a>n-Ii?l=ul[a-n+Ii-1]:a===0&&(l=0),i.push(l);const c=1/(o-2),d=-c,u=1+c,h=[d,d,u,d,u,u,d,d,u,u,d,u],m=6,_=6,x=3,p=2,f=1,v=new Float32Array(x*_*m),g=new Float32Array(p*_*m),y=new Float32Array(f*_*m);for(let T=0;T<m;T++){const C=T%3*2/3-1,z=T>2?0:-1,M=[C,z,0,C+2/3,z,0,C+2/3,z+1,0,C,z,0,C+2/3,z+1,0,C,z+1,0];v.set(M,x*_*T),g.set(h,p*_*T);const S=[T,T,T,T,T,T];y.set(S,f*_*T)}const R=new rt;R.setAttribute("position",new Qt(v,x)),R.setAttribute("uv",new Qt(g,p)),R.setAttribute("faceIndex",new Qt(y,f)),e.push(R),r>Ii&&r--}return{lodPlanes:e,sizeLods:t,sigmas:i}}function ml(n,e,t){const i=new ri(n,e,t);return i.texture.mapping=_s,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Hr(n,e,t,i,r){n.viewport.set(e,t,i,r),n.scissor.set(e,t,i,r)}function C0(n,e,t){const i=new Float32Array(Kn),r=new N(0,1,0);return new si({name:"SphericalGaussianBlur",defines:{n:Kn,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${n}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Ka(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function gl(){return new si({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Ka(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function xl(){return new si({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Ka(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Dn,depthTest:!1,depthWrite:!1})}function Ka(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function P0(n){let e=new WeakMap,t=null;function i(o){if(o&&o.isTexture){const l=o.mapping,c=l===Ea||l===Ta,d=l===Bi||l===Gi;if(c||d)if(o.isRenderTargetTexture&&o.needsPMREMUpdate===!0){o.needsPMREMUpdate=!1;let u=e.get(o);return t===null&&(t=new pl(n)),u=c?t.fromEquirectangular(o,u):t.fromCubemap(o,u),e.set(o,u),u.texture}else{if(e.has(o))return e.get(o).texture;{const u=o.image;if(c&&u&&u.height>0||d&&u&&r(u)){t===null&&(t=new pl(n));const h=c?t.fromEquirectangular(o):t.fromCubemap(o);return e.set(o,h),o.addEventListener("dispose",s),h.texture}else return null}}}return o}function r(o){let l=0;const c=6;for(let d=0;d<c;d++)o[d]!==void 0&&l++;return l===c}function s(o){const l=o.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function a(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:a}}function L0(n){const e={};function t(i){if(e[i]!==void 0)return e[i];let r;switch(i){case"WEBGL_depth_texture":r=n.getExtension("WEBGL_depth_texture")||n.getExtension("MOZ_WEBGL_depth_texture")||n.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=n.getExtension("EXT_texture_filter_anisotropic")||n.getExtension("MOZ_EXT_texture_filter_anisotropic")||n.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=n.getExtension("WEBGL_compressed_texture_s3tc")||n.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=n.getExtension("WEBGL_compressed_texture_pvrtc")||n.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=n.getExtension(i)}return e[i]=r,r}return{has:function(i){return t(i)!==null},init:function(i){i.isWebGL2?(t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance")):(t("WEBGL_depth_texture"),t("OES_texture_float"),t("OES_texture_half_float"),t("OES_texture_half_float_linear"),t("OES_standard_derivatives"),t("OES_element_index_uint"),t("OES_vertex_array_object"),t("ANGLE_instanced_arrays")),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture")},get:function(i){const r=t(i);return r===null&&console.warn("THREE.WebGLRenderer: "+i+" extension not supported."),r}}}function D0(n,e,t,i){const r={},s=new WeakMap;function a(u){const h=u.target;h.index!==null&&e.remove(h.index);for(const _ in h.attributes)e.remove(h.attributes[_]);for(const _ in h.morphAttributes){const x=h.morphAttributes[_];for(let p=0,f=x.length;p<f;p++)e.remove(x[p])}h.removeEventListener("dispose",a),delete r[h.id];const m=s.get(h);m&&(e.remove(m),s.delete(h)),i.releaseStatesOfGeometry(h),h.isInstancedBufferGeometry===!0&&delete h._maxInstanceCount,t.memory.geometries--}function o(u,h){return r[h.id]===!0||(h.addEventListener("dispose",a),r[h.id]=!0,t.memory.geometries++),h}function l(u){const h=u.attributes;for(const _ in h)e.update(h[_],n.ARRAY_BUFFER);const m=u.morphAttributes;for(const _ in m){const x=m[_];for(let p=0,f=x.length;p<f;p++)e.update(x[p],n.ARRAY_BUFFER)}}function c(u){const h=[],m=u.index,_=u.attributes.position;let x=0;if(m!==null){const v=m.array;x=m.version;for(let g=0,y=v.length;g<y;g+=3){const R=v[g+0],T=v[g+1],C=v[g+2];h.push(R,T,T,C,C,R)}}else if(_!==void 0){const v=_.array;x=_.version;for(let g=0,y=v.length/3-1;g<y;g+=3){const R=g+0,T=g+1,C=g+2;h.push(R,T,T,C,C,R)}}else return;const p=new(_c(h)?wc:bc)(h,1);p.version=x;const f=s.get(u);f&&e.remove(f),s.set(u,p)}function d(u){const h=s.get(u);if(h){const m=u.index;m!==null&&h.version<m.version&&c(u)}else c(u);return s.get(u)}return{get:o,update:l,getWireframeAttribute:d}}function I0(n,e,t,i){const r=i.isWebGL2;let s;function a(m){s=m}let o,l;function c(m){o=m.type,l=m.bytesPerElement}function d(m,_){n.drawElements(s,_,o,m*l),t.update(_,s,1)}function u(m,_,x){if(x===0)return;let p,f;if(r)p=n,f="drawElementsInstanced";else if(p=e.get("ANGLE_instanced_arrays"),f="drawElementsInstancedANGLE",p===null){console.error("THREE.WebGLIndexedBufferRenderer: using THREE.InstancedBufferGeometry but hardware does not support extension ANGLE_instanced_arrays.");return}p[f](s,_,o,m*l,x),t.update(_,s,x)}function h(m,_,x){if(x===0)return;const p=e.get("WEBGL_multi_draw");if(p===null)for(let f=0;f<x;f++)this.render(m[f]/l,_[f]);else{p.multiDrawElementsWEBGL(s,_,0,o,m,0,x);let f=0;for(let v=0;v<x;v++)f+=_[v];t.update(f,s,1)}}this.setMode=a,this.setIndex=c,this.render=d,this.renderInstances=u,this.renderMultiDraw=h}function U0(n){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(s,a,o){switch(t.calls++,a){case n.TRIANGLES:t.triangles+=o*(s/3);break;case n.LINES:t.lines+=o*(s/2);break;case n.LINE_STRIP:t.lines+=o*(s-1);break;case n.LINE_LOOP:t.lines+=o*s;break;case n.POINTS:t.points+=o*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",a);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:i}}function z0(n,e){return n[0]-e[0]}function N0(n,e){return Math.abs(e[1])-Math.abs(n[1])}function F0(n,e,t){const i={},r=new Float32Array(8),s=new WeakMap,a=new ut,o=[];for(let c=0;c<8;c++)o[c]=[c,0];function l(c,d,u){const h=c.morphTargetInfluences;if(e.isWebGL2===!0){const _=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,x=_!==void 0?_.length:0;let p=s.get(d);if(p===void 0||p.count!==x){let U=function(){W.dispose(),s.delete(d),d.removeEventListener("dispose",U)};var m=U;p!==void 0&&p.texture.dispose();const g=d.morphAttributes.position!==void 0,y=d.morphAttributes.normal!==void 0,R=d.morphAttributes.color!==void 0,T=d.morphAttributes.position||[],C=d.morphAttributes.normal||[],z=d.morphAttributes.color||[];let M=0;g===!0&&(M=1),y===!0&&(M=2),R===!0&&(M=3);let S=d.attributes.position.count*M,G=1;S>e.maxTextureSize&&(G=Math.ceil(S/e.maxTextureSize),S=e.maxTextureSize);const I=new Float32Array(S*G*4*x),W=new Mc(I,S,G,x);W.type=Pn,W.needsUpdate=!0;const L=M*4;for(let B=0;B<x;B++){const X=T[B],K=C[B],ie=z[B],ne=S*G*4*B;for(let ue=0;ue<X.count;ue++){const de=ue*L;g===!0&&(a.fromBufferAttribute(X,ue),I[ne+de+0]=a.x,I[ne+de+1]=a.y,I[ne+de+2]=a.z,I[ne+de+3]=0),y===!0&&(a.fromBufferAttribute(K,ue),I[ne+de+4]=a.x,I[ne+de+5]=a.y,I[ne+de+6]=a.z,I[ne+de+7]=0),R===!0&&(a.fromBufferAttribute(ie,ue),I[ne+de+8]=a.x,I[ne+de+9]=a.y,I[ne+de+10]=a.z,I[ne+de+11]=ie.itemSize===4?a.w:1)}}p={count:x,texture:W,size:new Oe(S,G)},s.set(d,p),d.addEventListener("dispose",U)}let f=0;for(let g=0;g<h.length;g++)f+=h[g];const v=d.morphTargetsRelative?1:1-f;u.getUniforms().setValue(n,"morphTargetBaseInfluence",v),u.getUniforms().setValue(n,"morphTargetInfluences",h),u.getUniforms().setValue(n,"morphTargetsTexture",p.texture,t),u.getUniforms().setValue(n,"morphTargetsTextureSize",p.size)}else{const _=h===void 0?0:h.length;let x=i[d.id];if(x===void 0||x.length!==_){x=[];for(let y=0;y<_;y++)x[y]=[y,0];i[d.id]=x}for(let y=0;y<_;y++){const R=x[y];R[0]=y,R[1]=h[y]}x.sort(N0);for(let y=0;y<8;y++)y<_&&x[y][1]?(o[y][0]=x[y][0],o[y][1]=x[y][1]):(o[y][0]=Number.MAX_SAFE_INTEGER,o[y][1]=0);o.sort(z0);const p=d.morphAttributes.position,f=d.morphAttributes.normal;let v=0;for(let y=0;y<8;y++){const R=o[y],T=R[0],C=R[1];T!==Number.MAX_SAFE_INTEGER&&C?(p&&d.getAttribute("morphTarget"+y)!==p[T]&&d.setAttribute("morphTarget"+y,p[T]),f&&d.getAttribute("morphNormal"+y)!==f[T]&&d.setAttribute("morphNormal"+y,f[T]),r[y]=C,v+=C):(p&&d.hasAttribute("morphTarget"+y)===!0&&d.deleteAttribute("morphTarget"+y),f&&d.hasAttribute("morphNormal"+y)===!0&&d.deleteAttribute("morphNormal"+y),r[y]=0)}const g=d.morphTargetsRelative?1:1-v;u.getUniforms().setValue(n,"morphTargetBaseInfluence",g),u.getUniforms().setValue(n,"morphTargetInfluences",r)}}return{update:l}}function O0(n,e,t,i){let r=new WeakMap;function s(l){const c=i.render.frame,d=l.geometry,u=e.get(l,d);if(r.get(u)!==c&&(e.update(u),r.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",o)===!1&&l.addEventListener("dispose",o),r.get(l)!==c&&(t.update(l.instanceMatrix,n.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,n.ARRAY_BUFFER),r.set(l,c))),l.isSkinnedMesh){const h=l.skeleton;r.get(h)!==c&&(h.update(),r.set(h,c))}return u}function a(){r=new WeakMap}function o(l){const c=l.target;c.removeEventListener("dispose",o),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:s,dispose:a}}class Cc extends Gt{constructor(e,t,i,r,s,a,o,l,c,d){if(d=d!==void 0?d:ti,d!==ti&&d!==Hi)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&d===ti&&(i=Cn),i===void 0&&d===Hi&&(i=ei),super(null,r,s,a,o,l,d,i,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:Pt,this.minFilter=l!==void 0?l:Pt,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const Pc=new Gt,Lc=new Cc(1,1);Lc.compareFunction=xc;const Dc=new Mc,Ic=new Mu,Uc=new Ac,_l=[],vl=[],yl=new Float32Array(16),Ml=new Float32Array(9),Sl=new Float32Array(4);function Ki(n,e,t){const i=n[0];if(i<=0||i>0)return n;const r=e*t;let s=_l[r];if(s===void 0&&(s=new Float32Array(r),_l[r]=s),e!==0){i.toArray(s,0);for(let a=1,o=0;a!==e;++a)o+=t,n[a].toArray(s,o)}return s}function Mt(n,e){if(n.length!==e.length)return!1;for(let t=0,i=n.length;t<i;t++)if(n[t]!==e[t])return!1;return!0}function St(n,e){for(let t=0,i=e.length;t<i;t++)n[t]=e[t]}function Ms(n,e){let t=vl[e];t===void 0&&(t=new Int32Array(e),vl[e]=t);for(let i=0;i!==e;++i)t[i]=n.allocateTextureUnit();return t}function k0(n,e){const t=this.cache;t[0]!==e&&(n.uniform1f(this.addr,e),t[0]=e)}function B0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2fv(this.addr,e),St(t,e)}}function G0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(n.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(Mt(t,e))return;n.uniform3fv(this.addr,e),St(t,e)}}function H0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4fv(this.addr,e),St(t,e)}}function V0(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix2fv(this.addr,!1,e),St(t,e)}else{if(Mt(t,i))return;Sl.set(i),n.uniformMatrix2fv(this.addr,!1,Sl),St(t,i)}}function W0(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix3fv(this.addr,!1,e),St(t,e)}else{if(Mt(t,i))return;Ml.set(i),n.uniformMatrix3fv(this.addr,!1,Ml),St(t,i)}}function X0(n,e){const t=this.cache,i=e.elements;if(i===void 0){if(Mt(t,e))return;n.uniformMatrix4fv(this.addr,!1,e),St(t,e)}else{if(Mt(t,i))return;yl.set(i),n.uniformMatrix4fv(this.addr,!1,yl),St(t,i)}}function q0(n,e){const t=this.cache;t[0]!==e&&(n.uniform1i(this.addr,e),t[0]=e)}function Y0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2iv(this.addr,e),St(t,e)}}function j0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;n.uniform3iv(this.addr,e),St(t,e)}}function Z0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4iv(this.addr,e),St(t,e)}}function $0(n,e){const t=this.cache;t[0]!==e&&(n.uniform1ui(this.addr,e),t[0]=e)}function K0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(n.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(Mt(t,e))return;n.uniform2uiv(this.addr,e),St(t,e)}}function J0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(n.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(Mt(t,e))return;n.uniform3uiv(this.addr,e),St(t,e)}}function Q0(n,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(n.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(Mt(t,e))return;n.uniform4uiv(this.addr,e),St(t,e)}}function ep(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r);const s=this.type===n.SAMPLER_2D_SHADOW?Lc:Pc;t.setTexture2D(e||s,r)}function tp(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture3D(e||Ic,r)}function np(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTextureCube(e||Uc,r)}function ip(n,e,t){const i=this.cache,r=t.allocateTextureUnit();i[0]!==r&&(n.uniform1i(this.addr,r),i[0]=r),t.setTexture2DArray(e||Dc,r)}function rp(n){switch(n){case 5126:return k0;case 35664:return B0;case 35665:return G0;case 35666:return H0;case 35674:return V0;case 35675:return W0;case 35676:return X0;case 5124:case 35670:return q0;case 35667:case 35671:return Y0;case 35668:case 35672:return j0;case 35669:case 35673:return Z0;case 5125:return $0;case 36294:return K0;case 36295:return J0;case 36296:return Q0;case 35678:case 36198:case 36298:case 36306:case 35682:return ep;case 35679:case 36299:case 36307:return tp;case 35680:case 36300:case 36308:case 36293:return np;case 36289:case 36303:case 36311:case 36292:return ip}}function sp(n,e){n.uniform1fv(this.addr,e)}function ap(n,e){const t=Ki(e,this.size,2);n.uniform2fv(this.addr,t)}function op(n,e){const t=Ki(e,this.size,3);n.uniform3fv(this.addr,t)}function lp(n,e){const t=Ki(e,this.size,4);n.uniform4fv(this.addr,t)}function cp(n,e){const t=Ki(e,this.size,4);n.uniformMatrix2fv(this.addr,!1,t)}function hp(n,e){const t=Ki(e,this.size,9);n.uniformMatrix3fv(this.addr,!1,t)}function up(n,e){const t=Ki(e,this.size,16);n.uniformMatrix4fv(this.addr,!1,t)}function dp(n,e){n.uniform1iv(this.addr,e)}function fp(n,e){n.uniform2iv(this.addr,e)}function pp(n,e){n.uniform3iv(this.addr,e)}function mp(n,e){n.uniform4iv(this.addr,e)}function gp(n,e){n.uniform1uiv(this.addr,e)}function xp(n,e){n.uniform2uiv(this.addr,e)}function _p(n,e){n.uniform3uiv(this.addr,e)}function vp(n,e){n.uniform4uiv(this.addr,e)}function yp(n,e,t){const i=this.cache,r=e.length,s=Ms(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTexture2D(e[a]||Pc,s[a])}function Mp(n,e,t){const i=this.cache,r=e.length,s=Ms(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTexture3D(e[a]||Ic,s[a])}function Sp(n,e,t){const i=this.cache,r=e.length,s=Ms(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTextureCube(e[a]||Uc,s[a])}function bp(n,e,t){const i=this.cache,r=e.length,s=Ms(t,r);Mt(i,s)||(n.uniform1iv(this.addr,s),St(i,s));for(let a=0;a!==r;++a)t.setTexture2DArray(e[a]||Dc,s[a])}function wp(n){switch(n){case 5126:return sp;case 35664:return ap;case 35665:return op;case 35666:return lp;case 35674:return cp;case 35675:return hp;case 35676:return up;case 5124:case 35670:return dp;case 35667:case 35671:return fp;case 35668:case 35672:return pp;case 35669:case 35673:return mp;case 5125:return gp;case 36294:return xp;case 36295:return _p;case 36296:return vp;case 35678:case 36198:case 36298:case 36306:case 35682:return yp;case 35679:case 36299:case 36307:return Mp;case 35680:case 36300:case 36308:case 36293:return Sp;case 36289:case 36303:case 36311:case 36292:return bp}}class Ep{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=rp(t.type)}}class Tp{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=wp(t.type)}}class Ap{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){const r=this.seq;for(let s=0,a=r.length;s!==a;++s){const o=r[s];o.setValue(e,t[o.id],i)}}}const da=/(\w+)(\])?(\[|\.)?/g;function bl(n,e){n.seq.push(e),n.map[e.id]=e}function Rp(n,e,t){const i=n.name,r=i.length;for(da.lastIndex=0;;){const s=da.exec(i),a=da.lastIndex;let o=s[1];const l=s[2]==="]",c=s[3];if(l&&(o=o|0),c===void 0||c==="["&&a+2===r){bl(t,c===void 0?new Ep(o,n,e):new Tp(o,n,e));break}else{let u=t.map[o];u===void 0&&(u=new Ap(o),bl(t,u)),t=u}}}class Kr{constructor(e,t){this.seq=[],this.map={};const i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<i;++r){const s=e.getActiveUniform(t,r),a=e.getUniformLocation(t,s.name);Rp(s,a,this)}}setValue(e,t,i,r){const s=this.map[t];s!==void 0&&s.setValue(e,i,r)}setOptional(e,t,i){const r=t[i];r!==void 0&&this.setValue(e,i,r)}static upload(e,t,i,r){for(let s=0,a=t.length;s!==a;++s){const o=t[s],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,r)}}static seqWithValue(e,t){const i=[];for(let r=0,s=e.length;r!==s;++r){const a=e[r];a.id in t&&i.push(a)}return i}}function wl(n,e,t){const i=n.createShader(e);return n.shaderSource(i,t),n.compileShader(i),i}const Cp=37297;let Pp=0;function Lp(n,e){const t=n.split(`
`),i=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let a=r;a<s;a++){const o=a+1;i.push(`${o===e?">":" "} ${o}: ${t[a]}`)}return i.join(`
`)}function Dp(n){const e=tt.getPrimaries(tt.workingColorSpace),t=tt.getPrimaries(n);let i;switch(e===t?i="":e===ss&&t===rs?i="LinearDisplayP3ToLinearSRGB":e===rs&&t===ss&&(i="LinearSRGBToLinearDisplayP3"),n){case Mn:case vs:return[i,"LinearTransferOETF"];case xt:case Ya:return[i,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space:",n),[i,"LinearTransferOETF"]}}function El(n,e,t){const i=n.getShaderParameter(e,n.COMPILE_STATUS),r=n.getShaderInfoLog(e).trim();if(i&&r==="")return"";const s=/ERROR: 0:(\d+)/.exec(r);if(s){const a=parseInt(s[1]);return t.toUpperCase()+`

`+r+`

`+Lp(n.getShaderSource(e),a)}else return r}function Ip(n,e){const t=Dp(e);return`vec4 ${n}( vec4 value ) { return ${t[0]}( ${t[1]}( value ) ); }`}function Up(n,e){let t;switch(e){case Wh:t="Linear";break;case Xh:t="Reinhard";break;case qh:t="OptimizedCineon";break;case Yh:t="ACESFilmic";break;case Zh:t="AgX";break;case jh:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+n+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}function zp(n){return[n.extensionDerivatives||n.envMapCubeUVHeight||n.bumpMap||n.normalMapTangentSpace||n.clearcoatNormalMap||n.flatShading||n.shaderID==="physical"?"#extension GL_OES_standard_derivatives : enable":"",(n.extensionFragDepth||n.logarithmicDepthBuffer)&&n.rendererExtensionFragDepth?"#extension GL_EXT_frag_depth : enable":"",n.extensionDrawBuffers&&n.rendererExtensionDrawBuffers?"#extension GL_EXT_draw_buffers : require":"",(n.extensionShaderTextureLOD||n.envMap||n.transmission)&&n.rendererExtensionShaderTextureLod?"#extension GL_EXT_shader_texture_lod : enable":""].filter(Ui).join(`
`)}function Np(n){return[n.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":""].filter(Ui).join(`
`)}function Fp(n){const e=[];for(const t in n){const i=n[t];i!==!1&&e.push("#define "+t+" "+i)}return e.join(`
`)}function Op(n,e){const t={},i=n.getProgramParameter(e,n.ACTIVE_ATTRIBUTES);for(let r=0;r<i;r++){const s=n.getActiveAttrib(e,r),a=s.name;let o=1;s.type===n.FLOAT_MAT2&&(o=2),s.type===n.FLOAT_MAT3&&(o=3),s.type===n.FLOAT_MAT4&&(o=4),t[a]={type:s.type,location:n.getAttribLocation(e,a),locationSize:o}}return t}function Ui(n){return n!==""}function Tl(n,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return n.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Al(n,e){return n.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const kp=/^[ \t]*#include +<([\w\d./]+)>/gm;function Ia(n){return n.replace(kp,Gp)}const Bp=new Map([["encodings_fragment","colorspace_fragment"],["encodings_pars_fragment","colorspace_pars_fragment"],["output_fragment","opaque_fragment"]]);function Gp(n,e){let t=Ye[e];if(t===void 0){const i=Bp.get(e);if(i!==void 0)t=Ye[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i);else throw new Error("Can not resolve #include <"+e+">")}return Ia(t)}const Hp=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Rl(n){return n.replace(Hp,Vp)}function Vp(n,e,t,i){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=i.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function Cl(n){let e="precision "+n.precision+` float;
precision `+n.precision+" int;";return n.precision==="highp"?e+=`
#define HIGH_PRECISION`:n.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:n.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Wp(n){let e="SHADOWMAP_TYPE_BASIC";return n.shadowMapType===ac?e="SHADOWMAP_TYPE_PCF":n.shadowMapType===_h?e="SHADOWMAP_TYPE_PCF_SOFT":n.shadowMapType===pn&&(e="SHADOWMAP_TYPE_VSM"),e}function Xp(n){let e="ENVMAP_TYPE_CUBE";if(n.envMap)switch(n.envMapMode){case Bi:case Gi:e="ENVMAP_TYPE_CUBE";break;case _s:e="ENVMAP_TYPE_CUBE_UV";break}return e}function qp(n){let e="ENVMAP_MODE_REFLECTION";if(n.envMap)switch(n.envMapMode){case Gi:e="ENVMAP_MODE_REFRACTION";break}return e}function Yp(n){let e="ENVMAP_BLENDING_NONE";if(n.envMap)switch(n.combine){case Xa:e="ENVMAP_BLENDING_MULTIPLY";break;case Hh:e="ENVMAP_BLENDING_MIX";break;case Vh:e="ENVMAP_BLENDING_ADD";break}return e}function jp(n){const e=n.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,i=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Zp(n,e,t,i){const r=n.getContext(),s=t.defines;let a=t.vertexShader,o=t.fragmentShader;const l=Wp(t),c=Xp(t),d=qp(t),u=Yp(t),h=jp(t),m=t.isWebGL2?"":zp(t),_=Np(t),x=Fp(s),p=r.createProgram();let f,v,g=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x].filter(Ui).join(`
`),f.length>0&&(f+=`
`),v=[m,"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x].filter(Ui).join(`
`),v.length>0&&(v+=`
`)):(f=[Cl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+d:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors&&t.isWebGL2?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE":"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0&&t.isWebGL2?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#if ( defined( USE_MORPHTARGETS ) && ! defined( MORPHTARGETS_TEXTURE ) )","	attribute vec3 morphTarget0;","	attribute vec3 morphTarget1;","	attribute vec3 morphTarget2;","	attribute vec3 morphTarget3;","	#ifdef USE_MORPHNORMALS","		attribute vec3 morphNormal0;","		attribute vec3 morphNormal1;","		attribute vec3 morphNormal2;","		attribute vec3 morphNormal3;","	#else","		attribute vec3 morphTarget4;","		attribute vec3 morphTarget5;","		attribute vec3 morphTarget6;","		attribute vec3 morphTarget7;","	#endif","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Ui).join(`
`),v=[m,Cl(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,x,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",t.envMap?"#define "+u:"",h?"#define CUBEUV_TEXEL_WIDTH "+h.texelWidth:"",h?"#define CUBEUV_TEXEL_HEIGHT "+h.texelHeight:"",h?"#define CUBEUV_MAX_MIP "+h.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.useLegacyLights?"#define LEGACY_LIGHTS":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.logarithmicDepthBuffer&&t.rendererExtensionFragDepth?"#define USE_LOGDEPTHBUF_EXT":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==In?"#define TONE_MAPPING":"",t.toneMapping!==In?Ye.tonemapping_pars_fragment:"",t.toneMapping!==In?Up("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ye.colorspace_pars_fragment,Ip("linearToOutputTexel",t.outputColorSpace),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Ui).join(`
`)),a=Ia(a),a=Tl(a,t),a=Al(a,t),o=Ia(o),o=Tl(o,t),o=Al(o,t),a=Rl(a),o=Rl(o),t.isWebGL2&&t.isRawShaderMaterial!==!0&&(g=`#version 300 es
`,f=[_,"precision mediump sampler2DArray;","#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,v=["precision mediump sampler2DArray;","#define varying in",t.glslVersion===Yo?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Yo?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+v);const y=g+f+a,R=g+v+o,T=wl(r,r.VERTEX_SHADER,y),C=wl(r,r.FRAGMENT_SHADER,R);r.attachShader(p,T),r.attachShader(p,C),t.index0AttributeName!==void 0?r.bindAttribLocation(p,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(p,0,"position"),r.linkProgram(p);function z(I){if(n.debug.checkShaderErrors){const W=r.getProgramInfoLog(p).trim(),L=r.getShaderInfoLog(T).trim(),U=r.getShaderInfoLog(C).trim();let B=!0,X=!0;if(r.getProgramParameter(p,r.LINK_STATUS)===!1)if(B=!1,typeof n.debug.onShaderError=="function")n.debug.onShaderError(r,p,T,C);else{const K=El(r,T,"vertex"),ie=El(r,C,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(p,r.VALIDATE_STATUS)+`

Program Info Log: `+W+`
`+K+`
`+ie)}else W!==""?console.warn("THREE.WebGLProgram: Program Info Log:",W):(L===""||U==="")&&(X=!1);X&&(I.diagnostics={runnable:B,programLog:W,vertexShader:{log:L,prefix:f},fragmentShader:{log:U,prefix:v}})}r.deleteShader(T),r.deleteShader(C),M=new Kr(r,p),S=Op(r,p)}let M;this.getUniforms=function(){return M===void 0&&z(this),M};let S;this.getAttributes=function(){return S===void 0&&z(this),S};let G=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return G===!1&&(G=r.getProgramParameter(p,Cp)),G},this.destroy=function(){i.releaseStatesOfProgram(this),r.deleteProgram(p),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=Pp++,this.cacheKey=e,this.usedTimes=1,this.program=p,this.vertexShader=T,this.fragmentShader=C,this}let $p=0;class Kp{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,i=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(r)===!1&&(a.add(r),r.usedTimes++),a.has(s)===!1&&(a.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){const t=this.shaderCache;let i=t.get(e);return i===void 0&&(i=new Jp(e),t.set(e,i)),i}}class Jp{constructor(e){this.id=$p++,this.code=e,this.usedTimes=0}}function Qp(n,e,t,i,r,s,a){const o=new ja,l=new Kp,c=[],d=r.isWebGL2,u=r.logarithmicDepthBuffer,h=r.vertexTextures;let m=r.precision;const _={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function x(M){return M===0?"uv":`uv${M}`}function p(M,S,G,I,W){const L=I.fog,U=W.geometry,B=M.isMeshStandardMaterial?I.environment:null,X=(M.isMeshStandardMaterial?t:e).get(M.envMap||B),K=X&&X.mapping===_s?X.image.height:null,ie=_[M.type];M.precision!==null&&(m=r.getMaxPrecision(M.precision),m!==M.precision&&console.warn("THREE.WebGLProgram.getParameters:",M.precision,"not supported, using",m,"instead."));const ne=U.morphAttributes.position||U.morphAttributes.normal||U.morphAttributes.color,ue=ne!==void 0?ne.length:0;let de=0;U.morphAttributes.position!==void 0&&(de=1),U.morphAttributes.normal!==void 0&&(de=2),U.morphAttributes.color!==void 0&&(de=3);let J,se,ge,Ae;if(ie){const Ut=on[ie];J=Ut.vertexShader,se=Ut.fragmentShader}else J=M.vertexShader,se=M.fragmentShader,l.update(M),ge=l.getVertexShaderID(M),Ae=l.getFragmentShaderID(M);const we=n.getRenderTarget(),ke=W.isInstancedMesh===!0,Ge=W.isBatchedMesh===!0,Ie=!!M.map,w=!!M.matcap,b=!!X,H=!!M.aoMap,F=!!M.lightMap,ae=!!M.bumpMap,oe=!!M.normalMap,ee=!!M.displacementMap,me=!!M.emissiveMap,A=!!M.metalnessMap,E=!!M.roughnessMap,O=M.anisotropy>0,Q=M.clearcoat>0,j=M.iridescence>0,te=M.sheen>0,ve=M.transmission>0,xe=O&&!!M.anisotropyMap,ye=Q&&!!M.clearcoatMap,Ee=Q&&!!M.clearcoatNormalMap,Ue=Q&&!!M.clearcoatRoughnessMap,ce=j&&!!M.iridescenceMap,Ke=j&&!!M.iridescenceThicknessMap,qe=te&&!!M.sheenColorMap,ze=te&&!!M.sheenRoughnessMap,Ce=!!M.specularMap,Se=!!M.specularColorMap,Ne=!!M.specularIntensityMap,re=ve&&!!M.transmissionMap,le=ve&&!!M.thicknessMap,fe=!!M.gradientMap,Z=!!M.alphaMap,D=M.alphaTest>0,he=!!M.alphaHash,pe=!!M.extensions,Te=!!U.attributes.uv1,Pe=!!U.attributes.uv2,st=!!U.attributes.uv3;let at=In;return M.toneMapped&&(we===null||we.isXRRenderTarget===!0)&&(at=n.toneMapping),{isWebGL2:d,shaderID:ie,shaderType:M.type,shaderName:M.name,vertexShader:J,fragmentShader:se,defines:M.defines,customVertexShaderID:ge,customFragmentShaderID:Ae,isRawShaderMaterial:M.isRawShaderMaterial===!0,glslVersion:M.glslVersion,precision:m,batching:Ge,instancing:ke,instancingColor:ke&&W.instanceColor!==null,supportsVertexTextures:h,outputColorSpace:we===null?n.outputColorSpace:we.isXRRenderTarget===!0?we.texture.colorSpace:Mn,map:Ie,matcap:w,envMap:b,envMapMode:b&&X.mapping,envMapCubeUVHeight:K,aoMap:H,lightMap:F,bumpMap:ae,normalMap:oe,displacementMap:h&&ee,emissiveMap:me,normalMapObjectSpace:oe&&M.normalMapType===ou,normalMapTangentSpace:oe&&M.normalMapType===gc,metalnessMap:A,roughnessMap:E,anisotropy:O,anisotropyMap:xe,clearcoat:Q,clearcoatMap:ye,clearcoatNormalMap:Ee,clearcoatRoughnessMap:Ue,iridescence:j,iridescenceMap:ce,iridescenceThicknessMap:Ke,sheen:te,sheenColorMap:qe,sheenRoughnessMap:ze,specularMap:Ce,specularColorMap:Se,specularIntensityMap:Ne,transmission:ve,transmissionMap:re,thicknessMap:le,gradientMap:fe,opaque:M.transparent===!1&&M.blending===Ni,alphaMap:Z,alphaTest:D,alphaHash:he,combine:M.combine,mapUv:Ie&&x(M.map.channel),aoMapUv:H&&x(M.aoMap.channel),lightMapUv:F&&x(M.lightMap.channel),bumpMapUv:ae&&x(M.bumpMap.channel),normalMapUv:oe&&x(M.normalMap.channel),displacementMapUv:ee&&x(M.displacementMap.channel),emissiveMapUv:me&&x(M.emissiveMap.channel),metalnessMapUv:A&&x(M.metalnessMap.channel),roughnessMapUv:E&&x(M.roughnessMap.channel),anisotropyMapUv:xe&&x(M.anisotropyMap.channel),clearcoatMapUv:ye&&x(M.clearcoatMap.channel),clearcoatNormalMapUv:Ee&&x(M.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Ue&&x(M.clearcoatRoughnessMap.channel),iridescenceMapUv:ce&&x(M.iridescenceMap.channel),iridescenceThicknessMapUv:Ke&&x(M.iridescenceThicknessMap.channel),sheenColorMapUv:qe&&x(M.sheenColorMap.channel),sheenRoughnessMapUv:ze&&x(M.sheenRoughnessMap.channel),specularMapUv:Ce&&x(M.specularMap.channel),specularColorMapUv:Se&&x(M.specularColorMap.channel),specularIntensityMapUv:Ne&&x(M.specularIntensityMap.channel),transmissionMapUv:re&&x(M.transmissionMap.channel),thicknessMapUv:le&&x(M.thicknessMap.channel),alphaMapUv:Z&&x(M.alphaMap.channel),vertexTangents:!!U.attributes.tangent&&(oe||O),vertexColors:M.vertexColors,vertexAlphas:M.vertexColors===!0&&!!U.attributes.color&&U.attributes.color.itemSize===4,vertexUv1s:Te,vertexUv2s:Pe,vertexUv3s:st,pointsUvs:W.isPoints===!0&&!!U.attributes.uv&&(Ie||Z),fog:!!L,useFog:M.fog===!0,fogExp2:L&&L.isFogExp2,flatShading:M.flatShading===!0,sizeAttenuation:M.sizeAttenuation===!0,logarithmicDepthBuffer:u,skinning:W.isSkinnedMesh===!0,morphTargets:U.morphAttributes.position!==void 0,morphNormals:U.morphAttributes.normal!==void 0,morphColors:U.morphAttributes.color!==void 0,morphTargetsCount:ue,morphTextureStride:de,numDirLights:S.directional.length,numPointLights:S.point.length,numSpotLights:S.spot.length,numSpotLightMaps:S.spotLightMap.length,numRectAreaLights:S.rectArea.length,numHemiLights:S.hemi.length,numDirLightShadows:S.directionalShadowMap.length,numPointLightShadows:S.pointShadowMap.length,numSpotLightShadows:S.spotShadowMap.length,numSpotLightShadowsWithMaps:S.numSpotLightShadowsWithMaps,numLightProbes:S.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:M.dithering,shadowMapEnabled:n.shadowMap.enabled&&G.length>0,shadowMapType:n.shadowMap.type,toneMapping:at,useLegacyLights:n._useLegacyLights,decodeVideoTexture:Ie&&M.map.isVideoTexture===!0&&tt.getTransfer(M.map.colorSpace)===ct,premultipliedAlpha:M.premultipliedAlpha,doubleSided:M.side===yt,flipSided:M.side===Bt,useDepthPacking:M.depthPacking>=0,depthPacking:M.depthPacking||0,index0AttributeName:M.index0AttributeName,extensionDerivatives:pe&&M.extensions.derivatives===!0,extensionFragDepth:pe&&M.extensions.fragDepth===!0,extensionDrawBuffers:pe&&M.extensions.drawBuffers===!0,extensionShaderTextureLOD:pe&&M.extensions.shaderTextureLOD===!0,extensionClipCullDistance:pe&&M.extensions.clipCullDistance&&i.has("WEBGL_clip_cull_distance"),rendererExtensionFragDepth:d||i.has("EXT_frag_depth"),rendererExtensionDrawBuffers:d||i.has("WEBGL_draw_buffers"),rendererExtensionShaderTextureLod:d||i.has("EXT_shader_texture_lod"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:M.customProgramCacheKey()}}function f(M){const S=[];if(M.shaderID?S.push(M.shaderID):(S.push(M.customVertexShaderID),S.push(M.customFragmentShaderID)),M.defines!==void 0)for(const G in M.defines)S.push(G),S.push(M.defines[G]);return M.isRawShaderMaterial===!1&&(v(S,M),g(S,M),S.push(n.outputColorSpace)),S.push(M.customProgramCacheKey),S.join()}function v(M,S){M.push(S.precision),M.push(S.outputColorSpace),M.push(S.envMapMode),M.push(S.envMapCubeUVHeight),M.push(S.mapUv),M.push(S.alphaMapUv),M.push(S.lightMapUv),M.push(S.aoMapUv),M.push(S.bumpMapUv),M.push(S.normalMapUv),M.push(S.displacementMapUv),M.push(S.emissiveMapUv),M.push(S.metalnessMapUv),M.push(S.roughnessMapUv),M.push(S.anisotropyMapUv),M.push(S.clearcoatMapUv),M.push(S.clearcoatNormalMapUv),M.push(S.clearcoatRoughnessMapUv),M.push(S.iridescenceMapUv),M.push(S.iridescenceThicknessMapUv),M.push(S.sheenColorMapUv),M.push(S.sheenRoughnessMapUv),M.push(S.specularMapUv),M.push(S.specularColorMapUv),M.push(S.specularIntensityMapUv),M.push(S.transmissionMapUv),M.push(S.thicknessMapUv),M.push(S.combine),M.push(S.fogExp2),M.push(S.sizeAttenuation),M.push(S.morphTargetsCount),M.push(S.morphAttributeCount),M.push(S.numDirLights),M.push(S.numPointLights),M.push(S.numSpotLights),M.push(S.numSpotLightMaps),M.push(S.numHemiLights),M.push(S.numRectAreaLights),M.push(S.numDirLightShadows),M.push(S.numPointLightShadows),M.push(S.numSpotLightShadows),M.push(S.numSpotLightShadowsWithMaps),M.push(S.numLightProbes),M.push(S.shadowMapType),M.push(S.toneMapping),M.push(S.numClippingPlanes),M.push(S.numClipIntersection),M.push(S.depthPacking)}function g(M,S){o.disableAll(),S.isWebGL2&&o.enable(0),S.supportsVertexTextures&&o.enable(1),S.instancing&&o.enable(2),S.instancingColor&&o.enable(3),S.matcap&&o.enable(4),S.envMap&&o.enable(5),S.normalMapObjectSpace&&o.enable(6),S.normalMapTangentSpace&&o.enable(7),S.clearcoat&&o.enable(8),S.iridescence&&o.enable(9),S.alphaTest&&o.enable(10),S.vertexColors&&o.enable(11),S.vertexAlphas&&o.enable(12),S.vertexUv1s&&o.enable(13),S.vertexUv2s&&o.enable(14),S.vertexUv3s&&o.enable(15),S.vertexTangents&&o.enable(16),S.anisotropy&&o.enable(17),S.alphaHash&&o.enable(18),S.batching&&o.enable(19),M.push(o.mask),o.disableAll(),S.fog&&o.enable(0),S.useFog&&o.enable(1),S.flatShading&&o.enable(2),S.logarithmicDepthBuffer&&o.enable(3),S.skinning&&o.enable(4),S.morphTargets&&o.enable(5),S.morphNormals&&o.enable(6),S.morphColors&&o.enable(7),S.premultipliedAlpha&&o.enable(8),S.shadowMapEnabled&&o.enable(9),S.useLegacyLights&&o.enable(10),S.doubleSided&&o.enable(11),S.flipSided&&o.enable(12),S.useDepthPacking&&o.enable(13),S.dithering&&o.enable(14),S.transmission&&o.enable(15),S.sheen&&o.enable(16),S.opaque&&o.enable(17),S.pointsUvs&&o.enable(18),S.decodeVideoTexture&&o.enable(19),M.push(o.mask)}function y(M){const S=_[M.type];let G;if(S){const I=on[S];G=Uu.clone(I.uniforms)}else G=M.uniforms;return G}function R(M,S){let G;for(let I=0,W=c.length;I<W;I++){const L=c[I];if(L.cacheKey===S){G=L,++G.usedTimes;break}}return G===void 0&&(G=new Zp(n,S,M,s),c.push(G)),G}function T(M){if(--M.usedTimes===0){const S=c.indexOf(M);c[S]=c[c.length-1],c.pop(),M.destroy()}}function C(M){l.remove(M)}function z(){l.dispose()}return{getParameters:p,getProgramCacheKey:f,getUniforms:y,acquireProgram:R,releaseProgram:T,releaseShaderCache:C,programs:c,dispose:z}}function em(){let n=new WeakMap;function e(s){let a=n.get(s);return a===void 0&&(a={},n.set(s,a)),a}function t(s){n.delete(s)}function i(s,a,o){n.get(s)[a]=o}function r(){n=new WeakMap}return{get:e,remove:t,update:i,dispose:r}}function tm(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.material.id!==e.material.id?n.material.id-e.material.id:n.z!==e.z?n.z-e.z:n.id-e.id}function Pl(n,e){return n.groupOrder!==e.groupOrder?n.groupOrder-e.groupOrder:n.renderOrder!==e.renderOrder?n.renderOrder-e.renderOrder:n.z!==e.z?e.z-n.z:n.id-e.id}function Ll(){const n=[];let e=0;const t=[],i=[],r=[];function s(){e=0,t.length=0,i.length=0,r.length=0}function a(u,h,m,_,x,p){let f=n[e];return f===void 0?(f={id:u.id,object:u,geometry:h,material:m,groupOrder:_,renderOrder:u.renderOrder,z:x,group:p},n[e]=f):(f.id=u.id,f.object=u,f.geometry=h,f.material=m,f.groupOrder=_,f.renderOrder=u.renderOrder,f.z=x,f.group=p),e++,f}function o(u,h,m,_,x,p){const f=a(u,h,m,_,x,p);m.transmission>0?i.push(f):m.transparent===!0?r.push(f):t.push(f)}function l(u,h,m,_,x,p){const f=a(u,h,m,_,x,p);m.transmission>0?i.unshift(f):m.transparent===!0?r.unshift(f):t.unshift(f)}function c(u,h){t.length>1&&t.sort(u||tm),i.length>1&&i.sort(h||Pl),r.length>1&&r.sort(h||Pl)}function d(){for(let u=e,h=n.length;u<h;u++){const m=n[u];if(m.id===null)break;m.id=null,m.object=null,m.geometry=null,m.material=null,m.group=null}}return{opaque:t,transmissive:i,transparent:r,init:s,push:o,unshift:l,finish:d,sort:c}}function nm(){let n=new WeakMap;function e(i,r){const s=n.get(i);let a;return s===void 0?(a=new Ll,n.set(i,[a])):r>=s.length?(a=new Ll,s.push(a)):a=s[r],a}function t(){n=new WeakMap}return{get:e,dispose:t}}function im(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new N,color:new $e};break;case"SpotLight":t={position:new N,direction:new N,color:new $e,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new N,color:new $e,distance:0,decay:0};break;case"HemisphereLight":t={direction:new N,skyColor:new $e,groundColor:new $e};break;case"RectAreaLight":t={color:new $e,position:new N,halfWidth:new N,halfHeight:new N};break}return n[e.id]=t,t}}}function rm(){const n={};return{get:function(e){if(n[e.id]!==void 0)return n[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"SpotLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"PointLight":t={shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return n[e.id]=t,t}}}let sm=0;function am(n,e){return(e.castShadow?2:0)-(n.castShadow?2:0)+(e.map?1:0)-(n.map?1:0)}function om(n,e){const t=new im,i=rm(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)r.probe.push(new N);const s=new N,a=new Qe,o=new Qe;function l(d,u){let h=0,m=0,_=0;for(let I=0;I<9;I++)r.probe[I].set(0,0,0);let x=0,p=0,f=0,v=0,g=0,y=0,R=0,T=0,C=0,z=0,M=0;d.sort(am);const S=u===!0?Math.PI:1;for(let I=0,W=d.length;I<W;I++){const L=d[I],U=L.color,B=L.intensity,X=L.distance,K=L.shadow&&L.shadow.map?L.shadow.map.texture:null;if(L.isAmbientLight)h+=U.r*B*S,m+=U.g*B*S,_+=U.b*B*S;else if(L.isLightProbe){for(let ie=0;ie<9;ie++)r.probe[ie].addScaledVector(L.sh.coefficients[ie],B);M++}else if(L.isDirectionalLight){const ie=t.get(L);if(ie.color.copy(L.color).multiplyScalar(L.intensity*S),L.castShadow){const ne=L.shadow,ue=i.get(L);ue.shadowBias=ne.bias,ue.shadowNormalBias=ne.normalBias,ue.shadowRadius=ne.radius,ue.shadowMapSize=ne.mapSize,r.directionalShadow[x]=ue,r.directionalShadowMap[x]=K,r.directionalShadowMatrix[x]=L.shadow.matrix,y++}r.directional[x]=ie,x++}else if(L.isSpotLight){const ie=t.get(L);ie.position.setFromMatrixPosition(L.matrixWorld),ie.color.copy(U).multiplyScalar(B*S),ie.distance=X,ie.coneCos=Math.cos(L.angle),ie.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),ie.decay=L.decay,r.spot[f]=ie;const ne=L.shadow;if(L.map&&(r.spotLightMap[C]=L.map,C++,ne.updateMatrices(L),L.castShadow&&z++),r.spotLightMatrix[f]=ne.matrix,L.castShadow){const ue=i.get(L);ue.shadowBias=ne.bias,ue.shadowNormalBias=ne.normalBias,ue.shadowRadius=ne.radius,ue.shadowMapSize=ne.mapSize,r.spotShadow[f]=ue,r.spotShadowMap[f]=K,T++}f++}else if(L.isRectAreaLight){const ie=t.get(L);ie.color.copy(U).multiplyScalar(B),ie.halfWidth.set(L.width*.5,0,0),ie.halfHeight.set(0,L.height*.5,0),r.rectArea[v]=ie,v++}else if(L.isPointLight){const ie=t.get(L);if(ie.color.copy(L.color).multiplyScalar(L.intensity*S),ie.distance=L.distance,ie.decay=L.decay,L.castShadow){const ne=L.shadow,ue=i.get(L);ue.shadowBias=ne.bias,ue.shadowNormalBias=ne.normalBias,ue.shadowRadius=ne.radius,ue.shadowMapSize=ne.mapSize,ue.shadowCameraNear=ne.camera.near,ue.shadowCameraFar=ne.camera.far,r.pointShadow[p]=ue,r.pointShadowMap[p]=K,r.pointShadowMatrix[p]=L.shadow.matrix,R++}r.point[p]=ie,p++}else if(L.isHemisphereLight){const ie=t.get(L);ie.skyColor.copy(L.color).multiplyScalar(B*S),ie.groundColor.copy(L.groundColor).multiplyScalar(B*S),r.hemi[g]=ie,g++}}v>0&&(e.isWebGL2?n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_FLOAT_1,r.rectAreaLTC2=_e.LTC_FLOAT_2):(r.rectAreaLTC1=_e.LTC_HALF_1,r.rectAreaLTC2=_e.LTC_HALF_2):n.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_FLOAT_1,r.rectAreaLTC2=_e.LTC_FLOAT_2):n.has("OES_texture_half_float_linear")===!0?(r.rectAreaLTC1=_e.LTC_HALF_1,r.rectAreaLTC2=_e.LTC_HALF_2):console.error("THREE.WebGLRenderer: Unable to use RectAreaLight. Missing WebGL extensions.")),r.ambient[0]=h,r.ambient[1]=m,r.ambient[2]=_;const G=r.hash;(G.directionalLength!==x||G.pointLength!==p||G.spotLength!==f||G.rectAreaLength!==v||G.hemiLength!==g||G.numDirectionalShadows!==y||G.numPointShadows!==R||G.numSpotShadows!==T||G.numSpotMaps!==C||G.numLightProbes!==M)&&(r.directional.length=x,r.spot.length=f,r.rectArea.length=v,r.point.length=p,r.hemi.length=g,r.directionalShadow.length=y,r.directionalShadowMap.length=y,r.pointShadow.length=R,r.pointShadowMap.length=R,r.spotShadow.length=T,r.spotShadowMap.length=T,r.directionalShadowMatrix.length=y,r.pointShadowMatrix.length=R,r.spotLightMatrix.length=T+C-z,r.spotLightMap.length=C,r.numSpotLightShadowsWithMaps=z,r.numLightProbes=M,G.directionalLength=x,G.pointLength=p,G.spotLength=f,G.rectAreaLength=v,G.hemiLength=g,G.numDirectionalShadows=y,G.numPointShadows=R,G.numSpotShadows=T,G.numSpotMaps=C,G.numLightProbes=M,r.version=sm++)}function c(d,u){let h=0,m=0,_=0,x=0,p=0;const f=u.matrixWorldInverse;for(let v=0,g=d.length;v<g;v++){const y=d[v];if(y.isDirectionalLight){const R=r.directional[h];R.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(f),h++}else if(y.isSpotLight){const R=r.spot[_];R.position.setFromMatrixPosition(y.matrixWorld),R.position.applyMatrix4(f),R.direction.setFromMatrixPosition(y.matrixWorld),s.setFromMatrixPosition(y.target.matrixWorld),R.direction.sub(s),R.direction.transformDirection(f),_++}else if(y.isRectAreaLight){const R=r.rectArea[x];R.position.setFromMatrixPosition(y.matrixWorld),R.position.applyMatrix4(f),o.identity(),a.copy(y.matrixWorld),a.premultiply(f),o.extractRotation(a),R.halfWidth.set(y.width*.5,0,0),R.halfHeight.set(0,y.height*.5,0),R.halfWidth.applyMatrix4(o),R.halfHeight.applyMatrix4(o),x++}else if(y.isPointLight){const R=r.point[m];R.position.setFromMatrixPosition(y.matrixWorld),R.position.applyMatrix4(f),m++}else if(y.isHemisphereLight){const R=r.hemi[p];R.direction.setFromMatrixPosition(y.matrixWorld),R.direction.transformDirection(f),p++}}}return{setup:l,setupView:c,state:r}}function Dl(n,e){const t=new om(n,e),i=[],r=[];function s(){i.length=0,r.length=0}function a(u){i.push(u)}function o(u){r.push(u)}function l(u){t.setup(i,u)}function c(u){t.setupView(i,u)}return{init:s,state:{lightsArray:i,shadowsArray:r,lights:t},setupLights:l,setupLightsView:c,pushLight:a,pushShadow:o}}function lm(n,e){let t=new WeakMap;function i(s,a=0){const o=t.get(s);let l;return o===void 0?(l=new Dl(n,e),t.set(s,[l])):a>=o.length?(l=new Dl(n,e),o.push(l)):l=o[a],l}function r(){t=new WeakMap}return{get:i,dispose:r}}class cm extends $i{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=su,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class hm extends $i{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const um=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,dm=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function fm(n,e,t){let i=new Za;const r=new Oe,s=new Oe,a=new ut,o=new cm({depthPacking:au}),l=new hm,c={},d=t.maxTextureSize,u={[yn]:Bt,[Bt]:yn,[yt]:yt},h=new si({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Oe},radius:{value:4}},vertexShader:um,fragmentShader:dm}),m=h.clone();m.defines.HORIZONTAL_PASS=1;const _=new rt;_.setAttribute("position",new Qt(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const x=new Le(_,h),p=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=ac;let f=this.type;this.render=function(T,C,z){if(p.enabled===!1||p.autoUpdate===!1&&p.needsUpdate===!1||T.length===0)return;const M=n.getRenderTarget(),S=n.getActiveCubeFace(),G=n.getActiveMipmapLevel(),I=n.state;I.setBlending(Dn),I.buffers.color.setClear(1,1,1,1),I.buffers.depth.setTest(!0),I.setScissorTest(!1);const W=f!==pn&&this.type===pn,L=f===pn&&this.type!==pn;for(let U=0,B=T.length;U<B;U++){const X=T[U],K=X.shadow;if(K===void 0){console.warn("THREE.WebGLShadowMap:",X,"has no shadow.");continue}if(K.autoUpdate===!1&&K.needsUpdate===!1)continue;r.copy(K.mapSize);const ie=K.getFrameExtents();if(r.multiply(ie),s.copy(K.mapSize),(r.x>d||r.y>d)&&(r.x>d&&(s.x=Math.floor(d/ie.x),r.x=s.x*ie.x,K.mapSize.x=s.x),r.y>d&&(s.y=Math.floor(d/ie.y),r.y=s.y*ie.y,K.mapSize.y=s.y)),K.map===null||W===!0||L===!0){const ue=this.type!==pn?{minFilter:Pt,magFilter:Pt}:{};K.map!==null&&K.map.dispose(),K.map=new ri(r.x,r.y,ue),K.map.texture.name=X.name+".shadowMap",K.camera.updateProjectionMatrix()}n.setRenderTarget(K.map),n.clear();const ne=K.getViewportCount();for(let ue=0;ue<ne;ue++){const de=K.getViewport(ue);a.set(s.x*de.x,s.y*de.y,s.x*de.z,s.y*de.w),I.viewport(a),K.updateMatrices(X,ue),i=K.getFrustum(),y(C,z,K.camera,X,this.type)}K.isPointLightShadow!==!0&&this.type===pn&&v(K,z),K.needsUpdate=!1}f=this.type,p.needsUpdate=!1,n.setRenderTarget(M,S,G)};function v(T,C){const z=e.update(x);h.defines.VSM_SAMPLES!==T.blurSamples&&(h.defines.VSM_SAMPLES=T.blurSamples,m.defines.VSM_SAMPLES=T.blurSamples,h.needsUpdate=!0,m.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new ri(r.x,r.y)),h.uniforms.shadow_pass.value=T.map.texture,h.uniforms.resolution.value=T.mapSize,h.uniforms.radius.value=T.radius,n.setRenderTarget(T.mapPass),n.clear(),n.renderBufferDirect(C,null,z,h,x,null),m.uniforms.shadow_pass.value=T.mapPass.texture,m.uniforms.resolution.value=T.mapSize,m.uniforms.radius.value=T.radius,n.setRenderTarget(T.map),n.clear(),n.renderBufferDirect(C,null,z,m,x,null)}function g(T,C,z,M){let S=null;const G=z.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(G!==void 0)S=G;else if(S=z.isPointLight===!0?l:o,n.localClippingEnabled&&C.clipShadows===!0&&Array.isArray(C.clippingPlanes)&&C.clippingPlanes.length!==0||C.displacementMap&&C.displacementScale!==0||C.alphaMap&&C.alphaTest>0||C.map&&C.alphaTest>0){const I=S.uuid,W=C.uuid;let L=c[I];L===void 0&&(L={},c[I]=L);let U=L[W];U===void 0&&(U=S.clone(),L[W]=U,C.addEventListener("dispose",R)),S=U}if(S.visible=C.visible,S.wireframe=C.wireframe,M===pn?S.side=C.shadowSide!==null?C.shadowSide:C.side:S.side=C.shadowSide!==null?C.shadowSide:u[C.side],S.alphaMap=C.alphaMap,S.alphaTest=C.alphaTest,S.map=C.map,S.clipShadows=C.clipShadows,S.clippingPlanes=C.clippingPlanes,S.clipIntersection=C.clipIntersection,S.displacementMap=C.displacementMap,S.displacementScale=C.displacementScale,S.displacementBias=C.displacementBias,S.wireframeLinewidth=C.wireframeLinewidth,S.linewidth=C.linewidth,z.isPointLight===!0&&S.isMeshDistanceMaterial===!0){const I=n.properties.get(S);I.light=z}return S}function y(T,C,z,M,S){if(T.visible===!1)return;if(T.layers.test(C.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&S===pn)&&(!T.frustumCulled||i.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(z.matrixWorldInverse,T.matrixWorld);const W=e.update(T),L=T.material;if(Array.isArray(L)){const U=W.groups;for(let B=0,X=U.length;B<X;B++){const K=U[B],ie=L[K.materialIndex];if(ie&&ie.visible){const ne=g(T,ie,M,S);T.onBeforeShadow(n,T,C,z,W,ne,K),n.renderBufferDirect(z,null,W,ne,T,K),T.onAfterShadow(n,T,C,z,W,ne,K)}}}else if(L.visible){const U=g(T,L,M,S);T.onBeforeShadow(n,T,C,z,W,U,null),n.renderBufferDirect(z,null,W,U,T,null),T.onAfterShadow(n,T,C,z,W,U,null)}}const I=T.children;for(let W=0,L=I.length;W<L;W++)y(I[W],C,z,M,S)}function R(T){T.target.removeEventListener("dispose",R);for(const z in c){const M=c[z],S=T.target.uuid;S in M&&(M[S].dispose(),delete M[S])}}}function pm(n,e,t){const i=t.isWebGL2;function r(){let D=!1;const he=new ut;let pe=null;const Te=new ut(0,0,0,0);return{setMask:function(Pe){pe!==Pe&&!D&&(n.colorMask(Pe,Pe,Pe,Pe),pe=Pe)},setLocked:function(Pe){D=Pe},setClear:function(Pe,st,at,bt,Ut){Ut===!0&&(Pe*=bt,st*=bt,at*=bt),he.set(Pe,st,at,bt),Te.equals(he)===!1&&(n.clearColor(Pe,st,at,bt),Te.copy(he))},reset:function(){D=!1,pe=null,Te.set(-1,0,0,0)}}}function s(){let D=!1,he=null,pe=null,Te=null;return{setTest:function(Pe){Pe?Ge(n.DEPTH_TEST):Ie(n.DEPTH_TEST)},setMask:function(Pe){he!==Pe&&!D&&(n.depthMask(Pe),he=Pe)},setFunc:function(Pe){if(pe!==Pe){switch(Pe){case zh:n.depthFunc(n.NEVER);break;case Nh:n.depthFunc(n.ALWAYS);break;case Fh:n.depthFunc(n.LESS);break;case ns:n.depthFunc(n.LEQUAL);break;case Oh:n.depthFunc(n.EQUAL);break;case kh:n.depthFunc(n.GEQUAL);break;case Bh:n.depthFunc(n.GREATER);break;case Gh:n.depthFunc(n.NOTEQUAL);break;default:n.depthFunc(n.LEQUAL)}pe=Pe}},setLocked:function(Pe){D=Pe},setClear:function(Pe){Te!==Pe&&(n.clearDepth(Pe),Te=Pe)},reset:function(){D=!1,he=null,pe=null,Te=null}}}function a(){let D=!1,he=null,pe=null,Te=null,Pe=null,st=null,at=null,bt=null,Ut=null;return{setTest:function(ot){D||(ot?Ge(n.STENCIL_TEST):Ie(n.STENCIL_TEST))},setMask:function(ot){he!==ot&&!D&&(n.stencilMask(ot),he=ot)},setFunc:function(ot,zt,an){(pe!==ot||Te!==zt||Pe!==an)&&(n.stencilFunc(ot,zt,an),pe=ot,Te=zt,Pe=an)},setOp:function(ot,zt,an){(st!==ot||at!==zt||bt!==an)&&(n.stencilOp(ot,zt,an),st=ot,at=zt,bt=an)},setLocked:function(ot){D=ot},setClear:function(ot){Ut!==ot&&(n.clearStencil(ot),Ut=ot)},reset:function(){D=!1,he=null,pe=null,Te=null,Pe=null,st=null,at=null,bt=null,Ut=null}}}const o=new r,l=new s,c=new a,d=new WeakMap,u=new WeakMap;let h={},m={},_=new WeakMap,x=[],p=null,f=!1,v=null,g=null,y=null,R=null,T=null,C=null,z=null,M=new $e(0,0,0),S=0,G=!1,I=null,W=null,L=null,U=null,B=null;const X=n.getParameter(n.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let K=!1,ie=0;const ne=n.getParameter(n.VERSION);ne.indexOf("WebGL")!==-1?(ie=parseFloat(/^WebGL (\d)/.exec(ne)[1]),K=ie>=1):ne.indexOf("OpenGL ES")!==-1&&(ie=parseFloat(/^OpenGL ES (\d)/.exec(ne)[1]),K=ie>=2);let ue=null,de={};const J=n.getParameter(n.SCISSOR_BOX),se=n.getParameter(n.VIEWPORT),ge=new ut().fromArray(J),Ae=new ut().fromArray(se);function we(D,he,pe,Te){const Pe=new Uint8Array(4),st=n.createTexture();n.bindTexture(D,st),n.texParameteri(D,n.TEXTURE_MIN_FILTER,n.NEAREST),n.texParameteri(D,n.TEXTURE_MAG_FILTER,n.NEAREST);for(let at=0;at<pe;at++)i&&(D===n.TEXTURE_3D||D===n.TEXTURE_2D_ARRAY)?n.texImage3D(he,0,n.RGBA,1,1,Te,0,n.RGBA,n.UNSIGNED_BYTE,Pe):n.texImage2D(he+at,0,n.RGBA,1,1,0,n.RGBA,n.UNSIGNED_BYTE,Pe);return st}const ke={};ke[n.TEXTURE_2D]=we(n.TEXTURE_2D,n.TEXTURE_2D,1),ke[n.TEXTURE_CUBE_MAP]=we(n.TEXTURE_CUBE_MAP,n.TEXTURE_CUBE_MAP_POSITIVE_X,6),i&&(ke[n.TEXTURE_2D_ARRAY]=we(n.TEXTURE_2D_ARRAY,n.TEXTURE_2D_ARRAY,1,1),ke[n.TEXTURE_3D]=we(n.TEXTURE_3D,n.TEXTURE_3D,1,1)),o.setClear(0,0,0,1),l.setClear(1),c.setClear(0),Ge(n.DEPTH_TEST),l.setFunc(ns),me(!1),A(po),Ge(n.CULL_FACE),oe(Dn);function Ge(D){h[D]!==!0&&(n.enable(D),h[D]=!0)}function Ie(D){h[D]!==!1&&(n.disable(D),h[D]=!1)}function w(D,he){return m[D]!==he?(n.bindFramebuffer(D,he),m[D]=he,i&&(D===n.DRAW_FRAMEBUFFER&&(m[n.FRAMEBUFFER]=he),D===n.FRAMEBUFFER&&(m[n.DRAW_FRAMEBUFFER]=he)),!0):!1}function b(D,he){let pe=x,Te=!1;if(D)if(pe=_.get(he),pe===void 0&&(pe=[],_.set(he,pe)),D.isWebGLMultipleRenderTargets){const Pe=D.texture;if(pe.length!==Pe.length||pe[0]!==n.COLOR_ATTACHMENT0){for(let st=0,at=Pe.length;st<at;st++)pe[st]=n.COLOR_ATTACHMENT0+st;pe.length=Pe.length,Te=!0}}else pe[0]!==n.COLOR_ATTACHMENT0&&(pe[0]=n.COLOR_ATTACHMENT0,Te=!0);else pe[0]!==n.BACK&&(pe[0]=n.BACK,Te=!0);Te&&(t.isWebGL2?n.drawBuffers(pe):e.get("WEBGL_draw_buffers").drawBuffersWEBGL(pe))}function H(D){return p!==D?(n.useProgram(D),p=D,!0):!1}const F={[$n]:n.FUNC_ADD,[yh]:n.FUNC_SUBTRACT,[Mh]:n.FUNC_REVERSE_SUBTRACT};if(i)F[_o]=n.MIN,F[vo]=n.MAX;else{const D=e.get("EXT_blend_minmax");D!==null&&(F[_o]=D.MIN_EXT,F[vo]=D.MAX_EXT)}const ae={[Sh]:n.ZERO,[bh]:n.ONE,[wh]:n.SRC_COLOR,[ba]:n.SRC_ALPHA,[Ph]:n.SRC_ALPHA_SATURATE,[Rh]:n.DST_COLOR,[Th]:n.DST_ALPHA,[Eh]:n.ONE_MINUS_SRC_COLOR,[wa]:n.ONE_MINUS_SRC_ALPHA,[Ch]:n.ONE_MINUS_DST_COLOR,[Ah]:n.ONE_MINUS_DST_ALPHA,[Lh]:n.CONSTANT_COLOR,[Dh]:n.ONE_MINUS_CONSTANT_COLOR,[Ih]:n.CONSTANT_ALPHA,[Uh]:n.ONE_MINUS_CONSTANT_ALPHA};function oe(D,he,pe,Te,Pe,st,at,bt,Ut,ot){if(D===Dn){f===!0&&(Ie(n.BLEND),f=!1);return}if(f===!1&&(Ge(n.BLEND),f=!0),D!==vh){if(D!==v||ot!==G){if((g!==$n||T!==$n)&&(n.blendEquation(n.FUNC_ADD),g=$n,T=$n),ot)switch(D){case Ni:n.blendFuncSeparate(n.ONE,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case mo:n.blendFunc(n.ONE,n.ONE);break;case go:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case xo:n.blendFuncSeparate(n.ZERO,n.SRC_COLOR,n.ZERO,n.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}else switch(D){case Ni:n.blendFuncSeparate(n.SRC_ALPHA,n.ONE_MINUS_SRC_ALPHA,n.ONE,n.ONE_MINUS_SRC_ALPHA);break;case mo:n.blendFunc(n.SRC_ALPHA,n.ONE);break;case go:n.blendFuncSeparate(n.ZERO,n.ONE_MINUS_SRC_COLOR,n.ZERO,n.ONE);break;case xo:n.blendFunc(n.ZERO,n.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",D);break}y=null,R=null,C=null,z=null,M.set(0,0,0),S=0,v=D,G=ot}return}Pe=Pe||he,st=st||pe,at=at||Te,(he!==g||Pe!==T)&&(n.blendEquationSeparate(F[he],F[Pe]),g=he,T=Pe),(pe!==y||Te!==R||st!==C||at!==z)&&(n.blendFuncSeparate(ae[pe],ae[Te],ae[st],ae[at]),y=pe,R=Te,C=st,z=at),(bt.equals(M)===!1||Ut!==S)&&(n.blendColor(bt.r,bt.g,bt.b,Ut),M.copy(bt),S=Ut),v=D,G=!1}function ee(D,he){D.side===yt?Ie(n.CULL_FACE):Ge(n.CULL_FACE);let pe=D.side===Bt;he&&(pe=!pe),me(pe),D.blending===Ni&&D.transparent===!1?oe(Dn):oe(D.blending,D.blendEquation,D.blendSrc,D.blendDst,D.blendEquationAlpha,D.blendSrcAlpha,D.blendDstAlpha,D.blendColor,D.blendAlpha,D.premultipliedAlpha),l.setFunc(D.depthFunc),l.setTest(D.depthTest),l.setMask(D.depthWrite),o.setMask(D.colorWrite);const Te=D.stencilWrite;c.setTest(Te),Te&&(c.setMask(D.stencilWriteMask),c.setFunc(D.stencilFunc,D.stencilRef,D.stencilFuncMask),c.setOp(D.stencilFail,D.stencilZFail,D.stencilZPass)),O(D.polygonOffset,D.polygonOffsetFactor,D.polygonOffsetUnits),D.alphaToCoverage===!0?Ge(n.SAMPLE_ALPHA_TO_COVERAGE):Ie(n.SAMPLE_ALPHA_TO_COVERAGE)}function me(D){I!==D&&(D?n.frontFace(n.CW):n.frontFace(n.CCW),I=D)}function A(D){D!==gh?(Ge(n.CULL_FACE),D!==W&&(D===po?n.cullFace(n.BACK):D===xh?n.cullFace(n.FRONT):n.cullFace(n.FRONT_AND_BACK))):Ie(n.CULL_FACE),W=D}function E(D){D!==L&&(K&&n.lineWidth(D),L=D)}function O(D,he,pe){D?(Ge(n.POLYGON_OFFSET_FILL),(U!==he||B!==pe)&&(n.polygonOffset(he,pe),U=he,B=pe)):Ie(n.POLYGON_OFFSET_FILL)}function Q(D){D?Ge(n.SCISSOR_TEST):Ie(n.SCISSOR_TEST)}function j(D){D===void 0&&(D=n.TEXTURE0+X-1),ue!==D&&(n.activeTexture(D),ue=D)}function te(D,he,pe){pe===void 0&&(ue===null?pe=n.TEXTURE0+X-1:pe=ue);let Te=de[pe];Te===void 0&&(Te={type:void 0,texture:void 0},de[pe]=Te),(Te.type!==D||Te.texture!==he)&&(ue!==pe&&(n.activeTexture(pe),ue=pe),n.bindTexture(D,he||ke[D]),Te.type=D,Te.texture=he)}function ve(){const D=de[ue];D!==void 0&&D.type!==void 0&&(n.bindTexture(D.type,null),D.type=void 0,D.texture=void 0)}function xe(){try{n.compressedTexImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ye(){try{n.compressedTexImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ee(){try{n.texSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ue(){try{n.texSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ce(){try{n.compressedTexSubImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ke(){try{n.compressedTexSubImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function qe(){try{n.texStorage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function ze(){try{n.texStorage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ce(){try{n.texImage2D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Se(){try{n.texImage3D.apply(n,arguments)}catch(D){console.error("THREE.WebGLState:",D)}}function Ne(D){ge.equals(D)===!1&&(n.scissor(D.x,D.y,D.z,D.w),ge.copy(D))}function re(D){Ae.equals(D)===!1&&(n.viewport(D.x,D.y,D.z,D.w),Ae.copy(D))}function le(D,he){let pe=u.get(he);pe===void 0&&(pe=new WeakMap,u.set(he,pe));let Te=pe.get(D);Te===void 0&&(Te=n.getUniformBlockIndex(he,D.name),pe.set(D,Te))}function fe(D,he){const Te=u.get(he).get(D);d.get(he)!==Te&&(n.uniformBlockBinding(he,Te,D.__bindingPointIndex),d.set(he,Te))}function Z(){n.disable(n.BLEND),n.disable(n.CULL_FACE),n.disable(n.DEPTH_TEST),n.disable(n.POLYGON_OFFSET_FILL),n.disable(n.SCISSOR_TEST),n.disable(n.STENCIL_TEST),n.disable(n.SAMPLE_ALPHA_TO_COVERAGE),n.blendEquation(n.FUNC_ADD),n.blendFunc(n.ONE,n.ZERO),n.blendFuncSeparate(n.ONE,n.ZERO,n.ONE,n.ZERO),n.blendColor(0,0,0,0),n.colorMask(!0,!0,!0,!0),n.clearColor(0,0,0,0),n.depthMask(!0),n.depthFunc(n.LESS),n.clearDepth(1),n.stencilMask(4294967295),n.stencilFunc(n.ALWAYS,0,4294967295),n.stencilOp(n.KEEP,n.KEEP,n.KEEP),n.clearStencil(0),n.cullFace(n.BACK),n.frontFace(n.CCW),n.polygonOffset(0,0),n.activeTexture(n.TEXTURE0),n.bindFramebuffer(n.FRAMEBUFFER,null),i===!0&&(n.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),n.bindFramebuffer(n.READ_FRAMEBUFFER,null)),n.useProgram(null),n.lineWidth(1),n.scissor(0,0,n.canvas.width,n.canvas.height),n.viewport(0,0,n.canvas.width,n.canvas.height),h={},ue=null,de={},m={},_=new WeakMap,x=[],p=null,f=!1,v=null,g=null,y=null,R=null,T=null,C=null,z=null,M=new $e(0,0,0),S=0,G=!1,I=null,W=null,L=null,U=null,B=null,ge.set(0,0,n.canvas.width,n.canvas.height),Ae.set(0,0,n.canvas.width,n.canvas.height),o.reset(),l.reset(),c.reset()}return{buffers:{color:o,depth:l,stencil:c},enable:Ge,disable:Ie,bindFramebuffer:w,drawBuffers:b,useProgram:H,setBlending:oe,setMaterial:ee,setFlipSided:me,setCullFace:A,setLineWidth:E,setPolygonOffset:O,setScissorTest:Q,activeTexture:j,bindTexture:te,unbindTexture:ve,compressedTexImage2D:xe,compressedTexImage3D:ye,texImage2D:Ce,texImage3D:Se,updateUBOMapping:le,uniformBlockBinding:fe,texStorage2D:qe,texStorage3D:ze,texSubImage2D:Ee,texSubImage3D:Ue,compressedTexSubImage2D:ce,compressedTexSubImage3D:Ke,scissor:Ne,viewport:re,reset:Z}}function mm(n,e,t,i,r,s,a){const o=r.isWebGL2,l=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,c=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new WeakMap;let u;const h=new WeakMap;let m=!1;try{m=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function _(A,E){return m?new OffscreenCanvas(A,E):os("canvas")}function x(A,E,O,Q){let j=1;if((A.width>Q||A.height>Q)&&(j=Q/Math.max(A.width,A.height)),j<1||E===!0)if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap){const te=E?Da:Math.floor,ve=te(j*A.width),xe=te(j*A.height);u===void 0&&(u=_(ve,xe));const ye=O?_(ve,xe):u;return ye.width=ve,ye.height=xe,ye.getContext("2d").drawImage(A,0,0,ve,xe),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+A.width+"x"+A.height+") to ("+ve+"x"+xe+")."),ye}else return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+A.width+"x"+A.height+")."),A;return A}function p(A){return jo(A.width)&&jo(A.height)}function f(A){return o?!1:A.wrapS!==rn||A.wrapT!==rn||A.minFilter!==Pt&&A.minFilter!==$t}function v(A,E){return A.generateMipmaps&&E&&A.minFilter!==Pt&&A.minFilter!==$t}function g(A){n.generateMipmap(A)}function y(A,E,O,Q,j=!1){if(o===!1)return E;if(A!==null){if(n[A]!==void 0)return n[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let te=E;if(E===n.RED&&(O===n.FLOAT&&(te=n.R32F),O===n.HALF_FLOAT&&(te=n.R16F),O===n.UNSIGNED_BYTE&&(te=n.R8)),E===n.RED_INTEGER&&(O===n.UNSIGNED_BYTE&&(te=n.R8UI),O===n.UNSIGNED_SHORT&&(te=n.R16UI),O===n.UNSIGNED_INT&&(te=n.R32UI),O===n.BYTE&&(te=n.R8I),O===n.SHORT&&(te=n.R16I),O===n.INT&&(te=n.R32I)),E===n.RG&&(O===n.FLOAT&&(te=n.RG32F),O===n.HALF_FLOAT&&(te=n.RG16F),O===n.UNSIGNED_BYTE&&(te=n.RG8)),E===n.RGBA){const ve=j?is:tt.getTransfer(Q);O===n.FLOAT&&(te=n.RGBA32F),O===n.HALF_FLOAT&&(te=n.RGBA16F),O===n.UNSIGNED_BYTE&&(te=ve===ct?n.SRGB8_ALPHA8:n.RGBA8),O===n.UNSIGNED_SHORT_4_4_4_4&&(te=n.RGBA4),O===n.UNSIGNED_SHORT_5_5_5_1&&(te=n.RGB5_A1)}return(te===n.R16F||te===n.R32F||te===n.RG16F||te===n.RG32F||te===n.RGBA16F||te===n.RGBA32F)&&e.get("EXT_color_buffer_float"),te}function R(A,E,O){return v(A,O)===!0||A.isFramebufferTexture&&A.minFilter!==Pt&&A.minFilter!==$t?Math.log2(Math.max(E.width,E.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?E.mipmaps.length:1}function T(A){return A===Pt||A===yo||A===Fs?n.NEAREST:n.LINEAR}function C(A){const E=A.target;E.removeEventListener("dispose",C),M(E),E.isVideoTexture&&d.delete(E)}function z(A){const E=A.target;E.removeEventListener("dispose",z),G(E)}function M(A){const E=i.get(A);if(E.__webglInit===void 0)return;const O=A.source,Q=h.get(O);if(Q){const j=Q[E.__cacheKey];j.usedTimes--,j.usedTimes===0&&S(A),Object.keys(Q).length===0&&h.delete(O)}i.remove(A)}function S(A){const E=i.get(A);n.deleteTexture(E.__webglTexture);const O=A.source,Q=h.get(O);delete Q[E.__cacheKey],a.memory.textures--}function G(A){const E=A.texture,O=i.get(A),Q=i.get(E);if(Q.__webglTexture!==void 0&&(n.deleteTexture(Q.__webglTexture),a.memory.textures--),A.depthTexture&&A.depthTexture.dispose(),A.isWebGLCubeRenderTarget)for(let j=0;j<6;j++){if(Array.isArray(O.__webglFramebuffer[j]))for(let te=0;te<O.__webglFramebuffer[j].length;te++)n.deleteFramebuffer(O.__webglFramebuffer[j][te]);else n.deleteFramebuffer(O.__webglFramebuffer[j]);O.__webglDepthbuffer&&n.deleteRenderbuffer(O.__webglDepthbuffer[j])}else{if(Array.isArray(O.__webglFramebuffer))for(let j=0;j<O.__webglFramebuffer.length;j++)n.deleteFramebuffer(O.__webglFramebuffer[j]);else n.deleteFramebuffer(O.__webglFramebuffer);if(O.__webglDepthbuffer&&n.deleteRenderbuffer(O.__webglDepthbuffer),O.__webglMultisampledFramebuffer&&n.deleteFramebuffer(O.__webglMultisampledFramebuffer),O.__webglColorRenderbuffer)for(let j=0;j<O.__webglColorRenderbuffer.length;j++)O.__webglColorRenderbuffer[j]&&n.deleteRenderbuffer(O.__webglColorRenderbuffer[j]);O.__webglDepthRenderbuffer&&n.deleteRenderbuffer(O.__webglDepthRenderbuffer)}if(A.isWebGLMultipleRenderTargets)for(let j=0,te=E.length;j<te;j++){const ve=i.get(E[j]);ve.__webglTexture&&(n.deleteTexture(ve.__webglTexture),a.memory.textures--),i.remove(E[j])}i.remove(E),i.remove(A)}let I=0;function W(){I=0}function L(){const A=I;return A>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+r.maxTextures),I+=1,A}function U(A){const E=[];return E.push(A.wrapS),E.push(A.wrapT),E.push(A.wrapR||0),E.push(A.magFilter),E.push(A.minFilter),E.push(A.anisotropy),E.push(A.internalFormat),E.push(A.format),E.push(A.type),E.push(A.generateMipmaps),E.push(A.premultiplyAlpha),E.push(A.flipY),E.push(A.unpackAlignment),E.push(A.colorSpace),E.join()}function B(A,E){const O=i.get(A);if(A.isVideoTexture&&ee(A),A.isRenderTargetTexture===!1&&A.version>0&&O.__version!==A.version){const Q=A.image;if(Q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{ge(O,A,E);return}}t.bindTexture(n.TEXTURE_2D,O.__webglTexture,n.TEXTURE0+E)}function X(A,E){const O=i.get(A);if(A.version>0&&O.__version!==A.version){ge(O,A,E);return}t.bindTexture(n.TEXTURE_2D_ARRAY,O.__webglTexture,n.TEXTURE0+E)}function K(A,E){const O=i.get(A);if(A.version>0&&O.__version!==A.version){ge(O,A,E);return}t.bindTexture(n.TEXTURE_3D,O.__webglTexture,n.TEXTURE0+E)}function ie(A,E){const O=i.get(A);if(A.version>0&&O.__version!==A.version){Ae(O,A,E);return}t.bindTexture(n.TEXTURE_CUBE_MAP,O.__webglTexture,n.TEXTURE0+E)}const ne={[Aa]:n.REPEAT,[rn]:n.CLAMP_TO_EDGE,[Ra]:n.MIRRORED_REPEAT},ue={[Pt]:n.NEAREST,[yo]:n.NEAREST_MIPMAP_NEAREST,[Fs]:n.NEAREST_MIPMAP_LINEAR,[$t]:n.LINEAR,[$h]:n.LINEAR_MIPMAP_NEAREST,[ur]:n.LINEAR_MIPMAP_LINEAR},de={[lu]:n.NEVER,[pu]:n.ALWAYS,[cu]:n.LESS,[xc]:n.LEQUAL,[hu]:n.EQUAL,[fu]:n.GEQUAL,[uu]:n.GREATER,[du]:n.NOTEQUAL};function J(A,E,O){if(O?(n.texParameteri(A,n.TEXTURE_WRAP_S,ne[E.wrapS]),n.texParameteri(A,n.TEXTURE_WRAP_T,ne[E.wrapT]),(A===n.TEXTURE_3D||A===n.TEXTURE_2D_ARRAY)&&n.texParameteri(A,n.TEXTURE_WRAP_R,ne[E.wrapR]),n.texParameteri(A,n.TEXTURE_MAG_FILTER,ue[E.magFilter]),n.texParameteri(A,n.TEXTURE_MIN_FILTER,ue[E.minFilter])):(n.texParameteri(A,n.TEXTURE_WRAP_S,n.CLAMP_TO_EDGE),n.texParameteri(A,n.TEXTURE_WRAP_T,n.CLAMP_TO_EDGE),(A===n.TEXTURE_3D||A===n.TEXTURE_2D_ARRAY)&&n.texParameteri(A,n.TEXTURE_WRAP_R,n.CLAMP_TO_EDGE),(E.wrapS!==rn||E.wrapT!==rn)&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.wrapS and Texture.wrapT should be set to THREE.ClampToEdgeWrapping."),n.texParameteri(A,n.TEXTURE_MAG_FILTER,T(E.magFilter)),n.texParameteri(A,n.TEXTURE_MIN_FILTER,T(E.minFilter)),E.minFilter!==Pt&&E.minFilter!==$t&&console.warn("THREE.WebGLRenderer: Texture is not power of two. Texture.minFilter should be set to THREE.NearestFilter or THREE.LinearFilter.")),E.compareFunction&&(n.texParameteri(A,n.TEXTURE_COMPARE_MODE,n.COMPARE_REF_TO_TEXTURE),n.texParameteri(A,n.TEXTURE_COMPARE_FUNC,de[E.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){const Q=e.get("EXT_texture_filter_anisotropic");if(E.magFilter===Pt||E.minFilter!==Fs&&E.minFilter!==ur||E.type===Pn&&e.has("OES_texture_float_linear")===!1||o===!1&&E.type===dr&&e.has("OES_texture_half_float_linear")===!1)return;(E.anisotropy>1||i.get(E).__currentAnisotropy)&&(n.texParameterf(A,Q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(E.anisotropy,r.getMaxAnisotropy())),i.get(E).__currentAnisotropy=E.anisotropy)}}function se(A,E){let O=!1;A.__webglInit===void 0&&(A.__webglInit=!0,E.addEventListener("dispose",C));const Q=E.source;let j=h.get(Q);j===void 0&&(j={},h.set(Q,j));const te=U(E);if(te!==A.__cacheKey){j[te]===void 0&&(j[te]={texture:n.createTexture(),usedTimes:0},a.memory.textures++,O=!0),j[te].usedTimes++;const ve=j[A.__cacheKey];ve!==void 0&&(j[A.__cacheKey].usedTimes--,ve.usedTimes===0&&S(E)),A.__cacheKey=te,A.__webglTexture=j[te].texture}return O}function ge(A,E,O){let Q=n.TEXTURE_2D;(E.isDataArrayTexture||E.isCompressedArrayTexture)&&(Q=n.TEXTURE_2D_ARRAY),E.isData3DTexture&&(Q=n.TEXTURE_3D);const j=se(A,E),te=E.source;t.bindTexture(Q,A.__webglTexture,n.TEXTURE0+O);const ve=i.get(te);if(te.version!==ve.__version||j===!0){t.activeTexture(n.TEXTURE0+O);const xe=tt.getPrimaries(tt.workingColorSpace),ye=E.colorSpace===Jt?null:tt.getPrimaries(E.colorSpace),Ee=E.colorSpace===Jt||xe===ye?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,E.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,E.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ee);const Ue=f(E)&&p(E.image)===!1;let ce=x(E.image,Ue,!1,r.maxTextureSize);ce=me(E,ce);const Ke=p(ce)||o,qe=s.convert(E.format,E.colorSpace);let ze=s.convert(E.type),Ce=y(E.internalFormat,qe,ze,E.colorSpace,E.isVideoTexture);J(Q,E,Ke);let Se;const Ne=E.mipmaps,re=o&&E.isVideoTexture!==!0&&Ce!==pc,le=ve.__version===void 0||j===!0,fe=R(E,ce,Ke);if(E.isDepthTexture)Ce=n.DEPTH_COMPONENT,o?E.type===Pn?Ce=n.DEPTH_COMPONENT32F:E.type===Cn?Ce=n.DEPTH_COMPONENT24:E.type===ei?Ce=n.DEPTH24_STENCIL8:Ce=n.DEPTH_COMPONENT16:E.type===Pn&&console.error("WebGLRenderer: Floating point depth texture requires WebGL2."),E.format===ti&&Ce===n.DEPTH_COMPONENT&&E.type!==qa&&E.type!==Cn&&(console.warn("THREE.WebGLRenderer: Use UnsignedShortType or UnsignedIntType for DepthFormat DepthTexture."),E.type=Cn,ze=s.convert(E.type)),E.format===Hi&&Ce===n.DEPTH_COMPONENT&&(Ce=n.DEPTH_STENCIL,E.type!==ei&&(console.warn("THREE.WebGLRenderer: Use UnsignedInt248Type for DepthStencilFormat DepthTexture."),E.type=ei,ze=s.convert(E.type))),le&&(re?t.texStorage2D(n.TEXTURE_2D,1,Ce,ce.width,ce.height):t.texImage2D(n.TEXTURE_2D,0,Ce,ce.width,ce.height,0,qe,ze,null));else if(E.isDataTexture)if(Ne.length>0&&Ke){re&&le&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,Ne[0].width,Ne[0].height);for(let Z=0,D=Ne.length;Z<D;Z++)Se=Ne[Z],re?t.texSubImage2D(n.TEXTURE_2D,Z,0,0,Se.width,Se.height,qe,ze,Se.data):t.texImage2D(n.TEXTURE_2D,Z,Ce,Se.width,Se.height,0,qe,ze,Se.data);E.generateMipmaps=!1}else re?(le&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,ce.width,ce.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,ce.width,ce.height,qe,ze,ce.data)):t.texImage2D(n.TEXTURE_2D,0,Ce,ce.width,ce.height,0,qe,ze,ce.data);else if(E.isCompressedTexture)if(E.isCompressedArrayTexture){re&&le&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Ce,Ne[0].width,Ne[0].height,ce.depth);for(let Z=0,D=Ne.length;Z<D;Z++)Se=Ne[Z],E.format!==sn?qe!==null?re?t.compressedTexSubImage3D(n.TEXTURE_2D_ARRAY,Z,0,0,0,Se.width,Se.height,ce.depth,qe,Se.data,0,0):t.compressedTexImage3D(n.TEXTURE_2D_ARRAY,Z,Ce,Se.width,Se.height,ce.depth,0,Se.data,0,0):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?t.texSubImage3D(n.TEXTURE_2D_ARRAY,Z,0,0,0,Se.width,Se.height,ce.depth,qe,ze,Se.data):t.texImage3D(n.TEXTURE_2D_ARRAY,Z,Ce,Se.width,Se.height,ce.depth,0,qe,ze,Se.data)}else{re&&le&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,Ne[0].width,Ne[0].height);for(let Z=0,D=Ne.length;Z<D;Z++)Se=Ne[Z],E.format!==sn?qe!==null?re?t.compressedTexSubImage2D(n.TEXTURE_2D,Z,0,0,Se.width,Se.height,qe,Se.data):t.compressedTexImage2D(n.TEXTURE_2D,Z,Ce,Se.width,Se.height,0,Se.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):re?t.texSubImage2D(n.TEXTURE_2D,Z,0,0,Se.width,Se.height,qe,ze,Se.data):t.texImage2D(n.TEXTURE_2D,Z,Ce,Se.width,Se.height,0,qe,ze,Se.data)}else if(E.isDataArrayTexture)re?(le&&t.texStorage3D(n.TEXTURE_2D_ARRAY,fe,Ce,ce.width,ce.height,ce.depth),t.texSubImage3D(n.TEXTURE_2D_ARRAY,0,0,0,0,ce.width,ce.height,ce.depth,qe,ze,ce.data)):t.texImage3D(n.TEXTURE_2D_ARRAY,0,Ce,ce.width,ce.height,ce.depth,0,qe,ze,ce.data);else if(E.isData3DTexture)re?(le&&t.texStorage3D(n.TEXTURE_3D,fe,Ce,ce.width,ce.height,ce.depth),t.texSubImage3D(n.TEXTURE_3D,0,0,0,0,ce.width,ce.height,ce.depth,qe,ze,ce.data)):t.texImage3D(n.TEXTURE_3D,0,Ce,ce.width,ce.height,ce.depth,0,qe,ze,ce.data);else if(E.isFramebufferTexture){if(le)if(re)t.texStorage2D(n.TEXTURE_2D,fe,Ce,ce.width,ce.height);else{let Z=ce.width,D=ce.height;for(let he=0;he<fe;he++)t.texImage2D(n.TEXTURE_2D,he,Ce,Z,D,0,qe,ze,null),Z>>=1,D>>=1}}else if(Ne.length>0&&Ke){re&&le&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,Ne[0].width,Ne[0].height);for(let Z=0,D=Ne.length;Z<D;Z++)Se=Ne[Z],re?t.texSubImage2D(n.TEXTURE_2D,Z,0,0,qe,ze,Se):t.texImage2D(n.TEXTURE_2D,Z,Ce,qe,ze,Se);E.generateMipmaps=!1}else re?(le&&t.texStorage2D(n.TEXTURE_2D,fe,Ce,ce.width,ce.height),t.texSubImage2D(n.TEXTURE_2D,0,0,0,qe,ze,ce)):t.texImage2D(n.TEXTURE_2D,0,Ce,qe,ze,ce);v(E,Ke)&&g(Q),ve.__version=te.version,E.onUpdate&&E.onUpdate(E)}A.__version=E.version}function Ae(A,E,O){if(E.image.length!==6)return;const Q=se(A,E),j=E.source;t.bindTexture(n.TEXTURE_CUBE_MAP,A.__webglTexture,n.TEXTURE0+O);const te=i.get(j);if(j.version!==te.__version||Q===!0){t.activeTexture(n.TEXTURE0+O);const ve=tt.getPrimaries(tt.workingColorSpace),xe=E.colorSpace===Jt?null:tt.getPrimaries(E.colorSpace),ye=E.colorSpace===Jt||ve===xe?n.NONE:n.BROWSER_DEFAULT_WEBGL;n.pixelStorei(n.UNPACK_FLIP_Y_WEBGL,E.flipY),n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),n.pixelStorei(n.UNPACK_ALIGNMENT,E.unpackAlignment),n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL,ye);const Ee=E.isCompressedTexture||E.image[0].isCompressedTexture,Ue=E.image[0]&&E.image[0].isDataTexture,ce=[];for(let Z=0;Z<6;Z++)!Ee&&!Ue?ce[Z]=x(E.image[Z],!1,!0,r.maxCubemapSize):ce[Z]=Ue?E.image[Z].image:E.image[Z],ce[Z]=me(E,ce[Z]);const Ke=ce[0],qe=p(Ke)||o,ze=s.convert(E.format,E.colorSpace),Ce=s.convert(E.type),Se=y(E.internalFormat,ze,Ce,E.colorSpace),Ne=o&&E.isVideoTexture!==!0,re=te.__version===void 0||Q===!0;let le=R(E,Ke,qe);J(n.TEXTURE_CUBE_MAP,E,qe);let fe;if(Ee){Ne&&re&&t.texStorage2D(n.TEXTURE_CUBE_MAP,le,Se,Ke.width,Ke.height);for(let Z=0;Z<6;Z++){fe=ce[Z].mipmaps;for(let D=0;D<fe.length;D++){const he=fe[D];E.format!==sn?ze!==null?Ne?t.compressedTexSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D,0,0,he.width,he.height,ze,he.data):t.compressedTexImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D,Se,he.width,he.height,0,he.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):Ne?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D,0,0,he.width,he.height,ze,Ce,he.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D,Se,he.width,he.height,0,ze,Ce,he.data)}}}else{fe=E.mipmaps,Ne&&re&&(fe.length>0&&le++,t.texStorage2D(n.TEXTURE_CUBE_MAP,le,Se,ce[0].width,ce[0].height));for(let Z=0;Z<6;Z++)if(Ue){Ne?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,ce[Z].width,ce[Z].height,ze,Ce,ce[Z].data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Se,ce[Z].width,ce[Z].height,0,ze,Ce,ce[Z].data);for(let D=0;D<fe.length;D++){const pe=fe[D].image[Z].image;Ne?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D+1,0,0,pe.width,pe.height,ze,Ce,pe.data):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D+1,Se,pe.width,pe.height,0,ze,Ce,pe.data)}}else{Ne?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,0,0,ze,Ce,ce[Z]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,0,Se,ze,Ce,ce[Z]);for(let D=0;D<fe.length;D++){const he=fe[D];Ne?t.texSubImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D+1,0,0,ze,Ce,he.image[Z]):t.texImage2D(n.TEXTURE_CUBE_MAP_POSITIVE_X+Z,D+1,Se,ze,Ce,he.image[Z])}}}v(E,qe)&&g(n.TEXTURE_CUBE_MAP),te.__version=j.version,E.onUpdate&&E.onUpdate(E)}A.__version=E.version}function we(A,E,O,Q,j,te){const ve=s.convert(O.format,O.colorSpace),xe=s.convert(O.type),ye=y(O.internalFormat,ve,xe,O.colorSpace);if(!i.get(E).__hasExternalTextures){const Ue=Math.max(1,E.width>>te),ce=Math.max(1,E.height>>te);j===n.TEXTURE_3D||j===n.TEXTURE_2D_ARRAY?t.texImage3D(j,te,ye,Ue,ce,E.depth,0,ve,xe,null):t.texImage2D(j,te,ye,Ue,ce,0,ve,xe,null)}t.bindFramebuffer(n.FRAMEBUFFER,A),oe(E)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,Q,j,i.get(O).__webglTexture,0,ae(E)):(j===n.TEXTURE_2D||j>=n.TEXTURE_CUBE_MAP_POSITIVE_X&&j<=n.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&n.framebufferTexture2D(n.FRAMEBUFFER,Q,j,i.get(O).__webglTexture,te),t.bindFramebuffer(n.FRAMEBUFFER,null)}function ke(A,E,O){if(n.bindRenderbuffer(n.RENDERBUFFER,A),E.depthBuffer&&!E.stencilBuffer){let Q=o===!0?n.DEPTH_COMPONENT24:n.DEPTH_COMPONENT16;if(O||oe(E)){const j=E.depthTexture;j&&j.isDepthTexture&&(j.type===Pn?Q=n.DEPTH_COMPONENT32F:j.type===Cn&&(Q=n.DEPTH_COMPONENT24));const te=ae(E);oe(E)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,te,Q,E.width,E.height):n.renderbufferStorageMultisample(n.RENDERBUFFER,te,Q,E.width,E.height)}else n.renderbufferStorage(n.RENDERBUFFER,Q,E.width,E.height);n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.RENDERBUFFER,A)}else if(E.depthBuffer&&E.stencilBuffer){const Q=ae(E);O&&oe(E)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Q,n.DEPTH24_STENCIL8,E.width,E.height):oe(E)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Q,n.DEPTH24_STENCIL8,E.width,E.height):n.renderbufferStorage(n.RENDERBUFFER,n.DEPTH_STENCIL,E.width,E.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.RENDERBUFFER,A)}else{const Q=E.isWebGLMultipleRenderTargets===!0?E.texture:[E.texture];for(let j=0;j<Q.length;j++){const te=Q[j],ve=s.convert(te.format,te.colorSpace),xe=s.convert(te.type),ye=y(te.internalFormat,ve,xe,te.colorSpace),Ee=ae(E);O&&oe(E)===!1?n.renderbufferStorageMultisample(n.RENDERBUFFER,Ee,ye,E.width,E.height):oe(E)?l.renderbufferStorageMultisampleEXT(n.RENDERBUFFER,Ee,ye,E.width,E.height):n.renderbufferStorage(n.RENDERBUFFER,ye,E.width,E.height)}}n.bindRenderbuffer(n.RENDERBUFFER,null)}function Ge(A,E){if(E&&E.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(n.FRAMEBUFFER,A),!(E.depthTexture&&E.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");(!i.get(E.depthTexture).__webglTexture||E.depthTexture.image.width!==E.width||E.depthTexture.image.height!==E.height)&&(E.depthTexture.image.width=E.width,E.depthTexture.image.height=E.height,E.depthTexture.needsUpdate=!0),B(E.depthTexture,0);const Q=i.get(E.depthTexture).__webglTexture,j=ae(E);if(E.depthTexture.format===ti)oe(E)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Q,0,j):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_ATTACHMENT,n.TEXTURE_2D,Q,0);else if(E.depthTexture.format===Hi)oe(E)?l.framebufferTexture2DMultisampleEXT(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Q,0,j):n.framebufferTexture2D(n.FRAMEBUFFER,n.DEPTH_STENCIL_ATTACHMENT,n.TEXTURE_2D,Q,0);else throw new Error("Unknown depthTexture format")}function Ie(A){const E=i.get(A),O=A.isWebGLCubeRenderTarget===!0;if(A.depthTexture&&!E.__autoAllocateDepthBuffer){if(O)throw new Error("target.depthTexture not supported in Cube render targets");Ge(E.__webglFramebuffer,A)}else if(O){E.__webglDepthbuffer=[];for(let Q=0;Q<6;Q++)t.bindFramebuffer(n.FRAMEBUFFER,E.__webglFramebuffer[Q]),E.__webglDepthbuffer[Q]=n.createRenderbuffer(),ke(E.__webglDepthbuffer[Q],A,!1)}else t.bindFramebuffer(n.FRAMEBUFFER,E.__webglFramebuffer),E.__webglDepthbuffer=n.createRenderbuffer(),ke(E.__webglDepthbuffer,A,!1);t.bindFramebuffer(n.FRAMEBUFFER,null)}function w(A,E,O){const Q=i.get(A);E!==void 0&&we(Q.__webglFramebuffer,A,A.texture,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,0),O!==void 0&&Ie(A)}function b(A){const E=A.texture,O=i.get(A),Q=i.get(E);A.addEventListener("dispose",z),A.isWebGLMultipleRenderTargets!==!0&&(Q.__webglTexture===void 0&&(Q.__webglTexture=n.createTexture()),Q.__version=E.version,a.memory.textures++);const j=A.isWebGLCubeRenderTarget===!0,te=A.isWebGLMultipleRenderTargets===!0,ve=p(A)||o;if(j){O.__webglFramebuffer=[];for(let xe=0;xe<6;xe++)if(o&&E.mipmaps&&E.mipmaps.length>0){O.__webglFramebuffer[xe]=[];for(let ye=0;ye<E.mipmaps.length;ye++)O.__webglFramebuffer[xe][ye]=n.createFramebuffer()}else O.__webglFramebuffer[xe]=n.createFramebuffer()}else{if(o&&E.mipmaps&&E.mipmaps.length>0){O.__webglFramebuffer=[];for(let xe=0;xe<E.mipmaps.length;xe++)O.__webglFramebuffer[xe]=n.createFramebuffer()}else O.__webglFramebuffer=n.createFramebuffer();if(te)if(r.drawBuffers){const xe=A.texture;for(let ye=0,Ee=xe.length;ye<Ee;ye++){const Ue=i.get(xe[ye]);Ue.__webglTexture===void 0&&(Ue.__webglTexture=n.createTexture(),a.memory.textures++)}}else console.warn("THREE.WebGLRenderer: WebGLMultipleRenderTargets can only be used with WebGL2 or WEBGL_draw_buffers extension.");if(o&&A.samples>0&&oe(A)===!1){const xe=te?E:[E];O.__webglMultisampledFramebuffer=n.createFramebuffer(),O.__webglColorRenderbuffer=[],t.bindFramebuffer(n.FRAMEBUFFER,O.__webglMultisampledFramebuffer);for(let ye=0;ye<xe.length;ye++){const Ee=xe[ye];O.__webglColorRenderbuffer[ye]=n.createRenderbuffer(),n.bindRenderbuffer(n.RENDERBUFFER,O.__webglColorRenderbuffer[ye]);const Ue=s.convert(Ee.format,Ee.colorSpace),ce=s.convert(Ee.type),Ke=y(Ee.internalFormat,Ue,ce,Ee.colorSpace,A.isXRRenderTarget===!0),qe=ae(A);n.renderbufferStorageMultisample(n.RENDERBUFFER,qe,Ke,A.width,A.height),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+ye,n.RENDERBUFFER,O.__webglColorRenderbuffer[ye])}n.bindRenderbuffer(n.RENDERBUFFER,null),A.depthBuffer&&(O.__webglDepthRenderbuffer=n.createRenderbuffer(),ke(O.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(n.FRAMEBUFFER,null)}}if(j){t.bindTexture(n.TEXTURE_CUBE_MAP,Q.__webglTexture),J(n.TEXTURE_CUBE_MAP,E,ve);for(let xe=0;xe<6;xe++)if(o&&E.mipmaps&&E.mipmaps.length>0)for(let ye=0;ye<E.mipmaps.length;ye++)we(O.__webglFramebuffer[xe][ye],A,E,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,ye);else we(O.__webglFramebuffer[xe],A,E,n.COLOR_ATTACHMENT0,n.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0);v(E,ve)&&g(n.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(te){const xe=A.texture;for(let ye=0,Ee=xe.length;ye<Ee;ye++){const Ue=xe[ye],ce=i.get(Ue);t.bindTexture(n.TEXTURE_2D,ce.__webglTexture),J(n.TEXTURE_2D,Ue,ve),we(O.__webglFramebuffer,A,Ue,n.COLOR_ATTACHMENT0+ye,n.TEXTURE_2D,0),v(Ue,ve)&&g(n.TEXTURE_2D)}t.unbindTexture()}else{let xe=n.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(o?xe=A.isWebGL3DRenderTarget?n.TEXTURE_3D:n.TEXTURE_2D_ARRAY:console.error("THREE.WebGLTextures: THREE.Data3DTexture and THREE.DataArrayTexture only supported with WebGL2.")),t.bindTexture(xe,Q.__webglTexture),J(xe,E,ve),o&&E.mipmaps&&E.mipmaps.length>0)for(let ye=0;ye<E.mipmaps.length;ye++)we(O.__webglFramebuffer[ye],A,E,n.COLOR_ATTACHMENT0,xe,ye);else we(O.__webglFramebuffer,A,E,n.COLOR_ATTACHMENT0,xe,0);v(E,ve)&&g(xe),t.unbindTexture()}A.depthBuffer&&Ie(A)}function H(A){const E=p(A)||o,O=A.isWebGLMultipleRenderTargets===!0?A.texture:[A.texture];for(let Q=0,j=O.length;Q<j;Q++){const te=O[Q];if(v(te,E)){const ve=A.isWebGLCubeRenderTarget?n.TEXTURE_CUBE_MAP:n.TEXTURE_2D,xe=i.get(te).__webglTexture;t.bindTexture(ve,xe),g(ve),t.unbindTexture()}}}function F(A){if(o&&A.samples>0&&oe(A)===!1){const E=A.isWebGLMultipleRenderTargets?A.texture:[A.texture],O=A.width,Q=A.height;let j=n.COLOR_BUFFER_BIT;const te=[],ve=A.stencilBuffer?n.DEPTH_STENCIL_ATTACHMENT:n.DEPTH_ATTACHMENT,xe=i.get(A),ye=A.isWebGLMultipleRenderTargets===!0;if(ye)for(let Ee=0;Ee<E.length;Ee++)t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.RENDERBUFFER,null),t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.TEXTURE_2D,null,0);t.bindFramebuffer(n.READ_FRAMEBUFFER,xe.__webglMultisampledFramebuffer),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,xe.__webglFramebuffer);for(let Ee=0;Ee<E.length;Ee++){te.push(n.COLOR_ATTACHMENT0+Ee),A.depthBuffer&&te.push(ve);const Ue=xe.__ignoreDepthValues!==void 0?xe.__ignoreDepthValues:!1;if(Ue===!1&&(A.depthBuffer&&(j|=n.DEPTH_BUFFER_BIT),A.stencilBuffer&&(j|=n.STENCIL_BUFFER_BIT)),ye&&n.framebufferRenderbuffer(n.READ_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.RENDERBUFFER,xe.__webglColorRenderbuffer[Ee]),Ue===!0&&(n.invalidateFramebuffer(n.READ_FRAMEBUFFER,[ve]),n.invalidateFramebuffer(n.DRAW_FRAMEBUFFER,[ve])),ye){const ce=i.get(E[Ee]).__webglTexture;n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0,n.TEXTURE_2D,ce,0)}n.blitFramebuffer(0,0,O,Q,0,0,O,Q,j,n.NEAREST),c&&n.invalidateFramebuffer(n.READ_FRAMEBUFFER,te)}if(t.bindFramebuffer(n.READ_FRAMEBUFFER,null),t.bindFramebuffer(n.DRAW_FRAMEBUFFER,null),ye)for(let Ee=0;Ee<E.length;Ee++){t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglMultisampledFramebuffer),n.framebufferRenderbuffer(n.FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.RENDERBUFFER,xe.__webglColorRenderbuffer[Ee]);const Ue=i.get(E[Ee]).__webglTexture;t.bindFramebuffer(n.FRAMEBUFFER,xe.__webglFramebuffer),n.framebufferTexture2D(n.DRAW_FRAMEBUFFER,n.COLOR_ATTACHMENT0+Ee,n.TEXTURE_2D,Ue,0)}t.bindFramebuffer(n.DRAW_FRAMEBUFFER,xe.__webglMultisampledFramebuffer)}}function ae(A){return Math.min(r.maxSamples,A.samples)}function oe(A){const E=i.get(A);return o&&A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&E.__useRenderToTexture!==!1}function ee(A){const E=a.render.frame;d.get(A)!==E&&(d.set(A,E),A.update())}function me(A,E){const O=A.colorSpace,Q=A.format,j=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||A.format===Pa||O!==Mn&&O!==Jt&&(tt.getTransfer(O)===ct?o===!1?e.has("EXT_sRGB")===!0&&Q===sn?(A.format=Pa,A.minFilter=$t,A.generateMipmaps=!1):E=vc.sRGBToLinear(E):(Q!==sn||j!==Un)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",O)),E}this.allocateTextureUnit=L,this.resetTextureUnits=W,this.setTexture2D=B,this.setTexture2DArray=X,this.setTexture3D=K,this.setTextureCube=ie,this.rebindTextures=w,this.setupRenderTarget=b,this.updateRenderTargetMipmap=H,this.updateMultisampleRenderTarget=F,this.setupDepthRenderbuffer=Ie,this.setupFrameBufferTexture=we,this.useMultisampledRTT=oe}function gm(n,e,t){const i=t.isWebGL2;function r(s,a=Jt){let o;const l=tt.getTransfer(a);if(s===Un)return n.UNSIGNED_BYTE;if(s===cc)return n.UNSIGNED_SHORT_4_4_4_4;if(s===hc)return n.UNSIGNED_SHORT_5_5_5_1;if(s===Kh)return n.BYTE;if(s===Jh)return n.SHORT;if(s===qa)return n.UNSIGNED_SHORT;if(s===lc)return n.INT;if(s===Cn)return n.UNSIGNED_INT;if(s===Pn)return n.FLOAT;if(s===dr)return i?n.HALF_FLOAT:(o=e.get("OES_texture_half_float"),o!==null?o.HALF_FLOAT_OES:null);if(s===Qh)return n.ALPHA;if(s===sn)return n.RGBA;if(s===eu)return n.LUMINANCE;if(s===tu)return n.LUMINANCE_ALPHA;if(s===ti)return n.DEPTH_COMPONENT;if(s===Hi)return n.DEPTH_STENCIL;if(s===Pa)return o=e.get("EXT_sRGB"),o!==null?o.SRGB_ALPHA_EXT:null;if(s===nu)return n.RED;if(s===uc)return n.RED_INTEGER;if(s===iu)return n.RG;if(s===dc)return n.RG_INTEGER;if(s===fc)return n.RGBA_INTEGER;if(s===Os||s===ks||s===Bs||s===Gs)if(l===ct)if(o=e.get("WEBGL_compressed_texture_s3tc_srgb"),o!==null){if(s===Os)return o.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===ks)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===Bs)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===Gs)return o.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(o=e.get("WEBGL_compressed_texture_s3tc"),o!==null){if(s===Os)return o.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===ks)return o.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===Bs)return o.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===Gs)return o.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===Mo||s===So||s===bo||s===wo)if(o=e.get("WEBGL_compressed_texture_pvrtc"),o!==null){if(s===Mo)return o.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===So)return o.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===bo)return o.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===wo)return o.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===pc)return o=e.get("WEBGL_compressed_texture_etc1"),o!==null?o.COMPRESSED_RGB_ETC1_WEBGL:null;if(s===Eo||s===To)if(o=e.get("WEBGL_compressed_texture_etc"),o!==null){if(s===Eo)return l===ct?o.COMPRESSED_SRGB8_ETC2:o.COMPRESSED_RGB8_ETC2;if(s===To)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:o.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(s===Ao||s===Ro||s===Co||s===Po||s===Lo||s===Do||s===Io||s===Uo||s===zo||s===No||s===Fo||s===Oo||s===ko||s===Bo)if(o=e.get("WEBGL_compressed_texture_astc"),o!==null){if(s===Ao)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:o.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Ro)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:o.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===Co)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:o.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Po)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:o.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Lo)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:o.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===Do)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:o.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Io)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:o.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Uo)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:o.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===zo)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:o.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===No)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:o.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===Fo)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:o.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Oo)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:o.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===ko)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:o.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Bo)return l===ct?o.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:o.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Hs||s===Go||s===Ho)if(o=e.get("EXT_texture_compression_bptc"),o!==null){if(s===Hs)return l===ct?o.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:o.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Go)return o.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Ho)return o.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===ru||s===Vo||s===Wo||s===Xo)if(o=e.get("EXT_texture_compression_rgtc"),o!==null){if(s===Hs)return o.COMPRESSED_RED_RGTC1_EXT;if(s===Vo)return o.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===Wo)return o.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Xo)return o.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===ei?i?n.UNSIGNED_INT_24_8:(o=e.get("WEBGL_depth_texture"),o!==null?o.UNSIGNED_INT_24_8_WEBGL:null):n[s]!==void 0?n[s]:null}return{convert:r}}class xm extends qt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class ft extends pt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const _m={type:"move"};class fa{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new ft,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new ft,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new N,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new N),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new ft,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new N,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new N),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let r=null,s=null,a=null;const o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(const x of e.hand.values()){const p=t.getJointPose(x,i),f=this._getHandJoint(c,x);p!==null&&(f.matrix.fromArray(p.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,f.jointRadius=p.radius),f.visible=p!==null}const d=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],h=d.position.distanceTo(u.position),m=.02,_=.005;c.inputState.pinching&&h>m+_?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&h<=m-_&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,i),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(r=t.getPose(e.targetRaySpace,i),r===null&&s!==null&&(r=s),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(_m)))}return o!==null&&(o.visible=r!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const i=new ft;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}}class vm extends Zi{constructor(e,t){super();const i=this;let r=null,s=1,a=null,o="local-floor",l=1,c=null,d=null,u=null,h=null,m=null,_=null;const x=t.getContextAttributes();let p=null,f=null;const v=[],g=[],y=new Oe;let R=null;const T=new qt;T.layers.enable(1),T.viewport=new ut;const C=new qt;C.layers.enable(2),C.viewport=new ut;const z=[T,C],M=new xm;M.layers.enable(1),M.layers.enable(2);let S=null,G=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(J){let se=v[J];return se===void 0&&(se=new fa,v[J]=se),se.getTargetRaySpace()},this.getControllerGrip=function(J){let se=v[J];return se===void 0&&(se=new fa,v[J]=se),se.getGripSpace()},this.getHand=function(J){let se=v[J];return se===void 0&&(se=new fa,v[J]=se),se.getHandSpace()};function I(J){const se=g.indexOf(J.inputSource);if(se===-1)return;const ge=v[se];ge!==void 0&&(ge.update(J.inputSource,J.frame,c||a),ge.dispatchEvent({type:J.type,data:J.inputSource}))}function W(){r.removeEventListener("select",I),r.removeEventListener("selectstart",I),r.removeEventListener("selectend",I),r.removeEventListener("squeeze",I),r.removeEventListener("squeezestart",I),r.removeEventListener("squeezeend",I),r.removeEventListener("end",W),r.removeEventListener("inputsourceschange",L);for(let J=0;J<v.length;J++){const se=g[J];se!==null&&(g[J]=null,v[J].disconnect(se))}S=null,G=null,e.setRenderTarget(p),m=null,h=null,u=null,r=null,f=null,de.stop(),i.isPresenting=!1,e.setPixelRatio(R),e.setSize(y.width,y.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(J){s=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(J){o=J,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(J){c=J},this.getBaseLayer=function(){return h!==null?h:m},this.getBinding=function(){return u},this.getFrame=function(){return _},this.getSession=function(){return r},this.setSession=async function(J){if(r=J,r!==null){if(p=e.getRenderTarget(),r.addEventListener("select",I),r.addEventListener("selectstart",I),r.addEventListener("selectend",I),r.addEventListener("squeeze",I),r.addEventListener("squeezestart",I),r.addEventListener("squeezeend",I),r.addEventListener("end",W),r.addEventListener("inputsourceschange",L),x.xrCompatible!==!0&&await t.makeXRCompatible(),R=e.getPixelRatio(),e.getSize(y),r.renderState.layers===void 0||e.capabilities.isWebGL2===!1){const se={antialias:r.renderState.layers===void 0?x.antialias:!0,alpha:!0,depth:x.depth,stencil:x.stencil,framebufferScaleFactor:s};m=new XRWebGLLayer(r,t,se),r.updateRenderState({baseLayer:m}),e.setPixelRatio(1),e.setSize(m.framebufferWidth,m.framebufferHeight,!1),f=new ri(m.framebufferWidth,m.framebufferHeight,{format:sn,type:Un,colorSpace:e.outputColorSpace,stencilBuffer:x.stencil})}else{let se=null,ge=null,Ae=null;x.depth&&(Ae=x.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,se=x.stencil?Hi:ti,ge=x.stencil?ei:Cn);const we={colorFormat:t.RGBA8,depthFormat:Ae,scaleFactor:s};u=new XRWebGLBinding(r,t),h=u.createProjectionLayer(we),r.updateRenderState({layers:[h]}),e.setPixelRatio(1),e.setSize(h.textureWidth,h.textureHeight,!1),f=new ri(h.textureWidth,h.textureHeight,{format:sn,type:Un,depthTexture:new Cc(h.textureWidth,h.textureHeight,ge,void 0,void 0,void 0,void 0,void 0,void 0,se),stencilBuffer:x.stencil,colorSpace:e.outputColorSpace,samples:x.antialias?4:0});const ke=e.properties.get(f);ke.__ignoreDepthValues=h.ignoreDepthValues}f.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await r.requestReferenceSpace(o),de.setContext(r),de.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode};function L(J){for(let se=0;se<J.removed.length;se++){const ge=J.removed[se],Ae=g.indexOf(ge);Ae>=0&&(g[Ae]=null,v[Ae].disconnect(ge))}for(let se=0;se<J.added.length;se++){const ge=J.added[se];let Ae=g.indexOf(ge);if(Ae===-1){for(let ke=0;ke<v.length;ke++)if(ke>=g.length){g.push(ge),Ae=ke;break}else if(g[ke]===null){g[ke]=ge,Ae=ke;break}if(Ae===-1)break}const we=v[Ae];we&&we.connect(ge)}}const U=new N,B=new N;function X(J,se,ge){U.setFromMatrixPosition(se.matrixWorld),B.setFromMatrixPosition(ge.matrixWorld);const Ae=U.distanceTo(B),we=se.projectionMatrix.elements,ke=ge.projectionMatrix.elements,Ge=we[14]/(we[10]-1),Ie=we[14]/(we[10]+1),w=(we[9]+1)/we[5],b=(we[9]-1)/we[5],H=(we[8]-1)/we[0],F=(ke[8]+1)/ke[0],ae=Ge*H,oe=Ge*F,ee=Ae/(-H+F),me=ee*-H;se.matrixWorld.decompose(J.position,J.quaternion,J.scale),J.translateX(me),J.translateZ(ee),J.matrixWorld.compose(J.position,J.quaternion,J.scale),J.matrixWorldInverse.copy(J.matrixWorld).invert();const A=Ge+ee,E=Ie+ee,O=ae-me,Q=oe+(Ae-me),j=w*Ie/E*A,te=b*Ie/E*A;J.projectionMatrix.makePerspective(O,Q,j,te,A,E),J.projectionMatrixInverse.copy(J.projectionMatrix).invert()}function K(J,se){se===null?J.matrixWorld.copy(J.matrix):J.matrixWorld.multiplyMatrices(se.matrixWorld,J.matrix),J.matrixWorldInverse.copy(J.matrixWorld).invert()}this.updateCamera=function(J){if(r===null)return;M.near=C.near=T.near=J.near,M.far=C.far=T.far=J.far,(S!==M.near||G!==M.far)&&(r.updateRenderState({depthNear:M.near,depthFar:M.far}),S=M.near,G=M.far);const se=J.parent,ge=M.cameras;K(M,se);for(let Ae=0;Ae<ge.length;Ae++)K(ge[Ae],se);ge.length===2?X(M,T,C):M.projectionMatrix.copy(T.projectionMatrix),ie(J,M,se)};function ie(J,se,ge){ge===null?J.matrix.copy(se.matrixWorld):(J.matrix.copy(ge.matrixWorld),J.matrix.invert(),J.matrix.multiply(se.matrixWorld)),J.matrix.decompose(J.position,J.quaternion,J.scale),J.updateMatrixWorld(!0),J.projectionMatrix.copy(se.projectionMatrix),J.projectionMatrixInverse.copy(se.projectionMatrixInverse),J.isPerspectiveCamera&&(J.fov=La*2*Math.atan(1/J.projectionMatrix.elements[5]),J.zoom=1)}this.getCamera=function(){return M},this.getFoveation=function(){if(!(h===null&&m===null))return l},this.setFoveation=function(J){l=J,h!==null&&(h.fixedFoveation=J),m!==null&&m.fixedFoveation!==void 0&&(m.fixedFoveation=J)};let ne=null;function ue(J,se){if(d=se.getViewerPose(c||a),_=se,d!==null){const ge=d.views;m!==null&&(e.setRenderTargetFramebuffer(f,m.framebuffer),e.setRenderTarget(f));let Ae=!1;ge.length!==M.cameras.length&&(M.cameras.length=0,Ae=!0);for(let we=0;we<ge.length;we++){const ke=ge[we];let Ge=null;if(m!==null)Ge=m.getViewport(ke);else{const w=u.getViewSubImage(h,ke);Ge=w.viewport,we===0&&(e.setRenderTargetTextures(f,w.colorTexture,h.ignoreDepthValues?void 0:w.depthStencilTexture),e.setRenderTarget(f))}let Ie=z[we];Ie===void 0&&(Ie=new qt,Ie.layers.enable(we),Ie.viewport=new ut,z[we]=Ie),Ie.matrix.fromArray(ke.transform.matrix),Ie.matrix.decompose(Ie.position,Ie.quaternion,Ie.scale),Ie.projectionMatrix.fromArray(ke.projectionMatrix),Ie.projectionMatrixInverse.copy(Ie.projectionMatrix).invert(),Ie.viewport.set(Ge.x,Ge.y,Ge.width,Ge.height),we===0&&(M.matrix.copy(Ie.matrix),M.matrix.decompose(M.position,M.quaternion,M.scale)),Ae===!0&&M.cameras.push(Ie)}}for(let ge=0;ge<v.length;ge++){const Ae=g[ge],we=v[ge];Ae!==null&&we!==void 0&&we.update(Ae,se,c||a)}ne&&ne(J,se),se.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:se}),_=null}const de=new Rc;de.setAnimationLoop(ue),this.setAnimationLoop=function(J){ne=J},this.dispose=function(){}}}function ym(n,e){function t(p,f){p.matrixAutoUpdate===!0&&p.updateMatrix(),f.value.copy(p.matrix)}function i(p,f){f.color.getRGB(p.fogColor.value,Ec(n)),f.isFog?(p.fogNear.value=f.near,p.fogFar.value=f.far):f.isFogExp2&&(p.fogDensity.value=f.density)}function r(p,f,v,g,y){f.isMeshBasicMaterial||f.isMeshLambertMaterial?s(p,f):f.isMeshToonMaterial?(s(p,f),u(p,f)):f.isMeshPhongMaterial?(s(p,f),d(p,f)):f.isMeshStandardMaterial?(s(p,f),h(p,f),f.isMeshPhysicalMaterial&&m(p,f,y)):f.isMeshMatcapMaterial?(s(p,f),_(p,f)):f.isMeshDepthMaterial?s(p,f):f.isMeshDistanceMaterial?(s(p,f),x(p,f)):f.isMeshNormalMaterial?s(p,f):f.isLineBasicMaterial?(a(p,f),f.isLineDashedMaterial&&o(p,f)):f.isPointsMaterial?l(p,f,v,g):f.isSpriteMaterial?c(p,f):f.isShadowMaterial?(p.color.value.copy(f.color),p.opacity.value=f.opacity):f.isShaderMaterial&&(f.uniformsNeedUpdate=!1)}function s(p,f){p.opacity.value=f.opacity,f.color&&p.diffuse.value.copy(f.color),f.emissive&&p.emissive.value.copy(f.emissive).multiplyScalar(f.emissiveIntensity),f.map&&(p.map.value=f.map,t(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.bumpMap&&(p.bumpMap.value=f.bumpMap,t(f.bumpMap,p.bumpMapTransform),p.bumpScale.value=f.bumpScale,f.side===Bt&&(p.bumpScale.value*=-1)),f.normalMap&&(p.normalMap.value=f.normalMap,t(f.normalMap,p.normalMapTransform),p.normalScale.value.copy(f.normalScale),f.side===Bt&&p.normalScale.value.negate()),f.displacementMap&&(p.displacementMap.value=f.displacementMap,t(f.displacementMap,p.displacementMapTransform),p.displacementScale.value=f.displacementScale,p.displacementBias.value=f.displacementBias),f.emissiveMap&&(p.emissiveMap.value=f.emissiveMap,t(f.emissiveMap,p.emissiveMapTransform)),f.specularMap&&(p.specularMap.value=f.specularMap,t(f.specularMap,p.specularMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest);const v=e.get(f).envMap;if(v&&(p.envMap.value=v,p.flipEnvMap.value=v.isCubeTexture&&v.isRenderTargetTexture===!1?-1:1,p.reflectivity.value=f.reflectivity,p.ior.value=f.ior,p.refractionRatio.value=f.refractionRatio),f.lightMap){p.lightMap.value=f.lightMap;const g=n._useLegacyLights===!0?Math.PI:1;p.lightMapIntensity.value=f.lightMapIntensity*g,t(f.lightMap,p.lightMapTransform)}f.aoMap&&(p.aoMap.value=f.aoMap,p.aoMapIntensity.value=f.aoMapIntensity,t(f.aoMap,p.aoMapTransform))}function a(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,f.map&&(p.map.value=f.map,t(f.map,p.mapTransform))}function o(p,f){p.dashSize.value=f.dashSize,p.totalSize.value=f.dashSize+f.gapSize,p.scale.value=f.scale}function l(p,f,v,g){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.size.value=f.size*v,p.scale.value=g*.5,f.map&&(p.map.value=f.map,t(f.map,p.uvTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function c(p,f){p.diffuse.value.copy(f.color),p.opacity.value=f.opacity,p.rotation.value=f.rotation,f.map&&(p.map.value=f.map,t(f.map,p.mapTransform)),f.alphaMap&&(p.alphaMap.value=f.alphaMap,t(f.alphaMap,p.alphaMapTransform)),f.alphaTest>0&&(p.alphaTest.value=f.alphaTest)}function d(p,f){p.specular.value.copy(f.specular),p.shininess.value=Math.max(f.shininess,1e-4)}function u(p,f){f.gradientMap&&(p.gradientMap.value=f.gradientMap)}function h(p,f){p.metalness.value=f.metalness,f.metalnessMap&&(p.metalnessMap.value=f.metalnessMap,t(f.metalnessMap,p.metalnessMapTransform)),p.roughness.value=f.roughness,f.roughnessMap&&(p.roughnessMap.value=f.roughnessMap,t(f.roughnessMap,p.roughnessMapTransform)),e.get(f).envMap&&(p.envMapIntensity.value=f.envMapIntensity)}function m(p,f,v){p.ior.value=f.ior,f.sheen>0&&(p.sheenColor.value.copy(f.sheenColor).multiplyScalar(f.sheen),p.sheenRoughness.value=f.sheenRoughness,f.sheenColorMap&&(p.sheenColorMap.value=f.sheenColorMap,t(f.sheenColorMap,p.sheenColorMapTransform)),f.sheenRoughnessMap&&(p.sheenRoughnessMap.value=f.sheenRoughnessMap,t(f.sheenRoughnessMap,p.sheenRoughnessMapTransform))),f.clearcoat>0&&(p.clearcoat.value=f.clearcoat,p.clearcoatRoughness.value=f.clearcoatRoughness,f.clearcoatMap&&(p.clearcoatMap.value=f.clearcoatMap,t(f.clearcoatMap,p.clearcoatMapTransform)),f.clearcoatRoughnessMap&&(p.clearcoatRoughnessMap.value=f.clearcoatRoughnessMap,t(f.clearcoatRoughnessMap,p.clearcoatRoughnessMapTransform)),f.clearcoatNormalMap&&(p.clearcoatNormalMap.value=f.clearcoatNormalMap,t(f.clearcoatNormalMap,p.clearcoatNormalMapTransform),p.clearcoatNormalScale.value.copy(f.clearcoatNormalScale),f.side===Bt&&p.clearcoatNormalScale.value.negate())),f.iridescence>0&&(p.iridescence.value=f.iridescence,p.iridescenceIOR.value=f.iridescenceIOR,p.iridescenceThicknessMinimum.value=f.iridescenceThicknessRange[0],p.iridescenceThicknessMaximum.value=f.iridescenceThicknessRange[1],f.iridescenceMap&&(p.iridescenceMap.value=f.iridescenceMap,t(f.iridescenceMap,p.iridescenceMapTransform)),f.iridescenceThicknessMap&&(p.iridescenceThicknessMap.value=f.iridescenceThicknessMap,t(f.iridescenceThicknessMap,p.iridescenceThicknessMapTransform))),f.transmission>0&&(p.transmission.value=f.transmission,p.transmissionSamplerMap.value=v.texture,p.transmissionSamplerSize.value.set(v.width,v.height),f.transmissionMap&&(p.transmissionMap.value=f.transmissionMap,t(f.transmissionMap,p.transmissionMapTransform)),p.thickness.value=f.thickness,f.thicknessMap&&(p.thicknessMap.value=f.thicknessMap,t(f.thicknessMap,p.thicknessMapTransform)),p.attenuationDistance.value=f.attenuationDistance,p.attenuationColor.value.copy(f.attenuationColor)),f.anisotropy>0&&(p.anisotropyVector.value.set(f.anisotropy*Math.cos(f.anisotropyRotation),f.anisotropy*Math.sin(f.anisotropyRotation)),f.anisotropyMap&&(p.anisotropyMap.value=f.anisotropyMap,t(f.anisotropyMap,p.anisotropyMapTransform))),p.specularIntensity.value=f.specularIntensity,p.specularColor.value.copy(f.specularColor),f.specularColorMap&&(p.specularColorMap.value=f.specularColorMap,t(f.specularColorMap,p.specularColorMapTransform)),f.specularIntensityMap&&(p.specularIntensityMap.value=f.specularIntensityMap,t(f.specularIntensityMap,p.specularIntensityMapTransform))}function _(p,f){f.matcap&&(p.matcap.value=f.matcap)}function x(p,f){const v=e.get(f).light;p.referencePosition.value.setFromMatrixPosition(v.matrixWorld),p.nearDistance.value=v.shadow.camera.near,p.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:r}}function Mm(n,e,t,i){let r={},s={},a=[];const o=t.isWebGL2?n.getParameter(n.MAX_UNIFORM_BUFFER_BINDINGS):0;function l(v,g){const y=g.program;i.uniformBlockBinding(v,y)}function c(v,g){let y=r[v.id];y===void 0&&(_(v),y=d(v),r[v.id]=y,v.addEventListener("dispose",p));const R=g.program;i.updateUBOMapping(v,R);const T=e.render.frame;s[v.id]!==T&&(h(v),s[v.id]=T)}function d(v){const g=u();v.__bindingPointIndex=g;const y=n.createBuffer(),R=v.__size,T=v.usage;return n.bindBuffer(n.UNIFORM_BUFFER,y),n.bufferData(n.UNIFORM_BUFFER,R,T),n.bindBuffer(n.UNIFORM_BUFFER,null),n.bindBufferBase(n.UNIFORM_BUFFER,g,y),y}function u(){for(let v=0;v<o;v++)if(a.indexOf(v)===-1)return a.push(v),v;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function h(v){const g=r[v.id],y=v.uniforms,R=v.__cache;n.bindBuffer(n.UNIFORM_BUFFER,g);for(let T=0,C=y.length;T<C;T++){const z=Array.isArray(y[T])?y[T]:[y[T]];for(let M=0,S=z.length;M<S;M++){const G=z[M];if(m(G,T,M,R)===!0){const I=G.__offset,W=Array.isArray(G.value)?G.value:[G.value];let L=0;for(let U=0;U<W.length;U++){const B=W[U],X=x(B);typeof B=="number"||typeof B=="boolean"?(G.__data[0]=B,n.bufferSubData(n.UNIFORM_BUFFER,I+L,G.__data)):B.isMatrix3?(G.__data[0]=B.elements[0],G.__data[1]=B.elements[1],G.__data[2]=B.elements[2],G.__data[3]=0,G.__data[4]=B.elements[3],G.__data[5]=B.elements[4],G.__data[6]=B.elements[5],G.__data[7]=0,G.__data[8]=B.elements[6],G.__data[9]=B.elements[7],G.__data[10]=B.elements[8],G.__data[11]=0):(B.toArray(G.__data,L),L+=X.storage/Float32Array.BYTES_PER_ELEMENT)}n.bufferSubData(n.UNIFORM_BUFFER,I,G.__data)}}}n.bindBuffer(n.UNIFORM_BUFFER,null)}function m(v,g,y,R){const T=v.value,C=g+"_"+y;if(R[C]===void 0)return typeof T=="number"||typeof T=="boolean"?R[C]=T:R[C]=T.clone(),!0;{const z=R[C];if(typeof T=="number"||typeof T=="boolean"){if(z!==T)return R[C]=T,!0}else if(z.equals(T)===!1)return z.copy(T),!0}return!1}function _(v){const g=v.uniforms;let y=0;const R=16;for(let C=0,z=g.length;C<z;C++){const M=Array.isArray(g[C])?g[C]:[g[C]];for(let S=0,G=M.length;S<G;S++){const I=M[S],W=Array.isArray(I.value)?I.value:[I.value];for(let L=0,U=W.length;L<U;L++){const B=W[L],X=x(B),K=y%R;K!==0&&R-K<X.boundary&&(y+=R-K),I.__data=new Float32Array(X.storage/Float32Array.BYTES_PER_ELEMENT),I.__offset=y,y+=X.storage}}}const T=y%R;return T>0&&(y+=R-T),v.__size=y,v.__cache={},this}function x(v){const g={boundary:0,storage:0};return typeof v=="number"||typeof v=="boolean"?(g.boundary=4,g.storage=4):v.isVector2?(g.boundary=8,g.storage=8):v.isVector3||v.isColor?(g.boundary=16,g.storage=12):v.isVector4?(g.boundary=16,g.storage=16):v.isMatrix3?(g.boundary=48,g.storage=48):v.isMatrix4?(g.boundary=64,g.storage=64):v.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",v),g}function p(v){const g=v.target;g.removeEventListener("dispose",p);const y=a.indexOf(g.__bindingPointIndex);a.splice(y,1),n.deleteBuffer(r[g.id]),delete r[g.id],delete s[g.id]}function f(){for(const v in r)n.deleteBuffer(r[v]);a=[],r={},s={}}return{bind:l,update:c,dispose:f}}class Ja{constructor(e={}){const{canvas:t=gu(),context:i=null,depth:r=!0,stencil:s=!0,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:d="default",failIfMajorPerformanceCaveat:u=!1}=e;this.isWebGLRenderer=!0;let h;i!==null?h=i.getContextAttributes().alpha:h=a;const m=new Uint32Array(4),_=new Int32Array(4);let x=null,p=null;const f=[],v=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=xt,this._useLegacyLights=!1,this.toneMapping=In,this.toneMappingExposure=1;const g=this;let y=!1,R=0,T=0,C=null,z=-1,M=null;const S=new ut,G=new ut;let I=null;const W=new $e(0);let L=0,U=t.width,B=t.height,X=1,K=null,ie=null;const ne=new ut(0,0,U,B),ue=new ut(0,0,U,B);let de=!1;const J=new Za;let se=!1,ge=!1,Ae=null;const we=new Qe,ke=new Oe,Ge=new N,Ie={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};function w(){return C===null?X:1}let b=i;function H(P,k){for(let Y=0;Y<P.length;Y++){const $=P[Y],q=t.getContext($,k);if(q!==null)return q}return null}try{const P={alpha:!0,depth:r,stencil:s,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:d,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${Wa}`),t.addEventListener("webglcontextlost",Z,!1),t.addEventListener("webglcontextrestored",D,!1),t.addEventListener("webglcontextcreationerror",he,!1),b===null){const k=["webgl2","webgl","experimental-webgl"];if(g.isWebGL1Renderer===!0&&k.shift(),b=H(k,P),b===null)throw H(k)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}typeof WebGLRenderingContext<"u"&&b instanceof WebGLRenderingContext&&console.warn("THREE.WebGLRenderer: WebGL 1 support was deprecated in r153 and will be removed in r163."),b.getShaderPrecisionFormat===void 0&&(b.getShaderPrecisionFormat=function(){return{rangeMin:1,rangeMax:1,precision:1}})}catch(P){throw console.error("THREE.WebGLRenderer: "+P.message),P}let F,ae,oe,ee,me,A,E,O,Q,j,te,ve,xe,ye,Ee,Ue,ce,Ke,qe,ze,Ce,Se,Ne,re;function le(){F=new L0(b),ae=new E0(b,F,e),F.init(ae),Se=new gm(b,F,ae),oe=new pm(b,F,ae),ee=new U0(b),me=new em,A=new mm(b,F,oe,me,ae,Se,ee),E=new A0(g),O=new P0(g),Q=new Gu(b,ae),Ne=new b0(b,F,Q,ae),j=new D0(b,Q,ee,Ne),te=new O0(b,j,Q,ee),qe=new F0(b,ae,A),Ue=new T0(me),ve=new Qp(g,E,O,F,ae,Ne,Ue),xe=new ym(g,me),ye=new nm,Ee=new lm(F,ae),Ke=new S0(g,E,O,oe,te,h,l),ce=new fm(g,te,ae),re=new Mm(b,ee,ae,oe),ze=new w0(b,F,ee,ae),Ce=new I0(b,F,ee,ae),ee.programs=ve.programs,g.capabilities=ae,g.extensions=F,g.properties=me,g.renderLists=ye,g.shadowMap=ce,g.state=oe,g.info=ee}le();const fe=new vm(g,b);this.xr=fe,this.getContext=function(){return b},this.getContextAttributes=function(){return b.getContextAttributes()},this.forceContextLoss=function(){const P=F.get("WEBGL_lose_context");P&&P.loseContext()},this.forceContextRestore=function(){const P=F.get("WEBGL_lose_context");P&&P.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(P){P!==void 0&&(X=P,this.setSize(U,B,!1))},this.getSize=function(P){return P.set(U,B)},this.setSize=function(P,k,Y=!0){if(fe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}U=P,B=k,t.width=Math.floor(P*X),t.height=Math.floor(k*X),Y===!0&&(t.style.width=P+"px",t.style.height=k+"px"),this.setViewport(0,0,P,k)},this.getDrawingBufferSize=function(P){return P.set(U*X,B*X).floor()},this.setDrawingBufferSize=function(P,k,Y){U=P,B=k,X=Y,t.width=Math.floor(P*Y),t.height=Math.floor(k*Y),this.setViewport(0,0,P,k)},this.getCurrentViewport=function(P){return P.copy(S)},this.getViewport=function(P){return P.copy(ne)},this.setViewport=function(P,k,Y,$){P.isVector4?ne.set(P.x,P.y,P.z,P.w):ne.set(P,k,Y,$),oe.viewport(S.copy(ne).multiplyScalar(X).floor())},this.getScissor=function(P){return P.copy(ue)},this.setScissor=function(P,k,Y,$){P.isVector4?ue.set(P.x,P.y,P.z,P.w):ue.set(P,k,Y,$),oe.scissor(G.copy(ue).multiplyScalar(X).floor())},this.getScissorTest=function(){return de},this.setScissorTest=function(P){oe.setScissorTest(de=P)},this.setOpaqueSort=function(P){K=P},this.setTransparentSort=function(P){ie=P},this.getClearColor=function(P){return P.copy(Ke.getClearColor())},this.setClearColor=function(){Ke.setClearColor.apply(Ke,arguments)},this.getClearAlpha=function(){return Ke.getClearAlpha()},this.setClearAlpha=function(){Ke.setClearAlpha.apply(Ke,arguments)},this.clear=function(P=!0,k=!0,Y=!0){let $=0;if(P){let q=!1;if(C!==null){const Me=C.texture.format;q=Me===fc||Me===dc||Me===uc}if(q){const Me=C.texture.type,Re=Me===Un||Me===Cn||Me===qa||Me===ei||Me===cc||Me===hc,De=Ke.getClearColor(),Fe=Ke.getClearAlpha(),je=De.r,He=De.g,We=De.b;Re?(m[0]=je,m[1]=He,m[2]=We,m[3]=Fe,b.clearBufferuiv(b.COLOR,0,m)):(_[0]=je,_[1]=He,_[2]=We,_[3]=Fe,b.clearBufferiv(b.COLOR,0,_))}else $|=b.COLOR_BUFFER_BIT}k&&($|=b.DEPTH_BUFFER_BIT),Y&&($|=b.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),b.clear($)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",Z,!1),t.removeEventListener("webglcontextrestored",D,!1),t.removeEventListener("webglcontextcreationerror",he,!1),ye.dispose(),Ee.dispose(),me.dispose(),E.dispose(),O.dispose(),te.dispose(),Ne.dispose(),re.dispose(),ve.dispose(),fe.dispose(),fe.removeEventListener("sessionstart",Ut),fe.removeEventListener("sessionend",ot),Ae&&(Ae.dispose(),Ae=null),zt.stop()};function Z(P){P.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),y=!0}function D(){console.log("THREE.WebGLRenderer: Context Restored."),y=!1;const P=ee.autoReset,k=ce.enabled,Y=ce.autoUpdate,$=ce.needsUpdate,q=ce.type;le(),ee.autoReset=P,ce.enabled=k,ce.autoUpdate=Y,ce.needsUpdate=$,ce.type=q}function he(P){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",P.statusMessage)}function pe(P){const k=P.target;k.removeEventListener("dispose",pe),Te(k)}function Te(P){Pe(P),me.remove(P)}function Pe(P){const k=me.get(P).programs;k!==void 0&&(k.forEach(function(Y){ve.releaseProgram(Y)}),P.isShaderMaterial&&ve.releaseShaderCache(P))}this.renderBufferDirect=function(P,k,Y,$,q,Me){k===null&&(k=Ie);const Re=q.isMesh&&q.matrixWorld.determinant()<0,De=dh(P,k,Y,$,q);oe.setMaterial($,Re);let Fe=Y.index,je=1;if($.wireframe===!0){if(Fe=j.getWireframeAttribute(Y),Fe===void 0)return;je=2}const He=Y.drawRange,We=Y.attributes.position;let gt=He.start*je,Ht=(He.start+He.count)*je;Me!==null&&(gt=Math.max(gt,Me.start*je),Ht=Math.min(Ht,(Me.start+Me.count)*je)),Fe!==null?(gt=Math.max(gt,0),Ht=Math.min(Ht,Fe.count)):We!=null&&(gt=Math.max(gt,0),Ht=Math.min(Ht,We.count));const wt=Ht-gt;if(wt<0||wt===1/0)return;Ne.setup(q,$,De,Y,Fe);let ln,dt=ze;if(Fe!==null&&(ln=Q.get(Fe),dt=Ce,dt.setIndex(ln)),q.isMesh)$.wireframe===!0?(oe.setLineWidth($.wireframeLinewidth*w()),dt.setMode(b.LINES)):dt.setMode(b.TRIANGLES);else if(q.isLine){let Ze=$.linewidth;Ze===void 0&&(Ze=1),oe.setLineWidth(Ze*w()),q.isLineSegments?dt.setMode(b.LINES):q.isLineLoop?dt.setMode(b.LINE_LOOP):dt.setMode(b.LINE_STRIP)}else q.isPoints?dt.setMode(b.POINTS):q.isSprite&&dt.setMode(b.TRIANGLES);if(q.isBatchedMesh)dt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else if(q.isInstancedMesh)dt.renderInstances(gt,wt,q.count);else if(Y.isInstancedBufferGeometry){const Ze=Y._maxInstanceCount!==void 0?Y._maxInstanceCount:1/0,Is=Math.min(Y.instanceCount,Ze);dt.renderInstances(gt,wt,Is)}else dt.render(gt,wt)};function st(P,k,Y){P.transparent===!0&&P.side===yt&&P.forceSinglePass===!1?(P.side=Bt,P.needsUpdate=!0,yr(P,k,Y),P.side=yn,P.needsUpdate=!0,yr(P,k,Y),P.side=yt):yr(P,k,Y)}this.compile=function(P,k,Y=null){Y===null&&(Y=P),p=Ee.get(Y),p.init(),v.push(p),Y.traverseVisible(function(q){q.isLight&&q.layers.test(k.layers)&&(p.pushLight(q),q.castShadow&&p.pushShadow(q))}),P!==Y&&P.traverseVisible(function(q){q.isLight&&q.layers.test(k.layers)&&(p.pushLight(q),q.castShadow&&p.pushShadow(q))}),p.setupLights(g._useLegacyLights);const $=new Set;return P.traverse(function(q){const Me=q.material;if(Me)if(Array.isArray(Me))for(let Re=0;Re<Me.length;Re++){const De=Me[Re];st(De,Y,q),$.add(De)}else st(Me,Y,q),$.add(Me)}),v.pop(),p=null,$},this.compileAsync=function(P,k,Y=null){const $=this.compile(P,k,Y);return new Promise(q=>{function Me(){if($.forEach(function(Re){me.get(Re).currentProgram.isReady()&&$.delete(Re)}),$.size===0){q(P);return}setTimeout(Me,10)}F.get("KHR_parallel_shader_compile")!==null?Me():setTimeout(Me,10)})};let at=null;function bt(P){at&&at(P)}function Ut(){zt.stop()}function ot(){zt.start()}const zt=new Rc;zt.setAnimationLoop(bt),typeof self<"u"&&zt.setContext(self),this.setAnimationLoop=function(P){at=P,fe.setAnimationLoop(P),P===null?zt.stop():zt.start()},fe.addEventListener("sessionstart",Ut),fe.addEventListener("sessionend",ot),this.render=function(P,k){if(k!==void 0&&k.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(y===!0)return;P.matrixWorldAutoUpdate===!0&&P.updateMatrixWorld(),k.parent===null&&k.matrixWorldAutoUpdate===!0&&k.updateMatrixWorld(),fe.enabled===!0&&fe.isPresenting===!0&&(fe.cameraAutoUpdate===!0&&fe.updateCamera(k),k=fe.getCamera()),P.isScene===!0&&P.onBeforeRender(g,P,k,C),p=Ee.get(P,v.length),p.init(),v.push(p),we.multiplyMatrices(k.projectionMatrix,k.matrixWorldInverse),J.setFromProjectionMatrix(we),ge=this.localClippingEnabled,se=Ue.init(this.clippingPlanes,ge),x=ye.get(P,f.length),x.init(),f.push(x),an(P,k,0,g.sortObjects),x.finish(),g.sortObjects===!0&&x.sort(K,ie),this.info.render.frame++,se===!0&&Ue.beginShadows();const Y=p.state.shadowsArray;if(ce.render(Y,P,k),se===!0&&Ue.endShadows(),this.info.autoReset===!0&&this.info.reset(),Ke.render(x,P),p.setupLights(g._useLegacyLights),k.isArrayCamera){const $=k.cameras;for(let q=0,Me=$.length;q<Me;q++){const Re=$[q];oo(x,P,Re,Re.viewport)}}else oo(x,P,k);C!==null&&(A.updateMultisampleRenderTarget(C),A.updateRenderTargetMipmap(C)),P.isScene===!0&&P.onAfterRender(g,P,k),Ne.resetDefaultState(),z=-1,M=null,v.pop(),v.length>0?p=v[v.length-1]:p=null,f.pop(),f.length>0?x=f[f.length-1]:x=null};function an(P,k,Y,$){if(P.visible===!1)return;if(P.layers.test(k.layers)){if(P.isGroup)Y=P.renderOrder;else if(P.isLOD)P.autoUpdate===!0&&P.update(k);else if(P.isLight)p.pushLight(P),P.castShadow&&p.pushShadow(P);else if(P.isSprite){if(!P.frustumCulled||J.intersectsSprite(P)){$&&Ge.setFromMatrixPosition(P.matrixWorld).applyMatrix4(we);const Re=te.update(P),De=P.material;De.visible&&x.push(P,Re,De,Y,Ge.z,null)}}else if((P.isMesh||P.isLine||P.isPoints)&&(!P.frustumCulled||J.intersectsObject(P))){const Re=te.update(P),De=P.material;if($&&(P.boundingSphere!==void 0?(P.boundingSphere===null&&P.computeBoundingSphere(),Ge.copy(P.boundingSphere.center)):(Re.boundingSphere===null&&Re.computeBoundingSphere(),Ge.copy(Re.boundingSphere.center)),Ge.applyMatrix4(P.matrixWorld).applyMatrix4(we)),Array.isArray(De)){const Fe=Re.groups;for(let je=0,He=Fe.length;je<He;je++){const We=Fe[je],gt=De[We.materialIndex];gt&&gt.visible&&x.push(P,Re,gt,Y,Ge.z,We)}}else De.visible&&x.push(P,Re,De,Y,Ge.z,null)}}const Me=P.children;for(let Re=0,De=Me.length;Re<De;Re++)an(Me[Re],k,Y,$)}function oo(P,k,Y,$){const q=P.opaque,Me=P.transmissive,Re=P.transparent;p.setupLightsView(Y),se===!0&&Ue.setGlobalState(g.clippingPlanes,Y),Me.length>0&&uh(q,Me,k,Y),$&&oe.viewport(S.copy($)),q.length>0&&vr(q,k,Y),Me.length>0&&vr(Me,k,Y),Re.length>0&&vr(Re,k,Y),oe.buffers.depth.setTest(!0),oe.buffers.depth.setMask(!0),oe.buffers.color.setMask(!0),oe.setPolygonOffset(!1)}function uh(P,k,Y,$){if((Y.isScene===!0?Y.overrideMaterial:null)!==null)return;const Me=ae.isWebGL2;Ae===null&&(Ae=new ri(1,1,{generateMipmaps:!0,type:F.has("EXT_color_buffer_half_float")?dr:Un,minFilter:ur,samples:Me?4:0})),g.getDrawingBufferSize(ke),Me?Ae.setSize(ke.x,ke.y):Ae.setSize(Da(ke.x),Da(ke.y));const Re=g.getRenderTarget();g.setRenderTarget(Ae),g.getClearColor(W),L=g.getClearAlpha(),L<1&&g.setClearColor(16777215,.5),g.clear();const De=g.toneMapping;g.toneMapping=In,vr(P,Y,$),A.updateMultisampleRenderTarget(Ae),A.updateRenderTargetMipmap(Ae);let Fe=!1;for(let je=0,He=k.length;je<He;je++){const We=k[je],gt=We.object,Ht=We.geometry,wt=We.material,ln=We.group;if(wt.side===yt&&gt.layers.test($.layers)){const dt=wt.side;wt.side=Bt,wt.needsUpdate=!0,lo(gt,Y,$,Ht,wt,ln),wt.side=dt,wt.needsUpdate=!0,Fe=!0}}Fe===!0&&(A.updateMultisampleRenderTarget(Ae),A.updateRenderTargetMipmap(Ae)),g.setRenderTarget(Re),g.setClearColor(W,L),g.toneMapping=De}function vr(P,k,Y){const $=k.isScene===!0?k.overrideMaterial:null;for(let q=0,Me=P.length;q<Me;q++){const Re=P[q],De=Re.object,Fe=Re.geometry,je=$===null?Re.material:$,He=Re.group;De.layers.test(Y.layers)&&lo(De,k,Y,Fe,je,He)}}function lo(P,k,Y,$,q,Me){P.onBeforeRender(g,k,Y,$,q,Me),P.modelViewMatrix.multiplyMatrices(Y.matrixWorldInverse,P.matrixWorld),P.normalMatrix.getNormalMatrix(P.modelViewMatrix),q.onBeforeRender(g,k,Y,$,P,Me),q.transparent===!0&&q.side===yt&&q.forceSinglePass===!1?(q.side=Bt,q.needsUpdate=!0,g.renderBufferDirect(Y,k,$,q,P,Me),q.side=yn,q.needsUpdate=!0,g.renderBufferDirect(Y,k,$,q,P,Me),q.side=yt):g.renderBufferDirect(Y,k,$,q,P,Me),P.onAfterRender(g,k,Y,$,q,Me)}function yr(P,k,Y){k.isScene!==!0&&(k=Ie);const $=me.get(P),q=p.state.lights,Me=p.state.shadowsArray,Re=q.state.version,De=ve.getParameters(P,q.state,Me,k,Y),Fe=ve.getProgramCacheKey(De);let je=$.programs;$.environment=P.isMeshStandardMaterial?k.environment:null,$.fog=k.fog,$.envMap=(P.isMeshStandardMaterial?O:E).get(P.envMap||$.environment),je===void 0&&(P.addEventListener("dispose",pe),je=new Map,$.programs=je);let He=je.get(Fe);if(He!==void 0){if($.currentProgram===He&&$.lightsStateVersion===Re)return ho(P,De),He}else De.uniforms=ve.getUniforms(P),P.onBuild(Y,De,g),P.onBeforeCompile(De,g),He=ve.acquireProgram(De,Fe),je.set(Fe,He),$.uniforms=De.uniforms;const We=$.uniforms;return(!P.isShaderMaterial&&!P.isRawShaderMaterial||P.clipping===!0)&&(We.clippingPlanes=Ue.uniform),ho(P,De),$.needsLights=ph(P),$.lightsStateVersion=Re,$.needsLights&&(We.ambientLightColor.value=q.state.ambient,We.lightProbe.value=q.state.probe,We.directionalLights.value=q.state.directional,We.directionalLightShadows.value=q.state.directionalShadow,We.spotLights.value=q.state.spot,We.spotLightShadows.value=q.state.spotShadow,We.rectAreaLights.value=q.state.rectArea,We.ltc_1.value=q.state.rectAreaLTC1,We.ltc_2.value=q.state.rectAreaLTC2,We.pointLights.value=q.state.point,We.pointLightShadows.value=q.state.pointShadow,We.hemisphereLights.value=q.state.hemi,We.directionalShadowMap.value=q.state.directionalShadowMap,We.directionalShadowMatrix.value=q.state.directionalShadowMatrix,We.spotShadowMap.value=q.state.spotShadowMap,We.spotLightMatrix.value=q.state.spotLightMatrix,We.spotLightMap.value=q.state.spotLightMap,We.pointShadowMap.value=q.state.pointShadowMap,We.pointShadowMatrix.value=q.state.pointShadowMatrix),$.currentProgram=He,$.uniformsList=null,He}function co(P){if(P.uniformsList===null){const k=P.currentProgram.getUniforms();P.uniformsList=Kr.seqWithValue(k.seq,P.uniforms)}return P.uniformsList}function ho(P,k){const Y=me.get(P);Y.outputColorSpace=k.outputColorSpace,Y.batching=k.batching,Y.instancing=k.instancing,Y.instancingColor=k.instancingColor,Y.skinning=k.skinning,Y.morphTargets=k.morphTargets,Y.morphNormals=k.morphNormals,Y.morphColors=k.morphColors,Y.morphTargetsCount=k.morphTargetsCount,Y.numClippingPlanes=k.numClippingPlanes,Y.numIntersection=k.numClipIntersection,Y.vertexAlphas=k.vertexAlphas,Y.vertexTangents=k.vertexTangents,Y.toneMapping=k.toneMapping}function dh(P,k,Y,$,q){k.isScene!==!0&&(k=Ie),A.resetTextureUnits();const Me=k.fog,Re=$.isMeshStandardMaterial?k.environment:null,De=C===null?g.outputColorSpace:C.isXRRenderTarget===!0?C.texture.colorSpace:Mn,Fe=($.isMeshStandardMaterial?O:E).get($.envMap||Re),je=$.vertexColors===!0&&!!Y.attributes.color&&Y.attributes.color.itemSize===4,He=!!Y.attributes.tangent&&(!!$.normalMap||$.anisotropy>0),We=!!Y.morphAttributes.position,gt=!!Y.morphAttributes.normal,Ht=!!Y.morphAttributes.color;let wt=In;$.toneMapped&&(C===null||C.isXRRenderTarget===!0)&&(wt=g.toneMapping);const ln=Y.morphAttributes.position||Y.morphAttributes.normal||Y.morphAttributes.color,dt=ln!==void 0?ln.length:0,Ze=me.get($),Is=p.state.lights;if(se===!0&&(ge===!0||P!==M)){const Yt=P===M&&$.id===z;Ue.setState($,P,Yt)}let mt=!1;$.version===Ze.__version?(Ze.needsLights&&Ze.lightsStateVersion!==Is.state.version||Ze.outputColorSpace!==De||q.isBatchedMesh&&Ze.batching===!1||!q.isBatchedMesh&&Ze.batching===!0||q.isInstancedMesh&&Ze.instancing===!1||!q.isInstancedMesh&&Ze.instancing===!0||q.isSkinnedMesh&&Ze.skinning===!1||!q.isSkinnedMesh&&Ze.skinning===!0||q.isInstancedMesh&&Ze.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ze.instancingColor===!1&&q.instanceColor!==null||Ze.envMap!==Fe||$.fog===!0&&Ze.fog!==Me||Ze.numClippingPlanes!==void 0&&(Ze.numClippingPlanes!==Ue.numPlanes||Ze.numIntersection!==Ue.numIntersection)||Ze.vertexAlphas!==je||Ze.vertexTangents!==He||Ze.morphTargets!==We||Ze.morphNormals!==gt||Ze.morphColors!==Ht||Ze.toneMapping!==wt||ae.isWebGL2===!0&&Ze.morphTargetsCount!==dt)&&(mt=!0):(mt=!0,Ze.__version=$.version);let On=Ze.currentProgram;mt===!0&&(On=yr($,k,q));let uo=!1,Ji=!1,Us=!1;const Tt=On.getUniforms(),kn=Ze.uniforms;if(oe.useProgram(On.program)&&(uo=!0,Ji=!0,Us=!0),$.id!==z&&(z=$.id,Ji=!0),uo||M!==P){Tt.setValue(b,"projectionMatrix",P.projectionMatrix),Tt.setValue(b,"viewMatrix",P.matrixWorldInverse);const Yt=Tt.map.cameraPosition;Yt!==void 0&&Yt.setValue(b,Ge.setFromMatrixPosition(P.matrixWorld)),ae.logarithmicDepthBuffer&&Tt.setValue(b,"logDepthBufFC",2/(Math.log(P.far+1)/Math.LN2)),($.isMeshPhongMaterial||$.isMeshToonMaterial||$.isMeshLambertMaterial||$.isMeshBasicMaterial||$.isMeshStandardMaterial||$.isShaderMaterial)&&Tt.setValue(b,"isOrthographic",P.isOrthographicCamera===!0),M!==P&&(M=P,Ji=!0,Us=!0)}if(q.isSkinnedMesh){Tt.setOptional(b,q,"bindMatrix"),Tt.setOptional(b,q,"bindMatrixInverse");const Yt=q.skeleton;Yt&&(ae.floatVertexTextures?(Yt.boneTexture===null&&Yt.computeBoneTexture(),Tt.setValue(b,"boneTexture",Yt.boneTexture,A)):console.warn("THREE.WebGLRenderer: SkinnedMesh can only be used with WebGL 2. With WebGL 1 OES_texture_float and vertex textures support is required."))}q.isBatchedMesh&&(Tt.setOptional(b,q,"batchingTexture"),Tt.setValue(b,"batchingTexture",q._matricesTexture,A));const zs=Y.morphAttributes;if((zs.position!==void 0||zs.normal!==void 0||zs.color!==void 0&&ae.isWebGL2===!0)&&qe.update(q,Y,On),(Ji||Ze.receiveShadow!==q.receiveShadow)&&(Ze.receiveShadow=q.receiveShadow,Tt.setValue(b,"receiveShadow",q.receiveShadow)),$.isMeshGouraudMaterial&&$.envMap!==null&&(kn.envMap.value=Fe,kn.flipEnvMap.value=Fe.isCubeTexture&&Fe.isRenderTargetTexture===!1?-1:1),Ji&&(Tt.setValue(b,"toneMappingExposure",g.toneMappingExposure),Ze.needsLights&&fh(kn,Us),Me&&$.fog===!0&&xe.refreshFogUniforms(kn,Me),xe.refreshMaterialUniforms(kn,$,X,B,Ae),Kr.upload(b,co(Ze),kn,A)),$.isShaderMaterial&&$.uniformsNeedUpdate===!0&&(Kr.upload(b,co(Ze),kn,A),$.uniformsNeedUpdate=!1),$.isSpriteMaterial&&Tt.setValue(b,"center",q.center),Tt.setValue(b,"modelViewMatrix",q.modelViewMatrix),Tt.setValue(b,"normalMatrix",q.normalMatrix),Tt.setValue(b,"modelMatrix",q.matrixWorld),$.isShaderMaterial||$.isRawShaderMaterial){const Yt=$.uniformsGroups;for(let Ns=0,mh=Yt.length;Ns<mh;Ns++)if(ae.isWebGL2){const fo=Yt[Ns];re.update(fo,On),re.bind(fo,On)}else console.warn("THREE.WebGLRenderer: Uniform Buffer Objects can only be used with WebGL 2.")}return On}function fh(P,k){P.ambientLightColor.needsUpdate=k,P.lightProbe.needsUpdate=k,P.directionalLights.needsUpdate=k,P.directionalLightShadows.needsUpdate=k,P.pointLights.needsUpdate=k,P.pointLightShadows.needsUpdate=k,P.spotLights.needsUpdate=k,P.spotLightShadows.needsUpdate=k,P.rectAreaLights.needsUpdate=k,P.hemisphereLights.needsUpdate=k}function ph(P){return P.isMeshLambertMaterial||P.isMeshToonMaterial||P.isMeshPhongMaterial||P.isMeshStandardMaterial||P.isShadowMaterial||P.isShaderMaterial&&P.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return T},this.getRenderTarget=function(){return C},this.setRenderTargetTextures=function(P,k,Y){me.get(P.texture).__webglTexture=k,me.get(P.depthTexture).__webglTexture=Y;const $=me.get(P);$.__hasExternalTextures=!0,$.__hasExternalTextures&&($.__autoAllocateDepthBuffer=Y===void 0,$.__autoAllocateDepthBuffer||F.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),$.__useRenderToTexture=!1))},this.setRenderTargetFramebuffer=function(P,k){const Y=me.get(P);Y.__webglFramebuffer=k,Y.__useDefaultFramebuffer=k===void 0},this.setRenderTarget=function(P,k=0,Y=0){C=P,R=k,T=Y;let $=!0,q=null,Me=!1,Re=!1;if(P){const Fe=me.get(P);Fe.__useDefaultFramebuffer!==void 0?(oe.bindFramebuffer(b.FRAMEBUFFER,null),$=!1):Fe.__webglFramebuffer===void 0?A.setupRenderTarget(P):Fe.__hasExternalTextures&&A.rebindTextures(P,me.get(P.texture).__webglTexture,me.get(P.depthTexture).__webglTexture);const je=P.texture;(je.isData3DTexture||je.isDataArrayTexture||je.isCompressedArrayTexture)&&(Re=!0);const He=me.get(P).__webglFramebuffer;P.isWebGLCubeRenderTarget?(Array.isArray(He[k])?q=He[k][Y]:q=He[k],Me=!0):ae.isWebGL2&&P.samples>0&&A.useMultisampledRTT(P)===!1?q=me.get(P).__webglMultisampledFramebuffer:Array.isArray(He)?q=He[Y]:q=He,S.copy(P.viewport),G.copy(P.scissor),I=P.scissorTest}else S.copy(ne).multiplyScalar(X).floor(),G.copy(ue).multiplyScalar(X).floor(),I=de;if(oe.bindFramebuffer(b.FRAMEBUFFER,q)&&ae.drawBuffers&&$&&oe.drawBuffers(P,q),oe.viewport(S),oe.scissor(G),oe.setScissorTest(I),Me){const Fe=me.get(P.texture);b.framebufferTexture2D(b.FRAMEBUFFER,b.COLOR_ATTACHMENT0,b.TEXTURE_CUBE_MAP_POSITIVE_X+k,Fe.__webglTexture,Y)}else if(Re){const Fe=me.get(P.texture),je=k||0;b.framebufferTextureLayer(b.FRAMEBUFFER,b.COLOR_ATTACHMENT0,Fe.__webglTexture,Y||0,je)}z=-1},this.readRenderTargetPixels=function(P,k,Y,$,q,Me,Re){if(!(P&&P.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let De=me.get(P).__webglFramebuffer;if(P.isWebGLCubeRenderTarget&&Re!==void 0&&(De=De[Re]),De){oe.bindFramebuffer(b.FRAMEBUFFER,De);try{const Fe=P.texture,je=Fe.format,He=Fe.type;if(je!==sn&&Se.convert(je)!==b.getParameter(b.IMPLEMENTATION_COLOR_READ_FORMAT)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}const We=He===dr&&(F.has("EXT_color_buffer_half_float")||ae.isWebGL2&&F.has("EXT_color_buffer_float"));if(He!==Un&&Se.convert(He)!==b.getParameter(b.IMPLEMENTATION_COLOR_READ_TYPE)&&!(He===Pn&&(ae.isWebGL2||F.has("OES_texture_float")||F.has("WEBGL_color_buffer_float")))&&!We){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}k>=0&&k<=P.width-$&&Y>=0&&Y<=P.height-q&&b.readPixels(k,Y,$,q,Se.convert(je),Se.convert(He),Me)}finally{const Fe=C!==null?me.get(C).__webglFramebuffer:null;oe.bindFramebuffer(b.FRAMEBUFFER,Fe)}}},this.copyFramebufferToTexture=function(P,k,Y=0){const $=Math.pow(2,-Y),q=Math.floor(k.image.width*$),Me=Math.floor(k.image.height*$);A.setTexture2D(k,0),b.copyTexSubImage2D(b.TEXTURE_2D,Y,0,0,P.x,P.y,q,Me),oe.unbindTexture()},this.copyTextureToTexture=function(P,k,Y,$=0){const q=k.image.width,Me=k.image.height,Re=Se.convert(Y.format),De=Se.convert(Y.type);A.setTexture2D(Y,0),b.pixelStorei(b.UNPACK_FLIP_Y_WEBGL,Y.flipY),b.pixelStorei(b.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),b.pixelStorei(b.UNPACK_ALIGNMENT,Y.unpackAlignment),k.isDataTexture?b.texSubImage2D(b.TEXTURE_2D,$,P.x,P.y,q,Me,Re,De,k.image.data):k.isCompressedTexture?b.compressedTexSubImage2D(b.TEXTURE_2D,$,P.x,P.y,k.mipmaps[0].width,k.mipmaps[0].height,Re,k.mipmaps[0].data):b.texSubImage2D(b.TEXTURE_2D,$,P.x,P.y,Re,De,k.image),$===0&&Y.generateMipmaps&&b.generateMipmap(b.TEXTURE_2D),oe.unbindTexture()},this.copyTextureToTexture3D=function(P,k,Y,$,q=0){if(g.isWebGL1Renderer){console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: can only be used with WebGL2.");return}const Me=P.max.x-P.min.x+1,Re=P.max.y-P.min.y+1,De=P.max.z-P.min.z+1,Fe=Se.convert($.format),je=Se.convert($.type);let He;if($.isData3DTexture)A.setTexture3D($,0),He=b.TEXTURE_3D;else if($.isDataArrayTexture||$.isCompressedArrayTexture)A.setTexture2DArray($,0),He=b.TEXTURE_2D_ARRAY;else{console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");return}b.pixelStorei(b.UNPACK_FLIP_Y_WEBGL,$.flipY),b.pixelStorei(b.UNPACK_PREMULTIPLY_ALPHA_WEBGL,$.premultiplyAlpha),b.pixelStorei(b.UNPACK_ALIGNMENT,$.unpackAlignment);const We=b.getParameter(b.UNPACK_ROW_LENGTH),gt=b.getParameter(b.UNPACK_IMAGE_HEIGHT),Ht=b.getParameter(b.UNPACK_SKIP_PIXELS),wt=b.getParameter(b.UNPACK_SKIP_ROWS),ln=b.getParameter(b.UNPACK_SKIP_IMAGES),dt=Y.isCompressedTexture?Y.mipmaps[q]:Y.image;b.pixelStorei(b.UNPACK_ROW_LENGTH,dt.width),b.pixelStorei(b.UNPACK_IMAGE_HEIGHT,dt.height),b.pixelStorei(b.UNPACK_SKIP_PIXELS,P.min.x),b.pixelStorei(b.UNPACK_SKIP_ROWS,P.min.y),b.pixelStorei(b.UNPACK_SKIP_IMAGES,P.min.z),Y.isDataTexture||Y.isData3DTexture?b.texSubImage3D(He,q,k.x,k.y,k.z,Me,Re,De,Fe,je,dt.data):Y.isCompressedArrayTexture?(console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: untested support for compressed srcTexture."),b.compressedTexSubImage3D(He,q,k.x,k.y,k.z,Me,Re,De,Fe,dt.data)):b.texSubImage3D(He,q,k.x,k.y,k.z,Me,Re,De,Fe,je,dt),b.pixelStorei(b.UNPACK_ROW_LENGTH,We),b.pixelStorei(b.UNPACK_IMAGE_HEIGHT,gt),b.pixelStorei(b.UNPACK_SKIP_PIXELS,Ht),b.pixelStorei(b.UNPACK_SKIP_ROWS,wt),b.pixelStorei(b.UNPACK_SKIP_IMAGES,ln),q===0&&$.generateMipmaps&&b.generateMipmap(He),oe.unbindTexture()},this.initTexture=function(P){P.isCubeTexture?A.setTextureCube(P,0):P.isData3DTexture?A.setTexture3D(P,0):P.isDataArrayTexture||P.isCompressedArrayTexture?A.setTexture2DArray(P,0):A.setTexture2D(P,0),oe.unbindTexture()},this.resetState=function(){R=0,T=0,C=null,oe.reset(),Ne.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return xn}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorSpace=e===Ya?"display-p3":"srgb",t.unpackColorSpace=tt.workingColorSpace===vs?"display-p3":"srgb"}get outputEncoding(){return console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace===xt?ni:mc}set outputEncoding(e){console.warn("THREE.WebGLRenderer: Property .outputEncoding has been removed. Use .outputColorSpace instead."),this.outputColorSpace=e===ni?xt:Mn}get useLegacyLights(){return console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights}set useLegacyLights(e){console.warn("THREE.WebGLRenderer: The property .useLegacyLights has been deprecated. Migrate your lighting according to the following guide: https://discourse.threejs.org/t/updates-to-lighting-in-three-js-r155/53733."),this._useLegacyLights=e}}class Sm extends Ja{}Sm.prototype.isWebGL1Renderer=!0;class Qa{constructor(e,t=1,i=1e3){this.isFog=!0,this.name="",this.color=new $e(e),this.near=t,this.far=i}clone(){return new Qa(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class zc extends pt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t}}class bm{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Ca,this._updateRange={offset:0,count:-1},this.updateRanges=[],this.version=0,this.uuid=zn()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}get updateRange(){return console.warn("THREE.InterleavedBuffer: updateRange() is deprecated and will be removed in r169. Use addUpdateRange() instead."),this._updateRange}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let r=0,s=this.stride;r<s;r++)this.array[e+r]=t.array[i+r];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=zn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=zn()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const Nt=new N;class ls{constructor(e,t,i,r=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=r}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)Nt.fromBufferAttribute(this,t),Nt.applyMatrix4(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)Nt.fromBufferAttribute(this,t),Nt.applyNormalMatrix(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)Nt.fromBufferAttribute(this,t),Nt.transformDirection(e),this.setXYZ(t,Nt.x,Nt.y,Nt.z);return this}setX(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=nt(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=gn(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=gn(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=gn(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=gn(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),r=nt(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this}setXYZW(e,t,i,r,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=nt(t,this.array),i=nt(i,this.array),r=nt(r,this.array),s=nt(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=r,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return new Qt(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new ls(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let i=0;i<this.count;i++){const r=i*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[r+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class eo extends $i{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new $e(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let wi;const ir=new N,Ei=new N,Ti=new N,Ai=new Oe,rr=new Oe,Nc=new Qe,Vr=new N,sr=new N,Wr=new N,Il=new Oe,pa=new Oe,Ul=new Oe;class Fc extends pt{constructor(e=new eo){if(super(),this.isSprite=!0,this.type="Sprite",wi===void 0){wi=new rt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new bm(t,5);wi.setIndex([0,1,2,0,2,3]),wi.setAttribute("position",new ls(i,3,0,!1)),wi.setAttribute("uv",new ls(i,2,3,!1))}this.geometry=wi,this.material=e,this.center=new Oe(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ei.setFromMatrixScale(this.matrixWorld),Nc.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Ti.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ei.multiplyScalar(-Ti.z);const i=this.material.rotation;let r,s;i!==0&&(s=Math.cos(i),r=Math.sin(i));const a=this.center;Xr(Vr.set(-.5,-.5,0),Ti,a,Ei,r,s),Xr(sr.set(.5,-.5,0),Ti,a,Ei,r,s),Xr(Wr.set(.5,.5,0),Ti,a,Ei,r,s),Il.set(0,0),pa.set(1,0),Ul.set(1,1);let o=e.ray.intersectTriangle(Vr,sr,Wr,!1,ir);if(o===null&&(Xr(sr.set(-.5,.5,0),Ti,a,Ei,r,s),pa.set(0,1),o=e.ray.intersectTriangle(Vr,Wr,sr,!1,ir),o===null))return;const l=e.ray.origin.distanceTo(ir);l<e.near||l>e.far||t.push({distance:l,point:ir.clone(),uv:Kt.getInterpolation(ir,Vr,sr,Wr,Il,pa,Ul,new Oe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function Xr(n,e,t,i,r,s){Ai.subVectors(n,t).addScalar(.5).multiply(i),r!==void 0?(rr.x=s*Ai.x-r*Ai.y,rr.y=r*Ai.x+s*Ai.y):rr.copy(Ai),n.copy(e),n.x+=rr.x,n.y+=rr.y,n.applyMatrix4(Nc)}class zl extends Qt{constructor(e,t,i,r=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){const e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}}const Ri=new Qe,Nl=new Qe,qr=[],Fl=new Sn,wm=new Qe,ar=new Le,or=new xr;class cs extends Le{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new zl(new Float32Array(i*16),16),this.instanceColor=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let r=0;r<i;r++)this.setMatrixAt(r,wm)}computeBoundingBox(){const e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Sn),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Ri),Fl.copy(e.boundingBox).applyMatrix4(Ri),this.boundingBox.union(Fl)}computeBoundingSphere(){const e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new xr),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Ri),or.copy(e.boundingSphere).applyMatrix4(Ri),this.boundingSphere.union(or)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,e*16)}raycast(e,t){const i=this.matrixWorld,r=this.count;if(ar.geometry=this.geometry,ar.material=this.material,ar.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),or.copy(this.boundingSphere),or.applyMatrix4(i),e.ray.intersectsSphere(or)!==!1))for(let s=0;s<r;s++){this.getMatrixAt(s,Ri),Nl.multiplyMatrices(i,Ri),ar.matrixWorld=Nl,ar.raycast(e,qr);for(let a=0,o=qr.length;a<o;a++){const l=qr[a];l.instanceId=s,l.object=this,t.push(l)}qr.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new zl(new Float32Array(this.instanceMatrix.count*3),3)),t.toArray(this.instanceColor.array,e*3)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,e*16)}updateMorphTargets(){}dispose(){this.dispatchEvent({type:"dispose"})}}class fr extends Gt{constructor(e,t,i,r,s,a,o,l,c){super(e,t,i,r,s,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class to extends rt{constructor(e=1,t=32,i=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:r},t=Math.max(3,t);const s=[],a=[],o=[],l=[],c=new N,d=new Oe;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let u=0,h=3;u<=t;u++,h+=3){const m=i+u/t*r;c.x=e*Math.cos(m),c.y=e*Math.sin(m),a.push(c.x,c.y,c.z),o.push(0,0,1),d.x=(a[h]/e+1)/2,d.y=(a[h+1]/e+1)/2,l.push(d.x,d.y)}for(let u=1;u<=t;u++)s.push(u,u+1,0);this.setIndex(s),this.setAttribute("position",new Ve(a,3)),this.setAttribute("normal",new Ve(o,3)),this.setAttribute("uv",new Ve(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new to(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class no extends rt{constructor(e=1,t=1,i=1,r=32,s=1,a=!1,o=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:r,heightSegments:s,openEnded:a,thetaStart:o,thetaLength:l};const c=this;r=Math.floor(r),s=Math.floor(s);const d=[],u=[],h=[],m=[];let _=0;const x=[],p=i/2;let f=0;v(),a===!1&&(e>0&&g(!0),t>0&&g(!1)),this.setIndex(d),this.setAttribute("position",new Ve(u,3)),this.setAttribute("normal",new Ve(h,3)),this.setAttribute("uv",new Ve(m,2));function v(){const y=new N,R=new N;let T=0;const C=(t-e)/i;for(let z=0;z<=s;z++){const M=[],S=z/s,G=S*(t-e)+e;for(let I=0;I<=r;I++){const W=I/r,L=W*l+o,U=Math.sin(L),B=Math.cos(L);R.x=G*U,R.y=-S*i+p,R.z=G*B,u.push(R.x,R.y,R.z),y.set(U,C,B).normalize(),h.push(y.x,y.y,y.z),m.push(W,1-S),M.push(_++)}x.push(M)}for(let z=0;z<r;z++)for(let M=0;M<s;M++){const S=x[M][z],G=x[M+1][z],I=x[M+1][z+1],W=x[M][z+1];d.push(S,G,W),d.push(G,I,W),T+=6}c.addGroup(f,T,0),f+=T}function g(y){const R=_,T=new Oe,C=new N;let z=0;const M=y===!0?e:t,S=y===!0?1:-1;for(let I=1;I<=r;I++)u.push(0,p*S,0),h.push(0,S,0),m.push(.5,.5),_++;const G=_;for(let I=0;I<=r;I++){const L=I/r*l+o,U=Math.cos(L),B=Math.sin(L);C.x=M*B,C.y=p*S,C.z=M*U,u.push(C.x,C.y,C.z),h.push(0,S,0),T.x=U*.5+.5,T.y=B*.5*S+.5,m.push(T.x,T.y),_++}for(let I=0;I<r;I++){const W=R+I,L=G+I;y===!0?d.push(L,L+1,W):d.push(L+1,L,W),z+=3}c.addGroup(f,z,y===!0?1:2),f+=z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new no(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class pr extends no{constructor(e=1,t=1,i=32,r=1,s=!1,a=0,o=Math.PI*2){super(0,e,t,i,r,s,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:r,openEnded:s,thetaStart:a,thetaLength:o}}static fromJSON(e){return new pr(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class io extends rt{constructor(e=[],t=[],i=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:r};const s=[],a=[];o(r),c(i),d(),this.setAttribute("position",new Ve(s,3)),this.setAttribute("normal",new Ve(s.slice(),3)),this.setAttribute("uv",new Ve(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(v){const g=new N,y=new N,R=new N;for(let T=0;T<t.length;T+=3)m(t[T+0],g),m(t[T+1],y),m(t[T+2],R),l(g,y,R,v)}function l(v,g,y,R){const T=R+1,C=[];for(let z=0;z<=T;z++){C[z]=[];const M=v.clone().lerp(y,z/T),S=g.clone().lerp(y,z/T),G=T-z;for(let I=0;I<=G;I++)I===0&&z===T?C[z][I]=M:C[z][I]=M.clone().lerp(S,I/G)}for(let z=0;z<T;z++)for(let M=0;M<2*(T-z)-1;M++){const S=Math.floor(M/2);M%2===0?(h(C[z][S+1]),h(C[z+1][S]),h(C[z][S])):(h(C[z][S+1]),h(C[z+1][S+1]),h(C[z+1][S]))}}function c(v){const g=new N;for(let y=0;y<s.length;y+=3)g.x=s[y+0],g.y=s[y+1],g.z=s[y+2],g.normalize().multiplyScalar(v),s[y+0]=g.x,s[y+1]=g.y,s[y+2]=g.z}function d(){const v=new N;for(let g=0;g<s.length;g+=3){v.x=s[g+0],v.y=s[g+1],v.z=s[g+2];const y=p(v)/2/Math.PI+.5,R=f(v)/Math.PI+.5;a.push(y,1-R)}_(),u()}function u(){for(let v=0;v<a.length;v+=6){const g=a[v+0],y=a[v+2],R=a[v+4],T=Math.max(g,y,R),C=Math.min(g,y,R);T>.9&&C<.1&&(g<.2&&(a[v+0]+=1),y<.2&&(a[v+2]+=1),R<.2&&(a[v+4]+=1))}}function h(v){s.push(v.x,v.y,v.z)}function m(v,g){const y=v*3;g.x=e[y+0],g.y=e[y+1],g.z=e[y+2]}function _(){const v=new N,g=new N,y=new N,R=new N,T=new Oe,C=new Oe,z=new Oe;for(let M=0,S=0;M<s.length;M+=9,S+=6){v.set(s[M+0],s[M+1],s[M+2]),g.set(s[M+3],s[M+4],s[M+5]),y.set(s[M+6],s[M+7],s[M+8]),T.set(a[S+0],a[S+1]),C.set(a[S+2],a[S+3]),z.set(a[S+4],a[S+5]),R.copy(v).add(g).add(y).divideScalar(3);const G=p(R);x(T,S+0,v,G),x(C,S+2,g,G),x(z,S+4,y,G)}}function x(v,g,y,R){R<0&&v.x===1&&(a[g]=v.x-1),y.x===0&&y.z===0&&(a[g]=R/2/Math.PI+.5)}function p(v){return Math.atan2(v.z,-v.x)}function f(v){return Math.atan2(-v.y,Math.sqrt(v.x*v.x+v.z*v.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new io(e.vertices,e.indices,e.radius,e.details)}}class mr extends io{constructor(e=1,t=0){const i=(1+Math.sqrt(5))/2,r=[-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new mr(e.radius,e.detail)}}class Ss extends rt{constructor(e=1,t=32,i=16,r=0,s=Math.PI*2,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:r,phiLength:s,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));const l=Math.min(a+o,Math.PI);let c=0;const d=[],u=new N,h=new N,m=[],_=[],x=[],p=[];for(let f=0;f<=i;f++){const v=[],g=f/i;let y=0;f===0&&a===0?y=.5/t:f===i&&l===Math.PI&&(y=-.5/t);for(let R=0;R<=t;R++){const T=R/t;u.x=-e*Math.cos(r+T*s)*Math.sin(a+g*o),u.y=e*Math.cos(a+g*o),u.z=e*Math.sin(r+T*s)*Math.sin(a+g*o),_.push(u.x,u.y,u.z),h.copy(u).normalize(),x.push(h.x,h.y,h.z),p.push(T+y,1-g),v.push(c++)}d.push(v)}for(let f=0;f<i;f++)for(let v=0;v<t;v++){const g=d[f][v+1],y=d[f][v],R=d[f+1][v],T=d[f+1][v+1];(f!==0||a>0)&&m.push(g,y,T),(f!==i-1||l<Math.PI)&&m.push(y,R,T)}this.setIndex(m),this.setAttribute("position",new Ve(_,3)),this.setAttribute("normal",new Ve(x,3)),this.setAttribute("uv",new Ve(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ss(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class It extends $i{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new $e(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new $e(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=gc,this.normalScale=new Oe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.combine=Xa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class ro extends pt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new $e(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),t}}class Oc extends ro{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(pt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new $e(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const ma=new Qe,Ol=new N,kl=new N;class kc{constructor(e){this.camera=e,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Oe(512,512),this.map=null,this.mapPass=null,this.matrix=new Qe,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Za,this._frameExtents=new Oe(1,1),this._viewportCount=1,this._viewports=[new ut(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,i=this.matrix;Ol.setFromMatrixPosition(e.matrixWorld),t.position.copy(Ol),kl.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(kl),t.updateMatrixWorld(),ma.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ma),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(ma)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Bl=new Qe,lr=new N,ga=new N;class Em extends kc{constructor(){super(new qt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new Oe(4,2),this._viewportCount=6,this._viewports=[new ut(2,1,1,1),new ut(0,1,1,1),new ut(3,1,1,1),new ut(1,1,1,1),new ut(3,0,1,1),new ut(1,0,1,1)],this._cubeDirections=[new N(1,0,0),new N(-1,0,0),new N(0,0,1),new N(0,0,-1),new N(0,1,0),new N(0,-1,0)],this._cubeUps=[new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,1,0),new N(0,0,1),new N(0,0,-1)]}updateMatrices(e,t=0){const i=this.camera,r=this.matrix,s=e.distance||i.far;s!==i.far&&(i.far=s,i.updateProjectionMatrix()),lr.setFromMatrixPosition(e.matrixWorld),i.position.copy(lr),ga.copy(i.position),ga.add(this._cubeDirections[t]),i.up.copy(this._cubeUps[t]),i.lookAt(ga),i.updateMatrixWorld(),r.makeTranslation(-lr.x,-lr.y,-lr.z),Bl.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Bl)}}class Tm extends ro{constructor(e,t,i=0,r=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=r,this.shadow=new Em}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Am extends kc{constructor(){super(new $a(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Bc extends ro{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(pt.DEFAULT_UP),this.updateMatrix(),this.target=new pt,this.shadow=new Am}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Rm{constructor(e,t,i=0,r=1/0){this.ray=new _r(e,t),this.near=i,this.far=r,this.camera=null,this.layers=new ja,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}intersectObject(e,t=!0,i=[]){return Ua(e,this,i,t),i.sort(Gl),i}intersectObjects(e,t=!0,i=[]){for(let r=0,s=e.length;r<s;r++)Ua(e[r],this,i,t);return i.sort(Gl),i}}function Gl(n,e){return n.distance-e.distance}function Ua(n,e,t,i){if(n.layers.test(e.layers)&&n.raycast(e,t),i===!0){const r=n.children;for(let s=0,a=r.length;s<a;s++)Ua(r[s],e,t,!0)}}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Wa}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Wa);const Gc={flowers:[[.5,.16,.5,.6,.32,.6,11827792],[.5,.48,.5,.06,.64,.06,5671001],[.5,.78,.5,.46,.18,.46,14523267],[.5,.89,.5,.18,.06,.18,16110715]],lantern:[[.5,.06,.5,.55,.12,.55,6255726],[.5,.46,.5,.4,.7,.4,16174707],[.5,.87,.5,.6,.12,.6,6255726],...[.27,.73].flatMap(n=>[.27,.73].map(e=>[n,.46,e,.06,.75,.06,6255726]))],bench:[[.5,.47,.5,.94,.12,.64,11369552],[.5,.77,.77,.94,.4,.1,11369552],...[.12,.88].flatMap(n=>[.25,.72].map(e=>[n,.22,e,.1,.44,.1,6714986]))]},Fn=[],hs=[],za=[15851437,15185051,12177332,14728124,14268559,11914194],Hc=[4488320,11365457,7042704,7108992];function bs(n,e,t,i,r){e.forEach((s,a)=>{const o=t+i*16,l=i<0?0:Math.PI;if(r.includes(a))hs.push({id:`${n}-lot-${a}`,x:s,z:o,w:17,d:16,angle:l,street:n,roadZ:t,subtle:!0});else{const c=n==="north"?[1,5].includes(a)&&i<0:[2,5].includes(a)&&i>0;Fn.push({id:`${n}-${i<0?"n":"s"}-${a}`,name:`${n==="north"?"Linden":"Willow"} ${c?"family home":"cottage"} ${a+1}`,x:s,z:o,w:c?12:8+a%3,d:c?12:8+a%2*2,angle:l,wall:za[(a+(i+1)*2)%za.length],roof:Hc[(a+(i+1))%4],style:c?"gable":["hip","gable","shed"][a%3],storeys:c?2:1,rooms:c||a%3===0,designed:!0,garden:0,garage:a%4===0,street:n})}})}bs("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,-1,[2,6]);bs("north",[-96,-74,-52,-30,-8,14,36,58,80],-143,1,[1,5,8]);bs("south",[-90,-66,-42,-18,6,30,54,78],128,-1,[0,3,6]);bs("south",[-90,-66,-42,-18,6,30,54,78],128,1,[1,4]);Fn.push({id:"linden-library",name:"Linden library",x:60,z:-195,w:12,d:12,angle:Math.PI,route:"trail",wall:15851437,roof:4488320,style:"hip",shop:!0,sign:"LIBRARY",rooms:!0,designed:!0},{id:"willow-workshop",name:"Willow motor workshop",x:-109,z:110,w:12,d:12,angle:0,street:"south",wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,designed:!0},{id:"manor",name:"Magnolia manor",x:103,z:16,w:22,d:18,angle:-Math.PI/2,route:"trail",wall:15851437,roof:7042704,style:"hip",storeys:2,rooms:!0,designed:!0,porch:5},{id:"garden-cafe",name:"Garden cafe",x:112,z:-26,w:10,d:9,angle:Math.PI,wall:14728124,roof:11365457,style:"gable",shop:!0,sign:"GARDEN CAFE",designed:!0});const Na=[[[-108,-143],[-64,-143],[-8,-143],[54,-143],[118,-143]],[[-112,128],[-66,128],[-6,128],[60,128],[119,128]],[[72,-28],[81,-16],[83,14],[83,39],[104,42]]];for(const[n,e]of[-28,-52,-76,-100,-122].entries())Fn.push({id:`elm-${n}`,name:`Elm lane ${n===2?"family house":"cottage"}`,x:-121,z:e,w:n===2?12:9,d:n===2?12:9,angle:-Math.PI/2,wall:za[n%6],roof:Hc[n%4],style:n%2?"hip":"gable",storeys:n===2?2:1,rooms:!0,designed:!0,street:"elm"});hs.push({id:"elm-lot",x:-150,z:-98,w:12,d:14,angle:Math.PI/2,street:"elm",roadX:-137,subtle:!0});Na.push([[-137,-132],[-137,-90],[-137,-45],[-137,-9],[-146,10]]);const Cm=[[[73,62],[80,66]],[[80,52],[84,52]],[[53,25],[53,36],[53,56],[65,62],[73,56],[80,52]],[[53,36],[61,34],[76,34],[80,41],[80,52]],[[65,62],[65,45]],[[197,98],[185,96],[181,82],[185,69],[197,65],[208,72],[210,86],[206,96],[197,98]],[[185,96],[197,84],[208,72]]],Vc=[{id:"linden",name:"Linden street",icon:"⌂",x:-30,z:-143,color:"#b7a48a",signX:-113,signZ:-150},{id:"willow-street",name:"Willow street",icon:"⌂",x:-18,z:128,color:"#aebf90",signX:-118,signZ:136},{id:"manor",name:"Magnolia manor",icon:"♜",x:103,z:16,color:"#cfbc97",signX:88,signZ:29}],Pm=Fn.findIndex(n=>n.id==="north-n-0");Fn.splice(Pm,1);for(const n of["north-n-1","north-n-8"])Fn.find(e=>e.id===n).z=-154;Fn.find(n=>n.id==="south-s-0").x=-86;const ht=(n,e,t,i,r,s,a,o,l,c,d={})=>({id:n,name:e,x:t,z:i,w:r,d:s,angle:a,style:o,wall:l,roof:c,...d}),Ci=0,Wn=Math.PI,Yr=Math.PI/2,Xn=-Math.PI/2,Lm=[ht("juniper","Juniper veranda",-160,-45,12,10,Xn,"hip",12177332,11365457,{porch:4.4,carport:!0,garden:2,bay:!0}),ht("birch","Birch twin cottage",-212,-40,8,11,Yr,"gable",15851437,7042704,{wing:!0,garden:3,chimney:!0}),ht("copper","Copper longhouse",-161,-80,7,12,Xn,"shed",14268559,4488320,{porch:4,garden:1,bay:!0}),ht("lavender","Lavender bungalow",-215,5,10,8,Yr,"hip",14728124,7108992,{garage:!0,garden:2}),ht("acacia","Acacia courtyard",-213,47,14,9,Yr,"gable",15185051,4488320,{wing:!0,porch:4.6,garden:3}),ht("riverside","Riverside home",-151,45,9,9,Xn,"hip",11914194,11365457,{carport:!0,garden:1,bay:!0}),ht("north-house","North garden house",-42,-214,12,10,Ci,"hip",14728124,7042704,{wing:!0,garden:3}),ht("north-bakery","Sunbeam bakery",-18,-214,9,8,Ci,"gable",15851437,11365457,{shop:!0,sign:"SUNBEAM",approach:{x:-18,z:-202},chimney:!0}),ht("north-hall","North village hall",7,-214,14,10,Ci,"gable",12177332,4488320,{shop:!0,sign:"VILLAGE HALL",approach:{x:7,z:-202},porch:4.2}),ht("north-clock","Clockmaker house",35,-214,8,8,Ci,"hip",14268559,7108992,{tower:!0,porch:3.2,garden:2}),ht("weavers","Weavers studio",202,-132,9,10,Xn,"shed",14728124,7042704,{shop:!0,sign:"WEAVERS",bay:!0}),ht("clay-yard","Clay courtyard",206,-103,12,8,Xn,"hip",15185051,4488320,{shop:!0,sign:"CLAY YARD",wing:!0}),ht("makers","Makers long workshop",205,-75,8,14,Xn,"gable",14268559,11365457,{shop:!0,sign:"MAKERS",carport:!0,chimney:!0}),ht("greenhouse","Garden potting house",207,-45,7,7,Xn,"gable",12177332,4488320,{porch:3.4,garden:3,bay:!0}),ht("lake-house","Lakeview veranda",213,4,10,9,Ci,"shed",11914194,7108992,{route:"trail",porch:4.6,garden:2,bay:!0}),ht("east-house","Eastern carport house",212,109,14,8,Wn,"hip",15851437,11365457,{route:"trail",carport:!0,garden:1}),ht("beacon-house","Beacon lodge",214,145,8,9,Wn,"gable",14728124,4488320,{route:"trail",tower:!0,garden:2}),ht("farm-home","Farmhouse porch",43,215,12,10,Wn,"gable",15851437,7042704,{route:"trail",porch:5,chimney:!0,garden:1}),ht("farm-shop","Farmyard store",12,216,10,8,Wn,"hip",12177332,11365457,{route:"trail",shop:!0,sign:"FARM STORE",approach:{x:12,z:204},carport:!0}),ht("red-barn","Red barn workshop",-18,214,14,12,Wn,"gambrel",13075044,7108992,{route:"trail",shop:!0,sign:"RED BARN",approach:{x:-18,z:202},chimney:!0}),ht("farm-cottage","Farm garden cottage",-47,213,8,9,Wn,"hip",15185051,4488320,{route:"trail",wing:!0,garden:3}),ht("orchard-barn","Orchard long barn",-96,211,14,12,Wn,"gambrel",14268559,11365457,{route:"trail",carport:!0,garden:1}),ht("pond-cabin","Reed pond cabin",-201,192,7,8,Yr,"gable",12177332,7042704,{route:"trail",porch:3.5,garden:2}),ht("trail-hut","North trail cabin",152,-218,6,7,Ci,"shed",14728124,4488320,{route:"trail",porch:3,garden:2})],Dm=[[[-124,6],[-146,10],[-169,1],[-186,-22],[-193,-61],[-177,-100],[-147,-127],[-112,-151],[-68,-171],[-15,-183],[40,-182],[89,-166],[133,-136],[160,-100],[175,-55],[174,-12],[176,20],[157,57],[139,92],[122,129],[91,162],[50,184],[3,190],[-47,181],[-91,157],[-124,126],[-156,91],[-181,55],[-196,18],[-174,7],[-146,10]],[[115,-53],[139,-56],[175,-55]]],Im=[[[-65,-103],[-108,-120],[-123,-150],[-128,-182],[-127,-209],[-99,-225],[-60,-221],[-66,-202],[-42,-202],[-8,-197],[-8,-182]],[[89,-166],[117,-185],[152,-198],[184,-210],[215,-208],[234,-183],[222,-151],[202,-147],[160,-100]],[[108,62],[142,48],[166,45],[184,44],[193,24],[220,20],[239,45],[236,70],[216,95],[185,116],[144,148],[122,129]],[[50,184],[33,202],[-10,198],[-57,193],[-95,193],[-131,174],[-157,173],[-184,174],[-213,181],[-216,205],[-193,222],[-162,224],[-137,212],[-131,192],[-131,174],[-139,147],[-124,126]],[[91,162],[128,181],[151,209],[181,226],[217,212],[232,174],[234,148],[222,127],[185,116]],[[-193,-61],[-218,-88],[-214,-123],[-192,-145],[-157,-151],[-147,-127]],[[-8,-197],[17,-197],[43,-202],[72,-215],[111,-229],[152,-198]],[[-184,174],[-190,183],[-192,194],[-190,206],[-193,222]],[[216,95],[208,99],[197,98],[197,84]]],Um=[{x:-161,z:-218,w:36,d:28,subtle:!0},{x:214,z:-232,w:36,d:20,subtle:!0},{x:-234,z:-111,w:22,d:24,subtle:!0},{x:151,z:234,w:36,d:20,subtle:!0}],Jr=[{x:-167,z:197,rx:23,rz:14},{x:215,z:45,rx:18,rz:12}],Wc=[{id:"north-square",name:"Sunbeam village",icon:"☀",x:-8,z:-197,color:"#d7ae71"},{id:"artists",name:"Makers village",icon:"▤",x:190,z:-102,color:"#bd9583"},{id:"east-park",name:"Lake park",icon:"⚑",x:197,z:84,color:"#7aa276"},{id:"farm",name:"Red barn farm",icon:"♧",x:-18,z:197,color:"#bd7967"},{id:"reed-pond",name:"Reed pond",icon:"≈",x:-167,z:197,color:"#72aebc",signX:-141,signZ:216},{id:"beacon",name:"Beacon walk",icon:"♜",x:214,z:145,color:"#8eaaa1",signX:225,signZ:143},{id:"north-meadow",name:"North meadow",icon:"▦",x:-161,z:-218,color:"#a9b774",signX:-182,signZ:-218},{id:"east-meadow",name:"East meadow",icon:"▦",x:151,z:234,color:"#a9b774",signX:173,signZ:234}],it=Object.freeze({id:"little-block-world-06",saveVersion:4,halfSize:250,buildHeight:24,maxBlocks:12e3,maxSaveBytes:4e6,chunkSize:24,fogNear:75,fogFar:155,cameraFar:190,saveKey:"blockworld.neighborhood.06",preferencesKey:"blockworld.neighborhood.controls.v6"}),xa=Object.freeze({normal:3.4,quick:5.1,fast:6.8}),Xc=n=>typeof xa[n]=="number"?xa[n]:xa.normal,zm=[{id:"home",name:"Home",icon:"⌂",x:-14.4,z:-1.2,color:"#cc9168"},{id:"village",name:"Village square",icon:"▥",x:49,z:-26,color:"#d9ac68"},{id:"park",name:"Play park",icon:"⚑",x:65,z:45,color:"#7aa276"},{id:"pond",name:"Willow pond",icon:"≈",x:18,z:-101,color:"#72aebc"},{id:"woods",name:"Woodland walk",icon:"♠",x:-65,z:-103,color:"#528969"},{id:"meadow",name:"Building meadow",icon:"▦",x:-59,z:61,color:"#a9b774"},{id:"orchard",name:"Orchard picnic",icon:"●",x:81,z:94,color:"#b89c78"},...Wc,...Vc];class vn{constructor(e=12){this.size=e,this.cells=new Map,this.global=new Set,this.entries=new Map}keys(e){const t=[];for(let i=Math.floor(e.minX/this.size);i<=Math.floor(e.maxX/this.size);i++)for(let r=Math.floor(e.minZ/this.size);r<=Math.floor(e.maxZ/this.size);r++)t.push(`${i},${r}`);return t}add(e){const t=this.keys(e);if(this.entries.set(e,t),t.length>64){this.global.add(e);return}for(const i of t)this.cells.has(i)||this.cells.set(i,new Set),this.cells.get(i).add(e)}remove(e){for(const t of this.entries.get(e)||[]){const i=this.cells.get(t);i==null||i.delete(e),i!=null&&i.size||this.cells.delete(t)}this.global.delete(e),this.entries.delete(e)}query(e){const t=new Set(this.global);for(const i of this.keys(e))for(const r of this.cells.get(i)||[])t.add(r);return[...t].filter(i=>i.minX<=e.maxX&&i.maxX>=e.minX&&i.minZ<=e.maxZ&&i.maxZ>=e.minZ&&i.minY<=e.maxY&&i.maxY>=e.minY)}}const Zn=(n,e=2)=>({minX:n.x-e,maxX:n.x+e,minZ:n.z-e,maxZ:n.z+e,minY:-1,maxY:(n.y||0)+30}),Pi=it.halfSize,Nm=it.maxBlocks,jr=.28,Fm=1.65,Fa=["wood","brick","stone","glass"],us=["flowers","lantern","bench"],Hl=[...Fa,...us],qc=(n,e,t)=>Math.max(e,Math.min(t,n)),ds=n=>`${n.x},${n.y},${n.z}`,Jn=n=>{const e=(n.rotation||0)*Math.PI/180,t=Math.abs(Math.cos(e)),i=Math.abs(Math.sin(e)),r=n.type==="bench"?Math.max(0,(.94*t+.64*i-1)/2):0,s=n.type==="bench"?Math.max(0,(.94*i+.64*t-1)/2):0;return{minX:n.x-r,minY:n.y,minZ:n.z-s,maxX:n.x+1+r,maxY:n.y+1,maxZ:n.z+1+s}},Yc=n=>({minX:n.x-jr,minY:n.y+.001,minZ:n.z-jr,maxX:n.x+jr,maxY:n.y+Fm,maxZ:n.z+jr});function Vl(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function Om(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:qc((i.length/2-o)/i.length,0,1)*i.rise}function Wi(n,e){if(e.ramp){const a=Om(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return Wi(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=Vl(n),i=Vl(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const l=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),c=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=l+c-1e-5)return!1}return!0}const km=(n,e)=>e.some(t=>Wi(Yc(n),t)),jc={x:-14.4,y:0,z:-1.2,yaw:0,pitch:0};function Bm(){return{version:it.saveVersion,world:it.id,blocks:[],inventory:{flowers:0,lantern:0,bench:0},selected:"hand",player:{...jc},doors:{},doorSwings:{}}}function Gm(n,e=[]){var c,d,u;if(!n||![1,2,3,it.saveVersion].includes(n.version)||n.version===it.saveVersion&&n.world!==it.id||n.version===2&&n.world!=="little-block-world-04"||n.version===3&&n.world!=="little-block-world-05"||!Array.isArray(n.blocks)||n.blocks.length>Nm)throw Error("This is not a supported BlockWorld save");const t=n.version===1,i=n.version===2;if(t&&n.blocks.length>800)throw Error("Older saves support up to 800 pieces");const r=Bm(),s=new Set,a=new vn(4),o=new vn;for(const h of e)o.add(h);for(const h of n.blocks){if(!h||!Hl.includes(h.type)||![h.x,h.y,h.z].every(Number.isInteger)||h.y<0||h.y>=it.buildHeight||h.x<-Pi||h.x>=Pi||h.z<-Pi||h.z>=Pi||t&&(Math.abs(h.x)>31||h.x===31||Math.abs(h.z)>31||h.z===31||h.y>9)||i&&(h.x<-125||h.x>=125||h.z<-125||h.z>=125)||s.has(ds(h)))throw Error("The save contains an invalid piece");if(o.query(Jn(h)).some(x=>Wi(Jn(h),x.ramp?{...x,ramp:null}:x)))throw Error("A saved piece overlaps the neighborhood");const m=Jn(h);if(a.query(m).some(x=>Wi(m,x)))throw Error("Saved pieces overlap");a.add(m),s.add(ds(h));const _=h.rotation??0;if(!Number.isFinite(_)||Math.abs(_)>36e3)throw Error("The piece rotation is invalid");r.blocks.push({x:h.x,y:h.y,z:h.z,type:h.type,...us.includes(h.type)?{rotation:(_%360+360)%360}:{}})}for(const h of us){const m=((c=n.inventory)==null?void 0:c[h])??0;if(!Number.isInteger(m)||m<0||m>999)throw Error("The inventory is invalid");r.inventory[h]=m}const l=n.player;l&&["x","y","z","yaw","pitch"].every(h=>Number.isFinite(l[h]))&&Math.abs(l.x)<Pi&&Math.abs(l.z)<Pi&&l.y>=0&&l.y<=it.buildHeight+2&&(r.player={x:l.x,y:l.y,z:l.z,yaw:l.yaw%(Math.PI*2),pitch:qc(l.pitch,-1.3,1.3)}),(n.selected==="hand"||Hl.includes(n.selected))&&(r.selected=n.selected);for(const h of Object.keys(n.doors||{}).filter(m=>/^[a-z][a-z0-9-]{0,39}$/.test(m)&&!["constructor","prototype"].includes(m)))r.doors[h]=((d=n.doors)==null?void 0:d[h])===!0,r.doorSwings[h]=((u=n.doorSwings)==null?void 0:u[h])===1?1:-1;return km(r.player,[...e,...r.blocks.map(Jn)])&&(r.player={...jc}),r}function Hm(n,e){const l=(h,m,_=.7)=>[-h/2+.1,h/2-.1].flatMap(x=>[-m/2+.1,m/2-.1].map(p=>e(x,_/2,p,.1,_,.1,11963744))),c=(h,m,_=.2)=>[e(-h/2,m/2,0,.2,m,_,15655365),e(h/2,m/2,0,.2,m,_,15655365),e(0,m,0,h+.2,.2,_,15655365)],d=(h,m,_,x)=>[e(-h/2,m/2,0,.12,m,_,11963744),e(h/2,m/2,0,.12,m,_,11963744),...Array.from({length:x},(p,f)=>e(0,.08+f*(m-.16)/(x-1),0,h,.12,_,11963744))],u=[e(0,.45,0,.8,.15,.8,7838867),e(0,.85,.35,.8,.7,.12,7838867),...l(.7,.7,.4)];for(const[h,m,_,x]of[["parquet","Parquet flooring",12622701,"parquet"],["herringbone-brick","Herringbone paving",12748393,"herringbone"],["river-stone","River stone",9873565,"river"],["corrugated-metal","Corrugated sheet",10663094,"corrugated"],["woven-bamboo","Woven bamboo",13022593,"woven"],["shingles","Roof shingles",9143927,"shingles"]])n(h,m,"Materials",[e(0,.5,0,1,1,1,_)],{cube:!0,surface:x});n("window-wall","Wall with window opening","Shapes",[e(-.8,1.25,0,.4,2.5,.2,15655365),e(.8,1.25,0,.4,2.5,.2,15655365),e(0,.4,0,1.2,.8,.2,15655365),e(0,2.25,0,1.2,.5,.2,15655365)]),n("doorway-wall","Wall with clear doorway","Shapes",c(1.5,2.5)),n("wide-floor","Four-metre floor","Shapes",[e(0,.075,0,4,.15,4,11963744)]),n("long-slab","Long half slab","Shapes",[e(0,.25,0,3,.5,1,13143410)]),n("half-block","Half-width block","Shapes",[e(0,.5,0,.5,1,1,15655365)]),n("corner-pillar","L-shaped pillar","Shapes",[e(-.25,1.25,0,.25,2.5,.8,13143410),e(0,1.25,-.25,.8,2.5,.25,13143410)]),n("fluted-column","Fluted column","Shapes",[e(0,.12,0,.9,.24,.9,15655365),e(0,1.4,0,.4,2.6,.7,15655365),e(0,1.4,0,.7,2.6,.4,15655365),e(0,2.8,0,.9,.2,.9,15655365)]),n("roof-ridge","Roof ridge cap","Shapes",[e(0,.15,0,1,.3,2,13143410),e(0,.36,0,.45,.18,2,13143410)]),n("roof-corner","Roof corner","Shapes",[e(0,.5,0,1,1,1,13143410,"wedge"),{...e(.5,.5,.5,1,1,1,13143410,"wedge"),yaw:Math.PI/2}]),n("brick-stairs","Wide masonry stairs","Shapes",Array.from({length:6},(h,m)=>e(0,(m+1)/6,1.25-m*.5,2,(m+1)/3,.5,13143410)),{ramp:!0,rampLength:3}),n("long-ramp","Long accessible ramp","Shapes",[e(0,1,0,2,2,4,11963744,"wedge")],{ramp:!0,rampLength:4}),n("balcony","Balcony platform","Shapes",[e(0,.1,0,2,.2,2,11963744),...[-.95,.95].map(h=>e(h,.7,0,.1,1.2,2,6782077)),e(0,.7,-.95,2,1.2,.1,6782077)]),n("casement-window","Opening casement window","Openings",[...c(1.2,1.2,.12),e(0,.05,0,1.2,.1,.12,15655365),e(0,.6,0,1.04,1.05,.08,10536654)],{interaction:"door"}),n("stable-door","Stable half door","Openings",[...c(1.4,1.2),e(0,.6,0,1.2,1.05,.12,11963744)],{interaction:"door"}),n("field-gate","Wide field gate","Openings",[...c(2.5,1.25),e(0,.65,0,2.3,1,.1,7838867)],{interaction:"door"}),n("lattice-fence","Lattice fence","Openings",[e(-.65,.65,0,.1,1.3,.12,11963744),e(.65,.65,0,.1,1.3,.12,11963744),...[-.4,0,.4].flatMap(h=>[e(h,.45,0,.1,.8,.12,11963744),e(0,.3+h,0,1.3,.08,.12,11963744)])]),n("garage-frame","Wide garage opening frame","Openings",c(4.5,3,.35)),n("round-table","Octagonal dining table","Furniture",[e(0,.76,0,1.4,.14,1,11963744),e(0,.76,0,1,.14,1.4,11963744),e(0,.38,0,.25,.76,.25,6782077),e(0,.08,0,.9,.16,.9,6782077)]),n("rocking-chair","Rocking chair","Furniture",[...u,e(-.3,.08,0,.12,.16,1.1,11963744),e(.3,.08,0,.12,.16,1.1,11963744)]),n("beanbag","Beanbag seat","Furniture",[e(0,.25,0,.9,.5,.9,13143410),e(0,.5,.2,.8,.35,.55,13143410),e(0,.18,-.25,1,.25,.7,13143410)],{interaction:"seat"}),n("loft-bed","Loft bed with desk","Furniture",[e(0,1.6,0,1.2,.25,2,7838867),...l(1.2,2,1.6),e(0,.75,-.5,1,.12,.7,11963744),e(0,1.85,-.95,1.2,.4,.1,11963744)]),n("chaise","Chaise lounge","Furniture",[e(0,.4,0,.85,.35,1.8,7838867),e(0,.75,.7,.85,.7,.25,7838867),...l(.8,1.7,.25)],{interaction:"seat"}),n("wall-clock","Wall clock","Furniture",[e(0,.45,0,.8,.9,.1,11963744),e(0,.45,.07,.64,.72,.04,15655365),e(0,.58,.1,.04,.27,.03,6782077),e(.15,.45,.1,.3,.04,.03,6782077)]),n("picture-frame","Landscape picture","Furniture",[e(0,.45,0,1.1,.9,.1,11963744),e(0,.46,.07,.95,.7,.04,10536654),e(0,.23,.1,.95,.25,.02,7838867),e(.25,.65,.1,.15,.15,.02,15980422)]),n("coat-rack","Coat stand","Furniture",[e(0,.9,0,.12,1.8,.12,11963744),e(0,1.5,0,.8,.1,.15,11963744),e(0,1.25,0,.15,.1,.7,11963744),e(0,.06,0,.7,.12,.7,6782077)]),n("shoe-rack","Open shoe rack","Furniture",d(1,.65,.4,3)),n("folding-screen","Folding room screen","Furniture",[-1,0,1].map(h=>({...e(h*.6,1,Math.abs(h)*.18,.6,2,.08,7838867),yaw:h*.35}))),n("corner-counter","Corner kitchen counter","Kitchen",[e(-.35,.5,0,.6,1,1.3,7838867),e(.3,.5,-.35,.7,1,.6,7838867),e(-.35,1.05,0,.68,.1,1.4,15655365),e(.3,1.05,-.35,.7,.1,.68,15655365)]),n("dishwasher","Dishwasher","Kitchen",[e(0,.5,0,.8,1,.7,15655365),e(0,.5,.37,.65,.65,.04,6782077),e(0,.9,.38,.5,.06,.04,7838867)]),n("washing-machine","Washing machine","Kitchen",[e(0,.5,0,.85,1,.75,15655365),e(0,.45,.39,.55,.55,.06,6782077),e(0,.45,.43,.35,.35,.02,10536654),e(.25,.9,.4,.1,.1,.04,7838867)]),n("microwave","Microwave","Kitchen",[e(0,.22,0,.65,.44,.45,15655365),e(-.08,.22,.24,.4,.3,.03,6782077),e(.23,.3,.25,.07,.08,.03,7838867)]),n("kettle","Electric kettle","Kitchen",[e(0,.18,0,.28,.36,.28,7838867),e(.18,.2,0,.12,.08,.12,7838867),e(-.18,.22,0,.1,.22,.12,6782077),e(0,.03,0,.35,.06,.35,6782077)]),n("toaster","Toaster","Kitchen",[e(0,.15,0,.42,.3,.28,13143410),e(-.1,.31,0,.06,.02,.2,6782077),e(.1,.31,0,.06,.02,.2,6782077),e(.23,.2,0,.04,.06,.08,6782077)]),n("cup-rack","Cup rack","Kitchen",[e(0,.06,0,.5,.12,.4,11963744),e(0,.4,0,.08,.7,.08,11963744),e(0,.55,0,.55,.06,.08,11963744),...[-.2,.2].map(h=>e(h,.42,0,.15,.2,.16,15655365))]),n("dining-hutch","Dining hutch","Kitchen",[e(0,.45,0,1.5,.9,.6,11963744),...d(1.4,1,.35,3).map(h=>({...h,y:h.y+.9,z:h.z-.1})),e(0,1.4,-.3,1.5,1,.08,11963744)]),n("corner-bath","Corner bath","Bathroom",[e(-.2,.3,0,.9,.6,1.4,15655365),e(.35,.3,-.3,.8,.6,.8,15655365),e(-.2,.62,0,.65,.03,1.1,10536654)]),n("laundry-basket","Laundry basket","Bathroom",[e(0,.05,0,.65,.1,.55,11963744),...[-.3,.3].map(h=>e(h,.35,0,.07,.7,.55,11963744)),...[-.25,.25].map(h=>e(0,.35,h,.6,.7,.06,11963744)),e(0,.67,0,.5,.08,.4,15655365)]),n("bath-mat","Bath mat","Bathroom",[e(0,.02,0,1.1,.04,.65,7838867),...[-.4,-.2,0,.2,.4].map(h=>e(h,.045,0,.06,.01,.6,15655365))]),n("soap-dispenser","Soap dispenser","Bathroom",[e(0,.15,0,.18,.3,.18,13143410),e(0,.34,0,.06,.08,.06,6782077),e(.06,.39,0,.18,.03,.05,6782077)]),n("shower-stool","Shower stool","Bathroom",[e(0,.45,0,.6,.1,.5,15655365),...l(.5,.4,.4)],{interaction:"seat"}),n("car-lift","Garage service lift","Workshop",[e(-1.4,1.4,0,.3,2.8,.5,7838867),e(1.4,1.4,0,.3,2.8,.5,7838867),e(-.8,.18,0,.45,.2,4,6782077),e(.8,.18,0,.45,.2,4,6782077)]),n("air-compressor","Air compressor","Workshop",[e(0,.4,0,1.1,.5,.5,13143410),e(0,.78,0,.45,.25,.35,6782077),...[-.4,.4].map(h=>e(h,.15,0,.2,.3,.65,6782077)),e(.55,.9,0,.1,.5,.1,6782077)]),n("tool-board","Tool pegboard","Workshop",[e(0,.65,0,1.6,1.3,.1,11963744),...[-.55,0,.55].flatMap((h,m)=>[e(h,.6,.1,.08,.65,.07,6782077),e(h,.9,.1,m===1?.3:.16,.1,.07,6782077)])]),n("wheelbarrow","Wheelbarrow","Workshop",[e(0,.55,0,.8,.25,1,7838867),e(-.35,.65,.7,.08,.1,1,11963744),e(.35,.65,.7,.08,.1,1,11963744),e(0,.2,-.5,.2,.4,.4,6782077),e(-.3,.25,.3,.06,.5,.06,6782077),e(.3,.25,.3,.06,.5,.06,6782077)]),n("sawhorse","Folding sawhorse","Workshop",[e(0,.8,0,1.4,.15,.2,11963744),...[-.55,.55].flatMap(h=>[-.3,.3].map(m=>e(h,.4,m,.1,.8,.1,11963744)))]),n("bench-vice","Bench vice","Workshop",[e(0,.08,0,.6,.16,.4,6782077),e(-.18,.27,0,.15,.3,.4,7838867),e(.18,.27,0,.15,.3,.4,7838867),e(.35,.2,0,.4,.06,.06,6782077)]),n("bicycle-rack","Bicycle parking rack","Workshop",[e(0,.08,0,2,.16,.65,6782077),...[-.7,0,.7].map(h=>e(h,.4,0,.08,.8,.65,6782077))]),n("willow","Weeping willow","Garden",[e(0,1.3,0,.35,2.6,.35,11963744),e(0,3,0,2.8,1.4,2.8,7838867),...[-1.2,1.2].flatMap(h=>[-1.2,1.2].map(m=>e(h,1.9,m,.35,2,.35,7838867)))]),n("birch","Birch tree","Garden",[e(0,1.6,0,.25,3.2,.25,15655365),e(0,3.1,0,1.3,1.8,1.4,10007682),e(.5,2.7,0,.9,1.1,1,10007682),...Array.from({length:6},(h,m)=>e(0,.3+m*.4,.13,.25,.06,.02,6782077))]),n("fern","Fern","Garden",[-1,0,1].flatMap(h=>[e(h*.23,.25,0,.18,.5,.8,7838867),e(0,.2,h*.23,.8,.4,.18,7838867)])),n("flower-arch","Flowered garden arch","Garden",[...c(2.4,2.8,.3),...[-1.15,1.15].flatMap(h=>[e(h,1.4,0,.4,1.8,.4,7838867),e(h,2.3,0,.5,.4,.5,13143410)]),e(0,2.9,0,2.3,.25,.5,7838867)]),n("raised-bed","Raised vegetable bed","Garden",[e(0,.2,0,2,.4,1.3,11963744),e(0,.42,0,1.8,.04,1.1,9205339),...[-.6,0,.6].flatMap(h=>[-.3,.3].map(m=>e(h,.58,m,.3,.3,.3,7838867)))]),n("stone-path","Stepping stone path","Garden",[-.65,0,.65].map((h,m)=>e(m%2?.1:-.1,.03,h,.85,.06,.5,11318688))),n("pond-bridge","Garden footbridge","Garden",[e(0,.18,0,1.6,.2,3,11963744),...[-.85,.85].flatMap(h=>[e(h,.65,0,.1,.1,3,11963744),...[-1.3,0,1.3].map(m=>e(h,.35,m,.1,.7,.1,11963744))])].map(h=>({...h,color:h.color||11963744}))),n("watering-can","Watering can","Garden",[e(0,.22,0,.4,.44,.35,7838867),{...e(.35,.24,0,.5,.12,.12,7838867),yaw:0},e(-.25,.3,0,.12,.35,.12,6782077),e(0,.5,0,.35,.08,.12,6782077)]),n("wall-sconce","Wall sconce","Lighting",[e(0,.35,-.1,.3,.7,.1,6782077),e(0,.45,.12,.35,.4,.35,16768917)],{interaction:"light"}),n("desk-lamp","Articulated desk lamp","Lighting",[e(0,.04,0,.5,.08,.4,6782077),e(-.15,.3,0,.06,.55,.06,7838867),e(0,.55,0,.4,.08,.08,7838867),e(.18,.5,0,.3,.2,.25,16768917)],{interaction:"light"}),n("string-lights","Garden string lights","Lighting",[e(-1.5,1.1,0,.1,2.2,.1,11963744),e(1.5,1.1,0,.1,2.2,.1,11963744),e(0,2.15,0,3,.04,.04,6782077),...[-1,-.33,.33,1].map(h=>e(h,2,0,.15,.25,.15,16768917))],{interaction:"light"}),n("camp-lantern","Camping lantern","Lighting",[e(0,.07,0,.4,.14,.4,6782077),e(0,.3,0,.28,.35,.28,16768917),e(0,.5,0,.4,.08,.4,7838867),e(0,.65,0,.25,.2,.05,6782077)],{interaction:"light"}),n("swing","Playground swing","Play",[e(-1,1.3,0,.15,2.6,.8,7838867),e(1,1.3,0,.15,2.6,.8,7838867),e(0,2.5,0,2.2,.15,.15,11963744),e(-.35,1.55,0,.04,1.8,.04,6782077),e(.35,1.55,0,.04,1.8,.04,6782077),e(0,.65,0,.8,.12,.45,13143410)]),n("seesaw","Seesaw","Play",[e(0,.3,0,.4,.6,.7,7838867),e(0,.65,0,3,.15,.4,11963744),e(-1.2,.8,0,.5,.15,.55,13143410),e(1.2,.8,0,.5,.15,.55,13143410)]),n("spring-rider","Spring pony","Play",[e(0,.25,0,.25,.5,.25,6782077),e(0,.65,0,.45,.5,.9,13143410),e(0,1,-.4,.3,.5,.25,13143410),e(0,.9,0,.6,.1,.1,7838867)]),n("trampoline","Garden trampoline","Play",[e(0,.4,0,2,.15,2,7838867),e(0,.49,0,1.7,.04,1.7,6782077),...l(1.9,1.9,.35)]),n("teddy","Teddy bear","Play",[e(0,.25,0,.3,.4,.25,11963744),e(0,.55,0,.35,.3,.28,11963744),...[-.18,.18].flatMap(h=>[e(h,.7,0,.12,.14,.12,11963744),e(h,.1,.1,.15,.15,.2,11963744)]),e(0,.54,.16,.12,.07,.04,6782077)]),n("toy-train","Toy train","Play",[e(0,.18,0,.4,.2,1,13143410),e(0,.4,.2,.4,.4,.35,7838867),e(0,.4,-.25,.25,.25,.35,6782077),...[-.23,.23].flatMap(h=>[-.32,.32].map(m=>e(h,.12,m,.12,.22,.2,6782077)))]),n("toy-blocks","Wooden toy blocks","Play",[e(-.2,.12,0,.25,.24,.3,13143410),e(.15,.17,0,.3,.34,.3,7838867),e(.1,.42,0,.6,.16,.3,15655365)]),n("chalkboard","Standing chalkboard","Play",[e(0,.95,0,1.4,1,.12,11963744),e(0,.95,.08,1.2,.8,.03,3693394),...[-.55,.55].map(h=>e(h,.5,0,.12,1,.5,11963744)),e(0,.9,.11,.6,.04,.02,15655365)]),n("post-box","Post box","Street",[e(0,.5,0,.5,1,.5,13143410),e(0,1.05,0,.6,.15,.6,13143410),e(0,.85,.26,.35,.06,.02,6782077)]),n("bus-shelter","Bus shelter","Street",[e(0,2.3,0,3,.2,1.8,7838867),...[-1.3,1.3].map(h=>e(h,1.1,-.6,.12,2.2,.12,6782077)),e(0,1.2,-.7,2.8,1.8,.08,10536654),e(0,.5,-.3,2,.15,.45,11963744),e(-.8,.25,-.3,.1,.5,.1,6782077),e(.8,.25,-.3,.1,.5,.1,6782077)]),n("street-sign","Direction signpost","Street",[e(0,1.1,0,.12,2.2,.12,11963744),e(.25,1.9,0,1,.3,.1,7838867),e(-.25,1.5,0,1,.3,.1,13143410)]),n("park-bin","Park recycling bin","Street",[e(0,.5,0,.65,1,.65,7838867),e(0,1.05,0,.75,.12,.75,6782077),e(0,.85,.34,.4,.16,.03,6782077)]),n("hydrant","Street hydrant","Street",[e(0,.4,0,.3,.8,.3,13143410),e(0,.85,0,.4,.12,.4,13143410),e(0,.6,0,.7,.18,.18,6782077)]),n("bollard","Path bollard","Street",[e(0,.45,0,.2,.9,.2,6782077),e(0,.75,0,.23,.15,.23,15655365)]),n("feeding-trough","Animal feeding trough","Farm",[e(0,.2,0,1.5,.4,.6,11963744),e(0,.42,0,1.3,.04,.4,7838867),e(-.55,.12,0,.12,.24,.75,6782077),e(.55,.12,0,.12,.24,.75,6782077)]),n("hay-bale","Hay bale","Farm",[e(0,.35,0,1.2,.7,.75,14007677),e(-.35,.35,0,.06,.72,.78,11963744),e(.35,.35,0,.06,.72,.78,11963744)]),n("chicken-coop","Chicken coop","Farm",[...l(1.4,1,.4),e(0,.5,0,1.4,.2,1,11963744),e(-.6,.9,0,.2,.8,1,15655365),e(.6,.9,0,.2,.8,1,15655365),e(0,.9,-.45,1.2,.8,.1,15655365),e(0,1.35,0,1.6,.25,1.2,13143410,"wedge")]),n("kennel","Dog kennel","Farm",[e(-.4,.35,0,.15,.7,1,11963744),e(.4,.35,0,.15,.7,1,11963744),e(0,.35,-.45,.8,.7,.1,11963744),e(0,.8,0,1,.25,1.1,7838867,"wedge")]),n("hitching-post","Hitching rail","Farm",[e(-.8,.6,0,.15,1.2,.15,11963744),e(.8,.6,0,.15,1.2,.15,11963744),e(0,1,0,1.8,.15,.15,11963744)]),n("beehive","Garden beehive","Farm",[e(0,.1,0,.85,.2,.75,11963744),...[0,1,2].map(h=>e(0,.3+h*.24,0,.65,.22,.6,14204024)),e(0,.92,0,.8,.12,.75,7838867)])}const Qr=new Set(["wood","brick","stone","glass","flowers","lantern","bench"]),V=(n,e,t,i,r,s,a,o="box")=>({x:n,y:e,z:t,w:i,h:r,d:s,color:a,shape:o}),Be=11239513,lt=15852744,Je=5796718,Xi=10340302,oi=[];function be(n,e,t,i,r={}){var s;oi.push({id:n,label:e,category:t,parts:i,icon:t==="Garden"?"🌿":t==="Lighting"?"💡":t==="Openings"?"🚪":t==="Furniture"?"🪑":"▦",color:((s=i[0])==null?void 0:s.color)||Be,...r})}for(const[n,e,t]of[["wood","Wood",12424551],["brick","Brick",13075044],["stone","Stone",10267045],["glass","Glass",Xi]])be(n,e,"Materials",[V(0,.5,0,1,1,1,t)],{cube:!0,icon:n==="wood"?"▥":n==="brick"?"▦":n==="stone"?"▧":"◈"});for(const[n,e,t]of[["flowers","Flowers","🌷"],["lantern","Lantern","🏮"],["bench","Bench","🪑"]])be(n,e,n==="flowers"?"Garden":"Furniture",Gc[n].map(([i,r,s,a,o,l,c])=>V(i-.5,r,s-.5,a,o,l,c)),{icon:t});for(const[n,e,t,i]of[["oak-planks","Oak planks",12423520,"wood"],["bamboo","Bamboo",12763001,"bamboo"],["log-end","Timber logs",10912340,"log"],["white-brick","White brick",14407359,"brick"],["cobble","Cobblestone",9607822,"cobble"],["sandstone","Sandstone",14468245,"stone"],["marble","Marble",14867920,"marble"],["slate","Slate",6912896,"stone"],["concrete","Concrete",11710880,"concrete"],["terracotta","Terracotta",12419166,"tile"],["mosaic","Mosaic tiles",8563103,"mosaic"],["checker-tile","Checker tiles",14274995,"checker"],["copper","Copper panels",12157540,"metal"],["steel","Steel plate",11123392,"metal"],["grass","Turf",8957292,"grass"],["sand","Sand",14930847,"sand"]])be(n,e,"Materials",[V(0,.5,0,1,1,1,t)],{cube:!0,surface:i});for(const[n,e,t,i,r,s]of[["slab","Half slab",1,.5,1,"box"],["floor-panel","Floor panel",1,.15,1,"box"],["wall-panel","Wall panel",1,2,.15,"box"],["half-wall","Half wall",1,1,.15,"box"],["pillar","Square pillar",.35,2.5,.35,"box"],["beam","Long beam",3,.25,.25,"box"],["post","Fence post",.18,1.2,.18,"box"],["roof-slope","Roof slope",1,1,1,"wedge"],["roof-slab","Roof sheet",2,.15,2,"box"],["ramp","Walking ramp",1,1,2,"wedge"],["wide-ramp","Wide ramp",2,1,2,"wedge"],["step","Low step",1,.25,.5,"box"],["foundation","Foundation plinth",2,.4,2,"box"]])be(n,e,"Shapes",[V(0,i/2,0,t,i,r,n.includes("roof")?9665388:Be,s)],{ramp:s==="wedge"});be("stairs","Timber stairs","Shapes",Array.from({length:4},(n,e)=>V(0,(e+1)*.125,.75-e*.5,1,(e+1)*.25,.5,Be)),{ramp:!0});be("arch","Wide arch","Shapes",[V(-.8,1,0,.3,2,.4,12627596),V(.8,1,0,.3,2,.4,12627596),V(0,2,0,1.9,.35,.4,12627596)]);be("corner-wall","Corner wall","Shapes",[V(-.42,1,0,.16,2,1,lt),V(0,1,-.42,1,2,.16,lt)]);for(const[n,e,t,i,r]of[["door","Timber door",1,2.2,Be],["glass-door","Glass door",1,2.2,Xi],["double-door","Double-width door",2,2.2,Be],["garden-gate","Garden gate",1.4,1.2,10268294]])be(n,e,"Openings",[V(-t/2,i/2,0,.1,i,.18,Je),V(t/2,i/2,0,.1,i,.18,Je),V(0,i,0,t+.1,.1,.18,Je),V(0,i/2,0,t-.16,i-.1,.1,r)],{interaction:"door"});for(const[n,e,t,i]of[["window","Window",1.2,1.2],["wide-window","Wide window",2,1.2],["tall-window","Tall window",.8,2],["skylight","Skylight",1.2,.35]])be(n,e,"Openings",[V(0,i/2,0,t,i,.09,Xi),V(-t/2,i/2,0,.08,i,.15,lt),V(t/2,i/2,0,.08,i,.15,lt),V(0,i,0,t+.08,.08,.15,lt),V(0,.04,0,t+.08,.08,.15,lt),V(0,i/2,0,.06,i,.16,lt)]);for(const[n,e,t]of[["picket-fence","Picket fence",lt],["rail-fence","Timber rail fence",Be],["metal-rail","Metal railing",Je]])be(n,e,"Openings",[...[-.48,.48].map(i=>V(i,.6,0,.1,1.2,.1,t)),V(0,.9,0,1,.1,.1,t),V(0,.4,0,1,.1,.1,t),...n==="picket-fence"?[-.25,0,.25].map(i=>V(i,.55,0,.09,1.1,.1,t)):[]]);const ws=(n=1.5,e=1,t=.75,i=Be)=>[V(0,t,0,n,.12,e,i),...[-n*.38,n*.38].flatMap(r=>[-e*.35,e*.35].map(s=>V(r,t/2,s,.1,t,.1,Je)))],Es=(n=1,e=9942176)=>[V(0,.4,0,n,.25,.8,e),V(0,.8,.34,n,.6,.16,e),...[-n*.36,n*.36].map(t=>V(t,.15,0,.1,.3,.6,Be))];be("chair","Dining chair","Furniture",Es(.6),{interaction:"seat"});be("armchair","Armchair","Furniture",[...Es(1),V(-.48,.55,0,.18,.4,.8,9942176),V(.48,.55,0,.18,.4,.8,9942176)],{interaction:"seat"});be("sofa","Two-seat sofa","Furniture",Es(1.9,9152434),{interaction:"seat"});be("corner-sofa","Corner sofa","Furniture",[...Es(1.8,11772084),V(-.6,.4,-.7,.6,.25,1.2,11772084)],{interaction:"seat"});be("stool","Stool","Furniture",[V(0,.55,0,.55,.12,.55,14003573),...[-.2,.2].flatMap(n=>[-.2,.2].map(e=>V(n,.25,e,.08,.5,.08,Be)))],{interaction:"seat"});be("dining-table","Dining table","Furniture",ws(1.8,1));be("coffee-table","Coffee table","Furniture",ws(1.2,.7,.4));be("desk","Writing desk","Furniture",[...ws(1.5,.8),V(.5,.5,0,.4,.5,.65,14272417)]);for(const[n,e,t,i]of[["single-bed","Single bed",.95,2],["double-bed","Double bed",1.75,2.1]])be(n,e,"Furniture",[V(0,.25,0,t,.5,i,Be),V(0,.55,0,t,.15,i,15186816),V(0,.68,-i*.33,t*.8,.18,.45,lt),V(0,.65,-i/2,t,.8,.12,Be)]);be("bunk-bed","Bunk beds","Furniture",[V(0,.5,0,1,.2,2,14663563),V(0,1.7,0,1,.2,2,14663563),...[-.47,.47].flatMap(n=>[-.95,.95].map(e=>V(n,1,e,.1,2,.1,Be))),...Array.from({length:5},(n,e)=>V(-.58,.2+e*.33,.6,.25,.08,.18,Be))]);be("crib","Crib","Furniture",[V(0,.4,0,.9,.15,1.5,lt),...[-.45,.45].flatMap(n=>[-.65,-.3,0,.3,.65].map(e=>V(n,.75,e,.06,.8,.06,Be)))]);be("wardrobe","Wardrobe","Furniture",[V(0,1,0,1.2,2,.6,Be),V(0,1,.32,.04,1.8,.05,lt)]);be("dresser","Dresser","Furniture",[V(0,.6,0,1.4,1.2,.65,Be),...Array.from({length:3},(n,e)=>V(0,.25+e*.35,.34,1.25,.04,.04,lt))]);be("nightstand","Nightstand","Furniture",[V(0,.3,0,.55,.6,.5,Be),V(0,.4,.27,.1,.06,.05,Je)]);be("bookcase","Bookcase","Furniture",[V(0,1,0,1.4,2,.35,Be),...Array.from({length:6},(n,e)=>V(-.55+e*.22,1.35,.2,.16,.55,.08,[13208431,8562842,13876601][e%3]))]);be("shelf","Wall shelf","Furniture",[V(0,.2,0,1.5,.12,.35,Be),V(-.55,.1,.08,.1,.2,.1,Je),V(.55,.1,.08,.1,.2,.1,Je)]);be("tv-cabinet","TV cabinet","Furniture",[V(0,.35,0,1.5,.7,.5,Be),V(0,1,.05,1.2,.65,.12,Je),V(0,.95,.13,1.05,.5,.03,10930105)]);be("rug","Woven rug","Furniture",[V(0,.025,0,1.8,.05,1.3,13216390),V(0,.055,0,1.5,.01,1,14994589)]);const Ts=(n=12897715)=>[V(0,.5,0,.98,1,.6,n),V(0,1.04,0,1,.08,.68,lt),V(0,.75,.32,.25,.05,.06,Je)];be("kitchen-counter","Kitchen counter","Kitchen",Ts());be("sink","Kitchen sink","Kitchen",[...Ts(),V(0,1.09,0,.6,.04,.4,9218473),V(.28,1.3,-.2,.06,.45,.06,Je)]);be("stove","Cooker","Kitchen",[...Ts(13949132),...[-.25,.25].flatMap(n=>[-.18,.18].map(e=>V(n,1.1,e,.25,.02,.22,Je))),V(0,.55,.32,.7,.45,.04,Je)]);be("fridge","Fridge","Kitchen",[V(0,1,0,.85,2,.8,14476243),V(.28,1,.42,.06,.6,.06,Je)]);be("oven","Oven","Kitchen",[...Ts(11713718),V(0,.5,.32,.7,.5,.05,Je)]);be("kitchen-island","Kitchen island","Kitchen",[V(0,.5,0,2,1,.8,10860973),V(0,1.05,0,2.2,.12,1,lt)]);be("wall-cupboard","Wall cupboard","Kitchen",[V(0,.4,0,1,.8,.35,14081476),V(0,.4,.2,.04,.7,.03,Je)]);be("bin","Kitchen bin","Kitchen",[V(0,.4,0,.5,.8,.5,Je),V(0,.82,0,.55,.08,.55,11779249)]);be("toilet","Toilet","Bathroom",[V(0,.22,0,.4,.44,.5,lt),V(0,.48,-.05,.6,.15,.7,lt),V(0,.72,-.3,.6,.6,.18,lt)]);be("bath","Bath","Bathroom",[V(0,.25,0,.9,.5,1.8,lt),V(0,.52,0,.7,.03,1.5,10077642),V(.32,.7,-.55,.05,.35,.05,Je)]);be("shower","Shower","Bathroom",[V(0,.04,0,1,.08,1,lt),V(0,1,-.46,.9,2,.06,Xi),V(.44,1,0,.06,2,1,Xi),V(-.3,1.4,-.4,.05,1,.05,Je),V(-.3,1.95,-.2,.3,.07,.3,Je)]);be("washbasin","Washbasin","Bathroom",[V(0,.5,0,.7,1,.5,12306876),V(0,1.05,0,.8,.12,.6,lt),V(.2,1.2,-.2,.05,.3,.05,Je)]);be("mirror","Mirror","Bathroom",[V(0,.65,0,.8,1.3,.1,Be),V(0,.65,.06,.68,1.15,.04,Xi)]);be("towel-rail","Towel rail","Bathroom",[V(0,.6,0,.9,.08,.08,Je),V(0,.4,.04,.6,.45,.04,13939875)]);be("workbench","Workbench","Workshop",[...ws(2,.9,.9),V(0,1.4,-.35,2,.8,.1,Be)]);be("tool-cabinet","Tool cabinet","Workshop",[V(0,.7,0,1.1,1.4,.55,9153185),...Array.from({length:4},(n,e)=>V(0,.25+e*.3,.29,.8,.04,.05,Je))]);be("garage-shelf","Garage shelving","Workshop",[...[-.7,.7].flatMap(n=>[-.3,.3].map(e=>V(n,1,e,.08,2,.08,Je))),...Array.from({length:4},(n,e)=>V(0,.2+e*.55,0,1.5,.08,.7,Be))]);be("storage-crate","Storage crate","Workshop",[V(0,.4,0,.8,.8,.8,Be),V(0,.42,.41,.7,.1,.04,lt)]);be("traffic-cone","Traffic cone","Workshop",[V(0,.06,0,.6,.12,.6,6255729),V(0,.3,0,.35,.5,.35,13998948),V(0,.6,0,.2,.2,.2,16050123)]);be("tyre-stack","Tyre stack","Workshop",[V(0,.18,0,.7,.3,.7,Je),V(0,.52,0,.7,.3,.7,Je)]);for(const[n,e,t,i,r]of[["oak-tree","Oak tree",2.4,3.5,7444841],["pine-tree","Pine tree",1.6,4,6132863],["palm-tree","Palm tree",2.5,3.2,8890990],["fruit-tree","Fruit tree",2,2.8,9876856]])be(n,e,"Garden",[V(0,i*.35,0,.25,i*.7,.25,Be),...n==="pine-tree"?[0,1,2].map(s=>V(0,i*.48+s*.75,0,t*(1-s*.23),1,t*(1-s*.23),r)):n==="palm-tree"?[V(0,i*.86,0,t,.3,.45,r),V(0,i*.88,0,.45,.3,t,r),V(0,i*.95,0,.8,.5,.8,r)]:[V(0,i*.75,0,t*.75,i*.5,t*.75,r),...[-1,1].map(s=>V(s*t*.3,i*.71,0,t*.4,i*.33,t*.65,r))],...n==="fruit-tree"?[-.65,0,.65].map(s=>V(s,i*.75,.8,.2,.2,.2,14724205)):[]]);be("hedge","Hedge","Garden",[V(0,.5,0,1.5,1,.7,7840116)]);be("flower-bed","Flower bed","Garden",[V(0,.12,0,1.5,.24,.8,Be),...[-.5,0,.5].map(n=>V(n,.45,0,.3,.5,.3,14069921))]);be("planter","Square planter","Garden",[V(0,.25,0,.7,.5,.7,12555371),V(0,.65,0,.5,.5,.5,8956533)]);be("vegetable-patch","Vegetable patch","Garden",[V(0,.06,0,1.8,.12,1.5,10847589),...[-.5,0,.5].flatMap(n=>[-.45,0,.45].map(e=>V(n,.22,e,.2,.3,.2,9021805)))]);be("boulder","Boulder","Garden",[V(0,.35,0,1.3,.7,1.1,10398366),V(.2,.8,0,.8,.3,.8,10398366)]);be("birdhouse","Birdhouse","Garden",[V(0,.8,0,.1,1.6,.1,Be),V(0,1.65,0,.5,.5,.45,13939070),V(0,1.95,0,.65,.12,.6,9217434)]);be("pergola","Pergola","Garden",[...[-1,1].flatMap(n=>[-1,1].map(e=>V(n,1.25,e,.15,2.5,.15,Be))),...[-1,-.5,0,.5,1].map(n=>V(n,2.55,0,.15,.15,2.3,Be))]);for(const[n,e,t,i]of[["table-lamp","Table lamp",.65,.4],["floor-lamp","Floor lamp",1.8,.6],["street-lamp","Street lamp",3,.7],["garden-light","Garden light",.7,.35],["ceiling-light","Ceiling lamp",.3,.7],["wall-light","Wall light",.5,.3]])be(n,e,"Lighting",[V(0,t*.4,0,.08,t*.8,.08,Je),V(0,t*.85,0,i,t*.3,i,16768917),V(0,.04,0,i*.7,.08,i*.7,Je)],{interaction:"light"});be("toy-box","Toy box","Play",[V(0,.3,0,1.1,.6,.7,13874817),V(0,.65,0,1.15,.1,.75,9154209)]);be("dollhouse","Doll house","Play",[V(0,.25,0,.8,.5,.55,14529701),V(0,.6,0,.9,.25,.65,9348764,"wedge")]);be("sandpit","Sandpit","Play",[V(0,.08,0,2,.16,2,Be),V(0,.18,0,1.7,.08,1.7,14930335)]);be("play-slide","Play slide","Play",[V(0,.5,0,.6,1,1.7,14202233,"wedge"),V(-.4,1,.7,.12,2,.12,Je),V(.4,1,.7,.12,2,.12,Je)]);be("goal","Play goal","Play",[V(-1,.7,0,.1,1.4,.1,lt),V(1,.7,0,.1,1.4,.1,lt),V(0,1.4,0,2.1,.1,.1,lt)]);Hm(be,V);for(const[n,e]of[["swing","swing"],["seesaw","seesaw"],["spring-rider","rock"],["rocking-chair","rock"],["trampoline","bounce"],["play-slide","slide"],["bench","seat"],["lantern","light"]])oi.find(t=>t.id===n).interaction=e;const Oa=oi.find(n=>n.id==="dining-hutch");Oa.interaction="cabinet";Oa.parts=[V(-.7,.45,0,.1,.9,.6,Be),V(.7,.45,0,.1,.9,.6,Be),V(0,.45,-.25,1.4,.9,.1,Be),V(0,.05,0,1.4,.1,.6,Be),V(0,.87,0,1.5,.12,.6,Be),...Oa.parts.slice(1),V(0,.45,.32,1.3,.72,.08,10860706)];const Lt=new Map(oi.map(n=>[n.id,n]));function so(n,e){const t=Lt.get(n.type);if(!t)throw Error("Unknown catalogue item");const i=t.parts.map(r=>({...r}));if(["door","cabinet"].includes(t.interaction||"")&&(n.open||e!==void 0)){const r=i.at(-1),s=(e??(n.open?1:0))*Math.PI/2*(t.interaction==="cabinet"?-1:1);r.x+=-r.w/2+Math.cos(s)*r.w/2,r.z+=-Math.sin(s)*r.w/2,r.yaw=s}if(t.interaction==="light"&&n.on===!1)for(const r of i)r.color===16768917&&(r.color=12960431);return i}function Zc(n,e){if(Qr.has(n.type))return[Jn(n)];const t=(n.rotation||0)*Math.PI/180,i=Math.cos(t),r=Math.sin(t),s=Lt.get(n.type);if(s.ramp){const a=Math.max(...s.parts.map(c=>c.w)),o=s.rampLength||(n.type==="stairs"?2:s.parts[0].d),l=Math.max(...s.parts.map(c=>c.y+c.h/2));return[{minX:n.x+.5-(Math.abs(i)*a+Math.abs(r)*o)/2,maxX:n.x+.5+(Math.abs(i)*a+Math.abs(r)*o)/2,minZ:n.z+.5-(Math.abs(r)*a+Math.abs(i)*o)/2,maxZ:n.z+.5+(Math.abs(r)*a+Math.abs(i)*o)/2,minY:n.y,maxY:n.y+l,ramp:{cx:n.x+.5,cz:n.z+.5,c:i,s:r,width:a,length:o,rise:l,baseY:n.y}}]}return so(n,e).map(a=>{const o=t+(a.yaw||0),l=Math.cos(o),c=Math.sin(o),d=n.x+.5+a.x*i+a.z*r,u=n.z+.5-a.x*r+a.z*i,h=(Math.abs(l)*a.w+Math.abs(c)*a.d)/2,m=(Math.abs(c)*a.w+Math.abs(l)*a.d)/2;return{minX:d-h,maxX:d+h,minZ:u-m,maxZ:u+m,minY:n.y+a.y-a.h/2,maxY:n.y+a.y+a.h/2,obb:{cx:d,cz:u,c:l,s:c,halfW:a.w/2,halfD:a.d/2}}})}function et(n){return Zc(n)}function Vm(n,e){return Zc(n,e)}function fs(n){const e=et(n);return{minX:Math.min(...e.map(t=>t.minX)),maxX:Math.max(...e.map(t=>t.maxX)),minY:Math.min(...e.map(t=>t.minY)),maxY:Math.max(...e.map(t=>t.maxY)),minZ:Math.min(...e.map(t=>t.minZ)),maxZ:Math.max(...e.map(t=>t.maxZ))}}const As=[{id:"set-bedroom",label:"Bedroom set",category:"Presets",icon:"🛏",color:Be,blocks:[{x:0,y:0,z:0,type:"single-bed"},{x:2,y:0,z:0,type:"nightstand"},{x:2,y:0,z:2,type:"floor-lamp"}]},{id:"set-kitchen",label:"Kitchen run",category:"Presets",icon:"🍳",color:lt,blocks:[{x:0,y:0,z:0,type:"kitchen-counter"},{x:1,y:0,z:0,type:"sink"},{x:2,y:0,z:0,type:"stove"}]},{id:"set-garden",label:"Garden seating",category:"Presets",icon:"🌷",color:Be,blocks:[{x:0,y:0,z:0,type:"bench"},{x:-2,y:0,z:0,type:"planter"},{x:2,y:0,z:0,type:"planter"}]},{id:"set-workshop",label:"Workshop set",category:"Presets",icon:"🛠",color:Je,blocks:[{x:0,y:0,z:0,type:"workbench"},{x:3,y:0,z:0,type:"tool-cabinet"},{x:0,y:0,z:2,type:"storage-crate"}]}];As.push({id:"set-dining",label:"Family dining",category:"Presets",icon:"🍽",color:Be,blocks:[{x:0,y:0,z:0,type:"round-table"},{x:-2,y:0,z:0,type:"chair",rotation:270},{x:2,y:0,z:0,type:"chair",rotation:90},{x:0,y:0,z:2,type:"chair"}]},{id:"set-bathroom",label:"Bathroom suite",category:"Presets",icon:"🛁",color:lt,blocks:[{x:0,y:0,z:0,type:"washbasin"},{x:2,y:0,z:0,type:"toilet"},{x:4,y:0,z:0,type:"bath"}]},{id:"set-study",label:"Reading and study",category:"Presets",icon:"📚",color:Be,blocks:[{x:0,y:0,z:0,type:"desk"},{x:0,y:.81,z:0,type:"desk-lamp"},{x:0,y:0,z:2,type:"chair"},{x:3,y:0,z:0,type:"bookcase"}]},{id:"set-playground",label:"Little playground",category:"Presets",icon:"🛝",color:Be,blocks:[{x:0,y:0,z:0,type:"swing"},{x:4,y:0,z:0,type:"play-slide"},{x:0,y:0,z:4,type:"sandpit"}]},{id:"set-farm",label:"Animal care corner",category:"Presets",icon:"🐾",color:Be,blocks:[{x:0,y:0,z:0,type:"feeding-trough"},{x:3,y:0,z:0,type:"kennel"},{x:-3,y:0,z:0,type:"hay-bale"}]},{id:"set-bus-stop",label:"Neighbourhood bus stop",category:"Presets",icon:"🚏",color:Je,blocks:[{x:0,y:0,z:0,type:"bus-shelter"},{x:3,y:0,z:0,type:"street-sign"},{x:-3,y:0,z:0,type:"park-bin"}]},{id:"set-picnic",label:"Picnic corner",category:"Presets",icon:"☀",color:Be,blocks:[{x:0,y:0,z:0,type:"round-table"},{x:0,y:0,z:2,type:"bench"},{x:0,y:0,z:-2,type:"bench",rotation:180},{x:3,y:0,z:0,type:"planter"}]},{id:"set-pavilion",label:"Open garden pavilion",category:"Presets",icon:"⌂",color:Be,blocks:[{x:0,y:0,z:0,type:"wide-floor"},...[-1,1].flatMap(n=>[-1,1].map(e=>({x:n,y:.15,z:e,type:"pillar"}))),{x:0,y:2.65,z:0,type:"wide-floor"}]});const ii=[...oi,...As];function $c(n){const e=As.find(s=>s.id===n.type);if(!e)return[n];const t=(n.rotation||0)*Math.PI/180,i=Math.round(Math.cos(t)),r=Math.round(Math.sin(t));return e.blocks.map(s=>({x:n.x+s.x*i+s.z*r,y:n.y+s.y,z:n.z-s.x*r+s.z*i,type:s.type,rotation:((n.rotation||0)+(s.rotation||0))%360}))}const zi=n=>`${Math.floor(n.x/it.chunkSize)},${Math.floor(n.z/it.chunkSize)}`;class Wm{constructor(e,t,i,r){Object.assign(this,{parent:e,geometry:t,materials:i,decorMat:r}),this.cells=new Map,this.groups=new Map,this.rebuilt=0}clear(){for(const e of this.groups.values())this.dispose(e);this.cells.clear(),this.groups.clear()}dispose(e){e.traverse(t=>{t.isInstancedMesh&&t.dispose(),t.userData.ownedGeometry&&t.geometry.dispose()}),e.removeFromParent()}reset(e){this.clear();for(const t of e)this.store(t);for(const t of this.cells.keys())this.rebuild(t)}store(e){const t=zi(e);this.cells.has(t)||this.cells.set(t,new Map),this.cells.get(t).set(ds(e),e)}update(e,t){var s;const i=zi(e);t?this.store(e):(s=this.cells.get(i))==null||s.delete(ds(e));const r=new Set([i]);it.chunkSize;for(const[a,o]of[[1,0],[-1,0],[0,1],[0,-1]]){const l=zi({x:e.x+a,z:e.z+o});l!==i&&this.cells.has(l)&&r.add(l)}for(const a of r)this.rebuild(a)}opaque(e,t,i){var r,s;return Fa.includes((s=(r=this.cells.get(zi({x:e,z:i})))==null?void 0:r.get(`${e},${t},${i}`))==null?void 0:s.type)}rebuild(e){var d;const t=this.groups.get(e);t&&this.dispose(t);const i=new ft,r=[...((d=this.cells.get(e))==null?void 0:d.values())||[]],s=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],a=this.geometry;for(const u of Fa){const h=[],m=[],_=[],x=[],p=[];for(const g of r.filter(y=>y.type===u))for(let y=0;y<6;y++){const[R,T,C]=s[y];if(this.opaque(g.x+R,g.y+T,g.z+C))continue;const z=h.length/3;for(let M=0;M<4;M++){const S=y*4+M;h.push(a.attributes.position.getX(S)+g.x+.5,a.attributes.position.getY(S)+g.y+.5,a.attributes.position.getZ(S)+g.z+.5),m.push(a.attributes.normal.getX(S),a.attributes.normal.getY(S),a.attributes.normal.getZ(S)),_.push(a.attributes.uv.getX(S),a.attributes.uv.getY(S))}for(let M=0;M<6;M++)x.push(z+a.index.array[y*6+M]-y*4);p.push(g,g)}if(!h.length)continue;const f=new rt;f.setAttribute("position",new Ve(h,3)),f.setAttribute("normal",new Ve(m,3)),f.setAttribute("uv",new Ve(_,2)),f.setIndex(x),f.computeBoundingSphere(),f.computeBoundingBox();const v=new Le(f,this.materials[u]);v.userData.faceBlocks=p,v.userData.ownedGeometry=!0,i.add(v)}const o=new Map,l=new pt,c=new pt;for(const u of r.filter(h=>us.includes(h.type))){l.position.set(u.x+.5,u.y,u.z+.5),l.rotation.y=(u.rotation||0)*Math.PI/180,l.updateMatrix();for(const[h,m,_,x,p,f,v]of Gc[u.type])c.position.set(h-.5,m,_-.5),c.scale.set(x,p,f),c.updateMatrix(),o.has(v)||o.set(v,[]),o.get(v).push({b:u,m:new Qe().multiplyMatrices(l.matrix,c.matrix)})}for(const[u,h]of o){const m=new cs(this.geometry,this.decorMat(u),h.length);h.forEach((_,x)=>m.setMatrixAt(x,_.m)),m.userData.blocks=h.map(_=>_.b),m.computeBoundingSphere(),i.add(m)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i),this.rebuilt++}rayMeshes(){const e=[];return this.parent.traverse(t=>{t.isMesh&&e.push(t)}),e}}const Xm=new _t(1,1,1),Rs=new rt;Rs.setAttribute("position",new Ve([-.5,-.5,-.5,.5,-.5,-.5,-.5,-.5,.5,.5,-.5,.5,-.5,.5,-.5,.5,.5,-.5],3));Rs.setIndex([0,2,1,1,2,3,0,1,4,1,5,4,0,4,2,1,3,5,2,4,3,3,4,5]);Rs.computeVertexNormals();const _a=new Map;function Kc(n,e){if(_a.has(n))return _a.get(n);if(typeof document>"u")return;const t=document.createElement("canvas");t.width=t.height=128;const i=t.getContext("2d");if(i.fillStyle="#ffffff",i.fillRect(0,0,128,128),i.strokeStyle="#c7c7c7",i.lineWidth=3,["parquet","herringbone","woven","shingles","corrugated","river"].includes(e))if(e==="corrugated")for(let s=0;s<128;s+=16)i.fillStyle="#b2b2b2",i.fillRect(s,0,4,128),i.fillStyle="#eeeeee",i.fillRect(s+4,0,5,128);else if(e==="river")for(let s=0;s<24;s++)i.fillStyle=s%2?"#cccccc":"#eeeeee",i.beginPath(),i.ellipse(s*43%128,s*67%128,13,9,s,0,Math.PI*2),i.fill(),i.stroke();else{const s=e==="woven"?12:32;for(let a=0;a<128;a+=s)for(let o=0;o<128;o+=s){if(i.save(),i.translate(o+s/2,a+s/2),["parquet","herringbone"].includes(e)&&i.rotate((o+a)/s%2?Math.PI/2:0),i.strokeRect(-s/2,-s/2,s,s),e==="shingles")i.beginPath(),i.arc(0,-s/2,s/2,0,Math.PI),i.stroke();else for(let l=-s/2;l<s/2;l+=s/4)i.beginPath(),i.moveTo(l,-s/2),i.lineTo(l,s/2),i.stroke();i.restore()}}else if(["brick","tile","checker","mosaic","metal"].includes(e)){const s=e==="mosaic"?16:e==="metal"?64:32;for(let a=0;a<128;a+=s)for(let o=0;o<128;o+=s){const l=o-(e==="brick"&&a/s%2?s/2:0);e==="checker"&&(o+a)/s%2===0&&(i.fillStyle="#aaaaaa",i.fillRect(l,a,s,s)),i.strokeRect(l,a,s,s)}}else if(["wood","bamboo","log"].includes(e)){for(let s=0;s<8;s++)i.beginPath(),i.moveTo(s*18,0),i.lineTo(s*18,128),i.stroke();if(e==="log")for(let s=12;s<64;s+=12)i.beginPath(),i.arc(64,64,s,0,Math.PI*2),i.stroke()}else for(let s=0;s<110;s++){const a=s*37%128,o=s*67%128;i.fillStyle=s%3?"#e1e1e1":"#bdbdbd",i.fillRect(a,o,e==="cobble"?15:e==="marble"?22:3,e==="cobble"?12:2)}const r=new fr(t);return r.userData.shared=!0,r.colorSpace=xt,r.magFilter=Pt,_a.set(n,r),r}const Jc=n=>n.shape==="wedge"?Rs:Xm;function ai(n,e=!1){const t=new ft;t.position.set(n.x+.5,n.y,n.z+.5),t.rotation.y=(n.rotation||0)*Math.PI/180;const i=Lt.get(n.type);if(!i){for(const r of $c(n))t.add(ai({...r,x:r.x-n.x-.5,y:r.y-n.y,z:r.z-n.z-.5},e));return t.rotation.y=0,t.position.set(n.x+.5,n.y,n.z+.5),t}for(const r of so(n)){const s=new Le(Jc(r),new It({color:r.color,map:i.surface&&Kc(i.id,i.surface)||null,transparent:e,opacity:e?.55:1}));s.position.set(r.x,r.y,r.z),s.scale.set(r.w,r.h,r.d),s.rotation.y=r.yaw||0,s.userData.block=n,s.userData.sharedGeometry=!0,t.add(s)}return t}class qm{constructor(e,t,i,r){this.parent=e,e.add(this.legacyGroup),this.legacy=new Wm(this.legacyGroup,t,i,r)}legacy;legacyGroup=new ft;cells=new Map;groups=new Map;materials=new Map;rebuilt=0;key(e){return`${Math.floor(e.x/16)},${Math.floor(e.z/16)}`}anchor(e){return`${e.x},${e.y},${e.z}`}clear(){this.legacy.clear();for(const e of this.groups.values())e.traverse(t=>{t.isInstancedMesh&&t.dispose()}),e.removeFromParent();this.groups.clear(),this.cells.clear()}reset(e){this.clear(),this.legacy.reset(e.filter(t=>Qr.has(t.type)));for(const t of e.filter(i=>!Qr.has(i.type))){const i=this.key(t);this.cells.has(i)||this.cells.set(i,new Map),this.cells.get(i).set(this.anchor(t),t)}for(const t of this.cells.keys())this.rebuild(t)}update(e,t){this.updateMany([{block:e,present:t}])}updateMany(e){var r;const t=new Set,i=new Set;for(const{block:s,present:a}of e)if(Qr.has(s.type)){const o=zi(s);a?this.legacy.store(s):(r=this.legacy.cells.get(o))==null||r.delete(this.anchor(s)),t.add(o);for(const[l,c]of[[1,0],[-1,0],[0,1],[0,-1]]){const d=zi({x:s.x+l,z:s.z+c});d!==o&&this.legacy.cells.has(d)&&t.add(d)}}else{const o=this.key(s);this.cells.has(o)||this.cells.set(o,new Map),a?this.cells.get(o).set(this.anchor(s),s):this.cells.get(o).delete(this.anchor(s)),i.add(o)}for(const s of t)this.legacy.rebuild(s);for(const s of i)this.rebuild(s)}rebuild(e){var o;this.rebuilt++;const t=this.groups.get(e);t&&(t.traverse(l=>{l.isInstancedMesh&&l.dispose()}),t.removeFromParent());const i=new ft,r=new Map,s=new pt,a=new pt;for(const l of((o=this.cells.get(e))==null?void 0:o.values())||[]){s.position.set(l.x+.5,l.y,l.z+.5),s.rotation.y=(l.rotation||0)*Math.PI/180,s.updateMatrix();for(const c of so(l)){a.position.set(c.x,c.y,c.z),a.scale.set(c.w,c.h,c.d),a.rotation.y=c.yaw||0,a.updateMatrix();const d=Lt.get(l.type),u=(c.shape||"box")+":"+(d.surface?d.id:"plain");r.has(u)||r.set(u,[]),r.get(u).push({b:l,p:c,matrix:new Qe().multiplyMatrices(s.matrix,a.matrix)})}}for(const[l,c]of r){const d=Lt.get(c[0].b.type);this.materials.has(l)||this.materials.set(l,new It({color:16777215,map:d.surface&&Kc(d.id,d.surface)||null}));const u=new cs(Jc(c[0].p),this.materials.get(l),c.length);c.forEach((h,m)=>{u.setMatrixAt(m,h.matrix),u.setColorAt(m,new $e(h.p.color))}),u.userData.blocks=c.map(h=>h.b),u.computeBoundingSphere(),i.add(u)}this.parent.add(i),i.updateMatrixWorld(!0),this.groups.set(e,i)}rayMeshes(){return[...this.legacy.rayMeshes(),...[...this.groups.values()].flatMap(e=>e.children)]}}let Li;const va=new Map;function Qc(n,e=!1){Li||(Li=new Ja({alpha:!0,antialias:!1}),Li.setSize(112,96),Li.setPixelRatio(1));const t=new zc,i=new Sn().setFromObject(n),r=i.getCenter(new N),s=i.getSize(new N),a=Math.max(s.x,s.y,s.z)*.8+.25,o=new $a(-a*1.17,a*1.17,a,-a,.01,100);o.position.copy(r).add(new N(a*2,a*1.5,a*2.4)),o.lookAt(r),t.add(new Oc(16777215,8624771,2),new Bc(16777215,1),n),Li.render(t,o);const l=Li.domElement.toDataURL();if(n.traverse(c=>{c.isMesh&&c.material.dispose()}),e){const c=new Set;n.traverse(d=>{d.isMesh&&c.add(d.geometry)}),c.forEach(d=>d.dispose())}return l}function Ym(n){return va.has(n)||va.set(n,Qc(ai({x:0,y:0,z:0,type:n}))),va.get(n)}function ps(n){const e=[...n.hotbar.filter(i=>ii.some(r=>r.id===i)),...n.recent.filter(i=>ii.some(r=>r.id===i)),...oi.slice(0,7).map(i=>i.id)],t=[...new Set(e)].slice(0,8);document.querySelector("#palette").innerHTML=t.map(i=>{const r=ii.find(s=>s.id===i);return`<button data-item="${r.id}" aria-label="Choose ${r.label}" title="${r.label}" aria-pressed="${n.selected===i}"><span>${r.icon}</span><small>${r.label}</small></button>`}).join("")}function jm(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section class="cataloguePanel"><h1>▦ Build anything</h1><input id="catalogueSearch" aria-label="Search catalogue" placeholder="Search (optional)"><div id="categories"></div><div id="catalogueGrid"></div><div class="cataloguePages"><button id="previousPage" aria-label="Previous catalogue page">◀</button><output id="catalogueCount"></output><button id="nextPage" aria-label="Next catalogue page">▶</button><button id="repeatBuild" aria-label="Pieces in a building row"></button><button id="closeCatalogue">▶ Play</button></div></section>';let t="All",i=0,r=0;const s=()=>{r++,e.hidden=!0,n.paused=!1,n.controls.clear()},a=()=>{r++;const c=r,d=document.querySelector("#catalogueSearch").value.toLowerCase(),u=ii.filter(p=>(t==="All"||t==="Favourites"&&n.favourites.includes(p.id)||t==="Recent"&&n.recent.includes(p.id)||p.category===t)&&p.label.toLowerCase().includes(d));i=Math.min(i,Math.max(0,Math.ceil(u.length/24)-1));const h=u.slice(i*24,i*24+24),m=document.querySelector("#catalogueGrid");m.replaceChildren();const _=[];for(const p of h){const f=document.createElement("article");f.className="catalogueCard";const v=document.createElement("button");v.dataset.catalogue=p.id,v.setAttribute("aria-label","Choose "+p.label);const g=document.createElement("img");g.alt=p.label,g.width=112,g.height=96;const y=document.createElement("span");y.textContent=p.label,v.append(g,y),v.onclick=()=>{n.choose(p.id),s()};const R=document.createElement("button");R.className="favourite",R.textContent=n.favourites.includes(p.id)?"★":"☆",R.setAttribute("aria-label","Favourite "+p.label),R.setAttribute("aria-pressed",String(n.favourites.includes(p.id))),R.onclick=()=>{n.favourites=n.favourites.includes(p.id)?n.favourites.filter(C=>C!==p.id):[p.id,...n.favourites].slice(0,32),n.onEdit(),a()};const T=document.createElement("button");T.className="pin",T.textContent="📌",T.setAttribute("aria-label","Pin "+p.label),T.setAttribute("aria-pressed",String(n.hotbar.includes(p.id))),T.onclick=()=>{n.hotbar=n.hotbar.includes(p.id)?n.hotbar.filter(C=>C!==p.id):[p.id,...n.hotbar].slice(0,8),ps(n),n.onEdit(),a()},f.append(v,R,T),m.append(f),_.push(()=>{c===r&&g.isConnected&&(g.src=Ym(p.id))})}const x=()=>{var p;c!==r||e.hidden||((p=_.shift())==null||p(),_.length&&requestAnimationFrame(x))};requestAnimationFrame(x),document.querySelector("#catalogueCount").textContent=`${u.length} choices · ${i+1}/${Math.max(1,Math.ceil(u.length/24))}`,document.querySelector("#previousPage").disabled=i===0,document.querySelector("#nextPage").disabled=(i+1)*24>=u.length};for(const c of["All","Favourites","Recent",...new Set(ii.map(d=>d.category))]){const d=document.createElement("button");d.textContent=c==="Favourites"?"★ Favourites":c==="Recent"?"◷ Recent":c,d.dataset.category=c;const u={All:"▦",Materials:"🧱",Shapes:"△",Openings:"🚪",Furniture:"🪑",Kitchen:"🍳",Bathroom:"🛁",Workshop:"🛠",Garden:"🌿",Lighting:"💡",Play:"🧸",Street:"🚏",Farm:"🐾",Presets:"⌂"};u[c]&&(d.textContent=u[c]+" "+c),d.onclick=()=>{t=c,i=0,document.querySelectorAll("[data-category]").forEach(h=>h.setAttribute("aria-pressed",String(h.dataset.category===t))),a()},document.querySelector("#categories").append(d)}document.querySelector("#catalogueSearch").oninput=()=>{i=0,a()},document.querySelector("#nextPage").onclick=()=>{i++,a()},document.querySelector("#previousPage").onclick=()=>{i--,a()},document.querySelector("#closeCatalogue").onclick=s;const o=document.querySelector("#repeatBuild"),l=()=>o.textContent=`▦ ×${n.repeatCount}`;o.onclick=()=>{n.repeatCount=n.repeatCount===1?3:n.repeatCount===3?5:1,l()},l(),a()}function eh(n){document.body.classList.toggle("leftHanded",n.leftHanded)}function Zm(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section><h1>🎮 Comfortable controls</h1><h2>Look speed</h2><div id="lookSpeeds"></div><button id="handed" aria-label="Swap control sides">↔ Swap hands</button><button id="closeControls">▶ Play</button></section>';for(const[i,r]of[[.6,"🐢 Gentle"],[1,"🚶 Normal"],[1.4,"🐇 Quick"]]){const s=document.createElement("button");s.dataset.speed=String(i),s.textContent=r,s.setAttribute("aria-pressed",String(n.lookSpeed===i)),s.onclick=()=>{n.lookSpeed=i,n.onEdit(),document.querySelectorAll("[data-speed]").forEach(a=>a.setAttribute("aria-pressed",String(Number(a.dataset.speed)===i)))},document.querySelector("#lookSpeeds").append(s)}const t=document.querySelector("#handed");t.setAttribute("aria-pressed",String(n.leftHanded)),t.onclick=()=>{n.leftHanded=!n.leftHanded,eh(n),t.setAttribute("aria-pressed",String(n.leftHanded)),n.onEdit()},document.querySelector("#closeControls").onclick=()=>{e.hidden=!0,n.paused=!1,n.controls.clear()}}function $m(n,e,t,i,r){if(!n.grounded||!e.some(a=>a.ramp&&t(a,n.x,n.z)!==null))return;const s=i(n);for(const a of e){if(a.ramp||a.maxY<=n.y||a.maxY-n.y>.09||s.minX>=a.maxX||s.maxX<=a.minX||s.minZ>=a.maxZ||s.maxZ<=a.minZ)continue;const o={...n,y:a.maxY};r(o,e)||(n.y=o.y)}}const Wl=it.halfSize;it.maxBlocks;const Ln=.28,th=1.65,es=(n,e,t)=>Math.max(e,Math.min(t,n)),qi=n=>({minX:n.x-Ln,minY:n.y+.001,minZ:n.z-Ln,maxX:n.x+Ln,maxY:n.y+th,maxZ:n.z+Ln});function Xl(n){return n.obb??{cx:(n.minX+n.maxX)/2,cz:(n.minZ+n.maxZ)/2,c:1,s:0,halfW:(n.maxX-n.minX)/2,halfD:(n.maxZ-n.minZ)/2}}function Qn(n,e,t){if(!n.ramp)return null;const i=n.ramp,r=e-i.cx,s=t-i.cz,a=r*i.c-s*i.s,o=r*i.s+s*i.c;return Math.abs(a)>i.width/2+.001||Math.abs(o)>i.length/2+.001?null:(i.baseY||0)+es((i.length/2-o)/i.length,0,1)*i.rise}function Dt(n,e){if(e.ramp){const a=Qn(e,(n.minX+n.maxX)/2,(n.minZ+n.maxZ)/2);return a!==null&&n.minY<a-1e-5&&n.maxY>e.minY}if(n.ramp)return Dt(e,n);if(!(n.minX<e.maxX-1e-5&&n.maxX>e.minX+1e-5&&n.minY<e.maxY-1e-5&&n.maxY>e.minY+1e-5&&n.minZ<e.maxZ-1e-5&&n.maxZ>e.minZ+1e-5))return!1;if(!n.obb&&!e.obb)return!0;const t=Xl(n),i=Xl(e),r=i.cx-t.cx,s=i.cz-t.cz;for(const[a,o]of[[t.c,-t.s],[t.s,t.c],[i.c,-i.s],[i.s,i.c]]){const l=t.halfW*Math.abs(a*t.c-o*t.s)+t.halfD*Math.abs(a*t.s+o*t.c),c=i.halfW*Math.abs(a*i.c-o*i.s)+i.halfD*Math.abs(a*i.s+o*i.c);if(Math.abs(r*a+s*o)>=l+c-1e-5)return!1}return!0}const _n=(n,e)=>e.some(t=>Dt(qi(n),t));function ka(n,e){let t=0;for(const i of e){const r=Qn(i,n.x,n.z),s=r===null?i:{...i,maxY:r};i.ramp&&r===null||s.maxY<=n.y+.02&&s.maxY>t&&n.x+Ln>s.minX+.01&&n.x-Ln<s.maxX-.01&&n.z+Ln>s.minZ+.01&&n.z-Ln<s.maxZ-.01&&(t=s.maxY)}return t}function ql(n,e){return n.y<=.35?!0:[-.12,.12].every(t=>[-.12,.12].every(i=>e.some(r=>{const s=Qn(r,n.x+t,n.z+i);if(r.ramp)return s!==null&&Math.abs(s-n.y)<.3;if(r.maxY>n.y+.025||r.maxY<n.y-.3)return!1;const a={minX:n.x+t-.001,maxX:n.x+t+.001,minZ:n.z+i-.001,maxZ:n.z+i+.001,minY:r.maxY-.003,maxY:r.maxY+.003};return Dt(a,r)})))}function Yl(n,e){let t=1/0;for(const i of e){if(i.maxY>n.y+.025||i.maxY<n.y-.3)continue;const r=Math.max(i.minX+.12-n.x,0,n.x-(i.maxX-.12)),s=Math.max(i.minZ+.12-n.z,0,n.z-(i.maxZ-.12));t=Math.min(t,r*r+s*s)}return t}function Km(n,e,t,i){const r=Math.ceil(Math.min(t,.1)/.012),s=Math.min(t,.1)/r,a=Xc(e.walkSpeed);let o=es(e.forward||0,-1,1),l=es(e.right||0,-1,1),c=Math.max(1,Math.hypot(o,l));const d=(-Math.sin(n.yaw)*o+Math.cos(n.yaw)*l)*a/c,u=(-Math.cos(n.yaw)*o-Math.sin(n.yaw)*l)*a/c;for(let h=0;h<r;h++){const m=ka(n,i);(n.vy||0)<=0&&n.y>=m-.002&&n.y-m<.035&&(n.y=m,n.vy=0,n.grounded=!0);for(const[p,f]of[["x",d],["z",u]]){const v=n[p];n[p]=es(v+f*s,-Wl+.4,Wl-.4);const g=n.y;if(n.grounded)for(const y of i){const R=Qn(y,n.x,n.z),T=Qn(y,p==="x"?v:n.x,p==="z"?v:n.z);R!==null&&R-n.y<=.09&&R-n.y>=-.12&&(T!==null||Math.abs(n.y-(y.ramp.baseY||0))<.1||Math.abs(n.y-y.maxY)<.1)&&(n.y=R)}if($m(n,i,Qn,qi,_n),_n(n,i)&&(n[p]=v,n.y=g),e.edgeProtection&&n.grounded&&!e.allowDrop&&n.y>.35&&!ql(n,i)){const y={...n,[p]:v};(ql(y,i)||Yl(n,i)>=Yl(y,i)-1e-6)&&(n[p]=v)}}n.vy=(n.vy||0)-16*s;const _=n.y;if(n.y+=n.vy*s,n.y<=0)n.y=0,n.vy=0,n.grounded=!0;else if(_n(n,i)){const p=i.filter(f=>Dt(qi(n),f));n.vy<0?(n.y=Math.max(...p.map(f=>Qn(f,n.x,n.z)??f.maxY)),n.grounded=!0):(n.y=Math.min(...p.map(f=>f.minY))-th-.002,n.grounded=!1),(n.y<0||_n(n,i))&&(n.y=_),n.vy=0}else n.grounded=!1;const x=ka(n,i);n.vy<=0&&n.y>=x-.002&&n.y-x<.035&&(n.y=x,n.vy=0,n.grounded=!0)}}const nh=n=>Number.isInteger(n.x)&&Number.isInteger(n.z)&&Number.isFinite(n.y)&&Math.abs(n.y*100-Math.round(n.y*100))<1e-7;function Jm(n){if(!Array.isArray(n)||n.length>12e3)throw Error("Unsupported build capacity");const e=new Set,t=new vn(4);for(const i of n){if(!i||!Lt.has(i.type)||!nh(i)||i.x<-250||i.x>=250||i.z<-250||i.z>=250||i.y<0||i.y>=24||i.rotation!==void 0&&!Number.isFinite(i.rotation)||Math.abs(i.rotation||0)>36e3||i.open!==void 0&&typeof i.open!="boolean"||i.on!==void 0&&typeof i.on!="boolean")throw Error("Invalid catalogue object");const r=`${i.x},${i.y},${i.z}`;if(e.has(r))throw Error("Duplicate build anchor");if(e.add(r),fs(i).maxY>24.001)throw Error("Object exceeds build ceiling");for(const a of et(i))if(t.query(a).some(o=>Dt(a,o)))throw Error("Saved objects overlap");for(const a of et(i))t.add(a)}}function jl(n,e,t,i,r=!0){if(!n||!Lt.has(n.type))return"Choose a building piece";if(!nh(n)||n.x<-250||n.x>=250||n.z<-250||n.z>=250||n.y<0||n.y>=24)return"Build inside the world";if(e.length>=12e3)return"World geometry capacity reached";const s=fs(n);if(s.maxY>24.001)return"That is above the build ceiling";if(r&&Math.hypot(n.x+.5-i.x,n.y+.5-i.y,n.z+.5-i.z)>6)return"Move a little closer";if(e.some(l=>l.x===n.x&&l.y===n.y&&l.z===n.z))return"Find a clear space";const a=et(n),o=[...t,...e.flatMap(et)];return a.some(l=>Dt(l,qi(i)))?"Take a little step back":a.some(l=>o.some(c=>Dt(l,c.ramp?{...c,ramp:null}:c)))?"Find a clear space":n.y>0&&!e.some(l=>Math.abs(l.x-n.x)+Math.abs(l.y-n.y)+Math.abs(l.z-n.z)<=1)&&!o.some(l=>Math.abs(l.maxY-n.y)<.02&&l.minX<s.maxX&&l.maxX>s.minX&&l.minZ<s.maxZ&&l.maxZ>s.minZ)?"Join this piece to a surface":""}function ao({scene:n,material:e,doors:t,h:i,local:r,id:s=i.id,x:a=-1.4,z:o=i.d/2,width:l=1.26,height:c=2.3}){const d=r(a-l/2,o+.03),u=r(a,o),h=new ft;h.position.set(d.x,0,d.z),h.rotation.y=i.angle;const m=new Le(new _t(l,c,.1),e(9726028));m.position.set(l/2,c/2,0),h.add(m);const _=new Le(new _t(l*.62,.65,.112),e(11980733));_.position.set(l/2,1.65,0),h.add(_);const x=new Le(new Ss(.055,6,5),e(16768118));x.position.set(l-.16,1,.09),h.add(x),n.add(h),t.push({id:s,pivot:h,baseAngle:i.angle,open:!1,center:u,hinge:d,width:l,height:c})}function Cs({scene:n,material:e,doors:t,h:i,put:r,local:s}){const a=-i.w/2-2.1,o=i.d/2,l=o-2.7;r(a,.007,l,4.2,.014,5.4,12959399);for(const m of[-2.1,2.1])r(a+m,1.4,l,.2,2.8,5.4,i.wall,!0);r(a,1.4,o-5.4,4.2,2.8,.2,i.wall,!0),r(a,2.72,o,4.2,.16,.2,i.wall,!0);for(const m of[-1.92,1.92])r(a+m,1.32,o,.36,2.64,.2,i.wall,!0);r(a,2.88,l,4.6,.18,5.8,i.roof,!0);const c=s(a,o),d=new ft;d.position.set(c.x,0,c.z),d.rotation.y=i.angle;const u=new ft,h=new Le(new _t(3.46,2.6,.1),e(14144708));h.position.y=1.3,u.add(h);for(let m=.25;m<2.6;m+=.32){const _=new Le(new _t(3.42,.035,.12),e(10989475));_.position.y=m,u.add(_)}d.add(u),n.add(d),t.push({id:i.id+"-garage",kind:"roller",pivot:d,leaf:u,baseAngle:i.angle,center:c,hinge:c,width:3.46,height:2.6,open:!1})}function ih({h:n,put:e,local:t,scene:i,material:r,doors:s,solids:a,label:o,rooms:l}){const c=n.w,d=n.d,u=d/2,h=n.storeys===2,m=3.2,_=h?6.4:3,x=16774617,p=9725511,f=8501706;e(0,.007,0,c,.014,d,14006419);for(const I of[-u,u]){const W=I>0,L=c/2-2,U=2.1,B=W?[[-c/2,-2.1],[-.7,L-U/2],[L+U/2,c/2]]:[[-c/2,L-U/2],[L+U/2,c/2]];for(const[X,K]of B)K>X&&e((X+K)/2,1.5,I,K-X,3,.22,n.wall,!0);W&&e(-1.4,2.68,I,1.4,.64,.22,n.wall,!0),e(L,.5,I,U,1,.22,n.wall,!0),e(L,2.65,I,U,.7,.22,n.wall,!0),e(L,1.65,I,U,1.3,.1,f,!0);for(const X of[L-U/2,L,L+U/2])e(X,1.65,I,.065,1.42,.3,x);for(const X of[1,2.3])e(L,X,I,U+.15,.07,.3,x);if(h){e(0,3.22,I,c,.44,.22,n.wall,!0);const X=1.6,K=n.id==="manor"?[-c/2+2,-1.4,c/2-2]:[-c/2+2,c/2-2];let ie=-c/2;for(const ne of K){e((ie+ne-X/2)/2,4.8,I,ne-X/2-ie,3.2,.22,n.wall,!0),e(ne,3.7,I,X,1,.22,n.wall,!0),e(ne,5.98,I,X,.84,.22,n.wall,!0),e(ne,4.88,I,X,1.36,.1,f,!0);for(const ue of[ne-X/2,ne,ne+X/2])e(ue,4.88,I,.065,1.5,.3,x);for(const ue of[4.2,5.56])e(ne,ue,I,X+.15,.07,.3,x);ie=ne+X/2}e((ie+c/2)/2,4.8,I,c/2-ie,3.2,.22,n.wall,!0)}}for(const I of[-c/2,c/2])for(const W of h?[0,m]:[0]){const L=d>10?[-d/2+2.5,d/2-2.5]:[0],U=1.6;let B=-u;for(const X of L){e(I,W+1.5,(B+X-U/2)/2,.22,3,X-U/2-B,n.wall,!0),e(I,W+.5,X,.22,1,U,n.wall,!0),e(I,W+2.65,X,.22,.7,U,n.wall,!0),e(I,W+1.65,X,.1,1.3,U,f,!0);for(const K of[X-.8,X,X+.8])e(I,W+1.65,K,.3,1.42,.065,x);for(const K of[1,2.3])e(I,W+K,X,.3,.07,U+.15,x);B=X+U/2}e(I,W+1.5,(B+u)/2,.22,3,u-B,n.wall,!0),h&&(e(I,3.1,0,.22,.2,d,n.wall,!0),e(I,_-.1,0,.22,.2,d,n.wall,!0))}ao({scene:i,material:r,doors:s,h:n,local:t});const v=_+.06,g=v+(n.id==="manor"?3.3:1.8),y=c/2+.4,R=u+.4,T=[],C=(I,W,L,U)=>T.push(...I,...W,...L,...I,...L,...U);if(n.style==="hip")C([-y,v,R],[y,v,R],[0,g,1],[0,g,1]),C([y,v,R],[y,v,-R],[0,g,-1],[0,g,1]),C([y,v,-R],[-y,v,-R],[0,g,-1],[0,g,-1]),C([-y,v,-R],[-y,v,R],[0,g,1],[0,g,-1]);else if(n.style==="shed"){const I=v+1.4;C([-y,v,R],[y,v,R],[y,I,-R],[-y,I,-R]);for(const W of[-c/2,c/2]){const L=new rt;L.setAttribute("position",new Ve([W,_,-u,W,I,-u,W,v,u,W,_,-u,W,v,u,W,_,u],3)),L.computeVertexNormals();const U=r(n.wall).clone();U.side=yt;const B=new Le(L,U);B.position.set(n.x,0,n.z),B.rotation.y=n.angle,i.add(B)}e(0,(_+I)/2,-u,c,I-_,.22,n.wall,!0)}else{C([-y,v,R],[0,g,R],[0,g,-R],[-y,v,-R]),C([0,g,R],[y,v,R],[y,v,-R],[0,g,-R]);for(const I of[-u,u]){const W=new rt;W.setAttribute("position",new Ve([-c/2,_,I,c/2,_,I,0,g,I],3)),W.computeVertexNormals();const L=r(n.wall).clone();L.side=yt;const U=new Le(W,L);U.position.set(n.x,0,n.z),U.rotation.y=n.angle,i.add(U)}}const z=new rt;z.setAttribute("position",new Ve(T,3)),z.computeVertexNormals();const M=r(n.roof).clone();M.side=yt;const S=new Le(z,M);S.position.set(n.x,0,n.z),S.rotation.y=n.angle,i.add(S),e(0,_+.015,0,c,.09,d,x,!0),e(-1.4,2.64,u+.7,n.porch||2.4,.12,1.5,n.roof,!0);for(const I of[-2.45,-.35])e(I,1.27,u+1.3,.12,2.54,.12,x,!0);if(n.id==="manor"){for(const U of[-4.9,2.1]){e(U,3.15,u+2,.32,6.3,.32,x,!0);for(const B of[.12,6.25])e(U,B,u+2,.65,.24,.65,x,!0)}e(-1.4,6.5,u+1.1,7.9,.24,2.8,x,!0);const I=new rt;I.setAttribute("position",new Ve([-5.35,6.65,u+2.55,2.55,6.65,u+2.55,-1.4,8.15,u+2.55],3)),I.computeVertexNormals();const W=r(x).clone();W.side=yt;const L=new Le(I,W);L.position.set(n.x,0,n.z),L.rotation.y=n.angle,i.add(L),e(3,.34,u-2.5,3.4,.68,1,7183771,!0),e(3,.88,u-2.96,3.4,.72,.18,7183771,!0);for(const U of[1.4,4.6])e(U,.65,u-2.5,.2,.5,1,p,!0);e(3,.36,u-4.2,1.8,.72,.8,p,!0),e(-c/2+3.3,.79,u-3,2.6,.15,1.6,p,!0);for(const U of[-1,1])for(const B of[-.55,.55])e(-c/2+3.3+U,.36,u-3+B,.12,.72,.12,p,!0)}const G=(I,W,L=c/2-.2)=>{e((-c/2+-1.4-1.7/2)/2,I+1.5,W,-1.4-1.7/2+c/2,3,.16,n.wall,!0),e((-1.4+1.7/2+L)/2,I+1.5,W,L- -1.4-1.7/2,3,.16,n.wall,!0),e(-1.4,I+2.72,W,1.7,.56,.16,x,!0)};if(n.rooms&&(G(0,-.4,h?c/2-2.2:c/2-.2),l.push({house:n.id,name:"Back room",...t(-1.4,-u+1.7),y:0})),h){const I=c/2-1.2,W=1.65,L=u-1.4,U=-u+1.4,B=L-U,X=-c/2,K=I-W/2-.12;e((X+K)/2,m-.09,0,K-X,.18,d,14006419,!0);for(const[se,ge]of[[-u+.6,1.2],[u-.6,1.2]])e((K+c/2)/2,m-.09,se,c/2-K,.18,ge,14006419,!0);const ie=t(I,(L+U)/2),ne=Math.cos(n.angle),ue=Math.sin(n.angle),de=(W*Math.abs(ne)+B*Math.abs(ue))/2,J=(W*Math.abs(ue)+B*Math.abs(ne))/2;a.push({minX:ie.x-de,maxX:ie.x+de,minZ:ie.z-J,maxZ:ie.z+J,minY:0,maxY:m,ramp:{cx:ie.x,cz:ie.z,c:ne,s:ue,width:W,length:B,rise:m}});for(let se=0;se<16;se++){const ge=m*(se+1)/16;e(I,ge/2,L-(se+.5)*B/16,W,ge,B/16,p)}e(K-.04,m+.48,(L+U)/2,.1,.96,B,p,!0);for(const se of[L-.15,U+.15])e(K-.04,m+.48,se,.12,.96,.12,x,!0);G(m,-.4,K-.25),l.push({house:n.id,name:"Upper landing",...t(I,-u+.55),y:m},{house:n.id,name:"Upstairs bedroom",...t(-1.4,-u+1.7),y:m})}for(const I of h?[0,m]:[0])e(-c/2+1.3,I+.28,-u+1.6,1.8,.56,2.4,p,!0),e(-c/2+1.3,I+.62,-u+1.6,1.75,.13,2.3,n.roof),e(-c/2+1.3,I+.73,-u+.8,1.5,.16,.5,x),e(-c/2+1.1,I+.45,u-1.1,1.5,.9,.7,p,!0);if(n.shop){e(c/2-1.5,.5,-u+1.2,2,1,1,p,!0);const I=t(0,u+.2);o(n.sign,I.x,2.9,I.z,n.angle,Math.min(c-1,5))}if(n.street){const I=c/2+1.2;e(I,.22,0,1.1,.44,d+3,5933922,!0),e(0,.38,-u-1.6,c+2,.12,.12,p,!0);for(const W of[-c/2-1,0,c/2+1])e(W,.35,-u-1.6,.1,.7,.1,x,!0);e(c/2-1,.18,u+1.5,2,.36,1,5933922,!0);for(const W of[-.6,0,.6])e(c/2-1+W,.43,u+1.5,.3,.18,.3,15118451)}n.garage&&Cs({scene:i,material:r,doors:s,h:n,put:e,local:t}),l.push({house:n.id,name:"Entrance",...t(-1.4,u-1.1),y:0})}function Ps(n,e){const t=new Map,i=new Qe,r=new Qe,s=new N,a=new N,o=new Xe,l=[...n.children].filter(x=>x.isMesh&&!e.has(x)),c=new Set,d=new Set;for(const x of l){x.updateMatrixWorld(!0);const p=x.geometry.index?x.geometry.toNonIndexed():x.geometry,f=p.attributes.position,v=p.attributes.normal,g=x.material.color,y=x.isInstancedMesh?x.count:1;for(let R=0;R<y;R++){x.isInstancedMesh?(x.getMatrixAt(R,i),r.multiplyMatrices(x.matrixWorld,i)):r.copy(x.matrixWorld);const T=r.elements[12],C=r.elements[14],z=`${Math.floor(T/it.chunkSize)},${Math.floor(C/it.chunkSize)}`;t.has(z)||t.set(z,{positions:[],normals:[],colors:[]});const M=t.get(z);o.getNormalMatrix(r);for(let S=0;S<f.count;S++)s.fromBufferAttribute(f,S).applyMatrix4(r),a.fromBufferAttribute(v,S).applyMatrix3(o).normalize(),M.positions.push(s.x,s.y,s.z),M.normals.push(a.x,a.y,a.z),M.colors.push(g.r,g.g,g.b);if(x.material.side===yt)for(let S=0;S<f.count;S+=3)for(const G of[S+2,S+1,S])s.fromBufferAttribute(f,G).applyMatrix4(r),a.fromBufferAttribute(v,G).applyMatrix3(o).normalize().negate(),M.positions.push(s.x,s.y,s.z),M.normals.push(a.x,a.y,a.z),M.colors.push(g.r,g.g,g.b)}p!==x.geometry&&p.dispose(),c.add(x.geometry),d.add(x.material),x.isInstancedMesh&&x.dispose(),n.remove(x)}const u=new It({vertexColors:!0,side:yn}),h=[];let m=0;for(const[x,p]of t){const f=new rt;f.setAttribute("position",new Ve(p.positions,3)),f.setAttribute("normal",new Ve(p.normals,3)),f.setAttribute("color",new Ve(p.colors,3)),f.computeBoundingSphere();const v=new Le(f,u);v.name=`scenery ${x}`,n.add(v),h.push(v),m+=p.positions.length/9}const _=new Set;n.traverse(x=>{x.isMesh&&_.add(x.material)});for(const x of c)x.dispose();for(const x of d)_.has(x)||x.dispose();return{chunks:t.size,triangles:m,hidden:0,updateVisibility(x,p,f=!0){const v=x.matrixWorldInverse.elements;let g=0;for(const y of h){const R=y.geometry.boundingSphere,T=R.center,C=-(v[2]*T.x+v[6]*T.y+v[10]*T.z+v[14])-R.radius;y.visible=!f||C<=p+.1,y.visible||g++}return this.hidden=g,g},showAll(){for(const x of h)x.visible=!0;this.hidden=0}}}function Ls(n){const e=new Map,t=new It({vertexColors:!0}),i=new Qe,r=new N,s=new N,a=new Xe;let o=0;for(const l of n){const c=l.leaf||l.pivot,d=[...c.children].filter(x=>x.isMesh);o+=d.length;const u=JSON.stringify(d.map(x=>[x.geometry.parameters,x.position.toArray(),x.rotation.toArray(),x.scale.toArray(),x.material.color.getHex()]));let h=e.get(u),m=0;if(!h){const x=[],p=[],f=[];for(const[v,g]of d.entries()){g.updateMatrix(),i.copy(g.matrix),a.getNormalMatrix(i);const y=g.geometry.index?g.geometry.toNonIndexed():g.geometry,R=y.attributes.position,T=y.attributes.normal,C=g.material.color;v===0&&(m=R.count);for(let z=0;z<R.count;z++)r.fromBufferAttribute(R,z).applyMatrix4(i),s.fromBufferAttribute(T,z).applyMatrix3(a).normalize(),x.push(r.x,r.y,r.z),p.push(s.x,s.y,s.z),f.push(C.r,C.g,C.b);y!==g.geometry&&y.dispose()}h=new rt,h.setAttribute("position",new Ve(x,3)),h.setAttribute("normal",new Ve(p,3)),h.setAttribute("color",new Ve(f,3)),h.computeBoundingSphere(),h.userData.panelVertices=m,e.set(u,h)}for(const x of d)c.remove(x),x.geometry.dispose();const _=new Le(h,t);_.name=l.id+" leaf",c.add(_)}return{partsBefore:o,meshesAfter:n.length,sharedGeometries:e.size}}function rh(n){const e=[],t=[],i=[],r=[],s=new _t(1,1,1),a=new Map,o=h=>(a.has(h)||a.set(h,new It({color:h})),a.get(h));function l(h,m,_,x,p,f,v,g=!1){const y=new Le(s,o(v));return y.position.set(h,m,_),y.scale.set(x,p,f),n.add(y),g&&e.push({minX:h-x/2,maxX:h+x/2,minY:m-p/2,maxY:m+p/2,minZ:_-f/2,maxZ:_+f/2}),y}l(0,-.1,0,500,.2,500,10864267);for(const h of[-36,4,36])l(0,.012,h,84,.024,6,8558487);for(const h of[-40,8,40])l(h,.014,0,6,.028,78,8558487);for(let h=-36;h<=36;h+=5)l(h,.03,4,2,.02,.14,16772533);for(const[h,m]of[[-20,-12],[-5,-21],[24,-20],[-22,21]]){const _={id:r.length===0?"home":["cafe","library","workshop"][r.length-1],x:h,z:m,w:12,d:10,angle:r.length===3?Math.PI:0,wall:[15780251,15251368,12111037,13944996][r.length],roof:5209465};r.push(_);const x=Math.cos(_.angle),p=Math.sin(_.angle),f=(y,R)=>({x:h+y*x+R*p,z:m-y*p+R*x}),v=(y,R,T,C,z,M,S,G=!1)=>{const I=f(y,T);return l(I.x,R,I.z,C,z,M,S,G)};v(0,.025,0,12,.05,10,15127212),v(-6,1.6,0,.22,3.2,10,_.wall,!0),v(6,1.6,0,.22,3.2,10,_.wall,!0),v(0,1.6,-5,12,3.2,.22,_.wall,!0),v(-4.05,1.6,5,3.9,3.2,.22,_.wall,!0),v(2.65,1.6,5,6.7,3.2,.22,_.wall,!0),v(-1.4,2.77,5,1.4,.86,.22,_.wall,!0),v(0,3.27,0,12.8,.2,10.8,_.roof,!0);for(const y of[1.5,4])v(y,1.75,5.15,1.6,1.2,.08,9486022),v(y,1.75,5.21,.06,1.3,.08,16773589),v(y,2.35,5.21,1.7,.08,.08,16773589);ao({scene:n,material:o,doors:t,h:_,local:f}),i.push({id:_.id,x:h,z:m,y:0});const g=(y,R)=>{v(y,.72,R,1.6,.14,1,11501653,!0);for(const T of[-.65,.65])for(const C of[-.35,.35])v(y+T,.34,R+C,.1,.68,.1,8743505)};if(g(2,0),v(2,.36,1.3,1,.72,.65,9942170,!0),v(2,.8,1.6,1,.3,.12,9942170),_.id==="home"&&(v(-3,.32,-2,2.4,.64,3,12029801,!0),v(-3,.72,-2,2.3,.2,2.9,15846028),v(-3,.88,-3,1.8,.25,.6,16774879),v(3,.7,-3,3,1.4,.7,8496284,!0)),_.id==="cafe"&&(v(-3,.7,-2,3.5,1.4,1,12553574,!0),v(-3,1.45,-2,3.7,.1,1.1,16772304),g(2,-3)),_.id==="library")for(const y of[-4,0,4]){v(y,1.1,-3,2.3,2.2,.5,11766370,!0);for(let R=0;R<5;R++)v(y-.8+R*.38,1.45,-2.69,.25,.7,.12,[14588270,7905945,14730099][R%3])}_.id==="workshop"&&(v(-3,.85,-2,3,1.7,1.2,11055526,!0),v(3,.5,-3,2,1,1.5,14923112,!0)),_.id==="home"&&Cs({scene:n,material:o,doors:t,h:_,put:v,local:f})}for(const[h,m]of[[-34,15],[-10,30],[28,7],[30,31],[-32,-27],[13,-32],[34,-7],[-3,15]])l(h,1,m,.35,2,.35,10123350,!0),l(h,2.5,m,3.1,2.5,3.1,6790008);for(const[h,m]of[[17,12],[25,12]])l(h,.42,m,2.5,.16,.8,11701090,!0),l(h,.75,m+.36,2.5,.55,.12,11701090);l(30,.03,25,10,.04,8,8568778),l(15,.3,22,2,.6,2,13872254,!0),l(15,.7,22,1.8,.3,1.8,9678199);const c=new Le(new Nn(500,500),new Oi({visible:!1}));c.rotation.x=-Math.PI/2,n.add(c),c.updateMatrixWorld();const d=Ls(t),u=Ps(n,new Set([...t.map(h=>h.pivot),c]));return{ground:c,solids:e,doors:t,houses:r,rooms:i,roads:[],doorRender:d,staticRender:u,landmarks:[{name:"Home",icon:"⌂",x:-20,z:0},{name:"Square",icon:"☀",x:18,z:7},{name:"Library",icon:"📚",x:22.6,z:-10},{name:"Workshop",icon:"🛠",x:-20.6,z:13},{name:"Garden",icon:"🌷",x:22,z:20},{name:"Garage",icon:"🚗",x:-28,z:1}]}}const Zl=[{id:"sunbeam-cottage",name:"Sunbeam cottage",icon:"🏡",x:-21,z:-46,w:12,d:10,angle:0,wall:15123870,roof:10256756,garage:!0,kind:"home"},{id:"bluebell-house",name:"Bluebell house",icon:"🏠",x:22,z:-46,w:14,d:10,angle:0,wall:11847630,roof:7243909,garage:!0,kind:"home"},{id:"orchard-home",name:"Orchard home",icon:"🍎",x:-51,z:-13,w:12,d:10,angle:Math.PI/2,wall:13879200,roof:10454885,kind:"home"},{id:"school",name:"Sunbeam school",icon:"🎨",x:50,z:-22,w:16,d:10,angle:Math.PI/2,wall:14076320,roof:6852491,kind:"school"},{id:"clinic",name:"Friendly clinic",icon:"✚",x:50,z:4,w:12,d:10,angle:Math.PI/2,wall:13819347,roof:9349276,kind:"clinic"},{id:"bakery",name:"Little bakery",icon:"🥐",x:22,z:25,w:12,d:10,angle:0,wall:15055525,roof:10782067,kind:"bakery"},{id:"garden-studio",name:"Garden studio",icon:"🌿",x:-7,z:47,w:12,d:10,angle:Math.PI,wall:12110250,roof:7771788,kind:"garden"},{id:"stable",name:"Orchard stables",icon:"🐴",x:-51,z:29,w:16,d:10,angle:Math.PI/2,wall:12950905,roof:9205610,kind:"stable"}];function sh(n){const e=rh(n),t=new ft;n.add(t);const i=[],r=[],s=[],a=[],o=[],l=[],c=new _t(1,1,1),d=new Map,u=g=>(d.has(g)||d.set(g,new It({color:g})),d.get(g));function h(g,y,R,T,C,z,M,S=!1,G=0){const I=new Le(c,u(M));if(I.position.set(g,y,R),I.rotation.y=G,I.scale.set(T,C,z),t.add(I),S){const W=Math.cos(G),L=Math.sin(G),U=(Math.abs(W)*T+Math.abs(L)*z)/2,B=(Math.abs(L)*T+Math.abs(W)*z)/2;i.push({minX:g-U,maxX:g+U,minY:y-C/2,maxY:y+C/2,minZ:R-B,maxZ:R+B,obb:{cx:g,cz:R,c:W,s:L,halfW:T/2,halfD:z/2}})}return I}function m(g,y,R,T=0,C=0){const z={x:y-.5,y:C,z:R-.5,type:g,rotation:T},M=ai(z);M.updateMatrixWorld(!0),M.traverse(S=>{if(S.isMesh){const G=new Le(S.geometry.clone().applyMatrix4(S.matrixWorld),S.material);t.add(G)}}),i.push(...et(z)),["chair","armchair","sofa","bench","stool"].includes(g)&&l.push({x:y,y:C,z:R,rotation:T})}function _(g,y,R,T){if(typeof document>"u")return;const C=document.createElement("canvas");C.width=512,C.height=96;const z=C.getContext("2d");z.fillStyle="#fff2d4",z.fillRect(0,0,512,96),z.fillStyle="#315f54",z.textAlign="center",z.font="bold 36px sans-serif",z.fillText(g,256,62);const M=new Fc(new eo({map:new fr(C),depthTest:!0}));M.position.set(y,R,T),M.scale.set(5.5,1,1),t.add(M),o.push(M)}const x=[{x:0,z:-56,w:126,d:6},{x:0,z:56,w:126,d:6},{x:-60,z:0,w:6,d:118},{x:60,z:0,w:6,d:118},{x:8,z:0,w:6,d:118}];for(const g of x)h(g.x,.014,g.z,g.w,.028,g.d,8689812);for(const g of Zl){a.push(g);const y=Math.cos(g.angle),R=Math.sin(g.angle),T=(L,U)=>({x:g.x+L*y+U*R,z:g.z-L*R+U*y}),C=(L,U,B,X,K,ie,ne,ue=!1)=>{const de=T(L,B);return h(de.x,U,de.z,X,K,ie,ne,ue,g.angle)},z=g.d/2,M=g.w/2-2;C(0,.025,0,g.w,.05,g.d,14667178);for(const L of[-g.w/2,g.w/2])C(L,1.6,0,.22,3.2,g.d,g.wall,!0);C(0,1.6,-z,g.w,3.2,.22,g.wall,!0);for(const[L,U]of[[-g.w/2,-2.1],[-.7,M-.9],[M+.9,g.w/2]])U>L&&C((L+U)/2,1.6,z,U-L,3.2,.22,g.wall,!0);C(-1.4,2.76,z,1.4,.88,.22,g.wall,!0),C(M,.45,z,1.8,.9,.22,g.wall,!0),C(M,2.75,z,1.8,.9,.22,g.wall,!0),C(M,1.6,z,1.8,1.4,.08,10471628,!0);for(const L of[M-.9,M,M+.9])C(L,1.6,z+.07,.06,1.5,.16,16772555);C(0,3.25,0,g.w+.6,.18,g.d+.6,g.roof,!0),(g.kind==="home"||g.kind==="stable")&&(C(0,3.6,0,g.w+.2,.5,g.d-.2,g.roof,!0),C(0,4,0,g.w-.8,.3,g.d-2,g.roof,!0)),ao({scene:t,material:u,doors:r,h:g,local:T}),g.garage&&Cs({scene:t,material:u,doors:r,h:g,put:C,local:T}),s.push({id:g.id,x:g.x,y:0,z:g.z});const S=(L,U,B,X=0)=>{const K=T(U,B);m(L,K.x,K.z,g.angle*180/Math.PI+X)};if(g.kind==="home"&&(S("double-bed",-3,-2),S("wardrobe",3,-3),S("sofa",2,1),S("coffee-table",2,-.3),S("floor-lamp",4,1),S("kitchen-counter",-4,1),S("sink",-3,1)),g.kind==="school"){for(const L of[-5,-2,2,5])S("desk",L,-1.5),S("chair",L,.2);S("bookcase",4,-4),S("toy-box",-5,-4)}if(g.kind==="clinic"&&(S("single-bed",-3,-1),S("washbasin",4,-3),S("desk",3,.5),S("chair",3,2),S("wall-cupboard",4,3.5)),g.kind==="bakery"){for(const L of[-4,-3,-2])S("kitchen-counter",L,-3);S("oven",1,-3),S("fridge",3,-3),S("dining-table",3,1),S("chair",3,2.5)}if(g.kind==="garden"){for(const L of[-4,0,4])S("planter",L,-3);S("workbench",3,0),S("garage-shelf",-4,0)}if(g.kind==="stable"){for(const L of[-5,4])S("rail-fence",L,-2),S("storage-crate",L,1);S("workbench",5,3)}const G=T(-1.4,z),I=T(-1.4,z+3);h((G.x+I.x)/2,.008,(G.z+I.z)/2,2.2,.012,3,15127469,!1,g.angle);const W=T(0,z+.2);_(g.name,W.x,2.8,W.z)}const p=[{x:-51,z:8,w:12,d:12},{x:51,z:37,w:12,d:14},{x:-5,z:-47,w:10,d:10},{x:22,z:47,w:12,d:10}];for(const g of p)h(g.x,.005,g.z,g.w,.008,g.d,11914902),_("BUILD HERE",g.x,1.2,g.z+g.d/2);m("play-slide",-1,22),m("sandpit",-6,25),m("goal",1,31),m("bench",0,17),m("bench",18,18),m("flower-bed",-12,6),m("flower-bed",31,9),m("pergola",17,44),m("dining-table",17,44),m("chair",17,46),m("street-lamp",13,0),m("street-lamp",-10,8);for(const g of[-55,-43,-4,8,40,55])for(const y of[-64,64])m("oak-tree",g,y);for(const g of[-68,68])for(const y of[-40,-12,16,40])m("pine-tree",g,y);for(const g of[-12,-8,-4])for(const y of[28,31])m("fruit-tree",g,y);const f=Ls(r),v=Ps(t,new Set([...r.map(g=>g.pivot),...o]));return{...e,houses:[...e.houses,...a],rooms:[...e.rooms,...s],doors:[...e.doors,...r],solids:[...e.solids,...i],plots:p,activities:[{x:-1.5,y:0,z:21.5,type:"play-slide"}],seats:l,mapRoads:[...[-36,4,36].map(g=>({x:0,z:g,w:84,d:6})),...[-40,8,40].map(g=>({x:g,z:0,w:6,d:78})),...x],activityRange:70,landmarks:[...e.landmarks,...Zl.map(g=>{const y=Math.cos(g.angle),R=Math.sin(g.angle);return{name:g.name,icon:g.icon,x:g.x-1.4*y+(g.d/2+3)*R,z:g.z+1.4*R+(g.d/2+3)*y}}),{name:"Play park",icon:"🛝",x:0,z:20},{name:"Orchard plots",icon:"🧱",x:-51,z:8}],staticRender:{updateVisibility(g,y){e.staticRender.updateVisibility(g,y),v.updateVisibility(g,y)}},extraDoorRender:f}}class Qm{group=new ft;solids=[];seats=[];props=[];labels=[];geometry=new _t(1,1,1);materials=new Map;constructor(e){e.add(this.group)}material=e=>(this.materials.has(e)||this.materials.set(e,new It({color:e})),this.materials.get(e));box=(e,t,i,r,s,a,o,l=!1,c=0)=>{const d=new Le(this.geometry,this.material(o));if(d.position.set(e,t,i),d.scale.set(r,s,a),d.rotation.y=c,this.group.add(d),l){const u=Math.cos(c),h=Math.sin(c),m=(Math.abs(u)*r+Math.abs(h)*a)/2,_=(Math.abs(h)*r+Math.abs(u)*a)/2;this.solids.push({minX:e-m,maxX:e+m,minY:t-s/2,maxY:t+s/2,minZ:i-_,maxZ:i+_,obb:{cx:e,cz:i,c:u,s:h,halfW:r/2,halfD:a/2}})}return d};object(e,t,i,r=0,s=0,a){var c;const o={x:t-.5,y:s,z:i-.5,type:e,rotation:r},l=ai(o);return a?(this.group.add(l),this.props.push({id:a,block:o,model:l})):(l.updateMatrixWorld(!0),l.traverse(d=>{d.isMesh&&this.group.add(new Le(d.geometry.clone().applyMatrix4(d.matrixWorld),d.material))}),this.solids.push(...et(o))),(((c=Lt.get(e))==null?void 0:c.interaction)==="seat"||e==="bench")&&this.seats.push({x:t,y:s,z:i,rotation:r}),o}label=(e,t,i,r,s=0,a=5.5)=>{if(typeof document>"u")return;const o=document.createElement("canvas");o.width=512,o.height=96;const l=o.getContext("2d");l.fillStyle="#fff1d5",l.fillRect(0,0,512,96),l.fillStyle="#315d52",l.font="bold 34px sans-serif",l.textAlign="center",l.fillText(e,256,62);const c=new Fc(new eo({map:new fr(o)}));c.position.set(t,i,r),c.scale.set(a,1,1),this.labels.push(c),this.group.add(c)};finish(e){return Ps(this.group,new Set([...e.map(t=>t.pivot),...this.labels]))}}const $l=[{id:"cedar-villa",name:"Cedar villa",x:-111,z:-105,w:16,d:14,angle:0,style:"gable",storeys:2,garage:!0,kind:"home"},{id:"courtyard-home",name:"Courtyard home",x:-73,z:-105,w:18,d:14,angle:0,style:"hip",garage:!0,kind:"home"},{id:"oak-house",name:"Oak family house",x:-35,z:-105,w:18,d:14,angle:0,style:"hip",storeys:2,kind:"home"},{id:"lakeside-lodge",name:"Lakeside lodge",x:4,z:-105,w:16,d:14,angle:0,style:"shed",kind:"home"},{id:"bookshop",name:"Storybook shop",x:42,z:-104,w:18,d:12,angle:0,style:"gable",kind:"books"},{id:"grocer",name:"Garden grocer",x:-112,z:-49,w:16,d:12,angle:Math.PI/2,style:"shed",kind:"grocer"},{id:"museum",name:"Discovery museum",x:-112,z:-12,w:20,d:14,angle:Math.PI/2,style:"hip",kind:"museum"},{id:"community",name:"Community hall",x:-112,z:30,w:22,d:16,angle:Math.PI/2,style:"gable",kind:"community"},{id:"farmhouse",name:"Willow farmhouse",x:-111,z:81,w:18,d:16,angle:Math.PI/2,style:"gable",storeys:2,garage:!0,kind:"home"},{id:"farm-barn",name:"Willow farm barn",x:-70,z:108,w:22,d:14,angle:Math.PI,style:"gable",kind:"farm"},{id:"animal-care",name:"Animal care lodge",x:-33,z:108,w:18,d:12,angle:Math.PI,style:"hip",kind:"animals"},{id:"boathouse",name:"Lakeside boathouse",x:111,z:-65,w:20,d:12,angle:0,style:"shed",kind:"lake"},{id:"greenhouse",name:"Botanical conservatory",x:111,z:13,w:18,d:12,angle:-Math.PI/2,style:"shed",kind:"garden"},{id:"trail-cafe",name:"Woodland trail cafe",x:111,z:64,w:18,d:12,angle:-Math.PI/2,style:"hip",kind:"cafe"}];function eg(n,e=2){const t=sh(n),i=new Qm(n),r=[],s=[],a=[],o=[],l=[],c=[{x:0,z:-82,w:180,d:7},{x:0,z:82,w:180,d:7},{x:-86,z:0,w:7,d:171},{x:86,z:0,w:7,d:171},...[-60,8,60].flatMap(x=>[{x,z:-70,w:6,d:24},{x,z:70,w:6,d:24}]),...[-56,4,56].flatMap(x=>[{x:-73,z:x,w:26,d:6},{x:73,z:x,w:26,d:6}])];for(const x of c)i.box(x.x,.014,x.z,x.w,.028,x.d,8558225);for(const x of[-87.5,87.5])i.box(0,.02,x,184,.03,2,14536623);for(const x of[-91.5,91.5])i.box(x,.02,0,2,.03,174,14536623);for(const x of[-86,8,86])for(const p of[-82,82])for(let f=-2;f<=2;f++)i.box(x+f*1.2,.035,p,.6,.01,6,15919569);for(let x=0;x<$l.length;x++){const p=$l[x],f={...p,rooms:p.kind==="home",wall:[14272676,12044734,13678496,13949378][x%4],roof:[9531229,7178880,10914406][x%3]};a.push(f);const v=Math.cos(f.angle),g=Math.sin(f.angle),y=(M,S)=>({x:f.x+M*v+S*g,z:f.z-M*g+S*v}),R=(M,S,G,I,W,L,U,B=!1)=>{f.storeys===2&&Math.abs(S-3.11)<.001&&Math.abs(G+f.d/2-.6)<.001&&Math.abs(L-1.2)<.001&&(G+=.1,L+=.2);const X=y(M,G);return i.box(X.x,S,X.z,I,W,L,U,B,f.angle)};ih({h:f,put:R,local:y,scene:i.group,material:i.material,doors:r,solids:i.solids,label:i.label,rooms:s});const T=(M,S,G,I=0,W=0,L)=>{const U=y(S,G);i.object(M,U.x,U.z,f.angle*180/Math.PI+I,W,L?`${f.id}:${L}`:void 0)};if(f.kind==="home")T("sofa",2,2),T("coffee-table",2,.5),T("kitchen-island",-4,1.8),T("sink",-4,-1.5),T("fridge",-5,-3),T("coat-rack",4,3),T("floor-lamp",4,1,0,0,"light"),e===1?T("wall-cupboard",-f.w/2+.3,2,90,1.3,"cupboard"):T("dining-hutch",-f.w/2+.6,2.5,90,0,"cupboard"),f.storeys===2&&(T("double-bed",-4,-4,0,3.2),T("desk",1,-4,0,3.2),T("armchair",1,2,0,3.2),o.push({id:f.id,...y(f.w/2-1.2,f.d/2-1.2),yaw:f.angle,length:f.d-2.8}));else if(f.kind==="books"){for(const M of[-5,2,5])T("bookcase",M,-3);T("round-table",3,1),T("chair",3,3),T("rocking-chair",-5,2)}else if(f.kind==="grocer"){for(const M of[-4,0,4])T("garage-shelf",M,-3),T("storage-crate",M,2);T("kitchen-counter",3,0)}else if(f.kind==="museum")T("fluted-column",-5,0),T("toy-train",3,1,0,.81),T("dining-table",3,1),T("chalkboard",5,-4),T("picture-frame",0,-5,0,1),T("bench",-5,3);else if(f.kind==="community"){for(const M of[-6,2,6])T("round-table",M,0),T("chair",M,2);T("toy-box",-7,-5),T("chalkboard",5,-6)}else if(f.kind==="farm"||f.kind==="animals"){for(const M of[-5,3])T("feeding-trough",M,-2),T("hay-bale",M,2);T("chicken-coop",5,-3),T("kennel",-5,-4),T("workbench",5,3)}else if(f.kind==="garden"){for(const M of[-5,0,5])T("raised-bed",M,-3);T("fern",4,2),T("workbench",-5,2),T("watering-can",-5,2,0,.96)}else if(f.kind==="cafe"){T("corner-counter",-5,-3),T("kettle",-5,-3,0,1.1);for(const M of[1,5])T("round-table",M,0),T("chair",M,2);T("armchair",-5,2)}else f.kind==="lake"&&(T("workbench",-5,-3),T("garage-shelf",5,-3),T("bench",4,2),T("picture-frame",0,-5,0,1.1));const C=y(-1.4,f.d/2+4);l.push({name:f.name,icon:f.kind==="home"?"🏠":f.kind==="farm"?"🐄":"⌂",...C}),R(-1.4,.02,f.d/2+6,2,.025,12,14864298);const z=y(0,f.d/2+.25);i.label(f.name,z.x,2.85,z.z,f.angle)}const d=[{x:111,z:-113,w:44,d:30,shore:{x:84,z:-110}}];i.box(111,.018,-113,44,.025,30,8501446);for(const x of[84,138])i.box(x,.02,-113,2,.025,40,14272675);for(const x of[-133,-93])i.box(111,.02,x,54,.025,2,14272675);i.object("bench",84,-115,90),i.object("willow",80,-127),i.object("willow",138,-96),i.object("street-sign",84,-92),l.push({name:"Willow lake",icon:"💧",x:84,z:-110},{name:"Lakeside lookout",icon:"☀",x:138,z:-112});for(const x of[122,145])for(let p=-87;p<=-60;p+=3)i.object("rail-fence",p,x);for(const x of[-89,-58])for(let p=125;p<=142;p+=3)i.object("rail-fence",x,p,90);i.object("feeding-trough",-73,125),i.object("hay-bale",-83,141),i.object("chicken-coop",-60,116),l.push({name:"Farm paddock",icon:"🐴",x:-72,z:119});for(const x of[36,53,70,87,104,121,138])for(const p of[104,121,138])x===70&&p===121||i.object((x+p)%2?"birch":"pine-tree",x,p);const u=[{x:30,z:98},{x:70,z:98},{x:96,z:118},{x:70,z:132},{x:30,z:132}];for(let x=0;x<u.length;x++){const p=u[x],f=u[(x+1)%u.length],v=Math.hypot(f.x-p.x,f.z-p.z),g=Math.atan2(f.x-p.x,f.z-p.z);i.box((p.x+f.x)/2,.02,(p.z+f.z)/2,2,.025,v,14010276,!1,g),i.object("street-sign",p.x-2,p.z)}i.object("pond-bridge",96,119),i.object("bench",69,127),i.object("round-table",69,124),i.object("flower-arch",30,96),i.object("swing",-10,111,0,0,"region:swing"),i.object("seesaw",-4,111,0,0,"region:seesaw"),i.object("trampoline",3,111,0,0,"region:trampoline"),i.object("play-slide",9,111,0,0,"region:slide"),l.push({name:"Woodland trail",icon:"🌲",x:30,z:98},{name:"Forest picnic",icon:"☀",x:69,z:130},{name:"Adventure playground",icon:"🛝",x:-10,z:106});const h=[...t.plots,{x:25,z:108,w:14,d:14},{x:54,z:108,w:14,d:14},{x:-115,z:123,w:16,d:14},{x:117,z:91,w:14,d:14}];for(const x of h.slice(4))i.box(x.x,.008,x.z,x.w,.012,x.d,11980438),i.label("BUILD HERE",x.x,1.2,x.z+x.d/2);const m=[...t.solids,...i.solids],_=i.finish(r);return Ls(r),{...t,layout:e,houses:[...t.houses,...a],rooms:[...t.rooms,...s],doors:[...t.doors,...r],solids:[...m,...i.props.flatMap(x=>et(x.block))],staticSolids:m,authoredProps:i.props,seats:[...t.seats,...i.seats],stairs:o,plots:h,landmarks:[...t.landmarks,...l],waterAreas:d,mapRoads:[...t.mapRoads,...c],activityRange:148,staticRender:{updateVisibility(x,p){t.staticRender.updateVisibility(x,p),_.updateVisibility(x,p)}}}}function tg({box:n,bench:e,scene:t,material:i,reserved:r}){const c=(u,h)=>{n(u,.76,h,2.5,.15,1.2,9725511,!0);for(const m of[-.95,.95]){n(u,.43,h+m,2.5,.13,.45,9725511,!0);for(const _ of[-.85,.85])n(u+_,.22,h+m,.12,.44,.35,5992562,!0)}for(const m of[-.8,.8])n(u+m,.36,h,.16,.72,.9,5992562,!0)},d=(u,h)=>{for(const m of[-3.3,3.3])for(const _ of[-2.5,2.5])n(u+m,1.5,h+_,.18,3,.18,9725511,!0);n(u,3.08,h,7.3,.18,5.8,4488320,!0),c(u,h)};n(66,.006,46,29,.012,29,10993279),n(67,.012,43,22,.018,17,14995099);for(const u of[58,64])n(u,1.8,38,.2,3.6,.2,9725511,!0);n(61,3.55,38,6.5,.2,.22,4488320,!0);for(const u of[60,62]){for(const h of[-.3,.3])n(u+h,2.18,38,.035,2.4,.035,5992562);n(u,1,38,.85,.15,.5,11365457,!0)}for(const u of[-1,1])for(const h of[-1,1])n(73+u,1.15,39+h,.15,2.3,.15,9725511,!0);n(73,1.25,39,2.2,.15,2.2,4488320,!0);for(const u of[72,74])n(u,2,38,.12,1.4,.12,9725511,!0);n(73,2.68,39,2.6,.15,2.6,4488320,!0);for(let u=.22;u<1.3;u+=.22)n(73,u,40.1,1.5,.09,.18,16774617);if(!r({minX:74,maxX:79,minZ:38,maxZ:40,minY:0,maxY:2})){const u=new rt;u.setAttribute("position",new Ve([74,1.32,38.4,74,1.32,39.6,77.8,.12,39.6,74,1.32,38.4,77.8,.12,39.6,77.8,.12,38.4],3)),u.computeVertexNormals();const h=i(15118451).clone();h.side=yt,t.add(new Le(u,h))}n(60,.06,48,5,.12,4.2,9725511),n(60,.13,48,4.6,.14,3.8,14995099),n(69,.22,49,.6,.44,1.2,4488320,!0),n(69,.5,49,4.4,.14,.5,11365457,!0);for(const u of[67.2,70.8])n(u,.7,49,.1,.5,.1,16774617),n(u,.79,49,.4,.08,.08,16774617);e(56,44,-Math.PI/2),e(61,55,0),d(82,66);for(const u of[51,81])for(const h of[40,49])n(u,.45,h,.12,.9,.12,9725511,!0),n(u,.65,h,.12,.1,5,9725511,!0);d(195,82),c(204,91),e(204,64,0),e(178,77,-Math.PI/2),e(179,91,-Math.PI/2);for(const u of[190,202]){n(u,.18,64,3.5,.36,1.4,5933922,!0);for(const h of[-1,0,1])n(u+h,.42,64,.4,.2,.4,14728124)}c(-67,-111),n(-74,.5,-113,1.4,1,.14,9725511,!0),n(-74,1.2,-113,2.2,.6,.12,4488320)}const ah=[{id:"orchid",name:"Orchid family house",x:-55,z:-14,w:11,d:9,angle:0,wall:14728124,roof:7042704,style:"hip",garage:!0,garden:1},{id:"cedar",name:"Cedar lodge",x:-78,z:-16,w:7,d:11,angle:0,wall:14268559,roof:4488320,style:"gable",porch:3.6,garden:2},{id:"sunflower",name:"Sunflower courtyard",x:-59,z:24,w:12,d:7,angle:Math.PI,wall:15851437,roof:11365457,style:"shed",garage:!0,garden:3},{id:"bluebell",name:"Bluebell cottage",x:-84,z:-44,w:6,d:7,angle:-Math.PI/2,wall:11914194,roof:7108992,style:"gable",garden:2},{id:"maple",name:"Maple garden house",x:-54,z:-61,w:10,d:10,angle:Math.PI,wall:15185051,roof:7042704,style:"hip",garage:!0,garden:1},{id:"fern",name:"Fern studio",x:-23,z:-62,w:6,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"shed",porch:3.2,garden:3},{id:"bakery",name:"Sunrise bakery",x:44,z:-42,w:10,d:8,angle:0,wall:15851437,roof:11365457,style:"gable",shop:!0,sign:"BAKERY",garden:0},{id:"market",name:"Village market",x:60,z:-43,w:10,d:10,angle:0,wall:12177332,roof:4488320,style:"hip",shop:!0,sign:"MARKET",garden:0},{id:"pottery",name:"Clay corner",x:32,z:-25,w:8,d:9,angle:Math.PI/2,wall:14728124,roof:7042704,style:"shed",shop:!0,sign:"POTTERY",garden:0},{id:"workshop",name:"Oak workshop",x:92,z:-17,w:11,d:10,angle:-Math.PI/2,wall:14268559,roof:7108992,style:"gable",shop:!0,sign:"WORKSHOP",garage:!0,garden:0},{id:"willow",name:"Willow retreat",x:-10,z:-94,w:7,d:6,angle:Math.PI,wall:12177332,roof:4488320,style:"hip",porch:3.4,garden:2},{id:"pavilion",name:"Orchard shelter",x:103,z:90,w:8,d:6,angle:-Math.PI/2,wall:15851437,roof:11365457,style:"gable",porch:4,garden:2},...Lm],ng=[[[-124,6],[-103,6],[-85,6],[-66,3],[-49,3],[-35,6],[-20,6],[-6,6],[6,8.6],[17,9],[26,4],[35,3],[50,2],[65,-8],[72,-28],[70,-55],[52,-68],[25,-66],[-10,-77],[-45,-78],[-80,-69],[-98,-48],[-99,-18],[-85,6]],[[72,-28],[92,-52],[115,-53]],...Dm],ig=[[[-35,6],[-36,40],[-45,61],[-41,80],[-15,87],[15,86],[45,86],[66,67],[50,60],[50,33],[53,25],[50,2]],[[45,86],[66,98],[81,94],[94,91],[95,77],[108,62],[104,42],[82,30],[84,41],[84,54],[73,62],[66,67]],[[-80,-69],[-86,-90],[-65,-103],[-45,-108],[-21,-112],[-3,-105],[18,-117],[44,-109],[47,-90],[25,-66]],[[-10,-77],[-18,-89],[-14,-102],[-3,-105]],[[41,-33],[41,-18],[49,-12],[65,-8]],[[18,-117],[18,-104],[37,-103],[47,-90]],...Im];function Xt(n,e,t){let i=1/0,r=null;for(let s=1;s<t.length;s++){const a=t[s-1],o=t[s],l=o[0]-a[0],c=o[1]-a[1],d=Math.max(0,Math.min(1,((n-a[0])*l+(e-a[1])*c)/(l*l+c*c))),u={x:a[0]+l*d,z:a[1]+c*d},h=Math.hypot(n-u.x,e-u.z);h<i&&(i=h,r=u)}return{distance:i,point:r}}function cr(n){let e=n;for(let t=0;t<2;t++){const i=[e[0]];for(let r=1;r<e.length;r++){const s=e[r-1],a=e[r];i.push([s[0]*.75+a[0]*.25,s[1]*.75+a[1]*.25],[s[0]*.25+a[0]*.75,s[1]*.25+a[1]*.75])}i.push(e.at(-1)),e=i}return e}function rg({scene:n,box:e,material:t,bench:i,disk:r,roads:s,trails:a,drives:o,houses:l,clearings:c,treeAllowed:d,treePositions:u}){e(-8,.006,-197,70,.012,18,14141609);for(const v of[-32,-8,16])e(v,.25,-205.5,3,.5,3,11906454,!0),e(v,.54,-205.5,2.6,.08,2.6,7052647),i(v===-8?-16:v,-190,0);for(const v of[-5,5])for(const g of[-204,-199])e(v,1.5,g,.18,3,.18,9725511,!0);for(const v of[-204,-199])e(0,2.98,v,10.4,.18,.22,9725511,!0);for(let v=-5;v<=5;v+=1)e(v,3.08,-201.5,.15,.16,6,9725511);e(188,.006,-103,14,.012,21,14141609);for(const v of[-116,-104,-92])i(187,v,Math.PI/2);for(const v of[199,203,207,211])for(const g of[-27,-34]){e(v,.2,g,2.5,.4,4,9725511,!0),e(v,.43,g,2.2,.06,3.7,7052647);for(let y=0;y<4;y++)e(v,.65,g-1.2+y*.8,.4,.38,.4,y%2?15118451:14728124)}for(const v of Jr){r(v.x,v.z,v.rx+1.6,v.rz+1.6,14141609,.008),r(v.x,v.z,v.rx,v.rz,7515836,.026);for(let g=0;g<30;g++){const y=g*Math.PI*2/30,R=v.x+Math.cos(y)*(v.rx+.7),T=v.z+Math.sin(y)*(v.rz+.7);Math.abs(R-v.x)<2||(e(R,.4,T,.055,.8,.055,5474391),e(R,.85,T,.11,.18,.11,9725511))}}e(-18,.006,200,20,.012,9,14141609);for(const v of[-76,-70,-64])for(let g=216;g<=234;g+=2)e(v,.12,g,3,.24,1.6,9725511),e(v,.38,g,2.6,.3,1.3,g%4?7052647:15118451);const m=[];for(let v=0;v<20;v++){const g=v*.56;m.push({x:-110+Math.cos(g)*(9+Math.floor(v/7)*4),z:232+Math.sin(g)*(7+Math.floor(v/7)*2),fruit:!0})}const _=[[-210,-190,26,29],[-71,-225,26,10],[181,-185,44,24],[-214,111,19,34],[66,232,43,10],[220,164,17,32],[-220,214,14,22]];let x=19052;const p=()=>(x=Math.imul(x,1664525)+1013904223>>>0,x/4294967296),f=(v,g)=>!!(Math.abs(v)<128&&Math.abs(g)<128||l.some(y=>{const R=Math.abs(Math.cos(y.angle)),T=Math.abs(Math.sin(y.angle));return Math.abs(v-y.x)<(y.w*R+y.d*T)/2+10&&Math.abs(g-y.z)<(y.w*T+y.d*R)/2+10})||[...s,...a].some(y=>Xt(v,g,y).distance<5.3)||o.some(y=>Xt(v,g,y.points).distance<4)||c.some(y=>Math.abs(v-y.x)<y.w/2+4&&Math.abs(g-y.z)<y.d/2+4)||Jr.some(y=>((v-y.x)/(y.rx+5))**2+((g-y.z)/(y.rz+5))**2<1)||Wc.some(y=>Math.hypot(v-(y.signX??y.x+4),g-(y.signZ??y.z+4))<5)||Math.abs(v-197)<18&&Math.abs(g-84)<15||Math.abs(v+8)<39&&Math.abs(g+197)<14||v>-85&&v<-55&&g>208);for(let v=0;v<2100;v++){const g=_[v%_.length],y=p()*Math.PI*2,R=Math.sqrt(p()),T=g[0]+Math.cos(y)*g[2]*R,C=g[1]+Math.sin(y)*g[3]*R;f(T,C)||m.some(z=>Math.hypot(T-z.x,C-z.z)<4.1)||m.push({x:T,z:C})}for(const[v,g]of[[-223,-73],[-143,12],[-205,76],[-143,82],[91,-202],[120,-169],[199,-8],[178,123],[113,222],[-50,235],[-231,159]])for(const[y,R]of[[0,0],[5,4],[-4,6]])f(v+y,g+R)||m.push({x:v+y,z:g+R});for(const[v,g]of m.entries()){if(!d(g.x,g.z))continue;u.push({x:g.x,z:g.z});const y=g.fruit?2.2:2.8+v%4*.4;e(g.x,y/2,g.z,.4,y,.4,9725511,!0);const R=!g.fruit&&v%3===0,T=R?new pr(2.2,4.8,7):new mr(1,1);R||T.scale(2.2,2.05,2.2);const C=new Le(T,t(R?5082472:v%2?7052647:5933922));if(C.position.set(g.x,y+.7,g.z),n.add(C),g.fruit)for(const z of[-1,1])e(g.x+z,y+.5,g.z+.4,.22,.22,.22,13075044)}return{trees:m.length,groves:_.length,ponds:Jr.length}}function oh(n,e){if(n.kind==="roller"){const u=Math.cos(n.baseAngle),h=Math.sin(n.baseAngle),m=n.width/2,_=.055,x=n.center.x,p=n.center.z,f=Math.abs(u)*m+Math.abs(h)*_,v=Math.abs(h)*m+Math.abs(u)*_,g=Math.min(1,Math.max(0,e/(Math.PI/2)));return{minX:x-f,maxX:x+f,minZ:p-v,maxZ:p+v,minY:n.height*g,maxY:n.height,obb:{cx:x,cz:p,c:u,s:h,halfW:m,halfD:_},door:!0}}const t=n.baseAngle+e,i=Math.cos(t),r=Math.sin(t),s=n.width/2,a=.055,o=n.hinge.x+i*s,l=n.hinge.z-r*s,c=Math.abs(i)*s+Math.abs(r)*a,d=Math.abs(r)*s+Math.abs(i)*a;return{minX:o-c,maxX:o+c,minZ:l-d,maxZ:l+d,minY:0,maxY:n.height??2.3,obb:{cx:o,cz:l,c:i,s:r,halfW:s,halfD:a},door:!0}}function Rn(n,e,t=n.swing??-1){const i=n.angle??(n.open?t*Math.PI/2:0);return oh(n,i)}const Kl=[{id:"home",name:"Your home",x:-13,z:-9,w:8,d:7,angle:0,wall:15851437,roof:4488320,style:"gable"},{id:"peach",name:"Peach cottage",x:6,z:-10,w:7,d:8,angle:0,wall:15185051,roof:7042704,style:"hip"},{id:"sage",name:"Sage bungalow",x:-17,z:20,w:9,d:6,angle:Math.PI,wall:12177332,roof:11365457,style:"gable"},{id:"rose",name:"Rose cabin",x:17,z:20,w:6,d:8,angle:Math.PI,wall:14728124,roof:7108992,style:"shed"},...ah,...Fn];function Ot(n,e,t){const i=Math.cos(n.angle),r=Math.sin(n.angle);return{x:n.x+e*i+t*r,z:n.z-e*r+t*i}}function sg(n,e=[]){const t=new vn(8);for(const w of e)t.add(Jn(w));const i=w=>t.query(w).some(b=>Wi(b,w)),r=[],s=Kl.filter(w=>{if(!w.designed)return!0;const b=Math.max(w.w,w.d)/2+(w.garage?6:2),H=i({minX:w.x-b,maxX:w.x+b,minZ:w.z-b,maxZ:w.z+b,minY:0,maxY:10});return H&&r.push(w.id),!H}),a=[],o=[];let l=!1;const c=[],d=[],u=new Map,h=new _t(1,1,1),m=new Map,_=w=>(m.has(w)||m.set(w,new It({color:w})),m.get(w)),x=new pt;function p(w,b,H,F,ae,oe,ee,me=!1,A=0){const E=(Math.abs(Math.cos(A))*F+Math.abs(Math.sin(A))*oe)/2+.1,O=(Math.abs(Math.sin(A))*F+Math.abs(Math.cos(A))*oe)/2+.1;if(!(l&&ae>.03&&i({minX:w-E,maxX:w+E,minZ:H-O,maxZ:H+O,minY:b-ae/2,maxY:b+ae/2}))&&(u.has(ee)||u.set(ee,[]),u.get(ee).push({x:w,y:b,z:H,w:F,h:ae,d:oe,angle:A}),me)){const Q=Math.abs(Math.cos(A)),j=Math.abs(Math.sin(A)),te=(F*Q+oe*j)/2,ve=(F*j+oe*Q)/2;c.push({...Math.abs(Math.sin(A*2))>1e-6?{obb:{cx:w,cz:H,c:Math.cos(A),s:Math.sin(A),halfW:F/2,halfD:oe/2}}:{},minX:w-te,maxX:w+te,minY:b-ae/2,maxY:b+ae/2,minZ:H-ve,maxZ:H+ve})}}const f=[];function v(w,b,H,F,ae=0,oe=4){if(typeof document>"u")return;const ee=document.createElement("canvas");ee.width=512,ee.height=96;const me=ee.getContext("2d");me.fillStyle="#fff5d9",me.fillRect(0,0,512,96),me.fillStyle="#496c61",me.font="bold 48px sans-serif",me.textAlign="center",me.textBaseline="middle",me.fillText(w,256,50,480);const A=new fr(ee);A.colorSpace=xt;const E=new Le(new Nn(oe,oe*96/512),new Oi({map:A,side:yt}));E.position.set(b,H,F),E.rotation.y=ae,n.add(E),f.push(E)}const g=9418861,y=9725511,R=16774617,T=8501706;p(0,-.18,0,it.halfSize*2+2,.36,it.halfSize*2+2,g,!0);const C=ng.map(cr),z=ig.map(cr);for(const w of Na.filter((b,H)=>H!==2)){const b=cr(w);for(const H of[0,b.length-1]){const F=b[H],ae=Xt(F[0],F[1],C[2]).point;H===0?b.unshift([ae.x,ae.z]):b.push([ae.x,ae.z])}C.push(b)}z.push(...Cm.map(cr),cr(Na[2]));const M=C[0];function S(w,b,H,F){const ae=[],oe=[];w.forEach((A,E)=>{const O=w[Math.max(0,E-1)],Q=w[Math.min(w.length-1,E+1)],j=Q[0]-O[0],te=Q[1]-O[1],ve=Math.hypot(j,te),xe=-te/ve*b/2,ye=j/ve*b/2;if(ae.push(A[0]+xe,F,A[1]+ye,A[0]-xe,F,A[1]-ye),E){let Ee=E*2;oe.push(Ee-2,Ee,Ee-1,Ee-1,Ee,Ee+1)}});const ee=new rt;ee.setAttribute("position",new Ve(ae,3)),ee.setIndex(oe),ee.computeVertexNormals();const me=new Le(ee,_(H));return n.add(me),me}for(const w of C)S(w,7.4,14601641,.014),S(w,5,6845816,.024);for(const w of z)S(w,2.4,14008212,.019);const G=[];for(const w of C)for(const b of[0,w.length-1]){const H=w[b],F=b===0?w.slice(5):w.slice(0,-5);F.length>1&&Xt(H[0],H[1],F).distance<2.5&&G.push({x:H[0],z:H[1]})}for(const w of C){let b=0,H=1;for(let F=1;F<w.length;F++){const ae=w[F-1],oe=w[F],ee=oe[0]-ae[0],me=oe[1]-ae[1],A=Math.hypot(ee,me);for(;H<b+A;){const E=(H-b)/A,O=ae[0]+ee*E,Q=ae[1]+me*E;!G.some(j=>Math.hypot(O-j.x,Q-j.z)<5.5)&&!C.some(j=>j!==w&&Xt(O,Q,j).distance<5.5)&&p(ae[0]+ee*E,.031,ae[1]+me*E,.1,.012,1.1,15984318,!1,Math.atan2(ee,me)),H+=3.5}b+=A}}const I=s.map(w=>{const b=Ot(w,-1.4,w.d/2),H=Ot(w,-1.4,w.d/2+2.5),ae=(w.street?[C[{north:4,south:5,elm:6}[w.street]]]:w.route==="trail"?z:w.shop?[...C,z[4]]:w.id==="willow"||w.id==="pavilion"?z:C).map(me=>({...Xt(H.x,H.z,me),isRoad:C.includes(me)})).sort((me,A)=>me.distance-A.distance)[0];let oe=w.approach||{bakery:{x:44,z:-34},market:{x:60,z:-34},pottery:{x:39,z:-25}}[w.id]||ae.point;if(ae.isRoad&&!["bakery","market","pottery"].includes(w.id)){const me=H.x-oe.x,A=H.z-oe.z,E=Math.hypot(me,A);E>3.3&&(oe={x:oe.x+me/E*3.3,z:oe.z+A/E*3.3})}const ee=[[b.x,b.z],[H.x,H.z],[oe.x,oe.z]];if(S(ee,w.shop?2.8:2.4,12959399,.032),w.garage||w.carport){const me=Ot(w,-w.w/2-2.1,w.d/2+.15);let A=C.map(j=>Xt(me.x,me.z,j)).sort((j,te)=>j.distance-te.distance)[0].point;const E=me.x-A.x,O=me.z-A.z,Q=Math.hypot(E,O);Q>3.3&&(A={x:A.x+E/Q*3.3,z:A.z+O/Q*3.3}),S([[me.x,me.z],[A.x,A.z]],3.6,12959399,.033)}return{entry:b,end:oe,points:ee,w:w.shop?2.8:2.4}});for(const w of s){let me=function(re){const le=w.w>9?2.4:1.8,fe=w.shop?2.6:w.w>9?2.2:1.5,Z=1.05,D=1.2,he=re>0?[[-b/2,ae-oe/2],[ae+oe/2,le-fe/2],[le+fe/2,b/2]]:[[-b/2,le-fe/2],[le+fe/2,b/2]];for(const[pe,Te]of he)Te>pe&&ee((pe+Te)/2,1.5,re,Te-pe,3,.22,w.wall,!0);re>0&&ee(ae,2.675,re,oe,.65,.22,w.wall,!0),ee(le,Z/2,re,fe,Z,.22,w.wall,!0),ee(le,(Z+D+3)/2,re,fe,3-Z-D,.22,w.wall,!0),ee(le,Z+D/2,re,fe,D,.1,T,!0);for(const pe of[le-fe/2,le,le+fe/2])ee(pe,Z+D/2,re+.01,.065,D+.12,.29,R);for(const pe of[Z,Z+D/2,Z+D])ee(le,pe,re+.01,fe+.12,.065,.29,R);ee(le,Z-.06,re,fe+.27,.12,.42,R)};var Ie=me;const{w:b,d:H}=w,F=H/2,ae=-1.4,oe=1.4,ee=(re,le,fe,Z,D,he,pe,Te=!1)=>{const Pe=Ot(w,re,fe);p(Pe.x,le,Pe.z,Z,D,he,pe,Te,w.angle)};if(l=!!w.designed,w.designed){ih({h:w,put:ee,local:(re,le)=>Ot(w,re,le),scene:n,material:_,doors:d,solids:c,label:v,rooms:a}),l=!1;continue}if(ee(0,.006,0,b,.012,H,14006419),me(F),me(-F),w.wing){const re=-F+2.75;for(const[le,fe]of[[-F,re-.9],[re+.9,F]])fe>le&&ee(-b/2,1.5,(le+fe)/2,.22,3,fe-le,w.wall,!0);ee(-b/2,2.72,re,.22,.56,1.8,w.wall,!0),a.push({house:w.id,name:"Side room",...Ot(w,-b/2-2.25,re),y:0})}else ee(-b/2,1.5,0,.22,3,H,w.wall,!0);if((w.d>8||w.bay)&&ah.some(re=>re.id===w.id)){const re=w.d>10?[-2.6,2.6]:[0],le=.8;let fe=-F;for(const Z of re){const D=Z-le;ee(b/2,1.5,(fe+D)/2,.22,3,D-fe,w.wall,!0),ee(b/2,.525,Z,.22,1.05,1.6,w.wall,!0),ee(b/2,2.625,Z,.22,.75,1.6,w.wall,!0),w.bay||ee(b/2,1.65,Z,.1,1.2,1.6,T,!0);for(const he of[Z-le,Z,Z+le])ee(b/2+.01,1.65,he,.29,1.32,.065,R);for(const he of[1.05,1.65,2.25])ee(b/2+.01,he,Z,.29,.065,1.72,R);fe=Z+le}ee(b/2,1.5,(fe+F)/2,.22,3,F-fe,w.wall,!0)}else ee(b/2,1.5,0,.22,3,H,w.wall,!0);const A=[],E=[],O=(re,le,fe,Z)=>{const D=A.length/3;A.push(...re,...le,...fe,...Z),E.push(D,D+1,D+2,D,D+2,D+3)},Q=b/2+.4,j=F+.4,te=3.06,ve=4.7;if(w.style==="gable"){O([-Q,te,j],[0,ve,j],[0,ve,-j],[-Q,te,-j]),O([0,ve,j],[Q,te,j],[Q,te,-j],[0,ve,-j]);for(const re of[-F,F]){const le=te+(ve-te)*.4/Q,fe=new rt;fe.setAttribute("position",new Ve([-b/2,3,re,b/2,3,re,b/2,le,re,0,ve,re,-b/2,le,re],3)),fe.setIndex([0,1,2,0,2,3,0,3,4]),fe.computeVertexNormals();const Z=_(w.wall).clone();Z.side=yt;const D=new Le(fe,Z);D.position.set(w.x,0,w.z),D.rotation.y=w.angle,n.add(D)}}else if(w.style==="gambrel"){const re=[-Q,-Q*.56,0,Q*.56,Q],le=[te,4.45,5.4,4.45,te];for(let Z=1;Z<re.length;Z++)O([re[Z-1],le[Z-1],j],[re[Z],le[Z],j],[re[Z],le[Z],-j],[re[Z-1],le[Z-1],-j]);const fe=te+(4.45-te)*.4/(Q*.44);for(const Z of[-F,F]){const D=[[-b/2,3,Z],[b/2,3,Z],[b/2,fe,Z],[Q*.56,4.45,Z],[0,5.4,Z],[-Q*.56,4.45,Z],[-b/2,fe,Z]],he=new rt;he.setAttribute("position",new Ve(D.flat(),3)),he.setIndex([0,1,2,0,2,3,0,3,4,0,4,5,0,5,6]),he.computeVertexNormals();const pe=_(w.wall).clone();pe.side=yt;const Te=new Le(he,pe);Te.position.set(w.x,0,w.z),Te.rotation.y=w.angle,n.add(Te)}}else if(w.style==="hip")O([-Q,te,j],[Q,te,j],[0,ve,1.5],[0,ve,1.5]),O([Q,te,j],[Q,te,-j],[0,ve,-1.5],[0,ve,1.5]),O([Q,te,-j],[-Q,te,-j],[0,ve,-1.5],[0,ve,-1.5]),O([-Q,te,-j],[-Q,te,j],[0,ve,1.5],[0,ve,-1.5]);else{O([-Q,te,j],[Q,te,j],[Q,4.1,-j],[-Q,4.1,-j]);const re=te+(4.1-te)*.4/(H+.8),le=4.1-(4.1-te)*.4/(H+.8);ee(0,(3+le)/2,-F,b,le-3,.22,w.wall),ee(0,(3+re)/2,F,b,re-3,.22,w.wall);for(const fe of[-b/2,b/2]){const Z=new rt;Z.setAttribute("position",new Ve([fe,3,-F,fe,le,-F,fe,re,F,fe,3,F],3)),Z.setIndex([0,1,2,0,2,3]),Z.computeVertexNormals();const D=_(w.wall).clone();D.side=yt;const he=new Le(Z,D);he.position.set(w.x,0,w.z),he.rotation.y=w.angle,n.add(he)}}const xe=new rt;xe.setAttribute("position",new Ve(A,3)),xe.setIndex(E),xe.computeVertexNormals();const ye=_(w.roof).clone();ye.side=yt;const Ee=new Le(xe,ye);Ee.position.set(w.x,0,w.z),Ee.rotation.y=w.angle,n.add(Ee),ee(0,3.015,0,w.style==="shed"?b:b+.8,.09,w.style==="shed"?H:H+.8,R,!0);for(const re of[-b/2,b/2])ee(re,1.5,F+.08,.13,3,.14,R);ee(ae,2.62,F+.7,w.porch||2.2,.15,1.5,w.roof,!0);for(const re of[ae-(w.porch||2.2)/2+.14,ae+(w.porch||2.2)/2-.14])ee(re,1.27,F+1.28,.12,2.54,.12,R,!0);const Ue=new ft,ce=Ot(w,ae-oe/2+.07,F+.03),Ke=oe-.14;Ue.position.set(ce.x,0,ce.z),Ue.rotation.y=w.angle;const qe=new Le(new _t(Ke,2.3,.1),_(9726028));qe.position.set(Ke/2,1.15,0),Ue.add(qe);const ze=new Le(new _t(.78,.7,.11),_(11980733));ze.position.set(Ke/2,1.66,0),Ue.add(ze);const Ce=new Le(new Ss(.055,6,5),_(16768118));Ce.position.set(Ke-.18,1,.09),Ue.add(Ce),n.add(Ue);const Se=Ot(w,ae,F);if(d.push({id:w.id,pivot:Ue,baseAngle:w.angle,open:!1,center:Se,hinge:ce,width:Ke,height:2.3}),w.shop){ee(b/2-1,.45,-F+1,1.4,.9,1.3,y,!0),ee(b/2-1,.95,-F+1,1.6,.12,1.5,R);for(let le=0;le<3;le++)ee(-b/2+1.2+le*1.6,.6,-F+.7,1.2,1.2,.65,y,!0),ee(-b/2+1.2+le*1.6,1.28,-F+.7,.8,.16,.4,[15118451,12177332,14728124][le]);ee(1,2.6,F+.19,b-1,.25,.6,w.roof);for(let le=0;le<8;le++)ee(-b/2+.5+le*(b-1)/8,2.7,F+.8,(b-1)/8,.12,1.4,le%2?R:w.roof);ee(0,3.28,F+.2,4.05,.82,.12,y);for(const le of[-1.65,1.65])ee(le,2.96,F+.18,.1,.7,.12,y);const re=Ot(w,0,F+.28);v(w.sign,re.x,3.28,re.z,w.angle,3.8)}else ee(-b/2+1.15,.29,-F+1.6,1.7,.58,2.4,y,!0),ee(-b/2+1.15,.65,-F+1.45,1.65,.16,2.1,w.id==="home"?7183771:13214055),ee(-b/2+1.15,.78,-F+.65,1.4,.17,.48,R),ee(b/2-.9,.45,-F+.9,1.1,.9,.7,y,!0);if(w.garage&&Cs({scene:n,material:_,doors:d,h:w,put:ee,local:(re,le)=>Ot(w,re,le)}),w.carport){const re=-b/2-2.1,le=F-2.7;ee(re,2.55,le,4.6,.18,5.8,w.roof,!0);for(const fe of[-1.9,1.9])for(const Z of[-2.35,2.35])ee(re+fe,1.22,le+Z,.16,2.44,.16,y,!0);ee(re,.008,le,4.2,.016,5.4,12959399)}if(w.wing){const re=-b/2-2.25,le=-F+2.75;ee(re,.007,le,4.5,.014,5.5,14006419),ee(re-2.25,1.65,le,.22,3.3,5.5,w.wall,!0);for(const fe of[le-2.75,le+2.75])ee(re,1.65,fe,4.5,3.3,.22,w.wall,!0);ee(re,3.4,le,4.9,.2,5.9,w.roof,!0),ee(re,1.7,le+2.78,2.6,1.25,.08,T);for(const fe of[re-1.33,re,re+1.33])ee(fe,1.7,le+2.84,.065,1.38,.1,R);for(const fe of[1.05,2.35])ee(re,fe,le+2.84,2.73,.065,.1,R)}if(w.bay){l=!0,ee(b/2+.32,.525,0,.64,1.05,1.9,w.wall,!0),ee(b/2+.64,1.65,0,.08,1.2,1.8,T,!0);for(const re of[-.87,.87])ee(b/2+.32,1.65,re,.64,1.2,.08,T,!0);ee(b/2+.34,3.015,0,.9,.09,2.15,R,!0),ee(b/2+.64,2.625,0,.1,.75,1.8,w.wall,!0);for(const re of[-.87,.87])ee(b/2+.32,2.625,re,.64,.75,.1,w.wall,!0);for(const re of[-.9,0,.9])ee(b/2+.7,1.65,re,.1,1.35,.065,R)}if(l=!1,w.chimney&&ee(b/2-1,4.2,-F*.3,.8,2.4,.8,13075044,!0),w.tower){const re=b/2+1.8,le=-F+1.8;ee(re,3.4,le,3.6,6.8,3.6,w.wall,!0);for(const he of[le-1.83,le+1.83]){ee(re,5.1,he,1.5,1.5,.08,R),ee(re,5.3,he+(he>le?.06:-.06),.08,.58,.1,y),ee(re+.22,5.1,he+(he>le?.06:-.06),.48,.08,.1,y);for(const pe of[re-.58,re+.58])ee(pe,5.1,he,.08,1.65,.12,R)}const fe=Ot(w,re,le),Z=new pr(2.7,1.8,4),D=new Le(Z,_(w.roof));D.position.set(fe.x,7.7,fe.z),D.rotation.y=w.angle+Math.PI/4,n.add(D)}if(w.garden){l=!!w.wing;const re=w.garage||w.wing?b/2+2:-b/2-2;ee(re,.18,0,2.3,.36,H*.75,5933922,!0);for(let le=0;le<4;le++)ee(re,.42,-H*.25+le*H/6,.4,.2,.4,[15118451,14728124,15851437][w.garden-1]);w.garden===3&&(ee(0,.3,-F-2.2,b*.7,.6,1.2,y,!0),ee(0,.64,-F-2.2,b*.65,.12,1,7052647))}l=!1,ee(.55,.05,F+.5,.8,.09,.6,w.roof);const Ne=Ot(w,2.15,F+2.1);p(Ne.x,.5,Ne.z,.11,1,.11,y,!0),p(Ne.x,1.05,Ne.z,.55,.34,.4,w.roof)}const W={x:-10.8,z:-8.1};p(W.x,.88,W.z,1.4,.22,1.1,11368266,!0);for(const w of[-.5,.5])for(const b of[-.35,.35])p(W.x+w,.39,W.z+b,.14,.78,.14,y,!0);for(let w=0;w<3;w++)for(let b=0;b<3;b++)p(W.x-.36+w*.36,1.001,W.z-.32+b*.32,.29,.014,.26,(w+b)%2?15718563:7687734);p(-4,.004,-.5,8,.008,6,10993279);for(const w of[-8,0])for(const b of[-3.5,2.5])p(w,.16,b,.2,.32,.2,y);const L=[[-27,-18],[-23,-7],[-28,17],[-6,-22],[18,-17],[26,-7],[28,20],[2,25],[-28,28],[27,-25],[13,29],[-2,19]];function U(w,b){return C.some(H=>Xt(w,b,H).distance<4.8)||z.some(H=>Xt(w,b,H).distance<2.1)||I.some(H=>Xt(w,b,H.points).distance<2.2)||s.some(H=>{const F=Ot({...H,angle:-H.angle,x:0,z:0},w-H.x,b-H.z);return Math.abs(F.x)<H.w/2+(H.garage||H.wing?6:2.8)&&Math.abs(F.z)<H.d/2+3})||[...hs].some(H=>Math.abs(w-H.x)<H.w/2+2&&Math.abs(b-H.z)<H.d/2+2)?!1:!i({minX:w-2,maxX:w+2,minZ:b-2,maxZ:b+2,minY:0,maxY:7})}const B=[];for(const[w,[b,H]]of L.entries()){if(!U(b,H))continue;o.push({x:b,z:H});const F=2.5+w%3*.25;p(b,F/2,H,.42,F,.42,8675908,!0),B.push({x:b,y:F+.7,z:H,scale:1.9+w%2*.3,color:w%2?7052647:5082472})}for(const w of new Set(B.map(b=>b.color))){const b=B.filter(ae=>ae.color===w),H=new mr(1,1),F=new cs(H,_(w),b.length);b.forEach((ae,oe)=>{x.position.set(ae.x,ae.y,ae.z),x.scale.set(ae.scale,ae.scale*.85,ae.scale),x.rotation.set(0,oe,.2),x.updateMatrix(),F.setMatrixAt(oe,x.matrix)}),n.add(F)}for(let w=-it.halfSize+1;w<=it.halfSize-1;w+=4){for(const b of[-it.halfSize,it.halfSize])p(w,.7,b,4,1.4,1.4,5933922);for(const b of[-it.halfSize,it.halfSize])p(b,.7,w,1.4,1.4,4,5933922)}p(1,.48,15,2,.15,.65,y,!0),p(1,.94,15.28,2,.8,.12,y,!0);for(const w of[.25,1.75])p(w,.23,15,.12,.46,.5,5992562,!0);for(const[w,b]of[[-8,-14],[-18,-14],[10,-16],[20,15],[-21,17],[0,16]])p(w,.18,b,.07,.36,.07,5474391),p(w,.4,b,.32,.16,.32,15118451);if(p(49,.006,-26,23,.012,23,14141609),p(49,.2,-26,3,.4,3,11906454,!0),p(49,.44,-26,2.6,.08,2.6,7052647),p(49,2,-26,.32,4,.32,y,!0),p(49,4.1,-26,1.4,1.4,.4,15851437),typeof document<"u"){const w=document.createElement("canvas");w.width=w.height=192;const b=w.getContext("2d");b.fillStyle="#fff5d9",b.fillRect(0,0,192,192),b.strokeStyle="#496c61",b.lineWidth=5,b.beginPath(),b.arc(96,96,84,0,Math.PI*2),b.stroke(),b.font="bold 23px sans-serif",b.textAlign="center",b.textBaseline="middle",b.fillStyle="#496c61";for(const[ae,oe,ee]of[["12",96,34],["3",160,98],["6",96,160],["9",34,98]])b.fillText(ae,oe,ee);b.lineCap="round",b.lineWidth=8,b.beginPath(),b.moveTo(96,96),b.lineTo(65,77),b.moveTo(96,96),b.lineTo(132,60),b.stroke();const H=new fr(w);H.colorSpace=xt;const F=new Le(new Nn(1.14,1.14),new Oi({map:H}));F.position.set(49,4.1,-25.79),n.add(F),f.push(F)}function X(w,b,H=0){if(i({minX:w-1.4,maxX:w+1.4,minZ:b-1.4,maxZ:b+1.4,minY:0,maxY:1.5}))return;const F=(ae,oe,ee,me,A,E,O,Q=!0)=>{const j=Ot({x:w,z:b,angle:H},ae,ee);p(j.x,oe,j.z,me,A,E,O,Q,H)};F(0,.48,0,2,.15,.65,y),F(0,.94,.28,2,.8,.12,y);for(const ae of[-.75,.75])F(ae,.23,0,.12,.46,.5,5992562)}for(const w of[40,58])X(w,-26,Math.PI/2);const K=[{x:-70,z:61,w:36,d:30,subtle:!0},{x:8,z:61,w:27,d:27},...Um];for(const w of K){const b=z.map(oe=>Xt(w.x,w.z,oe)).sort((oe,ee)=>oe.distance-ee.distance)[0].point,H=b.x-w.x,F=b.z-w.z,ae=Math.min(Math.abs(H)>1e-6?w.w/2/Math.abs(H):1/0,Math.abs(F)>1e-6?w.d/2/Math.abs(F):1/0);if(ae<1){const oe=[[b.x,b.z],[w.x+H*ae,w.z+F*ae]];z.push(oe),S(oe,2.4,14008212,.019)}p(w.x,.004,w.z,w.w,.008,w.d,w.subtle?9878134:10993279);for(const oe of[-w.w/2,w.w/2])for(const ee of[-w.d/2,w.d/2])p(w.x+oe,.18,w.z+ee,.22,.36,.22,y)}for(const w of hs){K.push(w);const b=w.roadZ??w.z,H=w.roadX?w.z-6:w.z+(b-w.z)*.45;p(w.x,.005,w.z,w.w,.01,w.d,9878134),S(w.roadX?[[w.x+w.w/2,w.z],[w.roadX-3.3,w.z]]:[[w.x,w.z+(b>w.z?w.d/2:-w.d/2)],[w.x,b+(b>w.z?-3.3:3.3)]],2.4,12959399,.032),p(w.x-w.w/2+.4,.45,H,.12,.9,.12,y),p(w.x-w.w/2+.4,.82,H,1.2,.5,.08,4488320),v("BUILD",w.x-w.w/2+.4,.83,H+.05,0,1.1)}l=!0,tg({box:p,bench:X,material:_,scene:n,reserved:i}),l=!1;const ie={x:18,z:-101,rx:16,rz:10},ne=(w,b,H,F,ae,oe=.02)=>{const ee=new to(1,48);ee.rotateX(-Math.PI/2),ee.scale(H,1,F);const me=new Le(ee,_(ae));me.position.set(w,oe,b),n.add(me)};ne(18,-101,18,12,14141609,.006),ne(18,-101,16,10,7515836,.022);for(let w=0;w<9;w++)p(18+(w%2?.3:-.3),.035,-110+w*2.25,1.25,.018,1.45,11906454,!1);X(38,-103,Math.PI/2),X(10,-116,Math.PI);const ue=[];for(let w=0;w<18;w++){const b=w*.67;ue.push([81+Math.cos(b)*(7+Math.floor(w/6)*4),94+Math.sin(b)*(7+Math.floor(w/6)*4)])}X(81,100),p(81,.015,97,3,.03,2,14728124);const de=(w,b)=>!!(Math.abs(w)<32&&Math.abs(b)<32||Kl.slice(0,16).some(H=>{const F=Math.abs(Math.cos(H.angle)),ae=Math.abs(Math.sin(H.angle));return Math.abs(w-H.x)<(H.w*F+H.d*ae)/2+8&&Math.abs(b-H.z)<(H.w*ae+H.d*F)/2+6})||[...C.slice(0,2),...z.slice(0,6)].some(H=>Xt(w,b,H).distance<5.2)||I.slice(0,16).some(H=>Xt(w,b,H.points).distance<3)||K.slice(0,2).some(H=>Math.abs(w-H.x)<H.w/2+3&&Math.abs(b-H.z)<H.d/2+3)||Math.abs(w-65)<18&&Math.abs(b-46)<18||Math.abs(w-49)<17&&Math.abs(b+26)<17||Math.abs(w-18)<22&&Math.abs(b+101)<16||Math.hypot(w-81,b-94)<24);let J=73419;const se=()=>(J=Math.imul(J,1664525)+1013904223>>>0,J/4294967296),ge=[];for(let w=0;w<650;w++){const b=-118+se()*236,H=-118+se()*236;de(b,H)||ge.some(F=>Math.hypot(F[0]-b,F[1]-H)<5)||H>-80&&se()<.42||ge.push([b,H])}for(let w=0;w<600;w++){const b=-95+se()*63,H=-121+se()*36;de(b,H)||ge.some(F=>Math.hypot(F[0]-b,F[1]-H)<3.8)||ge.push([b,H])}for(let w=0;w<24;w++){const b=w*Math.PI*2/24,H=18+Math.cos(b)*16.8,F=-101+Math.sin(b)*10.8;Math.abs(H-18)<2||(p(H,.35,F,.055,.7,.055,5474391),p(H,.74,F,.12,.17,.12,9725511))}for(const[w,[b,H]]of[...ge,...ue].entries()){if(!U(b,H))continue;o.push({x:b,z:H});const F=w>=ge.length,ae=F?2.2:2.6+w%4*.35;p(b,ae/2,H,.38,ae,.38,y,!0);const oe=!F&&H<-80&&w%3===0,ee=oe?new pr(2.1,4.6,7):new mr(1,1);oe||ee.scale(2.2,1.9,2.2);const me=new Le(ee,_(oe?5082472:w%2?7052647:5933922));if(me.position.set(b,ae+.7,H),n.add(me),F)for(const A of[-1,1])p(b+A,ae+.5,H+.5,.22,.22,.22,13075044)}l=!0;const Ae=rg({scene:n,box:p,material:_,bench:X,disk:ne,roads:C,trails:z,drives:I,houses:s,treeAllowed:U,treePositions:o,clearings:K});l=!1;for(const w of zm.filter(b=>b.id!=="home")){l=Vc.some(F=>F.id===w.id);const b=w.signX??(w.id==="pond"?39:w.x+4),H=w.signZ??(w.id==="pond"?-94:w.z+4);i({minX:b-2,maxX:b+2,minZ:H-1,maxZ:H+1,minY:0,maxY:2.2})||(p(b,.9,H,.14,1.8,.14,y,!0),p(b,1.7,H,3.8,.8,.12,4488320),v(w.name.toUpperCase(),b,1.72,H+.075,0,3.6))}l=!1;for(const[w,b]of u){const H=new cs(h,_(w),b.length);b.forEach((F,ae)=>{x.position.set(F.x,F.y,F.z),x.rotation.set(0,F.angle,0),x.scale.set(F.w,F.h,F.d),x.updateMatrix(),H.setMatrixAt(ae,x.matrix)}),H.computeBoundingSphere(),n.add(H)}const we=new Le(new Nn(it.halfSize*2,it.halfSize*2),new Oi({visible:!1}));we.rotation.x=-Math.PI/2,we.updateMatrixWorld(),n.add(we);const ke=Ls(d),Ge=Ps(n,new Set([...d.map(w=>w.pivot),we,...f]));return{config:it,roads:C,selfJunctions:G,trails:z,clearings:K,pond:ie,ponds:[ie,...Jr],outerScenery:Ae,staticRender:Ge,doorRender:ke,treeCount:o.length,treePositions:o,rooms:a,omitted:r,solids:c,doors:d,table:W,ground:we,road:M,drives:I,houses:s,treeAllowed:U,batches:u}}const mn=[{id:"sunbeam-region",name:"Sunbeam Region",icon:"🌳",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"sunbeam-town",name:"Sunbeam Town",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"home-square",name:"Home & Square",icon:"☀",spawn:{x:-21.4,y:0,z:0,yaw:0,pitch:0}},{id:"legacy-06",name:"Legacy neighbourhood",icon:"🏡",spawn:{x:-14.4,y:0,z:-1.2,yaw:0,pitch:0}},{id:"blank",name:"Blank creative",icon:"🧱",spawn:{x:0,y:0,z:8,yaw:0,pitch:0}}];function ag(n,e,t=[],i=2){if(e==="sunbeam-region")return eg(n,i);if(e==="sunbeam-town")return sh(n);if(e==="home-square")return rh(n);if(e==="legacy-06")return sg(n,t);const r=new Le(new Nn(500,500),new It({color:11127178}));return r.rotation.x=-Math.PI/2,n.add(r),r.updateMatrixWorld(),{ground:r,solids:[],doors:[],houses:[],rooms:[],roads:[],staticRender:{updateVisibility(){}}}}const Yi=[{id:"explorer",name:"Explorer",skin:14395767,shirt:7183243,pants:11639667,hair:6638909,hat:"sun",extra:"pack"},{id:"builder",name:"Little builder",skin:12092507,shirt:15122027,pants:7179424,hair:4406066,hat:"hard",extra:"overalls"},{id:"gardener",name:"Gardener",skin:9133890,shirt:13017773,pants:6323816,hair:3945264,hat:"sun",extra:"apron"},{id:"pilot",name:"Friendly pilot",skin:12882024,shirt:8166578,pants:5860992,hair:5915959,hat:"cap",extra:"scarf"},{id:"painter",name:"Painter",skin:15188378,shirt:10849195,pants:8557967,hair:8938314,hat:"beret",extra:"apron"},{id:"sailor",name:"Sailor",skin:9726539,shirt:15327176,pants:6589853,hair:3748912,hat:"sailor",extra:"stripes"},{id:"cosy",name:"Cosy hoodie",skin:13803892,shirt:13143166,pants:7900032,hair:6310971,hat:"hood",extra:"pocket"},{id:"stargazer",name:"Stargazer",skin:11500885,shirt:7832742,pants:5991815,hair:3879985,hat:"cap",extra:"star"},{id:"sporty",name:"Park runner",skin:15054220,shirt:12158841,pants:7440277,hair:7491128,hat:"band",extra:"stripes"},{id:"rainbow",name:"Rainbow jumper",skin:9002304,shirt:11250340,pants:7637906,hair:3485227,hat:"none",extra:"rainbow"},{id:"farmer",name:"Farm friend",skin:13212272,shirt:12032370,pants:8034464,hair:5981235,hat:"sun",extra:"overalls"},{id:"blossom",name:"Blossom",skin:11435867,shirt:14203269,pants:9414033,hair:4535853,hat:"pony",extra:"skirt"}];function ms(n="explorer"){const e=Yi.find(g=>g.id===n)||Yi[0],t=new ft,i=new _t(1,1,1),r=new Map,s=(g,y,R,T,C,z,M)=>{r.has(M)||r.set(M,new It({color:M}));const S=new Le(i,r.get(M));return S.position.set(g,y,R),S.scale.set(T,C,z),t.add(S),S};s(0,1.43,0,.4,.4,.38,e.skin),s(0,1.65,.025,.43,.12,.4,e.hair),s(0,.93,0,.48,.55,.3,e.shirt);const a=s(-.14,.35,0,.2,.65,.24,e.pants),o=s(.14,.35,0,.2,.65,.24,e.pants),l=[s(-.34,.92,0,.16,.5,.2,e.skin),s(.34,.92,0,.16,.5,.2,e.skin)];for(const g of[-.08,.08])s(g,1.47,-.198,.045,.055,.025,4015424);if(s(0,1.35,-.198,.09,.025,.025,9069389),e.hat==="sun"&&(s(0,1.74,0,.72,.06,.62,14336653),s(0,1.82,0,.43,.16,.4,14336653)),e.hat==="hard"&&(s(0,1.72,0,.53,.07,.52,14925423),s(0,1.81,0,.45,.16,.43,14925423),s(0,1.9,0,.1,.04,.38,15914894)),(e.hat==="cap"||e.hat==="sailor")&&(s(0,1.74,0,.48,.15,.45,e.hat==="sailor"?15788757:e.pants),s(0,1.71,-.27,.48,.05,.2,e.hat==="sailor"?15788757:e.pants)),e.hat==="beret"&&s(-.04,1.78,0,.56,.15,.5,e.shirt),e.hat==="hood"&&(s(0,1.45,.2,.5,.55,.18,e.shirt),s(0,1.74,0,.5,.1,.48,e.shirt)),e.hat==="band"&&s(0,1.62,-.01,.44,.07,.42,15260088),e.hat==="pony"&&s(.2,1.45,.27,.18,.45,.2,e.hair),e.extra==="pack"){s(0,.95,.26,.4,.48,.23,12755318);for(const g of[-.18,.18])s(g,1,-.17,.06,.45,.04,12755318)}if(e.extra==="overalls"){s(0,.88,-.17,.32,.35,.04,e.pants);for(const g of[-.13,.13])s(g,1.12,-.17,.06,.25,.04,e.pants)}if(e.extra==="apron"&&s(0,.78,-.18,.4,.58,.04,14011036),e.extra==="scarf"&&(s(0,1.23,0,.46,.1,.35,14664844),s(.13,1.05,-.18,.1,.3,.05,14664844)),e.extra==="pocket"&&s(0,.83,-.18,.3,.18,.05,14263187),e.extra==="star"&&(s(0,1.02,-.18,.18,.06,.04,15783051),s(0,1.02,-.18,.06,.18,.04,15783051)),e.extra==="stripes"||e.extra==="rainbow")for(let g=0;g<4;g++)s(0,.78+g*.1,-.17,.46,.04,.035,e.extra==="rainbow"?[12879733,14531196,9219217,8495026][g]:e.pants);e.extra==="skirt"&&s(0,.59,0,.58,.35,.4,e.pants);const c=new Set([a,o,...l]),d=t.children.filter(g=>!c.has(g)),u=[],h=[],m=[],_=new N,x=new N,p=new Xe,f=new Set;for(const g of d){g.updateMatrix(),p.getNormalMatrix(g.matrix);const y=g.geometry.toNonIndexed(),R=y.attributes.position,T=y.attributes.normal,C=g.material.color;for(let z=0;z<R.count;z++)_.fromBufferAttribute(R,z).applyMatrix4(g.matrix),x.fromBufferAttribute(T,z).applyMatrix3(p).normalize(),u.push(_.x,_.y,_.z),h.push(x.x,x.y,x.z),m.push(C.r,C.g,C.b);f.add(g.material),y.dispose(),g.removeFromParent()}const v=new rt;v.setAttribute("position",new Ve(u,3)),v.setAttribute("normal",new Ve(h,3)),v.setAttribute("color",new Ve(m,3)),v.computeBoundingSphere(),t.add(new Le(v,new It({vertexColors:!0})));for(const g of f)t.children.some(y=>y.material===g)||g.dispose();return t.userData.appearance=e.id,{group:t,left:a,right:o,arms:l}}function og(n){const e=new Set,t=new Set;n.group.traverse(i=>{i.isMesh&&(e.add(i.geometry),t.add(i.material))}),e.forEach(i=>i.dispose()),t.forEach(i=>i.dispose()),n.group.removeFromParent()}function lh(n){let e=2166136261;for(let t=0;t<n.length;t++)e^=n.charCodeAt(t),e=Math.imul(e,16777619);return(e>>>0).toString(16).padStart(8,"0")}function Ds(n){const e=n;if(!e||![1,2,3].includes(e.schema)||!mn.some(s=>s.id===e.template)||!e.world||!e.player||!e.preferences)throw Error("Unsupported world schema or template");for(const s of["x","y","z","yaw","pitch"])if(!Number.isFinite(e.player[s]))throw Error("Invalid player position");if(Math.abs(e.player.x)>=250||Math.abs(e.player.z)>=250||e.player.y<0||e.player.y>26)throw Error("Player outside supported bounds");const t=e.world.layout??(e.template==="sunbeam-region"&&e.schema===3?2:1);if(!Number.isInteger(t)||Number(t)<1||Number(t)>2)throw Error("Unsupported template layout");if(e.preferences.avatar!==void 0&&!Yi.some(s=>s.id===e.preferences.avatar))throw Error("Unknown avatar appearance");if(e.preferences.lookSpeed!==void 0&&(typeof e.preferences.lookSpeed!="number"||![.6,1,1.4].includes(e.preferences.lookSpeed)))throw Error("Invalid look speed");if(e.preferences.leftHanded!==void 0&&typeof e.preferences.leftHanded!="boolean")throw Error("Invalid control side");for(const[s,a]of[["hotbar",8],["recent",8],["favourites",32]]){const o=e.preferences[s];if(o!==void 0&&(!Array.isArray(o)||o.length>a||o.some(l=>typeof l!="string"||!ii.some(c=>c.id===l))))throw Error("Invalid catalogue preferences")}if(Jm(e.world.blocks),!["hand",...ii.map(s=>s.id)].includes(e.preferences.selected))throw Error("Invalid selected item");if(!e.world.doors||Array.isArray(e.world.doors)||typeof e.world.doors!="object"||Object.values(e.world.doors).some(s=>typeof s!="boolean"))throw Error("Invalid doors");const i=e.world.props;if(i!==void 0&&(!i||Array.isArray(i)||typeof i!="object"||Object.keys(i).length>256||Object.values(i).some(s=>!s||Array.isArray(s)||typeof s!="object"||Object.entries(s).some(([a,o])=>!["open","on"].includes(a)||typeof o!="boolean"))))throw Error("Invalid furniture state");const r=e.world.activity;if(r!==void 0&&(!r||!r.car||![r.car.x,r.car.z,r.car.yaw].every(Number.isFinite)||Math.abs(r.car.x)>249||Math.abs(r.car.z)>249))throw Error("Invalid vehicle checkpoint");return{...structuredClone(e),world:{...structuredClone(e.world),layout:t},schema:3}}function ki(n){const e=JSON.stringify(Ds(n));return{json:e,checksum:lh(e)}}function ts(n){if(!n||typeof n.json!="string"||n.json.length>8e6||lh(n.json)!==n.checksum)throw Error("Checkpoint checksum failed");return Ds(JSON.parse(n.json))}function qn(n){return Ds({schema:3,template:n.template,world:{blocks:n.blocks,doors:n.doors,props:n.props||{},layout:n.layout??(n.template==="sunbeam-region"?2:1),...n.activity?{activity:n.activity}:{}},player:n.player,preferences:{selected:n.selected,avatar:n.avatar||"explorer",lookSpeed:n.lookSpeed||1,leftHanded:!!n.leftHanded,favourites:n.favourites||[],recent:n.recent||[],hotbar:n.hotbar||[],camera:n.camera||"first",flying:!!n.flying}})}function lg(n){if(n.length>12e6)throw Error("Backup is too large");const e=JSON.parse(n);if(e.format==="blockworld2"&&e.version===1)return{snapshot:ts(e.checkpoint),...typeof e.legacySource=="string"&&e.legacySource.length<=4e6?{source:e.legacySource}:{},name:typeof e.name=="string"?e.name.slice(0,60):"Imported world"};if(n.length>4e6)throw Error("Legacy backup exceeds 4 MB");const t=Gm(e);return{snapshot:Ds({schema:3,template:"legacy-06",world:{blocks:t.blocks,doors:t.doors},player:t.player,preferences:{selected:t.selected}}),source:n,name:"Imported legacy neighbourhood"}}class Jl extends Error{constructor(){super("This world changed in another tab. Your unsaved work is still here; export or save a new copy.")}}const Zr=n=>new Promise((e,t)=>{n.onsuccess=()=>e(n.result),n.onerror=()=>t(n.error||Error("Storage request failed"))}),$r=n=>new Promise((e,t)=>{n.oncomplete=()=>e(),n.onabort=()=>t(n.error||Error("Storage transaction aborted")),n.onerror=()=>{}});class gs{constructor(e){this.db=e}static open(e="blockworld2-development"){return new Promise((t,i)=>{const r=indexedDB.open(e,1);r.onupgradeneeded=()=>{for(const s of["worlds","meta"])r.result.objectStoreNames.contains(s)||r.result.createObjectStore(s,{keyPath:s==="worlds"?"id":"key"})},r.onsuccess=()=>{r.result.onversionchange=()=>r.result.close(),t(new gs(r.result))},r.onerror=()=>i(r.error),r.onblocked=()=>i(Error("Close another BlockWorld tab to open saves"))})}async read(e,t){const i=this.db.transaction(e,"readonly");return Zr(i.objectStore(e).get(t))}async list(){const e=this.db.transaction("worlds","readonly");return Zr(e.objectStore("worlds").getAll())}async last(){var e;return(e=await this.read("meta","last"))==null?void 0:e.value}async select(e){const t=this.db.transaction("meta","readwrite"),i=$r(t);t.objectStore("meta").put({key:"last",value:e}),await i}async create(e,t,i){const r=ki(t),s={id:crypto.randomUUID(),name:e.trim().slice(0,60)||"My world",template:t.template,revision:0,updated:Date.now(),current:r,previous:[],...i?{importSource:i}:{}},a=this.db.transaction("worlds","readwrite"),o=$r(a);return a.objectStore("worlds").add(s),await o,s}async load(e){const t=await this.read("worlds",e);if(!t)throw Error("World was not found");try{return{record:t,snapshot:ts(t.current),recovered:!1}}catch{for(const r of t.previous||[])try{return{record:t,snapshot:ts(r),recovered:!0}}catch{}throw Error("No valid checkpoint. Original data is retained; import a backup or choose another world.")}}async save(e,t,i){const r=ki(i),s=this.db.transaction("worlds","readwrite"),a=$r(s);try{const o=s.objectStore("worlds"),l=await Zr(o.get(e));if(!l)throw Error("World no longer exists");if(l.revision!==t)throw new Jl;ts(l.current);const c={...l,revision:t+1,current:r,previous:[l.current,...l.previous].slice(0,3),updated:Date.now()};return o.put(c),await a,c}catch(o){try{s.abort()}catch{}throw await a.catch(()=>{}),o}}async rename(e,t,i){const r=this.db.transaction("worlds","readwrite"),s=$r(r);try{const a=r.objectStore("worlds"),o=await Zr(a.get(e));if(!o||o.revision!==t)throw new Jl;const l={...o,name:i.trim().slice(0,60)||o.name,revision:t+1,updated:Date.now()};return a.put(l),await s,l}catch(a){try{r.abort()}catch{}throw await s.catch(()=>{}),a}}async duplicate(e){const{record:t,snapshot:i,recovered:r}=await this.load(e);if(r)throw Error("Recover this world to a new copy before duplicating");return this.create(t.name+" copy",i,t.importSource)}async import(e){const t=lg(e);return this.create(t.name,t.snapshot,t.source)}export(e,t){return JSON.stringify({format:"blockworld2",version:1,name:e.name,...e.importSource?{legacySource:e.importSource}:{},checkpoint:t?ki(t):e.current},null,2)}}class cg{constructor(e){this.game=e,e.paused=!0,document.querySelector("#worlds").onclick=()=>void this.menu(),e.onEdit=()=>{this.ready&&this.save().catch(()=>{})},this.init()}store;current=null;blocked=!1;ready=!1;flight=null;last="";async init(){try{this.store=await gs.open();const e=await this.store.list(),t=await this.store.last(),i=e.find(r=>r.id===t)||e[0]||await this.store.create("My neighbourhood",qn(this.game.snapshot()));await this.open(i.id),this.ready=!0,document.dispatchEvent(new Event("bw2-save-status")),setInterval(()=>{!this.game.paused&&!document.hidden&&this.save().catch(()=>{})},1500),addEventListener("blur",()=>{this.save().catch(()=>{})}),document.addEventListener("visibilitychange",()=>{document.hidden&&this.save().catch(()=>{})})}catch(e){this.ready=!1,this.game.paused=!1,this.failure(e)}}async open(e){var r;this.flight&&await this.flight;const t=await this.store.load(e),i=t.snapshot;this.game.load(i.template,i.world.blocks,i.player,i.world.doors,i.world.activity,i.world.props,i.world.layout),this.game.setAppearance(typeof i.preferences.avatar=="string"?i.preferences.avatar:"explorer"),this.game.lookSpeed=typeof i.preferences.lookSpeed=="number"?i.preferences.lookSpeed:1,this.game.leftHanded=!!i.preferences.leftHanded,eh(this.game),this.game.selected=i.preferences.selected,this.game.favourites=Array.isArray(i.preferences.favourites)?i.preferences.favourites:[],this.game.recent=Array.isArray(i.preferences.recent)?i.preferences.recent:[],this.game.hotbar=Array.isArray(i.preferences.hotbar)?i.preferences.hotbar.slice(0,8):[],ps(this.game),this.game.cameraMode=i.preferences.camera==="third"?"third":"first",this.game.flying=!!i.preferences.flying,document.querySelector("#flightControls").hidden=!this.game.flying,this.game.refreshModes(),this.current=t.record,this.last=ki(qn(this.game.snapshot())).json,this.blocked=t.recovered,document.dispatchEvent(new Event("bw2-save-status")),await this.store.select(e),this.game.paused=!1,t.recovered?this.failure(Error("An older checkpoint was recovered. The damaged original is retained. Save a new copy before continuing.")):((r=document.querySelector("#saveAlert"))==null||r.remove(),this.game.notice("✓ World ready · saved on this device"))}async save(){if(!this.current||!this.store)return;if(this.flight)return await this.flight,this.save();if(this.blocked)throw Error("Save blocked; export or save a new copy");let e,t;try{e=qn(this.game.snapshot()),t=ki(e).json}catch(r){throw this.failure(r),r}if(t===this.last)return;const i=this.current;this.flight=(async()=>{try{this.current=await this.store.save(i.id,i.revision,e),this.last=t}catch(r){throw this.failure(r),r}})();try{await this.flight}finally{this.flight=null}}async newWorld(e){await this.save();const t=mn.find(s=>s.id===e),i=qn({template:e,blocks:[],doors:{},player:t.spawn,selected:"hand",avatar:this.game.appearance,lookSpeed:this.game.lookSpeed,leftHanded:this.game.leftHanded}),r=await this.store.create(t.name,i);return await this.open(r.id),this.close(),r}exportCurrent(){const e=this.current||{name:"Unsaved recovered world"},t=this.store?this.store.export(e,qn(this.game.snapshot())):JSON.stringify({format:"blockworld2",version:1,name:e.name,checkpoint:ki(qn(this.game.snapshot()))},null,2),i=URL.createObjectURL(new Blob([t],{type:"application/json"})),r=document.createElement("a");return r.href=i,r.download="BlockWorld2-backup.bw2",r.click(),setTimeout(()=>URL.revokeObjectURL(i),6e4),t}failure(e){this.blocked=!0,document.dispatchEvent(new Event("bw2-save-status"));let t=document.querySelector("#saveAlert");t||(t=document.createElement("aside"),t.id="saveAlert",t.setAttribute("role","alert"),document.body.append(t)),t.replaceChildren();const i=document.createElement("p");i.textContent="Progress remains in memory. "+String(e),t.append(i);const r=(s,a)=>{const o=document.createElement("button");o.textContent=s,o.onclick=a,t.append(o)};r("Export unsaved work",()=>{try{this.exportCurrent()}catch(s){i.textContent=String(s)}}),r("Save as new copy",()=>{(async()=>{var a,o,l;let s;try{this.flight&&await this.flight.catch(()=>{}),s=await gs.open();const c=await s.create((((a=this.current)==null?void 0:a.name)||"Recovered world")+" recovered",qn(this.game.snapshot()),(o=this.current)==null?void 0:o.importSource);await s.select(c.id),(l=this.store)==null||l.db.close(),this.store=s,this.current=c,this.last=c.current.json,this.blocked=!1,this.ready=!0,document.dispatchEvent(new Event("bw2-save-status")),t.remove(),this.game.notice("✓ Recovered copy saved")}catch(c){s==null||s.db.close(),i.textContent=String(c)}})()})}close(){document.querySelector("#modal").hidden=!0,this.game.paused=!1,this.game.controls.clear()}async menu(){var e;try{await this.save(),this.game.paused=!0,this.game.controls.clear(),this.game.vertical=0;const t=document.querySelector("#modal");t.hidden=!1,t.innerHTML='<section><h1>🌍 Your worlds</h1><div id="worldList"></div><h2>Create another</h2><div id="templates"></div><div class="backupActions"><button id="export">⇩ Backup</button><label class="fileButton">⇧ Import<input id="import" type="file" accept=".bw2,.json,application/json"></label><button id="resume">▶ Play</button></div><p id="worldError" role="alert"></p></section>';const i=r=>{r().catch(s=>{document.querySelector("#worldError").textContent=String(s)})};for(const r of await this.store.list()){const s=document.createElement("div");s.className="worldRow";const a=document.createElement("button");a.textContent=(r.id===((e=this.current)==null?void 0:e.id)?"▶ ":"")+r.name,a.dataset.world=r.id,a.onclick=()=>i(async()=>{await this.open(r.id),this.close()});const o=document.createElement("input");o.value=r.name,o.setAttribute("aria-label","World name");const l=document.createElement("button");l.textContent="✎",l.setAttribute("aria-label","Rename "+r.name),l.onclick=()=>i(async()=>{var u;const d=await this.store.rename(r.id,r.revision,o.value);((u=this.current)==null?void 0:u.id)===r.id&&(this.current=d),await this.menu()});const c=document.createElement("button");c.textContent="⧉",c.setAttribute("aria-label","Duplicate "+r.name),c.onclick=()=>i(async()=>{await this.store.duplicate(r.id),await this.menu()}),s.append(a,o,l,c),document.querySelector("#worldList").append(s)}for(const r of mn){const s=document.createElement("button");s.dataset.template=r.id,s.textContent=r.icon+" "+r.name,s.onclick=()=>i(()=>this.newWorld(r.id)),document.querySelector("#templates").append(s)}document.querySelector("#resume").onclick=()=>this.close(),document.querySelector("#export").onclick=()=>this.exportCurrent(),document.querySelector("#import").onchange=r=>i(async()=>{var o;const s=(o=r.target.files)==null?void 0:o[0];if(!s)return;if(s.size>12e6)throw Error("Backup exceeds 12 MB");const a=await this.store.import(await s.text());await this.open(a.id),this.close()})}catch(t){this.failure(t)}}}class hg{index=new vn(4);entries=new Map;update(e,t){const i=`${e.x},${e.y},${e.z}`;for(const r of this.entries.get(i)||[])this.index.remove(r);if(this.entries.delete(i),t){const r=et(e).map(s=>({...s,block:e,owner:"build:"+i}));this.entries.set(i,r);for(const s of r)this.index.add(s)}}reset(e){this.index=new vn(4),this.entries.clear();for(const t of e)this.update(t,!0)}query(e,t){return this.index.query(Zn(e,t))}blocksNear(e,t){return[...new Set(this.query(e,t).map(i=>i.block))]}}function ug(n,e,t,i=160){const r=Math.round(n.x),s=Math.round(n.z),a=Math.hypot(e.x-n.x,e.z-n.z),o={x:Math.round(n.x+(e.x-n.x)*Math.min(1,12/Math.max(a,.01))),z:Math.round(n.z+(e.z-n.z)*Math.min(1,12/Math.max(a,.01)))},l=(m,_)=>`${m},${_}`,c=[{x:r,z:s,g:0}],d=new Map([[l(r,s),0]]),u=new Map;let h=0;for(;c.length&&h++<i;){c.sort((_,x)=>_.g+Math.abs(_.x-o.x)+Math.abs(_.z-o.z)-(x.g+Math.abs(x.x-o.x)+Math.abs(x.z-o.z)));const m=c.shift();if(m.x===o.x&&m.z===o.z){const _=[o];let x=l(m.x,m.z);for(;u.has(x);){const p=u.get(x);_.push(p),x=l(p.x,p.z)}return _.reverse(),_.shift(),_.length?_:null}for(const[_,x]of[[1,0],[0,1],[-1,0],[0,-1]]){const p=m.x+_,f=m.z+x,v=m.g+1;Math.abs(p-r)>14||Math.abs(f-s)>14||v>28||(d.get(l(p,f))??1/0)<=v||t(p,f)||t((p+m.x)/2,(f+m.z)/2)||(d.set(l(p,f),v),u.set(l(p,f),m),c.push({x:p,z:f,g:v}))}}return null}function dg(n,e,t,i,r){var h,m,_,x;if(!e.length)return!1;if(n.wait>0)return n.wait=Math.max(0,n.wait-t),!1;const s=((h=n.detour)==null?void 0:h[0])||e[n.target%e.length],a=s.x-n.x,o=s.z-n.z,l=Math.hypot(a,o);if(l<.15)return(m=n.detour)!=null&&m.length?(n.detour.shift(),!1):(n.target=(n.target+1)%e.length,n.wait=.6,!1);const c=Math.min(l,i*Math.min(t,.1)),d=n.x+a/l*c,u=n.z+o/l*c;return r(d,u)?(n.stuck+=t,n.stuck>.4&&!((_=n.detour)!=null&&_.length)&&(n.replans||0)<1&&(n.replans=(n.replans||0)+1,n.detour=ug(n,e[n.target%e.length],r)||void 0),n.stuck>2&&(n.target=(n.target+1)%e.length,n.stuck=0,n.wait=.5,n.detour=void 0,n.replans=0),!1):(n.x=d,n.z=u,n.stuck=0,(x=n.detour)!=null&&x.length||(n.replans=0),!0)}function Ql(n){const e=(n%304+304)%304;return e<80?{x:-40+e,z:-36,yaw:-Math.PI/2}:e<152?{x:40,z:-36+e-80,yaw:Math.PI}:e<232?{x:40-(e-152),z:36,yaw:Math.PI/2}:{x:-40,z:36-(e-232),yaw:0}}const Di=[{x:-86,z:-82},{x:8,z:-82},{x:86,z:-82},{x:-86,z:-56},{x:8,z:-56},{x:86,z:-56},{x:-86,z:82},{x:8,z:82},{x:86,z:82}],ec=[[1,3],[0,2,4],[1,5],[0,4,6],[1,3,5,7],[2,4,8],[3,7],[4,6,8],[5,7]];class fg{cars=[];reservations=new Map;constructor(){for(const[e,t]of[0,2,6,8].entries()){const i=ec[t][0],r=Di[t],s=Di[i],a=Math.hypot(s.x-r.x,s.z-r.z),o=(s.x-r.x)/a,l=(s.z-r.z)/a;this.cars.push({x:r.x+l*1.5,z:r.z-o*1.5,yaw:Math.atan2(-o,-l),from:t,to:i,previous:-1,visits:0,wait:e*.4,blocked:0,seed:e+1,reverse:!1})}}update(e,t){e=Math.min(e,.1);for(const[i,r]of this.reservations)Math.hypot(this.cars[r].x-Di[i].x,this.cars[r].z-Di[i].z)>6&&this.reservations.delete(i);for(const[i,r]of this.cars.entries()){if(r.wait>0){r.wait=Math.max(0,r.wait-e);continue}const s=Di[r.from],a=Di[r.to],o=Math.hypot(a.x-s.x,a.z-s.z),l=(a.x-s.x)/o,c=(a.z-s.z)/o,d=r.reverse?{x:s.x+c*1.5,z:s.z-l*1.5}:{x:a.x+c*1.5,z:a.z-l*1.5},u=Math.hypot(d.x-r.x,d.z-r.z);if(u<.12){const f=r.reverse?r.from:r.to,v=r.reverse?r.to:r.from;r.seed=r.seed*1664525+1013904223>>>0;const g=ec[f].filter(R=>R!==v),y=g[r.seed%g.length]??v;r.from=f,r.to=y,r.previous=v,r.visits++,r.reverse=!1,r.blocked=0,r.wait=r.visits%5===0?1.5:.25;continue}if(!r.reverse&&u<6){const f=this.reservations.get(r.to);if(f!==void 0&&f!==i)continue;this.reservations.set(r.to,i)}const h=2.8*e,m=r.x+(d.x-r.x)/u*Math.min(h,u),_=r.z+(d.z-r.z)/u*Math.min(h,u),x=Math.atan2(r.x-m,r.z-_),p=this.cars.some((f,v)=>v!==i&&Math.hypot(m-f.x,_-f.z)<4.8&&Math.cos(x-f.yaw)>.6&&(f.x-m)*-Math.sin(x)+(f.z-_)*-Math.cos(x)>0);if(p||t(m,_,x,i)){r.blocked+=e,r.blocked>5&&!p&&!r.reverse&&(r.reverse=!0,r.wait=.8,this.reservations.get(r.to)===i&&this.reservations.delete(r.to));continue}r.x=m,r.z=_,r.yaw=x,r.blocked=0}}}function pg(n){const e=new ft,t=new _t(1,1,1),i=[],r=n==="dog"?13019779:n==="cat"?12104869:n==="duck"?16113568:12159848,s=(a,o,l,c,d,u,h=r)=>{const m=new Le(t,new It({color:h}));return m.position.set(a,o,l),m.scale.set(c,d,u),e.add(m),m};if(n==="duck"){s(0,.35,0,.6,.45,.7),s(0,.65,-.35,.34,.35,.35),s(0,.61,-.58,.3,.12,.24,14261592);for(const a of[-.2,.2])i.push(s(a,.1,0,.13,.2,.25,14261592));s(-.34,.4,0,.12,.2,.4),s(.34,.4,0,.12,.2,.4)}else if(n==="chicken"){s(0,.3,0,.4,.45,.5,15919826),s(0,.65,-.2,.25,.3,.25,15919826),s(0,.65,-.4,.15,.1,.16,14068323),s(0,.85,-.2,.08,.15,.15,12943976);for(const a of[-.12,.12])i.push(s(a,.1,0,.06,.2,.1,14068323))}else if(n==="rabbit"){s(0,.3,0,.5,.4,.65,11841700),s(0,.55,-.3,.3,.3,.3,11841700);for(const a of[-.1,.1])s(a,.88,-.3,.09,.5,.12,11841700);for(const a of[-.2,.2])i.push(s(a,.12,.15,.18,.25,.35,14537924));s(0,.4,.4,.2,.2,.2,14537924)}else if(n==="cow"||n==="sheep"){const a=n==="cow",o=a?.9:.8,l=a?.95:.65,c=a?1.5:1.1;if(s(0,l,0,o,a?.75:.7,c,15328204),s(0,l+.15,-c*.55,.5,.5,.45,a?12823444:8550251),a){s(-.35,l+.08,.2,.22,.65,.5,8157033),s(.3,l-.1,-.25,.3,.4,.4,8157033);for(const d of[-.3,.3])s(d,l+.43,-c*.55,.12,.22,.1,14207137)}else for(const d of[-.35,0,.35])s(d,l+.4,0,.3,.3,c*.8,15788761);for(const d of[-o*.3,o*.3])for(const u of[-c*.3,c*.3])i.push(s(d,(l-.3)/2,u,.12,l-.3,.12,8550251))}else{const a=n==="horse",o=a?.95:.36,l=a?1.35:.75;s(0,o,0,a?.7:.5,a?.6:.35,l),s(0,a?1.55:.68,-l*.48,a?.4:.32,a?.6:.32,a?.65:.35);for(const c of[a?-.24:-.16,a?.24:.16])for(const d of[-l*.33,l*.33])i.push(s(c,a?.42:.15,d,.12,a?.85:.3,.12));for(const c of[-.13,.13])s(c,a?1.94:.94,-l*.48,.1,n==="dog"?.23:.18,.12,n==="dog"?9402207:r);s(0,a?1.05:.55,l*.65,.1,a?.65:.55,.12,n==="horse"?7756615:r)}return e.userData.species=n,{group:e,limbs:i}}function Ba(n,e){const t=new Sn,i=new N;if(e.obb){const s=e.obb,a=n.origin.x-s.cx,o=n.origin.z-s.cz,l=new _r(new N(a*s.c-o*s.s,n.origin.y,a*s.s+o*s.c),new N(n.direction.x*s.c-n.direction.z*s.s,n.direction.y,n.direction.x*s.s+n.direction.z*s.c));t.min.set(-s.halfW,e.minY,-s.halfD),t.max.set(s.halfW,e.maxY,s.halfD);const c=l.intersectBox(t,i);return c?l.origin.distanceTo(c):1/0}t.min.set(e.minX,e.minY,e.minZ),t.max.set(e.maxX,e.maxY,e.maxZ);const r=n.intersectBox(t,i);return r?n.origin.distanceTo(r):1/0}function mg(n,e,t,i,r){const s=Math.max(1,Math.hypot(e.forward,e.right)),a=(-Math.sin(n.yaw)*e.forward+Math.cos(n.yaw)*e.right)*6/s,o=(-Math.cos(n.yaw)*e.forward-Math.sin(n.yaw)*e.right)*6/s,l=Math.max(1,Math.ceil(i/.01));for(let c=0;c<l;c++)for(const[d,u]of[["x",a],["z",o],["y",t*5]]){const h=n[d];n[d]=Math.max(d==="y"?0:-249,Math.min(d==="y"?24:249,h+u*i/l)),_n(n,r)&&(n[d]=h)}n.vy=0,n.grounded=n.y===0}function gg(n=14987622){const e=new ft,t=new _t(1,1,1),i=(a,o,l,c,d,u,h)=>{const m=new Le(t,new It({color:h}));return m.position.set(a,o,l),m.scale.set(c,d,u),e.add(m),m};i(0,1.43,0,.4,.4,.38,15778974),i(0,1.66,.02,.43,.12,.4,7493190),i(0,.93,0,.48,.55,.3,n);const r=i(-.14,.35,0,.2,.65,.24,5602691),s=i(.14,.35,0,.2,.65,.24,5602691);return i(-.34,.92,0,.16,.5,.2,15778974),i(.34,.92,0,.16,.5,.2,15778974),{group:e,left:r,right:s}}function xg(n,e,t){const i=new N(e.x,e.y+1.3,e.z),r=new N(e.x+Math.sin(e.yaw)*4.5,e.y+3,e.z+Math.cos(e.yaw)*4.5),s=r.clone().sub(i).normalize(),a=new _r(i,s);let o=r.distanceTo(i);for(const l of t){const c={...l,minX:l.minX-.2,maxX:l.maxX+.2,minY:l.minY-.2,maxY:l.maxY+.2,minZ:l.minZ-.2,maxZ:l.maxZ+.2,...l.obb?{obb:{...l.obb,halfW:l.obb.halfW+.2,halfD:l.obb.halfD+.2}}:{}};o=Math.min(o,Ba(a,c)-.2)}return o=Math.max(.15,o),n.position.copy(i.addScaledVector(s,o)),n.lookAt(e.x,e.y+1.3,e.z),n.updateMatrixWorld(),o>.7}function tc(n,e){for(let t=0;t<=4;t++)for(let i=-t;i<=t;i++)for(let r=-t;r<=t;r++){if(t&&Math.abs(i)!==t&&Math.abs(r)!==t)continue;const s={...n,x:n.x+i*.6,z:n.z+r*.6,y:n.y||0,vy:0,grounded:!0};if(!_n(s,e)&&ka(s,e)>=s.y-.04)return s}throw Error("Keep a little space beside the seat")}function xs(n,e){for(let t=0;t<=12;t++)for(let i=-t;i<=t;i++)for(let r=-t;r<=t;r++){if(t&&Math.abs(i)!==t&&Math.abs(r)!==t)continue;const s={x:n.x+i,y:0,z:n.z+r,yaw:n.yaw||0,pitch:0,vy:0,grounded:!0};if(Math.abs(s.x)<249&&Math.abs(s.z)<249&&!_n(s,e))return s}throw Error("No clear arrival space. Your current position is retained.")}function nc(n,e=0){const t=new ft,i=new _t(1,1,1),r=(s,a,o,l,c,d,u)=>{const h=new Le(i,new It({color:u,transparent:u===13165276,opacity:u===13165276?.35:1,depthWrite:u!==13165276}));h.position.set(s,a,o),h.scale.set(l,c,d),t.add(h)};r(0,.65,0,1.5,.65,3,n),r(0,1.2,0,1.25,.6,1.4,13165276),e!==2&&r(0,1.56,e===1?.3:0,1.4,.12,e===1?2.2:1.6,n),e===1&&r(0,1.15,.85,1.4,.7,1.2,n),e===2&&(r(-.4,1,0,.35,.5,.7,7432798),r(.4,1,0,.35,.5,.7,7432798));for(const s of[-.78,.78])for(const a of[-.95,.95])r(s,.32,a,.22,.58,.58,4149581);return r(0,.65,-1.52,.9,.2,.06,16772278),t}function Ct(n){const e=Math.cos(n.yaw),t=Math.sin(n.yaw),i=Math.abs(e)*.8+Math.abs(t)*1.6,r=Math.abs(t)*.8+Math.abs(e)*1.6;return{minX:n.x-i,maxX:n.x+i,minY:0,maxY:1.7,minZ:n.z-r,maxZ:n.z+r,obb:{cx:n.x,cz:n.z,c:e,s:t,halfW:.8,halfD:1.6}}}class _g{constructor(e,t=47,i){var l;this.range=t,this.query=i,e.add(this.group),this.group.add(this.vehicle);const r=[[[26,8],[22,10],[12,10],[12,6],[22,6]],[[12,6],[17,6],[24,9],[17,10]],[[56,-12],[56,-20.6],[58,-20.6],[56,-12]],[[56,0],[56,9],[58,5.4]],[[14,32],[29,32],[25,31]],[[-9,16],[-9,22],[-2,22],[3,16]]],s=(c,d,u,h,m,_=0)=>{const x=d.map(([f,v])=>({x:f,z:v})),p={...x[_%x.length],target:(_+1)%x.length,wait:0,stuck:0};c.position.set(p.x,0,p.z),this.group.add(c),this.agents.push({model:c,route:x,state:p,phase:this.agents.length*.4,animal:u,limbs:h,greetUntil:0,species:m})};for(let c=0;c<(t>100?12:t>47?6:4);c++){const d=t>100?ms(Yi[c].id):gg([14260858,9088931,14139254,9545917,11705009,12171142][c%6]),u=[[[-91,-75],[-91,-30],[-94,-12],[-91,-30]],[[-80,-88],[-40,-88],[0,-88],[-40,-88]],[[91,-45],[91,0],[100,14],[91,0]],[[91,45],[91,70],[70,88],[91,70]],[[-91,55],[-91,85],[-70,88],[-91,85]],[[20,88],[50,88],[70,98],[50,88]]];s(d.group,t>100&&c>=6?u[c-6]:r[t>47?c:c%2],!1,[d.left,d.right],void 0,t<=47?Math.floor(c/2):0)}const a=t>100?["dog","cat","duck","horse","cow","sheep","chicken","rabbit"]:t>47?["dog","cat","duck","horse"]:["cat","duck"],o={cow:[[-83,130],[-78,130],[-78,137],[-83,137]],sheep:[[-69,130],[-63,130],[-63,138],[-69,138]],chicken:[[-61,117],[-56,117],[-56,120],[-61,120]],rabbit:[[48,119],[52,119],[52,124],[48,124]],dog:[[14,17],[22,17],[22,20],[14,20]],cat:[[-12,-5],[-8,-5],[-8,0],[-12,0]],duck:[[28,24],[32,24],[32,27],[28,27]],horse:[[-54,42],[-48,42],[-48,47],[-54,47]]};t>100&&(o.duck=[[87,-112],[87,-121],[88,-125],[87,-121]]);for(const c of a){const d=pg(c);s(d.group,o[c],!0,d.limbs,c)}t>100&&(this.roadTraffic=new fg);for(let c=0;c<(this.roadTraffic?4:2);c++){const d=nc([12156781,8628132,13218174,9480629][c],c%3);this.traffic.push(d);const u=((l=this.roadTraffic)==null?void 0:l.cars[c])||Ql(this.progress[c]);d.position.set(u.x,0,u.z),d.rotation.y=u.yaw,this.group.add(d)}this.sync()}group=new ft;car={x:-28,z:-2,yaw:0};vehicle=nc(15119462);driving=!1;time=0;agents=[];traffic=[];progress=[0,152];roadTraffic=null;sync(){this.vehicle.position.set(this.car.x,0,this.car.z),this.vehicle.rotation.y=this.car.yaw}load(e){if(e!=null&&e.car){const t=e.car;if(![t.x,t.z,t.yaw].every(Number.isFinite)||Math.abs(t.x)>249||Math.abs(t.z)>249)throw Error("Invalid saved car");this.car={...t}}this.driving=!1,this.sync()}snapshot(){return{car:{...this.car}}}use(e,t){if(this.driving){const r=xs({x:this.car.x+Math.cos(this.car.yaw)*2,z:this.car.z-Math.sin(this.car.yaw)*2,yaw:this.car.yaw},[...t,Ct(this.car)]);return Object.assign(e,r),this.driving=!1,"✓ Parked — ready to walk"}if(Math.abs(e.y)<2&&Math.hypot(e.x-this.car.x,e.z-this.car.z)<3)return this.driving=!0,e.y=0,this.sync(),"🚗 Drive with the stick · tap Use to leave";const i=this.agents.find(r=>Math.hypot(r.model.position.x-e.x,r.model.position.z-e.z)<2.5);return i&&Math.abs(e.y)<2?(i.greetUntil=this.time+2,i.model.rotation.y=Math.atan2(e.x-i.state.x,e.z-i.state.z),i.animal?`♡ Hello, ${i.species}!`:"👋 Hello, neighbour!"):null}update(e,t,i,r){var a,o;if(this.time+=e,this.driving){const l={...this.car,yaw:this.car.yaw-i.right*e*1.3*Math.sign(i.forward||1)},c=i.forward*6;l.x-=Math.sin(l.yaw)*c*e,l.z-=Math.cos(l.yaw)*c*e,Math.abs(l.x)<this.range&&Math.abs(l.z)<this.range&&![...((a=this.query)==null?void 0:a.call(this,l,3))||r,...this.traffic.map(d=>Ct({x:d.position.x,z:d.position.z,yaw:d.rotation.y}))].some(d=>Dt(Ct(l),d))&&(this.car=l),Object.assign(t,{x:this.car.x,y:0,z:this.car.z,yaw:this.car.yaw,vy:0,grounded:!0}),this.sync()}const s=Ct(this.car);for(const l of this.agents){const c=Math.hypot(l.state.x-t.x,l.state.z-t.z);if(l.model.visible=c<105,c>80)continue;const d={x:l.state.x,z:l.state.z};let u=!1;const h=l.state.target;this.time>=l.greetUntil&&(u=dg(l.state,l.route,e,l.animal?.65:1,(m,_)=>{var x;return Math.hypot(m-t.x,_-t.z)<.8||this.agents.some(p=>p!==l&&Math.hypot(m-p.state.x,_-p.state.z)<.65)||[...((x=this.query)==null?void 0:x.call(this,{x:m,y:0,z:_},1.2))||r,s,...this.traffic.map(p=>Ct({x:p.position.x,z:p.position.z,yaw:p.rotation.y}))].some(p=>{const f=l.species==="horse"||l.species==="cow"?.4:l.animal?.22:.28,v=l.species==="horse"?2:l.species==="cow"?1.5:l.animal?.95:1.65;return Dt({minX:m-f,maxX:m+f,minZ:_-f,maxZ:_+f,minY:.001,maxY:v},p)})})),h!==l.state.target&&(l.state.wait=l.animal?2:1),l.model.position.set(l.state.x,u&&l.species==="rabbit"?Math.abs(Math.sin(this.time*6))*.15:0,l.state.z),u&&(l.model.rotation.y=Math.atan2(-(l.state.x-d.x),-(l.state.z-d.z))),l.limbs.forEach((m,_)=>m.rotation.x=u?Math.sin(this.time*5+l.phase+(_%2?Math.PI:0))*.2:0)}if(this.roadTraffic){this.roadTraffic.update(e,(l,c,d,u)=>{var h;return Math.hypot(l-t.x,c-t.z)<3||this.agents.some(m=>Math.hypot(l-m.state.x,c-m.state.z)<2)||[...((h=this.query)==null?void 0:h.call(this,{x:l,y:0,z:c},3))||r,s,...this.roadTraffic.cars.filter((m,_)=>_!==u).map(Ct)].some(m=>Dt(Ct({x:l,z:c,yaw:d}),m))}),this.roadTraffic.cars.forEach((l,c)=>{this.traffic[c].position.set(l.x,0,l.z),this.traffic[c].rotation.y=l.yaw});return}for(let l=0;l<this.traffic.length;l++){const c=(this.progress[l]+e*2)%304,d=Ql(c),u=Ct(d),h=this.traffic.filter((_,x)=>x!==l).map(_=>Ct({x:_.position.x,z:_.position.z,yaw:_.rotation.y}));!this.progress.some((_,x)=>x!==l&&(_-c+304)%304<6)&&Math.hypot(d.x-t.x,d.z-t.z)>3&&!this.agents.some(_=>Math.hypot(_.state.x-d.x,_.state.z-d.z)<2.5)&&![...((o=this.query)==null?void 0:o.call(this,d,3))||r,s,...h].some(_=>Dt(u,_))&&(this.progress[l]=c,this.traffic[l].position.set(d.x,0,d.z),this.traffic[l].rotation.y=d.yaw)}}dispose(){const e=new Set,t=new Set;this.group.traverse(i=>{i.isMesh&&(e.add(i.geometry),t.add(i.material))}),e.forEach(i=>i.dispose()),t.forEach(i=>i.dispose()),this.group.removeFromParent()}}const ya=new Map;function vg(n){n.paused=!0,n.controls.clear(),n.vertical=0;const e=document.querySelector("#modal");e.hidden=!1,e.innerHTML='<section class="wardrobe"><h1>👤 Choose your look</h1><div id="avatarGrid"></div><button id="closeWardrobe">▶ Play</button></section>';let t=!0;const i=[];for(const s of Yi){const a=document.createElement("button");a.dataset.avatar=s.id,a.setAttribute("aria-label","Wear "+s.name),a.setAttribute("aria-pressed",String(n.appearance===s.id));const o=document.createElement("img");o.alt=s.name,o.width=112,o.height=96;const l=document.createElement("span");l.textContent=s.name,a.append(o,l),a.onclick=()=>{n.setAppearance(s.id),n.onEdit(),document.querySelectorAll("[data-avatar]").forEach(c=>c.setAttribute("aria-pressed",String(c.dataset.avatar===s.id)))},document.querySelector("#avatarGrid").append(a),i.push(()=>{if(t){if(!ya.has(s.id)){const c=ms(s.id).group;c.rotation.y=Math.PI,ya.set(s.id,Qc(c,!0))}o.src=ya.get(s.id)}})}const r=()=>{var s;t&&((s=i.shift())==null||s(),i.length&&requestAnimationFrame(r))};requestAnimationFrame(r),document.querySelector("#closeWardrobe").onclick=()=>{t=!1,e.hidden=!0,n.paused=!1,n.controls.clear()}}function yg(n){const e=document.querySelector("#modal");n.paused=!0,n.controls.clear(),n.vertical=0,e.hidden=!1,e.innerHTML='<section><h1>🗺 Let’s explore</h1><canvas id="mapCanvas" width="560" height="420" aria-label="Drag map; choose a landmark to travel"></canvas><div id="mapPlaces"></div><div><button id="zoomIn" aria-label="Zoom in">＋</button><button id="zoomOut" aria-label="Zoom out">−</button><button id="closeMap">▶ Play</button></div><p id="mapMessage">Drag to look around. Choose a picture to travel.</p></section>';const t=document.querySelector("#mapCanvas"),i=t.getContext("2d");let r=n.template==="sunbeam-region"?1.4:n.template==="sunbeam-town"?2.7:n.template==="home-square"?4:.8,s=280,a=210,o=null;const l=()=>{i.fillStyle="#c4d39e",i.fillRect(0,0,560,420),i.save(),i.translate(s,a),i.scale(r,r),i.fillStyle="#859995",i.fillStyle="#81b8c6";for(const u of n.world.waterAreas||[])i.fillRect(u.x-u.w/2,u.z-u.d/2,u.w,u.d);if(i.fillStyle="#859995",n.world.mapRoads)for(const u of n.world.mapRoads)i.fillRect(u.x-u.w/2,u.z-u.d/2,u.w,u.d);else if(n.template==="home-square"){for(const u of[-36,4,36])i.fillRect(-43,u-3,86,6);for(const u of[-40,8,40])i.fillRect(u-3,-39,6,78)}for(const u of n.world.houses)i.fillStyle="#b88361",i.save(),i.translate(u.x,u.z),i.rotate(-(u.angle||0)),i.fillRect(-u.w/2,-u.d/2,u.w,u.d),i.restore();i.fillStyle="#edb447",i.beginPath(),i.arc(n.player.x,n.player.z,2,0,Math.PI*2),i.fill(),i.restore()};l(),t.onpointerdown=u=>{t.setPointerCapture(u.pointerId),o={x:u.clientX,y:u.clientY}},t.onpointermove=u=>{if(!o)return;const h=t.getBoundingClientRect();s+=(u.clientX-o.x)*560/h.width,a+=(u.clientY-o.y)*420/h.height,o={x:u.clientX,y:u.clientY},l()},t.onpointerup=t.onpointercancel=()=>{o=null},document.querySelector("#zoomIn").onclick=()=>{r=Math.min(10,r*1.3),l()},document.querySelector("#zoomOut").onclick=()=>{r=Math.max(.3,r/1.3),l()};const c=()=>{e.hidden=!0,n.paused=!1,n.controls.clear()};document.querySelector("#closeMap").onclick=c;const d=n.world.landmarks||[{name:"Home",icon:"⌂",x:n.template==="blank"?0:-14.4,z:n.template==="blank"?8:-1.2}];for(const u of d){const h=document.createElement("button");h.textContent=u.icon+" "+u.name,h.dataset.place=u.name,h.onclick=()=>{try{const m=xs(u,[...n.obstacles(),...n.commands.blocks.flatMap(et)]);n.endPlay(!1),Object.assign(n.player,m),n.seated=null,n.flying=!1,n.activity&&(n.activity.driving=!1),n.vertical=0,n.refreshModes(),n.cancel(),n.onEdit(),c()}catch(m){document.querySelector("#mapMessage").textContent=String(m)}},document.querySelector("#mapPlaces").append(h)}}function Mg(n,e,t){return e.filter(i=>Math.abs(i.y-n.y)<1.8&&Math.hypot(i.x-n.x,i.z-n.z)<i.range).sort((i,r)=>Math.hypot(i.x-n.x,i.z-n.z)-Math.hypot(r.x-n.x,r.z-n.z)).find(t)}const ic=new Set(["swing","seesaw","bounce","slide","rock"]);function Ga(n){return n==="slide"?1.8:4}function Ma(n,e,t){const i=(e.rotation||0)*Math.PI/180,r=Math.min(t/Ga(n),1);let s=0,a=0,o=.3,l=i;return n==="slide"&&(a=-.65+r*1.3,o=1-r,l+=Math.PI),n==="swing"&&(a=Math.sin(t*2)*.65,o=.3+(1-Math.cos(t*2))*.18),n==="seesaw"&&(s=1.2,o=.4+Math.sin(t*2)*.2),n==="bounce"&&(o=.5+Math.abs(Math.sin(r*Math.PI*3))*.85),n==="rock"&&(o=.2+Math.sin(t*3)*.04),{x:e.x+.5+s*Math.cos(i)+a*Math.sin(i),y:e.y+o,z:e.z+.5-s*Math.sin(i)+a*Math.cos(i),yaw:l}}function ch(n){const e=n.model.parent;n.model.traverse(t=>{t.isMesh&&t.material.dispose()}),n.model.removeFromParent(),n.model=ai(n.block),e==null||e.add(n.model)}function rc(n,e){if(n.authoredProps){for(const t of n.authoredProps)e!=null&&e[t.id]&&(Object.assign(t.block,e[t.id]),ch(t));n.solids=[...n.staticSolids,...n.authoredProps.flatMap(t=>et(t.block).map(i=>({...i,owner:"prop:"+t.id})))]}}function Sg(n){return Object.fromEntries((n.authoredProps||[]).map(e=>[e.id,{...e.block.open!==void 0?{open:e.block.open}:{},...e.block.on!==void 0?{on:e.block.on}:{}}]))}function bg(n){const e=new Ja({canvas:n,antialias:!1,powerPreference:"low-power"});e.setPixelRatio(Math.min(devicePixelRatio,1.25)),e.outputColorSpace=xt;const t=new zc;t.background=new $e("#badbdc"),t.fog=new Qa("#badbdc",70,155),t.add(new Oc(16774620,6720624,2.2));const i=new Bc(16770744,1.8);i.position.set(-30,50,20),t.add(i);const r=new qt(67,1,.06,180);r.rotation.order="YXZ";function s(){e.setSize(innerWidth,innerHeight),r.aspect=innerWidth/innerHeight,r.updateProjectionMatrix()}return s(),addEventListener("resize",s),{renderer:e,scene:t,camera:r,dispose(){removeEventListener("resize",s),e.dispose()}}}class wg{constructor(e=1/60,t=5){this.step=e,this.maxSteps=t}previous=0;accumulator=0;reset(e){this.previous=e,this.accumulator=0}tick(e,t){const i=Math.max(0,Math.min(.1,(e-this.previous)/1e3));this.previous=e,this.accumulator=Math.min(this.accumulator+i,this.step*this.maxSteps);let r=0;for(;this.accumulator+1e-9>=this.step&&r<this.maxSteps;)t(this.step),this.accumulator-=this.step,r++;return r}}function Eg(n,e){let t=null,i=null;const r=()=>{clearTimeout(i),i=null};function s(){var a;r(),t=null,(a=e.onIndicator)==null||a.call(e,null)}n.addEventListener("pointerdown",a=>{var o;if(t){s();return}e.canStart()&&(a.preventDefault(),n.setPointerCapture(a.pointerId),t={id:a.pointerId,x:a.clientX,y:a.clientY,lastX:a.clientX,lastY:a.clientY,drag:!1,held:!1},(o=e.onStart)==null||o.call(e,t),i=setTimeout(()=>{var l;!t||t.drag||(t.held=!0,(l=e.onIndicator)==null||l.call(e,null),e.onHold(t.x,t.y))},550))}),n.addEventListener("pointermove",a=>{var c;if(!t||a.pointerId!==t.id)return;const o=a.clientX-t.lastX,l=a.clientY-t.lastY;!t.drag&&Math.hypot(a.clientX-t.x,a.clientY-t.y)>10?(t.drag=!0,r(),(c=e.onIndicator)==null||c.call(e,null),e.onLook(a.clientX-t.x,a.clientY-t.y)):t.drag&&e.onLook(o,l),t.lastX=a.clientX,t.lastY=a.clientY}),n.addEventListener("pointerup",a=>{var l;if(!t||a.pointerId!==t.id)return;const o=t;s(),!o.drag&&!o.held&&e.onTap(o.x,o.y),(l=e.onEnd)==null||l.call(e)});for(const a of["pointercancel","lostpointercapture"])n.addEventListener(a,o=>{(t==null?void 0:t.id)===o.pointerId&&s()});return n.addEventListener("contextmenu",a=>a.preventDefault()),{cancel:s}}function Tg(n=document){const e=new Map;let t=!1,i=0;n.addEventListener("pointerdown",r=>{var a,o;i=0;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button");(r.pointerType==="touch"||r.pointerType==="pen")&&s&&!s.disabled&&e.set(r.pointerId,{button:s,x:r.clientX,y:r.clientY,moved:!1})},!0),n.addEventListener("keydown",()=>{i=0},!0),n.addEventListener("pointermove",r=>{const s=e.get(r.pointerId);s&&Math.hypot(r.clientX-s.x,r.clientY-s.y)>10&&(s.moved=!0)},!0),n.addEventListener("pointercancel",r=>{e.has(r.pointerId)&&(i=performance.now()+900),e.delete(r.pointerId)},!0),n.addEventListener("pointerup",r=>{var a,o;const s=e.get(r.pointerId);if(e.delete(r.pointerId),(r.pointerType==="touch"||r.pointerType==="pen")&&((o=(a=r.target).closest)!=null&&o.call(a,"#world"))&&(i=performance.now()+900),!!s&&(i=performance.now()+900,!s.moved&&!s.button.disabled&&s.button.isConnected!==!1)){r.preventDefault(),t=!0;try{s.button.click()}finally{t=!1}}},!0),n.addEventListener("click",r=>{var a,o;const s=(o=(a=r.target).closest)==null?void 0:o.call(a,"button,summary,.file-button");!t&&s&&performance.now()<i&&(r.preventDefault(),r.stopImmediatePropagation())},!0)}class Ag{stick={x:0,y:0};keys=new Set;pointer=null;gestures;constructor(e,t,i){Tg();let r=null;this.gestures=Eg(e,{canStart:t,onStart:()=>{r=i.pose?{...i.pose()}:null},onTap:i.tap,onHold:(o,l)=>{var d;const c=(d=i.pose)==null?void 0:d.call(i);r&&c&&(Math.hypot(c.x-r.x,c.y-r.y,c.z-r.z)>.08||Math.abs(c.yaw-r.yaw)+Math.abs(c.pitch-r.pitch)>.01)||i.hold(o,l)},onLook:i.look});const s=document.querySelector("#joystick"),a=o=>{const l=s.getBoundingClientRect(),c=o.clientX-l.left-l.width/2,d=o.clientY-l.top-l.height/2,u=Math.max(1,Math.hypot(c,d)/40);this.stick={x:c/u/40,y:d/u/40},document.querySelector("#knob").style.transform=`translate(${this.stick.x*36}px,${this.stick.y*36}px)`};s.addEventListener("pointerdown",o=>{!t()||this.pointer!==null||(o.preventDefault(),this.pointer=o.pointerId,s.setPointerCapture(o.pointerId),a(o))}),s.addEventListener("pointermove",o=>{this.pointer===o.pointerId&&a(o)});for(const o of["pointerup","pointercancel","lostpointercapture"])s.addEventListener(o,l=>{this.pointer===l.pointerId&&this.clear()});addEventListener("keydown",o=>{var l;(l=o.target)!=null&&l.matches("input,textarea,select")||!t()&&o.code!=="Escape"||(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(o.code)&&o.preventDefault(),this.keys.add(o.code),o.repeat||i.action(o.code))}),addEventListener("keyup",o=>this.keys.delete(o.code)),addEventListener("blur",()=>this.clear()),document.addEventListener("visibilitychange",()=>this.clear())}clear(){var t;this.keys.clear(),this.pointer=null,this.stick={x:0,y:0},(t=this.gestures)==null||t.cancel();const e=document.querySelector("#knob");e&&(e.style.transform="")}movement(){return{forward:+(this.keys.has("KeyW")||this.keys.has("ArrowUp"))-+(this.keys.has("KeyS")||this.keys.has("ArrowDown"))-this.stick.y,right:+(this.keys.has("KeyD")||this.keys.has("ArrowRight"))-+(this.keys.has("KeyA")||this.keys.has("ArrowLeft"))+this.stick.x}}}const Zt=n=>`${n.x},${n.y},${n.z}`;class Sa{constructor(e,t,i,r=()=>{}){this.obstacles=e,this.player=t,this.changed=i,this.completed=r}blocks=[];past=[];future=[];reason(e,t=!0,i){return jl(e,this.blocks.filter(r=>!i||Zt(r)!==Zt(i)),this.obstacles(),this.player(),t)}apply(e,t,i=!1,r=!1){const s=t?e.before:e.after,a=t?e.after:e.before,o=new Set(s.map(Zt));if(s.some(c=>!this.blocks.some(d=>Zt(d)===Zt(c))))return"The original object changed";const l=this.blocks.filter(c=>!o.has(Zt(c)));for(const c of a){if(l.some(d=>Zt(d)===Zt(c)))return"Find a clear space";if(i){const d=jl(c,l,this.obstacles(),this.player(),r);if(d)return d}else if(et(c).some(d=>Dt(d,qi(this.player()))||[...this.obstacles(),...l.flatMap(et)].some(u=>Dt(d,u))))return"That space is occupied";l.push({...c})}return this.blocks.splice(0,this.blocks.length,...l),""}notify(e,t){for(const i of t?e.before:e.after)this.changed(i,!1);for(const i of t?e.after:e.before)this.changed(i,!0);this.completed()}execute(e,t,i=!0){const r=this.apply(e,!0,i,t);return r||(this.past.push(structuredClone(e)),this.past.length>100&&this.past.shift(),this.future=[],this.notify(e,!0),"")}place(e,t=!0){return this.execute({before:[],after:[{...e}]},t)}placeMany(e,t=!0){return this.execute({before:[],after:e.map(i=>({...i}))},t)}move(e,t,i=!0){return this.execute({before:[{...e}],after:[{...t}]},i)}toggle(e){const t=Lt.get(e.type);if((t==null?void 0:t.interaction)==="door"||(t==null?void 0:t.interaction)==="cabinet"){const i=[...this.obstacles(),...this.blocks.filter(r=>Zt(r)!==Zt(e)).flatMap(r=>et(r)),qi(this.player())];for(let r=0;r<=12;r++){const s=(e.open?1:0)+(e.open?-1:1)*r/12;if(Vm(e,s).some(a=>i.some(o=>Dt(a,o))))return"Door swing blocked — make a little room"}}return this.execute({before:[{...e}],after:[{...e,...(t==null?void 0:t.interaction)==="light"?{on:e.on===!1}:{open:!e.open}}]},!1,!1)}remove(e){const t=this.blocks.find(i=>Zt(i)===Zt(e));return!!t&&this.execute({before:[{...t}],after:[]},!1)===""}undo(){const e=this.past.at(-1);return!e||this.apply(e,!1)?!1:(this.past.pop(),this.future.push(e),this.notify(e,!1),!0)}redo(){const e=this.future.at(-1);return!e||this.apply(e,!0)?!1:(this.future.pop(),this.past.push(e),this.notify(e,!0),!0)}reset(e){this.blocks.splice(0,this.blocks.length,...e.map(t=>({...t}))),this.past=[],this.future=[]}get canUndo(){return!!this.past.length}get canRedo(){return!!this.future.length}}const ji=Math.PI/2,Rg=ji/.65,Cg=2.25,Pg=3.1,Lg=1.2;function hh(n){if(n.kind==="roller"){const e=Math.max(0,Math.min(1,n.angle/ji));n.leaf.scale.y=Math.max(.001,1-e),n.leaf.position.y=e*n.height,n.pivot.rotation.y=n.baseAngle}else n.pivot.rotation.y=n.baseAngle+n.angle}function Dg(n,e=!1,t=-1){n.kind==="roller"&&(t=1),Object.assign(n,{open:e,targetOpen:e,swing:t,angle:e?t*ji:0,leaveSince:null,manualHold:!1,lastAttempt:-1/0,blocked:!1}),hh(n)}function sc(n,e,t){return Math.abs(e.y)<2.3&&Math.hypot(e.x-n.center.x,e.z-n.center.z)<t}function Ha(n,e,t,i,r,s){const a=Math.max(1,Math.ceil(Math.abs(t-e)/.02)),o=[Yc(i),...r.map(Jn),...s];for(let l=0;l<=a;l++){const c=oh(n,e+(t-e)*l/a);if(o.some(d=>Wi(c,d)))return!1}return!0}function Va(n,e,t,i,r=[],s=!1){const a=n.angle??(n.open?(n.swing??-1)*ji:0);if(e){const o=(t.x-n.center.x)*Math.sin(n.baseAngle)+(t.z-n.center.z)*Math.cos(n.baseAngle),l=n.kind==="roller"?1:Math.abs(a)>.01?n.swing??-1:o>=0?1:-1;for(const c of Math.abs(a)>.01?[l]:[l,-l])if(Ha(n,a,c*ji,t,i,r))return n.swing=c,n.targetOpen=n.open=!0,n.manualHold=s,n.blocked=!1,{ok:!0}}else if(Ha(n,a,0,t,i,r))return n.targetOpen=n.open=!1,n.manualHold=s,n.blocked=!1,{ok:!0};return{ok:!1,message:e?"There is something in the door’s swing. Make room beside it.":"The door stays open while someone or something is in its way."}}function Ig(n,e,t,i,r,s,a,o=null,l="normal"){const c=Cg*Xc(l)/3.4,d=Math.max(Pg,c+.85);let u=!1;for(const h of n){let m;const _=()=>m??=(o==null?void 0:o(h))??{blocks:t,solids:i},x=sc(h,e,d);x?h.leaveSince=null:(h.leaveSince??=s,h.manualHold=!1),r&&!h.manualHold&&s-h.lastAttempt>.3&&(sc(h,e,c)&&!h.targetOpen?(h.lastAttempt=s,Va(h,!0,e,_().blocks,_().solids)):!x&&h.targetOpen&&s-h.leaveSince>Lg&&(h.lastAttempt=s,Va(h,!1,e,_().blocks,_().solids)));let f=(h.targetOpen?h.swing*ji:0)-h.angle;const v=Math.sign(f)*Math.min(Math.abs(f),Math.max(0,a)*Rg),g=Math.max(1,Math.ceil(Math.abs(v)/.02));for(let y=0;y<g&&Math.abs(v)>1e-8;y++){const R=h.angle+v/g;if(!Ha(h,h.angle,R,e,_().blocks,_().solids)){h.blocked=!0,h.targetOpen||(h.targetOpen=h.open=!0,h.manualHold=!1,h.leaveSince=null);break}h.angle=R,h.blocked=!1,u=!0}hh(h)}return u}const Ug=Ig;class zg{activity=null;seated=null;playing=null;contextTime=0;appearance="explorer";body=ms();lookSpeed=1;leftHanded=!1;lightPool=[];dirtyBuilds=[];gait=0;walkAmount=0;cameraMode="first";flying=!1;vertical=0;view;world;worldGroup=new ft;buildGroup=new ft;preview=new ft;player={...mn[0].spawn,vy:0,grounded:!0};selected="hand";favourites=[];recent=[];hotbar=[];repeatCount=1;pending=null;moving=null;pickingMove=!1;automatic=!0;guard=!0;paused=!1;template="legacy-06";controls;commands;chunks;index=new vn;builds=new hg;clock=new wg;ray=new Rm;geometry=new _t(1,1,1);materials={};decor=new Map;noticeTimer=0;onEdit=()=>{};constructor(){document.querySelector("#app").innerHTML='<canvas id="world" tabindex="-1" aria-label="Drag to look; tap to build; hold to remove"></canvas><div class="brand">BLOCKWORLD <b>2.0</b><small>Sunbeam Town · Development preview</small></div><nav id="top"><button id="home" aria-label="Return home">⌂</button><button id="doorMode" aria-label="Automatic doors" aria-pressed="true">🚪 Auto</button><button id="guard" aria-label="Edge protection" aria-pressed="true">🛡</button><button id="cameraMode" aria-label="Switch camera">👤</button><button id="flyMode" aria-label="Creative flight" aria-pressed="false">🪽</button><button id="mapButton" aria-label="World map">🗺</button><button id="catalogueButton" aria-label="Building catalogue">▦</button><button id="avatarButton" aria-label="Choose avatar">👕</button><button id="controlsButton" aria-label="Control settings">🎮</button><button id="worlds" aria-label="Worlds">🌍</button></nav><output id="status" role="status" aria-live="polite">Starting…</output><div id="crosshair">+</div><div id="joystick" aria-label="Move joystick"><div id="knob"></div></div><div id="actions"><button id="use" aria-label="Use nearby object">🚪</button><button id="undo" aria-label="Undo">↶</button><button id="redo" aria-label="Redo">↷</button><button id="jump" aria-label="Jump">↑</button></div><div id="palette" aria-label="Building hotbar"></div><button id="moveObject" aria-label="Move a built object">✥ Move</button><div id="flightControls" hidden><button id="flyUp" aria-label="Fly up">⇧</button><button id="flyDown" aria-label="Fly down">⇩</button></div><div id="previewControls" hidden><button id="cancel" aria-label="Cancel placement">✕</button><button id="lower" aria-label="Lower preview">⇩</button><button id="raise" aria-label="Raise preview">⇧</button><button id="rotate" aria-label="Rotate preview">↻</button><button id="confirm" aria-label="Confirm placement">✓</button></div><div id="modal" hidden></div>',this.view=bg(document.querySelector("#world")),this.view.scene.add(this.worldGroup,this.buildGroup,this.preview,this.body.group);for(let e=0;e<3;e++){const t=new Tm(16768917,0,8,2);this.lightPool.push(t),this.view.scene.add(t)}for(const e of oi)this.materials[e.id]=new It({color:e.color});this.chunks=new qm(this.buildGroup,this.geometry,this.materials,e=>(this.decor.has(e)||this.decor.set(e,new It({color:e})),this.decor.get(e))),this.commands=new Sa(()=>this.obstacles(),()=>this.player,(e,t)=>{this.dirtyBuilds.push({block:e,present:t}),this.builds.update(e,t)},()=>{this.chunks.updateMany(this.dirtyBuilds.splice(0)),this.refreshHistory(),this.onEdit()}),this.load("sunbeam-region"),this.controls=new Ag(document.querySelector("#world"),()=>!this.paused,{tap:(e,t)=>this.tap(e,t),hold:(e,t)=>this.removeAt(e,t),look:(e,t)=>{this.player.yaw-=e*.004*this.lookSpeed,this.player.pitch=Math.max(-1.3,Math.min(1.3,this.player.pitch-t*.0035*this.lookSpeed))},action:e=>this.key(e),pose:()=>this.player}),this.ui(),this.clock.reset(performance.now()),requestAnimationFrame(e=>this.frame(e)),this.notice("Ready · choose a picture to build")}load(e,t=[],i,r={},s,a,o=2){var u,h,m;const l=new ft,c=ag(l,e,t,o),d=new vn;rc(c,a);for(const _ of c.solids)d.add(_);if(t.some(_=>d.query(fs(_)).some(x=>et(_).some(p=>Dt(p,x.ramp?{...x,ramp:null}:x)))))throw this.clearGroup(l),Error("Saved objects overlap permanent structures; active progress is unchanged");if((e==="home-square"||e==="sunbeam-town"||e==="sunbeam-region")&&(s!=null&&s.car)&&[...c.solids,...t.flatMap(et)].some(_=>Dt(Ct(s.car),_)))throw this.clearGroup(l),Error("Saved vehicle overlaps structures; active world is retained");this.endPlay(!1),this.seated=null,(u=this.activity)==null||u.dispose(),this.activity=null,this.flying=!1,this.vertical=0,this.clearGroup(this.worldGroup);for(const _ of[...l.children])this.worldGroup.add(_);this.chunks.clear(),this.template=e,document.querySelector(".brand small").textContent=`${(h=mn.find(_=>_.id===e))==null?void 0:h.name} · Development preview`,this.world=c,this.index=d,(e==="home-square"||e==="sunbeam-town"||e==="sunbeam-region")&&(this.activity=new _g(this.view.scene,this.world.activityRange||47,(_,x)=>this.querySolids(_,x)),this.activity.load(s));for(const _ of this.world.doors)Dg(_,r[_.id]===!0,-1);this.player={...((m=mn.find(_=>_.id===e))==null?void 0:m.spawn)||mn[0].spawn,...i,vy:0,grounded:!0},this.commands.reset(t),this.builds.reset(t),this.chunks.reset(t),this.cancel(),_n(this.player,this.nearbySolids())&&this.home(),this.refreshHistory(),this.updateCamera()}clearGroup(e){const t=new Set,i=new Set,r=new Set;e.traverse(s=>{if(s.isSprite&&(i.add(s.material),s.material.map&&r.add(s.material.map)),s.isMesh){s.userData.sharedGeometry||t.add(s.geometry);for(const a of Array.isArray(s.material)?s.material:[s.material])i.add(a),a.map&&!a.map.userData.shared&&r.add(a.map);s.isInstancedMesh&&s.dispose()}}),t.forEach(s=>s.dispose()),i.forEach(s=>s.dispose()),r.forEach(s=>s.dispose()),e.clear()}obstacles(){return[...this.world.solids,...this.waterHazards(),...this.world.doors.map(e=>Rn(e)),...this.activity?[Ct(this.activity.car)]:[]]}waterHazards(){return(this.world.waterAreas||[]).map(e=>({minX:e.x-e.w/2,maxX:e.x+e.w/2,minZ:e.z-e.d/2,maxZ:e.z+e.d/2,minY:0,maxY:.08}))}querySolids(e,t){return[...this.index.query(Zn(e,t)),...this.builds.query(e,t),...this.world.doors.filter(i=>Math.hypot(i.center.x-e.x,i.center.z-e.z)<t+3).map(i=>Rn(i)),...this.waterHazards().filter(i=>i.minX<e.x+t&&i.maxX>e.x-t&&i.minZ<e.z+t&&i.maxZ>e.z-t)]}nearbySolids(){return[...this.activity&&!this.activity.driving?[Ct(this.activity.car)]:[],...this.index.query(Zn(this.player,3)),...this.builds.query(this.player,3),...this.world.doors.filter(e=>Math.hypot(e.center.x-this.player.x,e.center.z-this.player.z)<6).map(e=>Rn(e))]}update(e){var a,o,l,c;Ug(this.world.doors,this.player,this.commands.blocks,this.world.solids,this.automatic,performance.now()/1e3,e,d=>({solids:[...this.index.query(Zn({...d.center,y:0},4)),...this.activity?[Ct(this.activity.car)]:[],...this.builds.query({...d.center,y:0},4).map(u=>u.ramp?{...u,ramp:null}:u)],blocks:[]}));const t=this.controls.movement(),i=this.nearbySolids(),r=[];if(this.walkAmount=Math.min(1,Math.hypot(t.forward,t.right)),this.gait+=e*this.walkAmount*6,this.contextTime+=e,this.contextTime>.2&&(this.contextTime=0,this.refreshModes(),this.refreshLights()),this.playing){Math.abs(t.forward)+Math.abs(t.right)>.2?this.endPlay():(this.playing.elapsed+=e,Object.assign(this.player,Ma(this.playing.kind,this.playing.block,this.playing.elapsed)),this.animatePlay(),this.playing.elapsed>=Ga(this.playing.kind)&&this.endPlay()),(a=this.activity)==null||a.update(e,this.player,{forward:0,right:0},r);return}this.seated&&Math.abs(t.forward)+Math.abs(t.right)>.2&&this.stand(),!((o=this.activity)!=null&&o.driving)&&!this.seated&&(this.flying?mg(this.player,t,this.vertical+ +this.controls.keys.has("Space")-+(this.controls.keys.has("ShiftLeft")||this.controls.keys.has("ShiftRight")),e,i):Km(this.player,{...t,edgeProtection:this.guard,walkSpeed:"normal"},e,i)),(l=this.activity)==null||l.update(e,this.player,t,r);const s=(this.world.waterAreas||[]).find(d=>Math.abs(this.player.x-d.x)<d.w/2&&Math.abs(this.player.z-d.z)<d.d/2);s&&!this.flying&&!((c=this.activity)!=null&&c.driving)&&this.player.y<.25&&(Object.assign(this.player,xs(s.shore,[...this.obstacles(),...this.commands.blocks.flatMap(et)])),this.notice("💧 Back to the lakeside path"))}refreshLights(){const e=[...this.builds.blocksNear(this.player,12),...(this.world.authoredProps||[]).map(t=>t.block)].filter(t=>{var i;return((i=Lt.get(t.type))==null?void 0:i.interaction)==="light"&&t.on!==!1&&Math.hypot(t.x-this.player.x,t.z-this.player.z)<12}).sort((t,i)=>Math.hypot(t.x-this.player.x,t.z-this.player.z)-Math.hypot(i.x-this.player.x,i.z-this.player.z));this.lightPool.forEach((t,i)=>{const r=e[i];t.intensity=r?2.5:0,r&&t.position.set(r.x+.5,fs(r).maxY-.1,r.z+.5)})}frame(e){if(requestAnimationFrame(t=>this.frame(t)),this.paused||document.hidden){this.clock.reset(e);return}this.clock.tick(e,t=>this.update(t)),this.updateCamera(),this.world.staticRender.updateVisibility(this.view.camera,155),this.view.renderer.render(this.view.scene,this.view.camera)}updateCamera(){var t,i,r;this.body.group.scale.setScalar((t=this.activity)!=null&&t.driving?.72:1),this.body.group.position.set(this.player.x,(i=this.activity)!=null&&i.driving?.22:this.seated?this.seated.height-.65:this.player.y,this.player.z);const e=this.seated||this.playing||((r=this.activity)==null?void 0:r.driving);this.body.left.rotation.x=e?-1.2:Math.sin(this.gait)*.25*this.walkAmount,this.body.right.rotation.x=e?-1.2:-Math.sin(this.gait)*.25*this.walkAmount,this.body.arms.forEach((s,a)=>{var o;return s.rotation.x=(o=this.activity)!=null&&o.driving?-1:e?-.1:Math.sin(this.gait+(a?Math.PI:0))*.2*this.walkAmount}),this.body.group.rotation.y=this.player.yaw,this.body.group.visible=!1,this.cameraMode==="third"?this.body.group.visible=xg(this.view.camera,this.player,[...this.index.query(Zn(this.player,8)),...this.world.doors.map(s=>Rn(s)),...this.builds.query(this.player,8)]):(this.view.camera.position.set(this.player.x,this.seated?this.seated.height+.9:this.player.y+1.53,this.player.z),this.view.camera.rotation.set(this.player.pitch,this.player.yaw,0),this.view.camera.updateMatrixWorld())}hit(e=innerWidth/2,t=innerHeight/2){var o,l,c;this.updateCamera(),this.view.scene.updateMatrixWorld(!0),this.ray.setFromCamera(new Oe(e/innerWidth*2-1,1-t/innerHeight*2),this.view.camera);const i=this.ray.intersectObjects([...this.chunks.rayMeshes(),this.world.ground],!1)[0];if(!i||i.distance>8)return null;for(const d of[...this.index.query(Zn(this.player,9)),...this.world.doors.map(u=>Rn(u))])if(Ba(this.ray.ray,d)<i.distance-.02)return null;const r=i.object.userData,s=((o=r.faceBlocks)==null?void 0:o[i.faceIndex])||((l=r.blocks)==null?void 0:l[i.instanceId])||r.block;let a;if(s){const d=i.face.normal.clone().transformDirection(i.object.matrixWorld);if(i.object.isInstancedMesh){const h=new Qe;i.object.getMatrixAt(i.instanceId,h),d.copy(i.face.normal).transformDirection(h).transformDirection(i.object.matrixWorld)}const u=i.point.clone().addScaledVector(d,.015);if(a={x:Math.floor(u.x),y:d.y>.9?Math.ceil(i.point.y*100-1e-5)/100:d.y<-.9?Math.floor(i.point.y)-1:s.y,z:Math.floor(u.z),type:this.selected},!((c=Lt.get(s.type))!=null&&c.cube)){const h=["x","y","z"].sort((m,_)=>Math.abs(d[_])-Math.abs(d[m]))[0];h!=="y"?(a={...s,type:this.selected},a[h]+=Math.sign(d[h])):d.y<0&&(a.y=Math.floor(i.point.y)-1)}}else a={x:Math.floor(i.point.x),y:0,z:Math.floor(i.point.z),type:this.selected};return{target:s,aim:a}}tap(e,t){var a,o,l;if(this.paused)return;if(this.playing){this.notice("Tap Use to finish playing");return}if((a=this.activity)!=null&&a.driving){this.notice("Park before building");return}const i=this.hit(e,t);if(this.pickingMove){if(!(i!=null&&i.target)){this.notice("Tap an object you built");return}this.moving={...i.target},this.pending={...i.target},this.pickingMove=!1,this.showPreview(),this.notice("Tap its new spot, turn it, then confirm");return}if(this.moving&&i){this.pending={...i.aim,type:this.moving.type,rotation:((o=this.pending)==null?void 0:o.rotation)||0},this.showPreview();return}if(this.selected==="hand"){this.use();return}const r=i;if(!r){this.notice("Move closer to a clear space");return}const s=this.placementReason(r.aim);if(s){this.notice(s);return}!((l=Lt.get(this.selected))!=null&&l.cube)||this.repeatCount>1?(this.pending={...r.aim,rotation:0},this.showPreview()):this.notice(this.commands.place(r.aim)||"✓ Placed")}removeAt(e,t){if(this.paused||this.playing)return;const i=this.hit(e,t);i!=null&&i.target&&(this.cancel(),this.commands.remove(i.target),this.notice("↶ Removed — Undo brings it back"))}showPreview(){if(this.preview.traverse(e=>{e.isMesh&&e.material.dispose()}),this.preview.clear(),!!this.pending){for(const e of this.planned(this.pending))this.preview.add(ai(e,!0));document.querySelector("#previewControls").hidden=!1,document.querySelector("#confirm").disabled=!!this.placementReason(this.pending)}}cancel(){this.pending=null,this.moving=null,this.pickingMove=!1,this.preview.traverse(t=>{t.isMesh&&t.material.dispose()}),this.preview.clear();const e=document.querySelector("#previewControls");e&&(e.hidden=!0)}confirm(){if(!this.pending)return;const e=this.placementReason(this.pending)||(this.moving?this.commands.move(this.moving,this.pending):this.commands.placeMany(this.planned(this.pending),!1));e?this.notice(e):(this.cancel(),this.notice("✓ Placed"))}stand(){if(!this.seated)return!0;try{return Object.assign(this.player,tc(this.seated.entry,[...this.obstacles(),...this.commands.blocks.flatMap(et)])),this.seated=null,this.refreshModes(),this.onEdit(),!0}catch(e){return this.notice(String(e)),!1}}contextTarget(){const e=[],t=(i,r={})=>{var a;const s=(a=Lt.get(i.type))==null?void 0:a.interaction;s&&e.push({id:r.prop?"prop:"+r.prop.id:`build:${i.x},${i.y},${i.z}`,kind:"object",x:i.x+.5,y:i.y,z:i.z+.5,range:2.5,icon:s==="light"?"💡":s==="seat"?"🪑":ic.has(s)?"🛝":"🚪",label:Lt.get(i.type).label,data:{block:i,...r}})};for(const i of this.builds.blocksNear(this.player,3))Math.abs(i.x-this.player.x)<3&&Math.abs(i.z-this.player.z)<3&&t(i,{built:!0});for(const i of this.world.authoredProps||[])t(i.block,{prop:i});for(const i of this.world.activities||[])t(i,{static:!0});for(const[i,r]of(this.world.seats||[]).entries())e.push({id:"seat:"+i,kind:"seat",x:r.x,y:r.y||0,z:r.z,range:2,icon:"🪑",label:"Sit",data:r});for(const i of this.world.doors)e.push({id:"door:"+i.id,kind:"door",x:i.center.x,y:0,z:i.center.z,range:3.2,icon:"🚪",label:"Door",data:i});if(this.activity){const i=this.activity.car;e.push({id:"vehicle",kind:"vehicle",x:i.x,y:0,z:i.z,range:3,icon:"🚗",label:"Drive",data:i});for(const[r,s]of this.activity.agents.entries())e.push({id:"agent:"+r,kind:"agent",x:s.state.x,y:0,z:s.state.z,range:2.5,icon:s.animal?"🐾":"👋",label:s.species||"Neighbour",data:s})}return Mg(this.player,e,i=>{const r=new N(this.player.x,this.player.y+1.3,this.player.z),s=new N(i.x,i.y+1.2,i.z),a=r.distanceTo(s),o=new _r(r,s.sub(r).normalize()),l=i.kind==="object"?et(i.data.block):[];return![...this.index.query(Zn(this.player,4)).filter(d=>d.owner!==i.id&&!l.some(u=>["minX","maxX","minY","maxY","minZ","maxZ"].every(h=>Math.abs(u[h]-d[h])<1e-5))),...this.world.doors.filter(d=>i.id!=="door:"+d.id).map(d=>Rn(d)),...this.commands.blocks.filter(d=>i.id!==`build:${d.x},${d.y},${d.z}`&&Math.abs(d.x-this.player.x)<4&&Math.abs(d.z-this.player.z)<4).flatMap(et),...this.activity&&i.kind!=="vehicle"?[Ct(this.activity.car)]:[]].some(d=>Ba(o,d)<a-.2)})}sit(e){this.seated={entry:{...this.player},height:(e.y||0)+.4},Object.assign(this.player,{x:e.x,y:e.y||0,z:e.z,yaw:(e.rotation||0)*Math.PI/180,vy:0,grounded:!0}),this.flying=!1,this.vertical=0,this.controls.clear(),this.refreshModes(),this.notice("🪑 Sitting · move or tap Use to stand"),this.onEdit()}startPlay(e,t){var l;const i=t.block,r={...this.player},s=et(i),a=[...this.world.solids.filter(c=>{var d;return c.owner!=="prop:"+((d=t.prop)==null?void 0:d.id)&&!s.some(u=>["minX","maxX","minY","maxY","minZ","maxZ"].every(h=>Math.abs(u[h]-c[h])<1e-5))}),...this.world.doors.map(c=>Rn(c)),...this.commands.blocks.filter(c=>c.x!==i.x||c.y!==i.y||c.z!==i.z).flatMap(et)];for(let c=0;c<=24;c++)if(_n(Ma(e,i,Ga(e)*c/24),a)){this.notice("Leave a little space around the play equipment");return}let o=null;t.static||(o=ai(i),o.children.forEach(c=>c.userData.basePosition=c.position.clone()),this.view.scene.add(o),t.built&&this.chunks.update(i,!1),t.prop&&(t.prop.model.visible=!1)),this.playing={kind:e,block:{...i},entry:r,elapsed:0,model:o,built:!!t.built,original:(l=t.prop)==null?void 0:l.model},this.flying=!1,this.vertical=0,this.controls.clear(),Object.assign(this.player,Ma(e,i,0)),this.refreshModes(),this.notice("🛝 Playing · tap Use or move to finish"),this.onEdit()}animatePlay(){const e=this.playing;if(!(e!=null&&e.model))return;const t=Math.sin(e.elapsed*2);e.kind==="swing"&&e.model.children.slice(3).forEach(i=>{const r=i.userData.basePosition;i.position.z=r.z+t*.4}),e.kind==="seesaw"&&e.model.children.slice(1).forEach(i=>{const r=i.userData.basePosition;i.position.y=r.y+r.x*t*.17,i.rotation.z=t*.17}),e.kind==="rock"&&(e.model.rotation.x=t*.08)}endPlay(e=!0){var i,r,s;const t=this.playing;if(!t)return!0;if(e)try{Object.assign(this.player,tc(t.entry,[...this.obstacles(),...this.commands.blocks.flatMap(et)]))}catch(a){return this.notice(String(a)),!1}return(i=t.model)==null||i.traverse(a=>{a.isMesh&&a.material.dispose()}),(r=t.model)==null||r.removeFromParent(),t.built&&this.chunks.update(t.block,!0),t.original&&(t.original.visible=!0),this.playing=null,(s=this.controls)==null||s.clear(),this.refreshModes(),e&&this.onEdit(),!0}use(){var e;if(this.playing){this.endPlay();return}if(this.seated){this.stand();return}try{if((e=this.activity)!=null&&e.driving){this.notice(this.activity.use(this.player,[...this.obstacles(),...this.commands.blocks.flatMap(et)])||""),this.controls.clear(),this.refreshModes(),this.onEdit();return}const t=this.contextTarget();if(!t){this.notice("Walk closer to something to use");return}if(t.kind==="object"){const{block:i,prop:r}=t.data,s=Lt.get(i.type).interaction;if(ic.has(s)){this.startPlay(s,t.data);return}if(s==="seat"){this.sit({x:i.x+.5,y:i.y,z:i.z+.5,rotation:i.rotation});return}if(r){const a=new Sa(()=>[...this.world.solids.filter(l=>l.owner!=="prop:"+r.id),...this.world.doors.map(l=>Rn(l)),...this.commands.blocks.flatMap(et),...this.activity?[Ct(this.activity.car)]:[]],()=>this.player,()=>{});a.reset([i]);const o=a.toggle(a.blocks[0]);if(o){this.notice(o);return}r.block={...a.blocks[0]},ch(r),rc(this.world),this.index=new vn;for(const l of this.world.solids)this.index.add(l);this.onEdit(),this.notice("✓ Used")}else this.notice(this.commands.toggle(i)||"✓ Used")}else if(t.kind==="seat")this.sit(t.data);else if(t.kind==="agent"){const i=t.data;i.greetUntil=this.activity.time+2,i.model.rotation.y=Math.atan2(this.player.x-i.state.x,this.player.z-i.state.z),this.notice(i.animal?`♡ Hello, ${i.species}!`:"👋 Hello, neighbour!")}else if(t.kind==="vehicle")this.notice(this.activity.use(this.player,[...this.obstacles(),...this.commands.blocks.flatMap(et)])||""),this.flying=!1,this.vertical=0,this.controls.clear(),this.refreshModes(),this.onEdit();else{const i=t.data,r=Va(i,!i.targetOpen,this.player,[],[...this.world.solids,...this.commands.blocks.flatMap(et).map(s=>s.ramp?{...s,ramp:null}:s),...this.activity?[Ct(this.activity.car)]:[]],!0);this.notice(r.ok?"🚪 Door":r.message||"Clear the doorway"),this.onEdit()}}catch(t){this.notice(String(t))}}home(){var e,t;this.endPlay(!1),Object.assign(this.player,xs(((e=mn.find(i=>i.id===this.template))==null?void 0:e.spawn)||mn[0].spawn,[...this.obstacles(),...this.commands.blocks.flatMap(et)])),this.seated=null,this.flying=!1,this.activity&&(this.activity.driving=!1),this.vertical=0,this.refreshModes(),(t=this.controls)==null||t.clear(),this.cancel()}jump(){var e;if(this.playing){this.endPlay();return}if(this.seated){this.stand();return}!this.paused&&!this.flying&&!((e=this.activity)!=null&&e.driving)&&this.player.grounded&&(this.player.vy=6,this.player.grounded=!1)}key(e){e==="Space"&&this.jump(),e==="KeyE"&&this.use(),e==="KeyF"&&this.tap(innerWidth/2,innerHeight/2),e==="KeyR"&&(this.pending?(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview()):this.removeAt(innerWidth/2,innerHeight/2)),e==="Enter"&&this.confirm(),e==="KeyZ"&&this.endPlay()&&this.commands.undo(),e==="KeyY"&&this.endPlay()&&this.commands.redo(),e==="Escape"&&this.cancel()}ui(){const e=(t,i)=>document.querySelector("#"+t).onclick=i;e("cameraMode",()=>{this.cameraMode=this.cameraMode==="first"?"third":"first",this.updateCamera(),this.refreshModes(),this.onEdit()}),e("flyMode",()=>{var t;if(!(this.playing&&!this.endPlay())&&!(this.seated&&!this.stand())){if((t=this.activity)!=null&&t.driving){this.notice("Leave the car before flying");return}this.controls.clear(),this.vertical=0,this.flying=!this.flying,this.player.vy=0,document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),this.onEdit()}}),e("mapButton",()=>yg(this)),e("catalogueButton",()=>this.catalogue()),e("avatarButton",()=>vg(this)),e("controlsButton",()=>Zm(this));for(const[t,i]of[["flyUp",1],["flyDown",-1]]){const r=document.querySelector("#"+t);r.onpointerdown=s=>{s.preventDefault(),r.setPointerCapture(s.pointerId),this.vertical=i};for(const s of["pointerup","pointercancel","lostpointercapture"])r.addEventListener(s,()=>this.vertical=0)}addEventListener("blur",()=>this.vertical=0),e("moveObject",()=>{this.paused||(this.cancel(),this.pickingMove=!0,this.notice("Tap an object you built to move it"))}),document.addEventListener("visibilitychange",()=>this.vertical=0),e("home",()=>this.home()),e("jump",()=>this.jump()),e("use",()=>this.use()),e("undo",()=>this.endPlay()&&this.commands.undo()),e("redo",()=>this.endPlay()&&this.commands.redo()),e("cancel",()=>this.cancel()),e("rotate",()=>{this.pending&&(this.pending.rotation=((this.pending.rotation||0)+90)%360,this.showPreview())});for(const[t,i]of[["raise",1],["lower",-1]])e(t,()=>{this.pending&&(this.pending.y=Math.max(0,Math.min(23.75,Math.round((this.pending.y+i*.25)*100)/100)),this.showPreview())});e("confirm",()=>this.confirm()),e("doorMode",()=>{this.automatic=!this.automatic,document.querySelector("#doorMode").setAttribute("aria-pressed",String(this.automatic))}),e("guard",()=>{this.guard=!this.guard,document.querySelector("#guard").setAttribute("aria-pressed",String(this.guard))}),ps(this),document.querySelector("#palette").addEventListener("click",t=>{const i=t.target.closest("[data-item]");!i||this.paused||this.choose(i.dataset.item,!0)})}setAppearance(e){Yi.some(t=>t.id===e)||(e="explorer"),og(this.body),this.appearance=e,this.body=ms(e),this.view.scene.add(this.body.group),this.updateCamera()}catalogue(){jm(this)}choose(e,t=!1){this.selected=t&&this.selected===e?"hand":e,this.recent=[e,...this.recent.filter(i=>i!==e)].slice(0,8),this.cancel(),ps(this),this.refreshSelection(),this.onEdit()}planned(e){var r;if(this.moving)return[e];const t=$c(e);if(t.length>1||!((r=Lt.get(e.type))!=null&&r.cube))return t;const i=(e.rotation||0)*Math.PI/180;return Array.from({length:this.repeatCount},(s,a)=>({...e,x:e.x+a*Math.round(Math.cos(i)),z:e.z-a*Math.round(Math.sin(i))}))}placementReason(e){if(this.moving)return this.commands.reason(e,!0,this.moving);if(!As.some(i=>i.id===e.type)&&this.repeatCount===1)return this.commands.reason(e);if(Math.hypot(e.x+.5-this.player.x,e.y-this.player.y,e.z+.5-this.player.z)>6)return"Move a little closer";const t=new Sa(()=>this.obstacles(),()=>this.player,()=>{});return t.reset(this.commands.blocks),t.placeMany(this.planned(e),!1)}refreshSelection(){document.querySelectorAll("[data-item]").forEach(e=>e.setAttribute("aria-pressed",String(e.dataset.item===this.selected)))}refreshModes(){var e,t;this.refreshSelection(),document.querySelector("#flightControls").hidden=!this.flying,document.querySelector("#flyMode").setAttribute("aria-pressed",String(this.flying)),document.querySelector("#cameraMode").setAttribute("aria-pressed",String(this.cameraMode==="third")),document.querySelector("#use").textContent=this.playing?"🚶":this.seated?"🪑":(e=this.activity)!=null&&e.driving?"🚶":((t=this.contextTarget())==null?void 0:t.icon)||"✋"}refreshHistory(){const e=document.querySelector("#undo"),t=document.querySelector("#redo");e&&(e.disabled=!this.commands.canUndo),t&&(t.disabled=!this.commands.canRedo)}notice(e){const t=document.querySelector("#status");t.textContent=e,clearTimeout(this.noticeTimer),this.noticeTimer=window.setTimeout(()=>t.textContent="",5e3)}snapshot(){var e,t,i;return{avatar:this.appearance,lookSpeed:this.lookSpeed,leftHanded:this.leftHanded,favourites:this.favourites,recent:this.recent,hotbar:this.hotbar,camera:this.cameraMode,flying:this.flying,activity:(e=this.activity)==null?void 0:e.snapshot(),template:this.template,player:{...((t=this.playing)==null?void 0:t.entry)||((i=this.seated)==null?void 0:i.entry)||this.player},props:Sg(this.world),layout:this.world.layout||1,blocks:this.commands.blocks.map(r=>({...r})),doors:Object.fromEntries(this.world.doors.map(r=>[r.id,r.targetOpen])),selected:this.selected}}}async function Ng(n,e,t=()=>{}){if(!n.ready||n.blocked)throw Error("Save or export your world before updating");if(await n.save(),n.blocked)throw Error("Save failed; update is paused");t(),e.postMessage({type:"BW2_ACTIVATE"})}async function Fg(n){const e=document.createElement("output");if(e.id="offlineState",e.setAttribute("aria-live","polite"),document.querySelector(".brand").append(e),document.documentElement.dataset.standalone==="true"||location.protocol==="file:"){e.textContent="Local HTML · keep portable backups";return}if(!("serviceWorker"in navigator)){e.textContent="Use portable backups on this browser";return}e.textContent="◌ Preparing offline play…";try{const t=await navigator.serviceWorker.register("./sw.js",{scope:"./",updateViaCache:"none"}),i=document.createElement("button");i.id="updateReady",i.hidden=!0,i.textContent="↻ Update",i.setAttribute("aria-label","Save and update game"),document.body.append(i);let r=!1;navigator.serviceWorker.addEventListener("controllerchange",()=>{r&&location.reload()});const s=()=>{i.hidden=!t.waiting,i.disabled=!n.ready||n.blocked};document.addEventListener("bw2-save-status",s);const a=async()=>{try{const o=await fetch(new URL("release.json",t.scope)).then(c=>c.json()),l="bw2:development:"+encodeURIComponent(t.scope)+":"+o.build;await caches.has(l)&&await(await caches.open(l)).match(new URL("index.html",t.scope).href)?e.textContent="✓ Offline ready · "+String(o.build).slice(0,6):e.textContent="Open online once to prepare offline play"}catch{e.textContent="Offline preparation unavailable · keep backups"}};t.addEventListener("updatefound",()=>{const o=t.installing;o==null||o.addEventListener("statechange",()=>{o.state==="installed"&&setTimeout(s,0),o.state==="activated"&&a()})}),s(),i.onclick=()=>{(async()=>{i.disabled=!0;try{const o=t.waiting;if(!o){s();return}await Ng(n,o,()=>{r=!0})}catch(o){n.game.notice(String(o)),r=!1}finally{s()}})()},await navigator.serviceWorker.ready,await a()}catch{e.textContent="Offline preparation unavailable · keep backups"}}try{const n=new zg,e=new cg(n);new URLSearchParams(location.search).get("test")==="1"&&Object.assign(window,{bw2:{session:e,game:n,snapshot:()=>n.snapshot(),setPlayer:t=>Object.assign(n.player,t),simulate:(t,i)=>{const r=n.controls.movement;n.controls.movement=()=>t;for(let s=0;s<i;s+=1/60)n.update(1/60);n.controls.movement=r},add:t=>n.commands.place(t,!1)}}),Fg(e)}catch(n){const e=document.createElement("p");e.textContent=`Could not start: ${String(n)}`,document.querySelector("#app").append(e),console.error(n)}
