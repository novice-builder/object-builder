from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
import argparse,os
p=argparse.ArgumentParser();p.add_argument('--lan',action='store_true');p.add_argument('--port',type=int,default=8017);a=p.parse_args()
if not 1<=a.port<=65535:p.error('Port must be between 1 and 65535')
os.chdir(Path(__file__).resolve().parent)
print(f'Open http://localhost:{a.port}/adventures.html (Ctrl+C to stop)',flush=True)
ThreadingHTTPServer(('0.0.0.0' if a.lan else '127.0.0.1',a.port),SimpleHTTPRequestHandler).serve_forever()
